"""Compare SHA-256 hashes of the included simulator/analysis source with the hashes recorded at the protocol freeze.

    python3 source_code/verify_source_hashes.py
"""
import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "source_code" / "active_sensor_diagnosis"
FREEZE = ROOT / "evidence_package_2026-10-26" / "phase_robust_final" / "phase_robust_results" / "source_hashes_at_freeze.txt"

ok = bad = missing = 0
for line in FREEZE.read_text().splitlines():
    if not line.strip():
        continue
    h, rel = line.split()
    p = SRC / rel
    if not p.exists():
        print("MISSING ", rel); missing += 1; continue
    cur = hashlib.sha256(p.read_bytes()).hexdigest()
    if cur == h:
        ok += 1
    else:
        print("MISMATCH", rel); bad += 1
extra = sorted(p.name for p in (SRC / "src").glob("*.py") if f"src/{p.name}" not in FREEZE.read_text())
print(f"{ok} files match the freeze record, {bad} mismatch, {missing} missing")
if extra:
    print("files added after the freeze (not used by the phase-robust run):", ", ".join(extra))
sys.exit(1 if bad or missing else 0)
