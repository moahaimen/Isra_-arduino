"""Frozen reference-v2 validation for one dataset seed (see PROTOCOL_REFERENCE_V2_FROZEN.md).

Usage: python3 -m src.run_reference_v2 --dataset-seed 20261020
Writes reference_v2_results/seed_<S>/{predictions.npz, metrics.json, model_info.json, meta.json}.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
from sklearn.model_selection import GroupShuffleSplit

from .features import physics_features, raw_features
from .ref_features import N_COND, N_DESC, probe_scale, ref_descriptors
from .run_feasibility import _classifier, _rf_classifier
from .run_multiseed import (INITS, LAYER_ID, MODE_OFFSET, MODES, SEV_BOUNDS, SEV_CUT, TCN_CFG, _fit_tcn, _metrics)
from .simulate import FAULT_TO_LAYER, FAULTS, LAYERS, make_condition, make_fault, simulate_sample

ROOT = Path(__file__).resolve().parents[1]
GUARD = 0.30  # frozen settling guard
JITTER = (0.90, 1.10)  # frozen training reference-scale range (test shifts are outside it)
SHIFT_SCN = ("tolerance", "ref_m20", "ref_p20", "ref_m10", "ref_p10")
NOMINAL_TEST_SCN = ("nominal",) + SHIFT_SCN
ARMS = {
    # arm: (training variant, conditioning inputs, new descriptors, models)
    "A0": ("nominal", False, False, ["passive_mlp", "single_mlp", "afe_only_mlp", "adc_only_mlp", "two_point_mlp", "two_point_rf", "tcn_v2a"]),
    "A0j": ("jitter", False, False, ["single_mlp", "afe_only_mlp", "adc_only_mlp", "two_point_mlp", "two_point_rf"]),
    "A1": ("nominal", False, True, ["afe_only_mlp", "adc_only_mlp", "two_point_mlp", "two_point_rf", "tcn_v2a"]),
    "A1j": ("jitter", False, True, ["afe_only_mlp", "adc_only_mlp", "two_point_mlp", "two_point_rf"]),
    "A2": ("jitter", True, True, ["single_mlp", "afe_only_mlp", "adc_only_mlp", "two_point_mlp", "two_point_rf", "tcn_v2a"]),
}
MODEL_MODE = {"passive_mlp": "passive", "single_mlp": "single", "afe_only_mlp": "afe_only", "adc_only_mlp": "adc_only",
              "two_point_mlp": "two_point", "two_point_rf": "two_point", "tcn_v2a": "two_point"}


def _feat(rec, mode):
    raw, phys = raw_features(rec), physics_features(rec)
    desc, cond, wave = ref_descriptors(rec, GUARD)
    lt = np.zeros(38, dtype=np.float32)
    if mode in ("afe_only", "adc_only", "two_point"):
        lt[30], lt[31], lt[32], lt[33] = desc[0], desc[1], 1.0, 1.0
        lt[34], lt[35], lt[36], lt[37] = desc[3], desc[4], 1.0, 1.0
    return {"old": np.concatenate([raw, phys]).astype(np.float32), "desc": desc, "cond": cond, "wave": wave,
            "pk": np.float32(probe_scale(rec)), "lt": lt}


def _stack(rows):
    return {k: np.asarray([r[k] for r in rows], dtype=np.float32) for k in rows[0]}


def build(seed: int, n_cond: int = 350) -> dict:
    n_rows = n_cond * len(FAULTS)
    groups = np.repeat(np.arange(n_cond), len(FAULTS))
    dev_idx, test_idx = next(GroupShuffleSplit(1, test_size=0.25, random_state=seed + 1).split(np.zeros(n_rows), groups=groups))
    sub = next(GroupShuffleSplit(1, test_size=0.15, random_state=seed + 2).split(dev_idx, groups=groups[dev_idx]))
    train_idx, val_idx = dev_idx[sub[0]], dev_idx[sub[1]]
    test_conds = set(groups[test_idx].tolist())
    rng = np.random.default_rng(seed)
    shift_rng = np.random.default_rng(seed + 10_000)
    jit_rng = np.random.default_rng(seed + 20_000)
    nominal = {m: [] for m in MODES}
    jitter = {m: [] for m in MODES}
    shifted = {s: {m: [] for m in MODES} for s in SHIFT_SCN}
    y_fault, y_layer, severity, sev_u, k_used = [], [], [], [], []
    for cid in range(n_cond):
        cond = make_condition(rng)
        for class_id, name in enumerate(FAULTS):
            fault = make_fault(name, rng)
            sample_seed = int(rng.integers(0, 2**31 - 1))
            y_fault.append(class_id); y_layer.append(LAYER_ID[FAULT_TO_LAYER[name]]); severity.append(fault.severity)
            lo, hi = SEV_BOUNDS.get(name, (0.0, 1.0))
            sev_u.append(-1.0 if name == "healthy" else (fault.severity - lo) / (hi - lo))
            k = float(jit_rng.uniform(*JITTER))
            k_used.append(k)
            is_test = cid in test_conds
            if is_test:
                tol = dict(afe_gain_scale=1 + shift_rng.uniform(-0.05, 0.05), afe_tau_scale=1 + shift_rng.uniform(-0.10, 0.10),
                           adc_gain_scale=1 + shift_rng.uniform(-0.02, 0.02), adc_offset_extra=shift_rng.uniform(-0.010, 0.010),
                           sensor_base_scale=1 + shift_rng.uniform(-0.05, 0.05))
                scen_kw = {"tolerance": tol, "ref_m20": {"ref_scale": 0.8}, "ref_p20": {"ref_scale": 1.2},
                           "ref_m10": {"ref_scale": 0.9}, "ref_p10": {"ref_scale": 1.1}}
            for mode, pm in MODES.items():
                seed_m = sample_seed + MODE_OFFSET[mode]
                rec = simulate_sample(cond, fault, active=(mode != "passive"), seed=seed_m, probe_mode=pm)
                f0 = _feat(rec, mode)
                nominal[mode].append(f0)
                if not is_test:
                    if mode == "passive":
                        jitter[mode].append(f0)
                    else:
                        jitter[mode].append(_feat(simulate_sample(cond, fault, active=True, seed=seed_m, probe_mode=pm, ref_scale=k), mode))
                else:
                    jitter[mode].append(f0)  # unused placeholder for test rows
                    for scn, kw in scen_kw.items():
                        if mode == "passive" and scn != "tolerance":
                            shifted[scn][mode].append(f0)
                        else:
                            shifted[scn][mode].append(_feat(simulate_sample(cond, fault, active=(mode != "passive"), seed=seed_m, probe_mode=pm, **kw), mode))
    return {
        "groups": groups, "train": train_idx, "val": val_idx, "test": test_idx,
        "y_fault": np.asarray(y_fault), "y_layer": np.asarray(y_layer), "severity": np.asarray(severity, dtype=np.float32),
        "sev_u": np.asarray(sev_u), "k_used": np.asarray(k_used),
        "nominal": {m: _stack(v) for m, v in nominal.items()}, "jitter": {m: _stack(v) for m, v in jitter.items()},
        "shifted": {s: {m: _stack(v) for m, v in shifted[s].items()} for s in shifted},
    }


def _x(arm, model, feats):
    """sklearn input matrix for a feature dict (arrays) under an arm."""
    _, cond, new, _ = ARMS[arm]
    mode = MODEL_MODE[model]
    if mode == "passive" or not new and mode != "single":
        return feats["old"]
    if mode == "single":
        return np.hstack([feats["old"], feats["pk"][:, None]]) if cond else feats["old"]
    if not new:
        return feats["old"]
    return np.hstack([feats["desc"], feats["cond"]]) if cond else feats["desc"]


def _tcn_inputs(arm, feats):
    _, cond, new, _ = ARMS[arm]
    if not new:
        return feats["old"][:, :96], feats["old"][:, 96:], feats["old"][:, 96:]
    p = np.hstack([feats["desc"], feats["cond"]]) if cond else feats["desc"]
    return feats["wave"], p, feats["lt"]


def run_regime(regime: str, data: dict) -> tuple[dict, dict]:
    g = data["groups"]
    train, val, test = data["train"], data["val"], data["test"]
    yl, yf, sv, u = data["y_layer"], data["y_fault"], data["severity"], data["sev_u"]
    if regime == "severity":
        keep = lambda idx: idx[u[idx] < SEV_CUT]
        train, val = keep(train), keep(val)
        eval_rows = {"severity": test[(u[test] >= SEV_CUT) | ((u[test] < 0) & (g[test] % 3 == 0))]}
    else:
        eval_rows = {"nominal": test}
    preds, info = {}, {}
    for arm, (variant, cond, new, models) in ARMS.items():
        for model in models:
            mode = MODEL_MODE[model]
            tr_feats = {k: v[:] for k, v in data[variant][mode].items()}
            scen_feats = {}
            for scn, rows in eval_rows.items():
                scen_feats[scn] = {k: v[rows] for k, v in data["nominal"][mode].items()}
            if regime == "nominal":
                for scn in SHIFT_SCN:
                    scen_feats[scn] = data["shifted"][scn][mode]
            for init in INITS:
                t0 = time.time()
                key = f"{model}@{arm}"
                if model == "tcn_v2a":
                    X, P, L = _tcn_inputs(arm, tr_feats)
                    te = {}
                    for scn, f in scen_feats.items():
                        w, p, _ = _tcn_inputs(arm, f)
                        te[scn] = (w, p)
                    out, meta = _fit_tcn(TCN_CFG["tcn_v2a"], X, P, L, yl, yf, sv, train, val, te, init)
                    for scn, (pl, pf) in out.items():
                        preds[f"{scn}|{key}|{init}|layer"] = pl.astype(np.int8)
                        preds[f"{scn}|{key}|{init}|fault"] = pf.astype(np.int8)
                else:
                    Xtr = _x(arm, model, tr_feats)[train]
                    meta = {"train_seconds": 0.0, "infer_ms_per_sample": None}
                    for target, y in (("layer", yl), ("fault", yf)):
                        est = _classifier(init) if model.endswith("mlp") else _rf_classifier(init)
                        t1 = time.time(); est.fit(Xtr, y[train]); meta["train_seconds"] += time.time() - t1
                        for scn, f in scen_feats.items():
                            t2 = time.time(); pr = est.predict(_x(arm, model, f))
                            if scn in ("nominal", "severity") and target == "fault":
                                meta["infer_ms_per_sample"] = (time.time() - t2) / len(pr) * 1000
                            preds[f"{scn}|{key}|{init}|{target}"] = pr.astype(np.int8)
                info[f"{regime}|{key}|{init}"] = meta
                print(f"[{regime}] {key} init={init} {time.time() - t0:.0f}s", flush=True)
    return preds, {"info": info, "eval_rows": {k: v.tolist() for k, v in eval_rows.items()}, "n_train": int(len(train)), "n_val": int(len(val))}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset-seed", type=int, required=True)
    ap.add_argument("--threads", type=int, default=2)
    ap.add_argument("--n-cond", type=int, default=350)
    ap.add_argument("--out-dir", type=Path, default=None)
    args = ap.parse_args()
    import torch
    torch.set_num_threads(args.threads)
    out = args.out_dir or ROOT / "reference_v2_results" / f"seed_{args.dataset_seed}"
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    data = build(args.dataset_seed, args.n_cond)
    g = data["groups"]
    meta = {"dataset_seed": args.dataset_seed, "split_random_state": args.dataset_seed + 1, "val_random_state": args.dataset_seed + 2,
            "guard": GUARD, "jitter_range": list(JITTER), "conditions_total": int(len(set(g))),
            "train_conditions": int(len(set(g[data["train"]]))), "val_conditions": int(len(set(g[data["val"]]))),
            "test_conditions": int(len(set(g[data["test"]]))), "build_seconds": round(time.time() - t0, 1),
            "overlap": int(len(set(g[data["train"]]) & set(g[data["test"]])) + len(set(g[data["val"]]) & set(g[data["test"]]))
                           + len(set(g[data["train"]]) & set(g[data["val"]])))}
    assert meta["overlap"] == 0
    print(meta, flush=True)
    p1, i1 = run_regime("nominal", data)
    p2, i2 = run_regime("severity", data)
    preds = {**p1, **p2}
    info = {**i1["info"], **i2["info"]}
    test = data["test"]
    sev_rows = np.asarray(i2["eval_rows"]["severity"])
    rows_by_scn = {s: test for s in NOMINAL_TEST_SCN}
    rows_by_scn["severity"] = sev_rows
    meta.update(severity_train_rows=i2["n_train"], severity_val_rows=i2["n_val"], severity_test_rows=int(len(sev_rows)),
                severity_test_class_counts=np.bincount(data["y_fault"][sev_rows], minlength=9).tolist())
    arrays = {}
    for scn, rows in rows_by_scn.items():
        arrays[f"y_layer|{scn}"] = data["y_layer"][rows].astype(np.int8)
        arrays[f"y_fault|{scn}"] = data["y_fault"][rows].astype(np.int8)
        arrays[f"cond|{scn}"] = g[rows].astype(np.int32)
    arrays.update(preds)
    np.savez_compressed(out / "predictions.npz", **arrays)
    metrics = {}
    for key, pred in preds.items():
        scn, name, init, target = key.split("|")
        n, lab = (4, LAYERS) if target == "layer" else (9, FAULTS)
        metrics[key] = _metrics(arrays[f"y_{target}|{scn}"], pred, n, lab)
    (out / "metrics.json").write_text(json.dumps(metrics, indent=1), encoding="utf-8")
    (out / "model_info.json").write_text(json.dumps(info, indent=1), encoding="utf-8")
    meta["total_seconds"] = round(time.time() - t0, 1)
    (out / "meta.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")
    print("DONE", meta, flush=True)


if __name__ == "__main__":
    main()
