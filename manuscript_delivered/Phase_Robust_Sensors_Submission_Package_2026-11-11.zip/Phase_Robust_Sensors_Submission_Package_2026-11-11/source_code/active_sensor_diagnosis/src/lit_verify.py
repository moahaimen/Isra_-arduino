"""Verify selected references against Crossref (metadata) and doi.org (resolution); fetch OpenAlex abstracts for screening.
Writes paper_package/literature/verified_raw.json. Metadata are copied from Crossref, never typed by hand."""
import difflib, json, time
from pathlib import Path
import requests

OUT = Path(__file__).resolve().parents[1] / "paper_package" / "literature"
SEL = [
 ("T1", "10.3390/mi12010040"), ("T1", "10.1109/jsen.2016.2636861"), ("T1", "10.1109/jsen.2007.897957"), ("T1", "10.3390/mi9090444"), ("T1", "10.3390/mi12091115"),
 ("T1", "10.1109/tcad.2012.2218602"), ("T1", "10.1109/tcsi.2017.2767199"), ("T1", "10.6028/jres.116.025"), ("T1", "10.3390/chips1020008"), ("T1", "10.1109/19.650794"),
 ("T1", "10.1109/imtc.2003.1207897"),
 ("T2", "10.1109/tim.2013.2272867"), ("T2", "10.1093/ietisy/e91-d.8.2134"), ("T2", "10.1109/tim.2007.908343"), ("T2", "10.1007/s10836-005-6357-5"), ("T2", "10.1145/944027.944035"),
 ("T2", "10.1109/mim.2019.8917897"), ("T2", "10.1109/81.940182"), ("T2", "10.1109/4.991388"), ("T2", "10.1155/jece/8824886"), ("T2", "10.1109/tvlsi.2014.2321761"),
 ("T3", "10.1109/tim.2012.2205509"), ("T3", "10.1049/cce:20020508"), ("T3", "10.1016/j.measurement.2024.116025"),
 ("T4", "10.1109/jsen.2001.954835"), ("T4", "10.1109/tim.2020.3031208"),
 ("T5", "10.1088/0266-5611/19/2/201"), ("T5", "10.1016/j.measurement.2023.113392"),
 ("T6", "10.1109/82.823545"), ("T6", "10.1109/tim.2002.1017726"), ("T6", "10.1109/tim.2009.2025068"), ("T6", "10.1109/access.2020.2968744"), ("T6", "10.1109/tii.2017.2690940"),
 ("T6", "10.1109/tcsi.2021.3076282"), ("T6", "10.1016/j.vlsi.2025.102631"), ("T6", "10.1109/tim.2025.3588964"), ("T6", "10.1007/s10836-025-06190-6"), ("T6", "10.1016/j.microrel.2008.12.002"),
 ("T6", "10.3390/s23031305"),
 ("M", "10.1111/j.1467-9868.2007.00593.x"), ("M", "10.1017/cbo9780511802843"), ("M", "10.48550/arxiv.1412.6980"),
]


def inv(ix):
    if not ix:
        return ""
    pos = {i: w for w, idx in ix.items() for i in idx}
    return " ".join(pos[i] for i in sorted(pos))


def main():
    res = []
    for theme, doi in SEL:
        rec = {"theme": theme, "doi": doi}
        try:
            cr = requests.get(f"https://api.crossref.org/works/{doi}", timeout=60)
            rec["crossref_status"] = cr.status_code
            if cr.ok:
                m = cr.json()["message"]
                rec.update(title=(m.get("title") or [""])[0], container=(m.get("container-title") or [""])[0], short_container=(m.get("short-container-title") or [""])[0],
                           volume=m.get("volume"), issue=m.get("issue"), page=m.get("page"), article_number=m.get("article-number"), type=m.get("type"), publisher=m.get("publisher"),
                           year=(m.get("published-print") or m.get("published-online") or m.get("issued") or {}).get("date-parts", [[None]])[0][0],
                           issued=(m.get("issued") or {}).get("date-parts", [[None]])[0],
                           authors=[{"family": a.get("family"), "given": a.get("given"), "name": a.get("name")} for a in m.get("author", [])], crossref_doi=m.get("DOI"),
                           isbn=m.get("ISBN"), edition=m.get("edition-number"))
        except Exception as e:
            rec["crossref_error"] = str(e)
        try:
            h = requests.head(f"https://doi.org/{doi}", allow_redirects=False, timeout=60)
            rec["doi_org_status"] = h.status_code; rec["doi_org_location"] = h.headers.get("Location")
        except Exception as e:
            rec["doi_org_error"] = str(e)
        try:
            oa = requests.get(f"https://api.openalex.org/works/doi:{doi}", timeout=60)
            if oa.ok:
                w = oa.json(); rec["openalex_title"] = w.get("title"); rec["abstract"] = inv(w.get("abstract_inverted_index"))
                rec["title_match_ratio"] = round(difflib.SequenceMatcher(None, (w.get("title") or "").lower(), (rec.get("title") or "").lower()).ratio(), 3)
        except Exception as e:
            rec["openalex_error"] = str(e)
        res.append(rec)
        print(f"{doi:40s} CR={rec.get('crossref_status')} DOI={rec.get('doi_org_status')} match={rec.get('title_match_ratio')} | {str(rec.get('title'))[:70]} | {rec.get('year')}")
        time.sleep(0.3)
    (OUT / "verified_raw.json").write_text(json.dumps(res, indent=1))


if __name__ == "__main__":
    main()
