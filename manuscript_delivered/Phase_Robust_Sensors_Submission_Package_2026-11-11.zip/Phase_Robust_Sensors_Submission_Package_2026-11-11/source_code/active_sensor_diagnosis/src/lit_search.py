"""Systematic literature search via OpenAlex (open index covering IEEE, Elsevier/ScienceDirect, Springer, MDPI, ...).
Writes paper_package/literature/search_log.json and candidates.csv. Nothing here is invented: all metadata come from the API."""
import json, time
from pathlib import Path
import requests
import pandas as pd

OUT = Path(__file__).resolve().parents[1] / "paper_package" / "literature"
MAILTO = "research-audit@example.org"
QUERIES = {
    "T1 active self-test of sensor interfaces": ['"built-in self-test" sensor interface', '"self-test" sensor readout circuit', 'MEMS sensor "self-test" electrostatic actuation', '"on-line test" sensor interface circuit'],
    "T2 AFE and ADC fault diagnosis": ['"analog front-end" fault diagnosis', 'ADC "built-in self-test"', '"analog-to-digital converter" fault detection test', 'mixed-signal circuit fault diagnosis'],
    "T3 mixed-signal sensor fault isolation": ['sensor fault isolation signal conditioning', '"self-validating sensor"', 'sensor fault detection isolation "analog front end"', 'sensor and actuator fault isolation electronic measurement chain'],
    "T4 reference monitoring / drift": ['voltage reference drift monitoring ADC', 'ADC self-calibration reference voltage', 'two-point calibration gain offset ADC built-in', 'reference voltage aging drift compensation measurement'],
    "T5 phase-robust transient descriptors": ['step response estimation sampling phase', 'time constant estimation sampled exponential', 'sub-sample timing estimation step response', 'settling time measurement ADC sampling phase'],
    "T6 neural-network electronic fault diagnosis": ['analog circuit fault diagnosis neural network', 'analog circuit fault diagnosis deep learning', 'convolutional neural network analog circuit fault', 'mixed-signal circuit fault classification machine learning'],
}
FILTER = "publication_year:>1999,type:article|review"


def inv(abstract_index):
    if not abstract_index:
        return ""
    pos = {}
    for w, idx in abstract_index.items():
        for i in idx:
            pos[i] = w
    return " ".join(pos[i] for i in sorted(pos))


def main():
    log, rows = {"engine": "OpenAlex /works?search=", "filter": FILTER, "date": time.strftime("%Y-%m-%d"), "queries": []}, []
    for theme, qs in QUERIES.items():
        for q in qs:
            r = requests.get("https://api.openalex.org/works", params={"search": q, "filter": FILTER, "per-page": 25}, timeout=60)
            r.raise_for_status()
            js = r.json()
            log["queries"].append({"theme": theme, "query": q, "total_hits": js["meta"]["count"], "retrieved": len(js["results"])})
            for w in js["results"]:
                src = (w.get("primary_location") or {}).get("source") or {}
                rows.append({"theme": theme, "query": q, "openalex_id": w["id"], "doi": (w.get("doi") or "").replace("https://doi.org/", ""), "title": w.get("title"),
                             "year": w.get("publication_year"), "venue": src.get("display_name"), "publisher": src.get("host_organization_name"),
                             "type": w.get("type"), "cited_by": w.get("cited_by_count"), "authors": "; ".join(a["author"]["display_name"] for a in w.get("authorships", [])[:8]),
                             "abstract": inv(w.get("abstract_inverted_index"))[:3000]})
            time.sleep(0.25)
    df = pd.DataFrame(rows)
    df["n_queries"] = df.groupby("openalex_id")["query"].transform("count")
    df = df.sort_values(["theme", "cited_by"], ascending=[True, False])
    df.to_csv(OUT / "candidates_raw.csv", index=False)
    uniq = df.drop_duplicates("openalex_id")
    uniq.to_csv(OUT / "candidates.csv", index=False)
    log["n_records"] = len(df); log["n_unique"] = len(uniq)
    (OUT / "search_log.json").write_text(json.dumps(log, indent=1))
    print(len(df), "records,", len(uniq), "unique")
    for q in log["queries"]:
        print(f"{q['total_hits']:>9} | {q['theme'][:30]:30s} | {q['query']}")


if __name__ == "__main__":
    main()
