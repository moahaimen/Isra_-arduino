"""Behavioral simulation of a sensor--AFE--ADC measurement chain.

The model is intentionally transparent. It is a first feasibility gate before
replacing the behavioral blocks with an ngspice netlist. The diagnostic probe is
injected after the physical sensor and before the AFE, which creates a useful
source-isolation signal: sensor faults affect the passive signal, while AFE/ADC
faults also affect the known probe response.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Tuple

import numpy as np


FAULTS = (
    "healthy",
    "sensor_bias",
    "sensor_gain",
    "sensor_noise",
    "afe_offset",
    "afe_bandwidth",
    "adc_offset",
    "adc_gain",
    "adc_clipping",
)

LAYERS = ("healthy", "sensor", "afe", "adc")
FAULT_TO_LAYER = {
    "healthy": "healthy",
    "sensor_bias": "sensor",
    "sensor_gain": "sensor",
    "sensor_noise": "sensor",
    "afe_offset": "afe",
    "afe_bandwidth": "afe",
    "adc_offset": "adc",
    "adc_gain": "adc",
    "adc_clipping": "adc",
}


@dataclass(frozen=True)
class OperatingCondition:
    """Operating variation held out by group during evaluation."""

    base: float
    amplitude: float
    frequency_hz: float
    phase: float
    sensor_noise: float
    nominal_gain: float
    nominal_tau_s: float
    adc_vref: float


@dataclass(frozen=True)
class FaultInstance:
    name: str
    severity: float
    signed: float


def make_condition(rng: np.random.Generator) -> OperatingCondition:
    return OperatingCondition(
        base=float(rng.uniform(0.78, 1.18)),
        amplitude=float(rng.uniform(0.045, 0.18)),
        frequency_hz=float(rng.uniform(0.45, 3.0)),
        phase=float(rng.uniform(-np.pi, np.pi)),
        sensor_noise=float(rng.uniform(0.002, 0.014)),
        nominal_gain=float(rng.uniform(1.65, 2.05)),
        nominal_tau_s=float(rng.uniform(0.008, 0.016)),
        adc_vref=3.3,
    )


def make_fault(name: str, rng: np.random.Generator) -> FaultInstance:
    if name == "healthy":
        return FaultInstance(name, 0.0, 0.0)
    if name in {"sensor_bias", "afe_offset", "adc_offset"}:
        severity = float(rng.uniform(0.06, 0.24))
        return FaultInstance(name, severity, float(rng.choice([-1.0, 1.0])))
    if name in {"sensor_gain", "adc_gain"}:
        severity = float(rng.uniform(0.06, 0.28))
        return FaultInstance(name, severity, float(rng.choice([-1.0, 1.0])))
    if name == "sensor_noise":
        return FaultInstance(name, float(rng.uniform(0.025, 0.095)), 1.0)
    if name == "afe_bandwidth":
        return FaultInstance(name, float(rng.uniform(1.8, 4.5)), 1.0)
    if name == "adc_clipping":
        return FaultInstance(name, float(rng.uniform(0.72, 0.93)), 1.0)
    raise ValueError(f"Unknown fault: {name}")


def _first_order_lowpass(x: np.ndarray, tau_s: float, fs_hz: float) -> np.ndarray:
    alpha = 1.0 - np.exp(-1.0 / (fs_hz * max(tau_s, 1e-7)))
    y = np.empty_like(x)
    y[0] = x[0]
    for i in range(1, len(x)):
        y[i] = y[i - 1] + alpha * (x[i] - y[i - 1])
    return y


def _lowpass_fractional_step(
    x: np.ndarray, tau_s: float, fs_hz: float, edges: np.ndarray, phase: float
) -> np.ndarray:
    """First-order low-pass (exact discretisation) where the input steps at `phase`*T into the interval ending at
    each sample index in `edges`; elsewhere identical to ``_first_order_lowpass``."""
    T = 1.0 / fs_hz
    tau = max(tau_s, 1e-7)
    a_full = np.exp(-T / tau)
    a_pre, a_post = np.exp(-phase * T / tau), np.exp(-(1.0 - phase) * T / tau)
    edge_set = set(int(e) for e in edges)
    y = np.empty_like(x)
    y[0] = x[0]
    for i in range(1, len(x)):
        if i in edge_set:
            y_mid = x[i - 1] + (y[i - 1] - x[i - 1]) * a_pre
            y[i] = x[i] + (y_mid - x[i]) * a_post
        else:
            y[i] = x[i] + (y[i - 1] - x[i]) * a_full
    return y


def _base_signal(
    condition: OperatingCondition, n_samples: int, fs_hz: float, rng: np.random.Generator
) -> np.ndarray:
    t = np.arange(n_samples, dtype=float) / fs_hz
    slow = 0.025 * np.sin(2 * np.pi * 0.12 * t + 0.4 * condition.phase)
    carrier = condition.amplitude * np.sin(
        2 * np.pi * condition.frequency_hz * t + condition.phase
    )
    drift = rng.normal(0.0, 0.0015, size=n_samples).cumsum()
    drift -= drift.mean()
    signal = condition.base + carrier + slow + drift
    return signal


def _probe_signal(
    n_samples: int, fs_hz: float, amplitude: float = 0.075, start_s: float = 0.180
) -> Tuple[np.ndarray, int, int]:
    """Return a bounded reference-path pulse and its active window."""
    probe = np.zeros(n_samples, dtype=float)
    start = int(round(start_s * fs_hz))
    width = int(round(0.035 * fs_hz))
    end = min(start + width, n_samples)
    # A short bipolar pulse makes the response less confounded with baseline.
    half = max(1, (end - start) // 2)
    probe[start : start + half] = amplitude
    probe[start + half : end] = -amplitude
    return probe, start, end


def _adc_reference(n_samples: int, fs_hz: float) -> Tuple[np.ndarray, int, int]:
    """Known two-level ADC-input reference used by the test multiplexer."""
    reference = np.zeros(n_samples, dtype=float)
    start = int(round(0.340 * fs_hz))
    width = int(round(0.120 * fs_hz))
    end = min(start + width, n_samples)
    half = max(1, (end - start) // 2)
    reference[start : start + half] = 1.15
    reference[start + half : end] = 1.75
    return reference, start, end


def _afe_reference(n_samples: int, fs_hz: float) -> Tuple[np.ndarray, int, int]:
    """Known two-level reference that temporarily replaces the sensor at AFE input."""
    reference = np.zeros(n_samples, dtype=float)
    start = int(round(0.140 * fs_hz))
    width = int(round(0.120 * fs_hz))
    end = min(start + width, n_samples)
    half = max(1, (end - start) // 2)
    reference[start : start + half] = 0.90
    reference[start + half : end] = 1.30
    return reference, start, end


def simulate_sample(
    condition: OperatingCondition,
    fault: FaultInstance,
    *,
    active: bool,
    seed: int,
    probe_mode: str = "single",
    n_samples: int = 512,
    fs_hz: float = 1000.0,
    ref_scale: float = 1.0,
    afe_gain_scale: float = 1.0,
    afe_tau_scale: float = 1.0,
    adc_gain_scale: float = 1.0,
    adc_offset_extra: float = 0.0,
    sensor_base_scale: float = 1.0,
    ref_phase: float = 0.0,
) -> Dict[str, np.ndarray | float | str | int | bool]:
    """Simulate one sample and return the measured ADC waveform plus metadata.

    The trailing scale/extra arguments are test-time shifts (component
    tolerance, reference amplitude); their defaults leave the nominal
    simulation bit-identical.  They consume no random numbers.
    """
    rng = np.random.default_rng(seed)
    physical = _base_signal(condition, n_samples, fs_hz, rng)
    if sensor_base_scale != 1.0:
        physical = physical + (sensor_base_scale - 1.0) * condition.base
    if probe_mode not in {"passive", "single", "afe_only", "adc_only", "two_point"}:
        raise ValueError(f"Unknown probe mode: {probe_mode}")
    probe_afe, probe_start, probe_end = _probe_signal(n_samples, fs_hz, start_s=0.180)
    probe_adc, probe2_start, probe2_end = _probe_signal(n_samples, fs_hz, start_s=0.300)
    afe_reference, afe_ref_start, afe_ref_end = _afe_reference(n_samples, fs_hz)
    adc_reference, adc_ref_start, adc_ref_end = _adc_reference(n_samples, fs_hz)
    if probe_mode == "passive":
        probe_afe[:] = 0.0
        probe_adc[:] = 0.0
        afe_reference[:] = 0.0
        adc_reference[:] = 0.0
    elif probe_mode == "single":
        probe_adc[:] = 0.0
        afe_reference[:] = 0.0
        adc_reference[:] = 0.0
    elif probe_mode == "afe_only":
        probe_afe[:] = 0.0
        probe_adc[:] = 0.0
        adc_reference[:] = 0.0
    elif probe_mode == "adc_only":
        probe_afe[:] = 0.0
        probe_adc[:] = 0.0
        afe_reference[:] = 0.0
    elif probe_mode == "two_point":
        # Two-point mode uses absolute reference levels rather than additive
        # pulses, so the AFE path can be calibrated independently.
        probe_afe[:] = 0.0
        probe_adc[:] = 0.0

    if ref_scale != 1.0:
        probe_afe, probe_adc = probe_afe * ref_scale, probe_adc * ref_scale
        afe_reference, adc_reference = afe_reference * ref_scale, adc_reference * ref_scale

    # Physical sensor fault.
    sensor_out = physical.copy()
    if fault.name == "sensor_bias":
        sensor_out += fault.signed * fault.severity
    elif fault.name == "sensor_gain":
        sensor_out *= 1.0 + fault.signed * fault.severity
    elif fault.name == "sensor_noise":
        sensor_out += rng.normal(0.0, fault.severity, size=n_samples)

    # The active probe enters through a reference/test switch after the sensor.
    # This is the electronic source-isolation mechanism under test.
    afe_in = sensor_out + probe_afe
    if probe_mode in {"two_point", "afe_only"}:
        afe_mask = afe_reference > 0.0
        afe_in[afe_mask] = afe_reference[afe_mask]
    afe_gain = condition.nominal_gain * afe_gain_scale
    afe_offset = 0.0
    tau_s = condition.nominal_tau_s * afe_tau_scale
    if fault.name == "afe_offset":
        afe_offset = fault.signed * fault.severity
    elif fault.name == "afe_bandwidth":
        tau_s *= fault.severity

    if ref_phase != 0.0 and probe_mode in {"two_point", "afe_only"}:
        # Reference edges fall a fraction `ref_phase` of one sample period after the previous sample instead of
        # exactly on it (ref_phase = 0 is the zero-order-hold convention used everywhere else).
        edges = np.flatnonzero(afe_reference[1:] != afe_reference[:-1]) + 1
        afe_out = afe_gain * _lowpass_fractional_step(afe_in, tau_s, fs_hz, edges, ref_phase) + afe_offset
    else:
        afe_out = afe_gain * _first_order_lowpass(afe_in, tau_s, fs_hz) + afe_offset

    adc_gain = 1.0 * adc_gain_scale
    adc_offset = 0.0 + adc_offset_extra
    clip_low, clip_high = 0.0, condition.adc_vref
    if fault.name == "adc_offset":
        adc_offset = fault.signed * fault.severity + adc_offset_extra
    elif fault.name == "adc_gain":
        adc_gain = (1.0 + fault.signed * fault.severity) * adc_gain_scale
    elif fault.name == "adc_clipping":
        clip_high = condition.adc_vref * fault.severity

    # The second probe is injected after the AFE and immediately before the
    # ADC. It makes ADC-only gain/offset faults identifiable separately from
    # AFE gain/offset faults.
    adc_input = afe_out.copy()
    if probe_mode in {"two_point", "adc_only"}:
        adc_mask = adc_reference > 0.0
        adc_input[adc_mask] = adc_reference[adc_mask]
    adc_analog = adc_gain * adc_input + adc_offset + probe_adc
    adc_analog += rng.normal(0.0, 0.0025, size=n_samples)
    adc_clipped = np.clip(adc_analog, clip_low, clip_high)
    adc_codes = np.round(adc_clipped / condition.adc_vref * 4095.0)
    measured = adc_codes / 4095.0 * condition.adc_vref

    return {
        "waveform": measured.astype(np.float32),
        "probe": (probe_afe + probe_adc).astype(np.float32),
        "probe_start": probe_start,
        "probe_end": probe_end,
        "probe_windows": (
            ([(afe_ref_start, afe_ref_end), (adc_ref_start, adc_ref_end)] if probe_mode == "two_point" else
             [(afe_ref_start, afe_ref_end)] if probe_mode == "afe_only" else
             [(adc_ref_start, adc_ref_end)] if probe_mode == "adc_only" else
             [(probe_start, probe_end)])
        ),
        "adc_reference": adc_reference.astype(np.float32),
        "adc_ref_start": adc_ref_start,
        "adc_ref_end": adc_ref_end,
        "afe_reference": afe_reference.astype(np.float32),
        "afe_ref_start": afe_ref_start,
        "afe_ref_end": afe_ref_end,
        "fault": fault.name,
        "layer": FAULT_TO_LAYER[fault.name],
        "severity": float(fault.severity),
        "active": bool(active),
        "probe_mode": probe_mode,
        "seed": int(seed),
    }


def build_paired_dataset(
    samples_per_class: int = 350, seed: int = 20261014
) -> Dict[str, object]:
    """Build paired passive/active samples with condition-group IDs.

    Each operating condition contributes one example of every fault class. The
    same condition and fault instance are simulated in passive and active modes,
    making the mode comparison paired while GroupShuffleSplit can still hold
    complete operating conditions out of the test set.
    """
    rng = np.random.default_rng(seed)
    records = {
        "passive": [],
        "active": [],
        "active_afe_only": [],
        "active_adc_only": [],
        "active_two_point": [],
    }
    groups = []
    for condition_id in range(samples_per_class):
        condition = make_condition(rng)
        for class_id, name in enumerate(FAULTS):
            fault = make_fault(name, rng)
            sample_seed = int(rng.integers(0, 2**31 - 1))
            for mode in ("passive", "active", "active_afe_only", "active_adc_only", "active_two_point"):
                probe_mode = {
                    "passive": "passive",
                    "active": "single",
                    "active_afe_only": "afe_only",
                    "active_adc_only": "adc_only",
                    "active_two_point": "two_point",
                }[mode]
                record = simulate_sample(
                    condition,
                    fault,
                    active=(mode != "passive"),
                    seed=sample_seed + {
                        "passive": 0,
                        "active": 1,
                        "active_afe_only": 2,
                        "active_adc_only": 3,
                        "active_two_point": 4,
                    }[mode],
                    probe_mode=probe_mode,
                )
                record["condition_id"] = condition_id
                record["class_id"] = class_id
                records[mode].append(record)
                groups.append(condition_id)
    return {"records": records, "faults": FAULTS, "layers": LAYERS, "seed": seed}


def iter_records(dataset: Dict[str, object], mode: str) -> Iterable[Dict[str, object]]:
    return dataset["records"][mode]
