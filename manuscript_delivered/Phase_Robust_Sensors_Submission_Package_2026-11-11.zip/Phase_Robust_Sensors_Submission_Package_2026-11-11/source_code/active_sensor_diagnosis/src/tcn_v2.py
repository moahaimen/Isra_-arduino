"""Revised physics-guided TCN (v2) for a controlled comparison with v1.

``src.tcn_model`` is left untouched.  This module adds only the ingredients
under test, each switchable so they can be ablated one at a time:

* ``pool="bins"``  - keep *when* things happen: adaptive average pooling to a
  fixed number of time bins that are flattened, instead of a global mean.
* ``extra_channels`` - the known reference schedules (AFE / ADC reference
  waveforms) are fed as additional input channels.  They are fixed by the
  test-mux design, not derived from the fault label.
"""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F
from torch import Tensor, nn

from .tcn_model import CausalConv1d, TCNBlock


@dataclass(frozen=True)
class TCNv2Config:
    waveform_channels: int = 1
    physics_dim: int = 38
    hidden: int = 24
    kernel_size: int = 5
    blocks: int = 3
    layer_classes: int = 4
    fault_classes: int = 9
    pool: str = "mean"  # "mean" (v1 behaviour) or "bins"
    bins: int = 16


class TCNv2(nn.Module):
    def __init__(self, config: TCNv2Config) -> None:
        super().__init__()
        self.config = config
        c = config
        self.wave_stem = nn.Sequential(
            CausalConv1d(c.waveform_channels, c.hidden, c.kernel_size, 1),
            nn.GroupNorm(4, c.hidden),
            nn.GELU(),
        )
        self.tcn = nn.Sequential(*[TCNBlock(c.hidden, c.kernel_size, 2**i) for i in range(c.blocks)])
        self.physics_branch = nn.Sequential(
            nn.LayerNorm(c.physics_dim),
            nn.Linear(c.physics_dim, 32),
            nn.GELU(),
            nn.Linear(32, 32),
            nn.GELU(),
        )
        temporal_dim = c.hidden * (c.bins if c.pool == "bins" else 1)
        self.fusion = nn.Sequential(nn.Linear(temporal_dim + 32, 64), nn.GELU(), nn.Dropout(0.1))
        self.layer_head = nn.Linear(64, c.layer_classes)
        self.fault_head = nn.Linear(64, c.fault_classes)
        self.severity_head = nn.Linear(64, 1)
        self.parameter_head = nn.Linear(64, 4)

    def forward(self, waveform: Tensor, physics: Tensor) -> dict[str, Tensor]:
        h = self.tcn(self.wave_stem(waveform))
        if self.config.pool == "bins":
            h = F.adaptive_avg_pool1d(h, self.config.bins).flatten(1)
        else:
            h = h.mean(dim=-1)
        fused = self.fusion(torch.cat([h, self.physics_branch(physics)], dim=-1))
        return {
            "layer_logits": self.layer_head(fused),
            "fault_logits": self.fault_head(fused),
            "severity": self.severity_head(fused).squeeze(-1),
            "parameters": self.parameter_head(fused),
        }
