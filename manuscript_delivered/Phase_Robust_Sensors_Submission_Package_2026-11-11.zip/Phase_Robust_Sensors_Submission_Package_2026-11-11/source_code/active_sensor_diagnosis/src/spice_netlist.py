"""Generate an ngspice transient netlist for the two-point sensor interface.

The behavioral simulator remains the fast data generator. This netlist is a
small circuit-level validation model for the same topology: sensor -> AFE
reference switch -> low-pass/gain -> ADC reference switch -> ADC affine error.
It is intentionally parameterized so the same fault cases can be replayed in
ngspice on macOS after installing ngspice.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class SpiceCase:
    name: str
    afe_gain: float = 1.8
    afe_offset: float = 0.0
    tau_s: float = 0.012
    adc_gain: float = 1.0
    adc_offset: float = 0.0


def render_netlist(case: SpiceCase) -> str:
    """Return a batch-mode ngspice netlist for one diagnostic case."""
    # The reference levels and switching times match src.simulate exactly.
    return f"""* Active self-diagnosing mixed-signal sensor interface
* Case: {case.name}
* Sensor -> AFE reference MUX -> RC/gain AFE -> ADC reference MUX -> ADC model
.title {case.name}
.param AFE_GAIN={case.afe_gain:.9g}
.param AFE_OFFSET={case.afe_offset:.9g}
.param TAU={case.tau_s:.9g}
.param ADC_GAIN={case.adc_gain:.9g}
.param ADC_OFFSET={case.adc_offset:.9g}
.param VREF=3.3

* Physical sensor signal
V_SENSOR sensor 0 SIN(1.0 0.10 2.0 0 0 0)

* AFE reference replacement: 0.90 V then 1.30 V (step, 1 us edge, as in src.simulate)
V_AFE_REF afe_ref 0 PWL(0 0.90 0.20 0.90 0.200001 1.30 0.26 1.30 0.260001 0.90)
V_AFE_CTRL afe_ctrl 0 PULSE(0 5 0.14 1u 1u 0.12 1)
B_AFE_CTRL_N afe_ctrl_n 0 V={{5-V(afe_ctrl)}}
S_SENSOR afe_src sensor afe_ctrl_n 0 SW_DIAG
S_AFE_REF afe_src afe_ref afe_ctrl 0 SW_DIAG

* AFE low-pass and gain/offset model
R_AFE afe_src afe_lpf 1k
C_AFE afe_lpf 0 {{TAU/1k}}
B_AFE_OUT afe_out 0 V={{AFE_GAIN*V(afe_lpf)+AFE_OFFSET}}

* ADC reference replacement: 1.15 V then 1.75 V
V_ADC_REF adc_ref 0 PWL(0 1.15 0.40 1.15 0.400001 1.75 0.46 1.75 0.460001 1.15)
V_ADC_CTRL adc_ctrl 0 PULSE(0 5 0.34 1u 1u 0.12 1)
B_ADC_CTRL_N adc_ctrl_n 0 V={{5-V(adc_ctrl)}}
S_AFE_MAIN adc_src afe_out adc_ctrl_n 0 SW_DIAG
S_ADC_REF adc_src adc_ref adc_ctrl 0 SW_DIAG

* ADC affine gain/offset abstraction and load
B_ADC_OUT adc_out 0 V={{ADC_GAIN*V(adc_src)+ADC_OFFSET}}
R_ADC_LOAD adc_out 0 1Meg

.model SW_DIAG SW(Ron=0.5 Roff=1Meg Vt=2.5 Vh=0.1)
.tran 1m 512m
.save v(sensor) v(afe_src) v(afe_out) v(adc_src) v(adc_out) v(afe_ctrl) v(adc_ctrl)
.end
"""


def write_case(case: SpiceCase, directory: Path) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{case.name}.cir"
    path.write_text(render_netlist(case), encoding="utf-8")
    return path


DEFAULT_CASES = (
    SpiceCase("healthy"),
    SpiceCase("afe_bandwidth", tau_s=0.045),
    SpiceCase("afe_offset", afe_offset=0.15),
    SpiceCase("adc_gain", adc_gain=1.18),
    SpiceCase("adc_offset", adc_offset=0.15),
)
