"""Phase-robust transient descriptors for the AFE reference step.

Revision-1 descriptors read fixed samples after the reference step (rise_2 ... rise_30), so they depend on where the
(unknown) reference edge falls between two ADC samples.  The phase-robust set replaces them with descriptors estimated
from the WHOLE transient of the second AFE plateau, with the edge time as a free parameter:

    y(t) = base + S * (1 - exp(-(t - t_e)/tau))   for t >= t_e,     y(t) = base   for t < t_e

* ``base`` is the last sample of plateau 1 (the state just before the step).
* For a given (tau, t_e) the span S has a closed-form least-squares value (variable projection), so only (tau, t_e) are searched:
  a coarse log-spaced tau grid x an edge-time grid, followed by one local refinement.  This is a deterministic grid search, it has no
  convergence failure mode, and it is affine-invariant (independent of the ADC gain/offset and of the monitored reference levels).
* The edge time t_e is NOT used as a descriptor (it only encodes the sampling phase).

Descriptors (all dimensionless, normalised by the plateau length P):
    tau_norm      fitted first-order time constant / P
    rt_10_50_norm time between the 10% and 50% crossings of the normalised response / P
    rt_50_90_norm time between the 50% and 90% crossings / P  (capped at the window end if 90% is not reached)
    area_norm     transient area  sum_j (1 - r_j) T / P   with r_j = (y_j - base)/S  (normalised by the settled span)
    fit_rms_norm  rms fit residual / |S|
The plateau-settling errors (settle_err1/2) of the Revision-1 set are retained.

Fallback (documented, used only if the fit is degenerate, |S| tiny): the multi-sample window versions
area_norm from the raw samples and rise-time crossings from linear interpolation, with tau_norm set from area_norm.
"""

from __future__ import annotations

import numpy as np

from .ref_features import FEATURE_NAMES

RISE_IDX = [FEATURE_NAMES.index(n) for n in ("rise_2", "rise_5", "rise_10", "rise_20", "rise_30")]
KEEP_IDX = [i for i in range(len(FEATURE_NAMES)) if i not in RISE_IDX]
TF_NAMES = ("tau_norm", "rt_10_50_norm", "rt_50_90_norm", "area_norm", "fit_rms_norm")
PR_NAMES = tuple(FEATURE_NAMES[i] for i in KEEP_IDX) + TF_NAMES
N_PR = len(PR_NAMES)

_TAU_GRID = np.geomspace(1.0, 400.0, 56)  # ms
_TE_GRID = np.linspace(-0.25, 1.25, 7)  # in sample periods


def _fit(u: np.ndarray, d: np.ndarray, tau_grid: np.ndarray, te_grid: np.ndarray):
    """u: sample times (ms, relative to the base sample), d = y - base.  Returns (tau, te, S, rss)."""
    t = u[None, None, :] - te_grid[None, :, None]
    g = 1.0 - np.exp(-np.clip(t, 0.0, None) / tau_grid[:, None, None])
    g = np.where(t > 0, g, 0.0)
    gg = (g * g).sum(-1)
    gd = (g * d[None, None, :]).sum(-1)
    S = np.where(gg > 1e-12, gd / np.where(gg > 1e-12, gg, 1.0), 0.0)
    rss = (d * d).sum() - S * gd  # = |d|^2 - S*gd at the LS optimum
    k = np.unravel_index(np.argmin(rss), rss.shape)
    return tau_grid[k[0]], te_grid[k[1]], S[k], rss[k]


def transient_features(rec: dict, fs_hz: float = 1000.0) -> np.ndarray:
    """Return the 5 phase-robust transient descriptors (zeros if the record has no AFE reference)."""
    afe = np.asarray(rec["afe_reference"])
    if np.ptp(afe) < 1e-6:
        return np.zeros(len(TF_NAMES), dtype=np.float32)
    y = np.asarray(rec["waveform"], dtype=np.float64)
    s, e = int(rec["afe_ref_start"]), int(rec["afe_ref_end"])
    p2 = s + (e - s) // 2
    T = 1000.0 / fs_hz  # ms
    P = (e - p2) * T  # plateau length (ms)
    seg = y[p2 - 1:e]  # base sample + plateau-2 samples
    base = float(seg[0])
    d = seg[1:] - base
    u = (np.arange(1, len(seg)) * T).astype(np.float64)
    tau, te, S, rss = _fit(u, d, _TAU_GRID, _TE_GRID * T)
    # local refinement around the coarse optimum
    tau_g = tau * np.geomspace(0.9, 1.1, 9)
    te_g = te + np.linspace(-0.2, 0.2, 9) * T
    tau, te, S, rss = _fit(u, d, tau_g, te_g)
    if abs(S) < 1e-4:  # degenerate -> documented fallback
        r = np.zeros_like(d)
        area = float(np.sum(np.abs(d)) * T / P)
        return np.asarray([area, 0.0, 0.0, area, 1.0], dtype=np.float32)
    r = d / S
    env = np.maximum.accumulate(r) + 1e-9 * np.arange(len(r))
    tt = np.concatenate([[0.0], u])
    renv = np.concatenate([[0.0], env])

    def cross(level):
        return float(np.interp(level, renv, tt)) if level <= renv[-1] else float(tt[-1])

    t10, t50, t90 = cross(0.1), cross(0.5), cross(0.9)
    area = float(np.sum(1.0 - r) * T / P)
    rms = float(np.sqrt(max(rss, 0.0) / len(d)) / abs(S))
    out = np.asarray([tau / P, (t50 - t10) / P, (t90 - t50) / P, area, rms], dtype=np.float32)
    return np.clip(out, -5.0, 5.0)


def to_phase_robust(desc_r1: np.ndarray, tf: np.ndarray) -> np.ndarray:
    """Replace the 5 raw rise fractions of a Revision-1 descriptor vector by the phase-robust transient descriptors."""
    return np.concatenate([desc_r1[KEEP_IDX], tf]).astype(np.float32)
