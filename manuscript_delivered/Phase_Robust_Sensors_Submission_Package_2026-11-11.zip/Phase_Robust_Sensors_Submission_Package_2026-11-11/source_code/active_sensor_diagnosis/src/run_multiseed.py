"""Frozen multi-seed validation for one dataset seed (see multiseed_results/PROTOCOL_FROZEN.md).

Usage: python3 -m src.run_multiseed --dataset-seed 20261017
Writes multiseed_results/seed_<S>/{predictions.npz, metrics.json, meta.json}.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, recall_score
from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import StandardScaler

from .features import physics_features, raw_features
from .run_feasibility import _classifier, _rf_classifier
from .simulate import FAULT_TO_LAYER, FAULTS, LAYERS, make_condition, make_fault, simulate_sample
from .tcn_model import physics_guided_loss
from .tcn_v2 import TCNv2, TCNv2Config

ROOT = Path(__file__).resolve().parents[1]
MODES = {"passive": "passive", "single": "single", "afe_only": "afe_only", "adc_only": "adc_only", "two_point": "two_point"}
MODE_OFFSET = {"passive": 0, "single": 1, "afe_only": 2, "adc_only": 3, "two_point": 4}
LAYER_ID = {n: i for i, n in enumerate(LAYERS)}
SEV_BOUNDS = {
    "sensor_bias": (0.06, 0.24), "afe_offset": (0.06, 0.24), "adc_offset": (0.06, 0.24),
    "sensor_gain": (0.06, 0.28), "adc_gain": (0.06, 0.28),
    "sensor_noise": (0.025, 0.095), "afe_bandwidth": (1.8, 4.5), "adc_clipping": (0.72, 0.93),
}
INITS = (11, 22)
SEV_CUT = 2.0 / 3.0

# model name -> (mode, kind)
MODELS = {
    "passive_mlp": ("passive", "mlp"),
    "single_mlp": ("single", "mlp"),
    "afe_only_mlp": ("afe_only", "mlp"),
    "adc_only_mlp": ("adc_only", "mlp"),
    "two_point_mlp": ("two_point", "mlp"),
    "two_point_rf": ("two_point", "rf"),
    "tcn_v2a": ("two_point", "tcn"),
    "tcn_v2b": ("two_point", "tcn"),
    "tcn_v2b_nophys": ("two_point", "tcn"),  # declared loss-weight ablation, nominal training only
}
TCN_CFG = {
    "tcn_v2a": dict(pool="mean", phys_w=0.20),
    "tcn_v2b": dict(pool="bins", phys_w=0.20),
    "tcn_v2b_nophys": dict(pool="bins", phys_w=0.0),
}
SCENARIOS = ("nominal", "tolerance", "ref_m20", "ref_p20")


def _features(rec) -> tuple[np.ndarray, np.ndarray]:
    return raw_features(rec), physics_features(rec)


def build(dataset_seed: int, n_cond: int = 350) -> dict:
    """Replicates src.simulate.build_paired_dataset's RNG order, adding test-only shifted copies."""
    n_rows = n_cond * len(FAULTS)
    groups = np.repeat(np.arange(n_cond), len(FAULTS))
    dummy = np.zeros(n_rows)
    dev_idx, test_idx = next(GroupShuffleSplit(1, test_size=0.25, random_state=dataset_seed + 1).split(dummy, groups=groups))
    assert np.all(np.diff(test_idx) > 0) and np.all(np.diff(dev_idx) > 0)
    sub = next(GroupShuffleSplit(1, test_size=0.15, random_state=dataset_seed + 2).split(dev_idx, groups=groups[dev_idx]))
    train_idx, val_idx = dev_idx[sub[0]], dev_idx[sub[1]]
    test_conds = set(groups[test_idx].tolist())

    rng = np.random.default_rng(dataset_seed)
    shift_rng = np.random.default_rng(dataset_seed + 10_000)
    nominal = {m: {"raw": [], "phys": []} for m in MODES}
    shifted = {s: {m: {"raw": [], "phys": []} for m in MODES} for s in SCENARIOS[1:]}
    y_fault, y_layer, severity, sev_u = [], [], [], []
    for cid in range(n_cond):
        cond = make_condition(rng)
        for class_id, name in enumerate(FAULTS):
            fault = make_fault(name, rng)
            sample_seed = int(rng.integers(0, 2**31 - 1))
            y_fault.append(class_id)
            y_layer.append(LAYER_ID[FAULT_TO_LAYER[name]])
            severity.append(fault.severity)
            lo, hi = SEV_BOUNDS.get(name, (0.0, 1.0))
            sev_u.append(-1.0 if name == "healthy" else (fault.severity - lo) / (hi - lo))
            is_test = cid in test_conds
            if is_test:
                tol = dict(
                    afe_gain_scale=1 + shift_rng.uniform(-0.05, 0.05),
                    afe_tau_scale=1 + shift_rng.uniform(-0.10, 0.10),
                    adc_gain_scale=1 + shift_rng.uniform(-0.02, 0.02),
                    adc_offset_extra=shift_rng.uniform(-0.010, 0.010),
                    sensor_base_scale=1 + shift_rng.uniform(-0.05, 0.05),
                )
            for mode, pm in MODES.items():
                seed = sample_seed + MODE_OFFSET[mode]
                rec = simulate_sample(cond, fault, active=(mode != "passive"), seed=seed, probe_mode=pm)
                r, p = _features(rec)
                nominal[mode]["raw"].append(r); nominal[mode]["phys"].append(p)
                if not is_test:
                    continue
                scen_kwargs = {"tolerance": tol, "ref_m20": {"ref_scale": 0.8}, "ref_p20": {"ref_scale": 1.2}}
                for scn, kw in scen_kwargs.items():
                    if mode == "passive" and scn != "tolerance":
                        r2, p2 = r, p  # references do not exist in passive mode
                    else:
                        rec2 = simulate_sample(cond, fault, active=(mode != "passive"), seed=seed, probe_mode=pm, **kw)
                        r2, p2 = _features(rec2)
                    shifted[scn][mode]["raw"].append(r2); shifted[scn][mode]["phys"].append(p2)

    def stack(d):
        return {m: {k: np.asarray(v, dtype=np.float32) for k, v in d[m].items()} for m in d}

    return {
        "groups": groups, "train": train_idx, "val": val_idx, "test": test_idx,
        "y_fault": np.asarray(y_fault), "y_layer": np.asarray(y_layer),
        "severity": np.asarray(severity, dtype=np.float32), "sev_u": np.asarray(sev_u),
        "nominal": stack(nominal), "shifted": {s: stack(shifted[s]) for s in shifted},
    }


def _metrics(y, p, n_classes, labels):
    cm = confusion_matrix(y, p, labels=np.arange(n_classes))
    return {
        "accuracy": float(accuracy_score(y, p)),
        "macro_f1": float(f1_score(y, p, labels=np.arange(n_classes), average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y, p, labels=np.arange(n_classes), average="weighted", zero_division=0)),
        "per_class_recall": {labels[i]: float(v) for i, v in enumerate(
            recall_score(y, p, labels=np.arange(n_classes), average=None, zero_division=0))},
        "confusion_matrix": cm.tolist(),
    }


def _fit_tcn(cfg, X, P, RAW, yl, yf, sv, tr, va, te_inputs, init):
    """X: waveform (N,96); P: physics standardised later; RAW: unscaled physics for the loss."""
    import torch
    from torch.utils.data import DataLoader, TensorDataset

    torch.manual_seed(init); np.random.seed(init)
    mu, sd = X[tr].mean(), X[tr].std() + 1e-6
    scaler = StandardScaler().fit(P[tr])

    def prep(w, p):
        return torch.from_numpy(((w - mu) / sd)[:, None, :].astype(np.float32)), torch.from_numpy(scaler.transform(p).astype(np.float32))

    model = TCNv2(TCNv2Config(physics_dim=P.shape[1], pool=cfg["pool"]))
    opt = torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=1e-4)
    xtr, ptr = prep(X[tr], P[tr])
    ds = TensorDataset(xtr, ptr, torch.from_numpy(yl[tr]), torch.from_numpy(yf[tr]), torch.from_numpy(sv[tr]), torch.from_numpy(RAW[tr]))
    loader = DataLoader(ds, batch_size=64, shuffle=True, generator=torch.Generator().manual_seed(init))
    xva, pva = prep(X[va], P[va])
    best, best_state, best_epoch = -1.0, None, 0
    t0 = time.time()
    for epoch in range(40):
        model.train()
        for xb, pb, lb, fb, sb, rb in loader:
            out = model(xb, pb)
            loss = physics_guided_loss(out, lb, fb, sb, rb, physics_weight=cfg["phys_w"])["total"]
            opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
        model.eval()
        with torch.no_grad():
            o = model(xva, pva)
        score = 0.5 * (f1_score(yl[va], o["layer_logits"].argmax(1).numpy(), average="macro")
                       + f1_score(yf[va], o["fault_logits"].argmax(1).numpy(), average="macro"))
        if score > best:
            best, best_epoch = score, epoch + 1
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
    train_s = time.time() - t0
    model.load_state_dict(best_state); model.eval()
    preds, infer = {}, None
    for scn, (w, p) in te_inputs.items():
        xt, pt = prep(w, p)
        t1 = time.time()
        with torch.no_grad():
            o = model(xt, pt)
        if scn == "nominal":
            infer = (time.time() - t1) / len(w) * 1000
        preds[scn] = (o["layer_logits"].argmax(1).numpy(), o["fault_logits"].argmax(1).numpy())
    return preds, dict(train_seconds=train_s, infer_ms_per_sample=infer, selected_epoch=best_epoch, val_score=float(best))


def run_training_regime(regime: str, data: dict, models: list[str]) -> tuple[dict, dict]:
    """regime 'nominal' trains on all train rows; 'severity' on healthy + u<2/3."""
    g, nom = data["groups"], data["nominal"]
    train, val, test = data["train"], data["val"], data["test"]
    yl, yf, sv, u = data["y_layer"], data["y_fault"], data["severity"], data["sev_u"]
    if regime == "severity":
        keep = lambda idx: idx[(u[idx] < 0) | (u[idx] < SEV_CUT)]
        train, val = keep(train), keep(val)
        test_rows = test[(u[test] >= SEV_CUT) | ((u[test] < 0) & (g[test] % 3 == 0))]
        eval_sets = {"severity": test_rows}
    else:
        eval_sets = {"nominal": test}
    test_pos = {r: i for i, r in enumerate(test)}
    preds, info = {}, {}
    for name in models:
        mode, kind = MODELS[name]
        raw, phys = nom[mode]["raw"], nom[mode]["phys"]
        te = {}
        for scn, rows in eval_sets.items():
            te[scn] = (raw[rows], phys[rows])
        if regime == "nominal":
            for scn in SCENARIOS[1:]:
                sh = data["shifted"][scn][mode]
                te[scn] = (sh["raw"], sh["phys"])
        for init in INITS:
            t0 = time.time()
            if kind == "tcn":
                out, meta = _fit_tcn(TCN_CFG[name], raw, phys, phys, yl, yf, sv, train, val, te, init)
                for scn, (pl, pf) in out.items():
                    preds[f"{scn}|{name}|{init}|layer"] = pl.astype(np.int8)
                    preds[f"{scn}|{name}|{init}|fault"] = pf.astype(np.int8)
                info[f"{regime}|{name}|{init}"] = meta
            else:
                x_tr = np.hstack([raw[train], phys[train]])
                meta = {"train_seconds": 0.0, "infer_ms_per_sample": None}
                for target, y in (("layer", yl), ("fault", yf)):
                    est = _classifier(init) if kind == "mlp" else _rf_classifier(init)
                    t1 = time.time(); est.fit(x_tr, y[train]); meta["train_seconds"] += time.time() - t1
                    for scn, (w, p) in te.items():
                        t2 = time.time(); pr = est.predict(np.hstack([w, p]))
                        if scn in ("nominal", "severity") and target == "fault":
                            meta["infer_ms_per_sample"] = (time.time() - t2) / len(w) * 1000
                        preds[f"{scn}|{name}|{init}|{target}"] = pr.astype(np.int8)
                info[f"{regime}|{name}|{init}"] = meta
            print(f"[{regime}] {name} init={init} done in {time.time() - t0:.0f}s", flush=True)
    eval_rows = {scn: rows for scn, rows in eval_sets.items()}
    return preds, {"info": info, "eval_rows": {k: v.tolist() for k, v in eval_rows.items()},
                   "n_train": int(len(train)), "n_val": int(len(val))}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset-seed", type=int, required=True)
    ap.add_argument("--threads", type=int, default=2)
    ap.add_argument("--n-cond", type=int, default=350)
    ap.add_argument("--out-dir", type=Path, default=None)
    args = ap.parse_args()
    import torch
    torch.set_num_threads(args.threads)
    out = args.out_dir or ROOT / "multiseed_results" / f"seed_{args.dataset_seed}"
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    data = build(args.dataset_seed, args.n_cond)
    g = data["groups"]
    meta = {
        "dataset_seed": args.dataset_seed, "split_random_state": args.dataset_seed + 1, "val_random_state": args.dataset_seed + 2,
        "conditions_total": int(len(set(g))), "train_conditions": int(len(set(g[data["train"]]))),
        "val_conditions": int(len(set(g[data["val"]]))), "test_conditions": int(len(set(g[data["test"]]))),
        "overlap": int(len(set(g[data["train"]]) & set(g[data["test"]])) + len(set(g[data["val"]]) & set(g[data["test"]]))
                       + len(set(g[data["train"]]) & set(g[data["val"]]))),
        "build_seconds": round(time.time() - t0, 1),
    }
    assert meta["overlap"] == 0
    print(meta, flush=True)

    preds_all, info_all = {}, {}
    p1, i1 = run_training_regime("nominal", data, list(MODELS))
    p2, i2 = run_training_regime("severity", data, [m for m in MODELS if m != "tcn_v2b_nophys"])
    preds_all.update(p1); preds_all.update(p2)
    info_all.update(i1["info"]); info_all.update(i2["info"])
    meta["severity_train_rows"], meta["severity_val_rows"] = i2["n_train"], i2["n_val"]

    test = data["test"]
    sev_rows = np.asarray(i2["eval_rows"]["severity"])
    labels = {"nominal": test, "tolerance": test, "ref_m20": test, "ref_p20": test, "severity": sev_rows}
    meta["severity_test_rows"] = int(len(sev_rows))
    meta["severity_test_class_counts"] = np.bincount(data["y_fault"][sev_rows], minlength=9).tolist()
    arrays = {"groups_test": g[test], "groups_severity": g[sev_rows]}
    for scn, rows in labels.items():
        arrays[f"y_layer|{scn}"] = data["y_layer"][rows].astype(np.int8)
        arrays[f"y_fault|{scn}"] = data["y_fault"][rows].astype(np.int8)
        arrays[f"cond|{scn}"] = g[rows].astype(np.int32)
    arrays.update({k: v for k, v in preds_all.items()})
    np.savez_compressed(out / "predictions.npz", **arrays)

    metrics = {}
    for key, pred in preds_all.items():
        scn, name, init, target = key.split("|")
        y = arrays[f"y_{target}|{scn}"]
        n, lab = (4, LAYERS) if target == "layer" else (9, FAULTS)
        metrics[key] = _metrics(y, pred, n, lab)
    (out / "metrics.json").write_text(json.dumps(metrics, indent=1), encoding="utf-8")
    (out / "model_info.json").write_text(json.dumps(info_all, indent=1), encoding="utf-8")
    meta["total_seconds"] = round(time.time() - t0, 1)
    (out / "meta.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")
    print("DONE", meta, flush=True)


if __name__ == "__main__":
    main()
