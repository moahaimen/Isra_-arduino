"""Aggregate tcn_v2_results/ and tcn_comparison/baseline_runs.json."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
res_dir, cmp_dir = ROOT / "tcn_v2_results", ROOT / "tcn_comparison"
runs = json.loads((cmp_dir / "baseline_runs.json").read_text())
for p in sorted(res_dir.glob("*_seed*.json")):
    runs.append(json.loads(p.read_text()))
df = pd.DataFrame(runs)
cols = ["layer_accuracy", "layer_macro_f1", "fault_accuracy", "fault_macro_f1"]
order = ["mlp_raw", "mlp_physics", "mlp_raw_plus_physics", "rf_raw", "rf_physics", "rf_raw_plus_physics",
         "v1_repro", "v2a_standardize", "v2b_binpool", "v2c_refchannels", "v2d_earlystop",
         "v2d_no_physloss", "v2d_wave_only"]
g = df.groupby("variant")[cols]
mean, std = g.mean().loc[order], g.std(ddof=1).loc[order]
summary = pd.DataFrame({"n_init_seeds": df.groupby("variant").size().loc[order]})
for c in cols:
    summary[c + "_mean"], summary[c + "_std"] = mean[c], std[c]
summary.round(4).to_csv(cmp_dir / "comparison_summary.csv")
print(summary.round(3).to_string())

# per-class fault recall (mean over seeds)
rec = pd.DataFrame({v: pd.DataFrame(d["fault_per_class_recall"] for d in df[df.variant == v].to_dict("records")).mean()
                    for v in order}).T
rec.round(3).to_csv(cmp_dir / "fault_per_class_recall.csv")
print(rec.round(2).to_string())

# gap to best baseline (MLP raw+physics), per-seed-averaged
ref = "mlp_raw_plus_physics"
gap = {v: {c: float(mean.loc[v, c] - mean.loc[ref, c]) for c in cols} for v in order}
(cmp_dir / "comparison_summary.json").write_text(json.dumps(
    {"mean": mean.to_dict("index"), "std": std.to_dict("index"), "gap_vs_mlp_raw_plus_physics": gap}, indent=2))

fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), sharey=True)
colors = ["#888"] * 6 + ["#c0504d"] + ["#4f81bd"] * 6
for ax, c, t in zip(axes, ("layer_macro_f1", "fault_macro_f1"), ("Layer (4 classes)", "Fault (9 classes)")):
    ax.barh(range(len(order)), mean[c], xerr=std[c], color=colors, capsize=3)
    ax.set_title(t + " macro-F1"); ax.set_xlim(0, 0.75); ax.invert_yaxis()
    ax.set_yticks(range(len(order))); ax.set_yticklabels(order)
fig.suptitle("Same split (262 train / 88 held-out conditions), mean ± std over 3 init seeds\ngrey = classical baselines, red = TCN v1, blue = TCN v2 ladder")
fig.tight_layout(); fig.savefig(cmp_dir / "comparison_macro_f1.png", dpi=150)
