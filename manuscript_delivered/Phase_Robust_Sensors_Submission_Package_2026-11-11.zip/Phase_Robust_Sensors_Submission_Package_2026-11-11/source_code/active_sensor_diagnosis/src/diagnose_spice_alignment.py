"""POST-HOC exploratory test (development seed 20261098; NOT part of the frozen decision).

Hypothesis: the behavioral discrete filter y[i] = y[i-1] + a (x[i] - y[i-1]) corresponds to a zero-order-hold input, i.e. the new
level is applied over the interval (t_{i-1}, t_i].  The frozen ngspice edges arrive 1 us BEFORE t_i, so the circuit shows ~0 settling at the
step sample while the behavioral model shows one sample of settling.  Test: place the reference/control edges one sample earlier
(t_{i-1} + 1 us) and compare BS with BB, using the same matched-E=2% training.
"""
import json
import tempfile
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
from sklearn.metrics import f1_score
from sklearn.model_selection import GroupShuffleSplit

from . import spice_domain as sd_mod
from .monitor_model import draw, variant_descriptors
from .ref_features import FEATURE_NAMES
from .run_feasibility import _classifier
from .run_multiseed import INITS, LAYER_ID, MODE_OFFSET
from .run_reference_monitor import GUARD, _draw_tol
from .simulate import FAULT_TO_LAYER, FAULTS, make_condition, make_fault, simulate_sample

SEED, N_COND, AMPS = 20261098, 200, (0.8, 1.0, 1.2)
ROOT = Path(__file__).resolve().parents[1]


_ORIG = None


def _pwl_zoh(levels, noise=None, zero_outside=False):
    pts, n = [], len(levels)
    for i in range(n):
        t = i / sd_mod.FS
        v = float(levels[i]) + (0.0 if noise is None or (zero_outside and levels[i] == 0.0) else float(noise[i]))
        if i > 0 and levels[i] != levels[i - 1]:
            pts.append((t - 1.0 / sd_mod.FS + sd_mod.EDGE, v))
        pts.append((t, v))
    toks = " ".join(f"{t:.9g} {v:.6g}" for t, v in pts).split(" ")
    return "PWL(" + "\n+ ".join(" ".join(toks[k:k + 10]) for k in range(0, len(toks), 10)) + ")"


def _job(a):
    cond, fault, seed, amp, tol, wd, aligned = a
    global _ORIG
    if _ORIG is None:
        _ORIG = sd_mod._pwl_from_levels
    sd_mod._pwl_from_levels = _pwl_zoh if aligned else _ORIG  # set explicitly on EVERY job (workers are reused)
    return sd_mod.spice_record(cond, fault, seed, Path(wd), amp=amp, tol=tol, extra_noise=True)


def main():
    groups = np.repeat(np.arange(N_COND), 9)
    dev, test = next(GroupShuffleSplit(1, test_size=0.25, random_state=SEED + 1).split(np.zeros(N_COND * 9), groups=groups))
    sub = next(GroupShuffleSplit(1, test_size=0.15, random_state=SEED + 2).split(dev, groups=groups[dev]))
    train = dev[sub[0]]; train_set, test_set = set(train.tolist()), set(test.tolist())
    rng, tol_rng = np.random.default_rng(SEED), np.random.default_rng(SEED + 10_000)
    specs = []
    for cid in range(N_COND):
        cond = make_condition(rng)
        for ci, name in enumerate(FAULTS):
            fault = make_fault(name, rng); sd = int(rng.integers(0, 2**31 - 1))
            specs.append((cid * 9 + ci, ci, cond, fault, sd, _draw_tol(tol_rng)))
    Xtr, ytr, ylt, Xbh, tasks, meta = [], [], [], {a: [] for a in AMPS}, [], []
    for row, ci, cond, fault, sd, tol in specs:
        u, nz = draw(SEED, row)
        if row in train_set:
            rec = simulate_sample(cond, fault, active=True, seed=sd + MODE_OFFSET["two_point"], probe_mode="two_point")
            Xtr.append(variant_descriptors(rec, u, nz, ["mon2"], GUARD)["mon2"][0]); ytr.append(LAYER_ID[FAULT_TO_LAYER[FAULTS[ci]]])
        elif row in test_set:
            ylt.append(LAYER_ID[FAULT_TO_LAYER[FAULTS[ci]]])
            for a in AMPS:
                rec = simulate_sample(cond, fault, active=True, seed=sd + MODE_OFFSET["two_point"], probe_mode="two_point", ref_scale=a, **tol)
                Xbh[a].append(variant_descriptors(rec, u, nz, ["mon2"], GUARD)["mon2"][0])
                for aligned in (False, True):
                    tasks.append((cond, fault, sd + MODE_OFFSET["two_point"], a, tol, None, aligned)); meta.append((row, a, aligned))
    t0 = time.time()
    with tempfile.TemporaryDirectory(prefix="spice_") as wd:
        tasks = [t[:5] + (wd,) + t[6:] for t in tasks]
        with Pool(6) as p:
            recs = p.map(_job, tasks, chunksize=16)
    print(f"{len(tasks)} runs in {time.time() - t0:.0f}s", flush=True)
    Xsp = {(a, al): [] for a in AMPS for al in (False, True)}
    for (row, a, al), rec in zip(meta, recs):
        u, nz = draw(SEED, row)
        Xsp[(a, al)].append(variant_descriptors(rec, u, nz, ["mon2"], GUARD)["mon2"][0])
    Xtr, ytr, ylt = np.asarray(Xtr), np.asarray(ytr), np.asarray(ylt)
    Xbh = {a: np.asarray(v) for a, v in Xbh.items()}; Xsp = {k: np.asarray(v) for k, v in Xsp.items()}
    res = {"BB": [], "BS_frozen_alignment": [], "BS_zoh_aligned": []}
    for init in INITS:
        m = _classifier(init).fit(Xtr, ytr)
        for key, X in (("BB", Xbh), ("BS_frozen_alignment", {a: Xsp[(a, False)] for a in AMPS}), ("BS_zoh_aligned", {a: Xsp[(a, True)] for a in AMPS})):
            pred = np.concatenate([m.predict(X[a]) for a in AMPS]); y = np.concatenate([ylt] * len(AMPS))
            res[key].append(f1_score(y, pred, average="macro"))
    out = {k: float(np.mean(v)) for k, v in res.items()}
    sd = Xbh[1.0].std(0) + 1e-9
    out["mean_abs_shift_sigma_frozen"] = {n: float(np.mean(np.abs(Xsp[(1.0, False)][:, i] - Xbh[1.0][:, i])) / sd[i]) for i, n in enumerate(FEATURE_NAMES)}
    out["mean_abs_shift_sigma_zoh_aligned"] = {n: float(np.mean(np.abs(Xsp[(1.0, True)][:, i] - Xbh[1.0][:, i])) / sd[i]) for i, n in enumerate(FEATURE_NAMES)}
    (ROOT / "reference_monitor_final" / "reference_monitor_results" / "exploratory_spice_alignment.json").write_text(json.dumps(out, indent=1))
    print(json.dumps({k: v for k, v in out.items() if not k.startswith("mean")}, indent=1))
    for k in ("mean_abs_shift_sigma_frozen", "mean_abs_shift_sigma_zoh_aligned"):
        print(k, {n: round(v, 2) for n, v in out[k].items() if n.startswith("rise") or n in ("adc_noise", "afe_noise")})


if __name__ == "__main__":
    main()
