"""Run the first feasibility experiment for the active sensor-interface idea."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    mean_absolute_error,
)
from sklearn.model_selection import GroupShuffleSplit
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier

from .features import feature_matrix
from .simulate import FAULTS, LAYERS, build_paired_dataset


def _classifier(seed: int) -> Pipeline:
    return Pipeline(
        [
            ("scale", StandardScaler()),
            (
                "mlp",
                MLPClassifier(
                    hidden_layer_sizes=(96, 48),
                    activation="relu",
                    solver="adam",
                    alpha=1e-4,
                    batch_size=64,
                    learning_rate_init=8e-4,
                    max_iter=700,
                    early_stopping=True,
                    validation_fraction=0.15,
                    n_iter_no_change=35,
                    random_state=seed,
                ),
            ),
        ]
    )


def _rf_classifier(seed: int) -> Pipeline:
    return Pipeline(
        [
            ("scale", StandardScaler()),
            (
                "rf",
                RandomForestClassifier(
                    n_estimators=250,
                    min_samples_leaf=2,
                    max_features="sqrt",
                    random_state=seed,
                    n_jobs=-1,
                ),
            ),
        ]
    )


def _severity_regressor(seed: int) -> Pipeline:
    return Pipeline(
        [
            ("scale", StandardScaler()),
            (
                "mlp",
                MLPRegressor(
                    hidden_layer_sizes=(64, 32),
                    max_iter=600,
                    early_stopping=True,
                    validation_fraction=0.15,
                    n_iter_no_change=30,
                    random_state=seed,
                ),
            ),
        ]
    )


def _plot_confusion(cm: np.ndarray, labels: tuple[str, ...], title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(8.2, 7.0) if len(labels) > 5 else (6.5, 5.4))
    im = ax.imshow(cm, cmap="Blues", vmin=0.0, vmax=max(1.0, float(cm.max())))
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    ax.set_xticks(np.arange(len(labels)), labels=labels, rotation=45, ha="right")
    ax.set_yticks(np.arange(len(labels)), labels=labels)
    ax.set_xlabel("Predicted class")
    ax.set_ylabel("True class")
    ax.set_title(title)
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(int(cm[i, j])), ha="center", va="center", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def _plot_examples(records: Dict[str, List[Dict[str, object]]], path: Path) -> None:
    chosen = ["healthy", "sensor_bias", "afe_bandwidth", "adc_gain"]
    fig, axes = plt.subplots(2, 2, figsize=(11, 6.5), sharex=True)
    active = records.get("active_two_point", records["active"])
    for ax, fault in zip(axes.ravel(), chosen):
        candidates = [r for r in active if r["fault"] == fault]
        for r in candidates[:2]:
            y = np.asarray(r["waveform"])
            ax.plot(y, alpha=0.75, linewidth=1.0)
        first = candidates[0]
        windows = first.get("probe_windows", [(first["probe_start"], first["probe_end"])])
        for wi, (start_raw, end_raw) in enumerate(windows):
            start, end = int(start_raw), int(end_raw)
            ax.axvspan(start, end, color="tab:orange", alpha=0.18, label="active probe" if wi == 0 else None)
        ax.set_title(fault)
        ax.grid(alpha=0.2)
    axes[0, 0].legend(loc="upper right", fontsize=8)
    fig.suptitle("Example ADC waveforms under two-point active reference probing")
    fig.supxlabel("Sample")
    fig.supylabel("ADC voltage (V)")
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def evaluate_model(
    name: str,
    x: np.ndarray,
    y: np.ndarray,
    train_idx: np.ndarray,
    test_idx: np.ndarray,
    out_dir: Path,
    seed: int,
    labels: tuple[str, ...],
) -> Dict[str, object]:
    model = _classifier(seed)
    model.fit(x[train_idx], y[train_idx])
    pred = model.predict(x[test_idx])
    cm = confusion_matrix(y[test_idx], pred, labels=np.arange(len(labels)))
    report = classification_report(
        y[test_idx], pred, labels=np.arange(len(labels)), target_names=labels, output_dict=True, zero_division=0
    )
    _plot_confusion(cm, labels, name, out_dir / f"confusion_{name}.png")
    return {
        "name": name,
        "accuracy": float(accuracy_score(y[test_idx], pred)),
        "macro_f1": float(f1_score(y[test_idx], pred, average="macro")),
        "weighted_f1": float(f1_score(y[test_idx], pred, average="weighted")),
        "per_class_recall": {k: float(v["recall"]) for k, v in report.items() if k in labels},
        "confusion_matrix": cm.tolist(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples-per-class", type=int, default=350)
    parser.add_argument("--seed", type=int, default=20261014)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "results")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    print(f"Building paired dataset: {args.samples_per_class} operating conditions x {len(FAULTS)} faults")
    dataset = build_paired_dataset(args.samples_per_class, args.seed)
    records = dataset["records"]
    _plot_examples(records, args.output / "example_waveforms.png")

    feature_sets: Dict[str, Dict[str, np.ndarray]] = {}
    for target, labels in (("fault", FAULTS), ("layer", LAYERS)):
        for mode in ("passive", "active", "active_two_point"):
            for feature_mode in (
                "raw",
                "physics",
                "raw_plus_physics",
                "calibrated_raw",
                "calibrated_raw_plus_physics",
            ):
                x, y, groups, severity = feature_matrix(records[mode], feature_mode, target=target)
                feature_sets[f"{target}_{mode}_{feature_mode}"] = {
                    "x": x,
                    "y": y,
                    "groups": groups,
                    "severity": severity,
                }

    # A group is an operating condition. No condition appears in both splits.
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=args.seed + 1)
    reference = feature_sets["fault_active_two_point_raw"]
    train_idx, test_idx = next(splitter.split(reference["x"], reference["y"], reference["groups"]))
    train_groups = sorted(set(reference["groups"][train_idx].tolist()))
    test_groups = sorted(set(reference["groups"][test_idx].tolist()))

    # The mode comparisons use exactly the same condition indices.
    results: List[Dict[str, object]] = []
    for name in (
        "passive_raw",
        "active_raw",
        "active_physics",
        "active_raw_plus_physics",
        "active_two_point_raw",
        "active_two_point_physics",
        "active_two_point_raw_plus_physics",
        "active_two_point_calibrated_raw",
        "active_two_point_calibrated_raw_plus_physics",
    ):
        fs = feature_sets[f"fault_{name}"]
        results.append(evaluate_model(name, fs["x"], fs["y"], train_idx, test_idx, args.output, args.seed, FAULTS))

    # Add a non-neural classical reference for the physics feature set.
    rf = _rf_classifier(args.seed)
    fs = feature_sets["fault_active_physics"]
    rf.fit(fs["x"][train_idx], fs["y"][train_idx])
    rf_pred = rf.predict(fs["x"][test_idx])
    rf_cm = confusion_matrix(fs["y"][test_idx], rf_pred, labels=np.arange(len(FAULTS)))
    _plot_confusion(rf_cm, FAULTS, "active_physics_random_forest", args.output / "confusion_active_physics_random_forest.png")
    results.append(
        {
            "name": "active_physics_random_forest",
            "accuracy": float(accuracy_score(fs["y"][test_idx], rf_pred)),
            "macro_f1": float(f1_score(fs["y"][test_idx], rf_pred, average="macro")),
            "weighted_f1": float(f1_score(fs["y"][test_idx], rf_pred, average="weighted")),
            "confusion_matrix": rf_cm.tolist(),
        }
    )

    # Classical reference for the two-point physics feature set.
    rf2 = _rf_classifier(args.seed + 7)
    fs2 = feature_sets["fault_active_two_point_physics"]
    rf2.fit(fs2["x"][train_idx], fs2["y"][train_idx])
    rf2_pred = rf2.predict(fs2["x"][test_idx])
    rf2_cm = confusion_matrix(fs2["y"][test_idx], rf2_pred, labels=np.arange(len(FAULTS)))
    _plot_confusion(
        rf2_cm,
        FAULTS,
        "active_two_point_physics_random_forest",
        args.output / "confusion_active_two_point_physics_random_forest.png",
    )
    results.append(
        {
            "name": "active_two_point_physics_random_forest",
            "accuracy": float(accuracy_score(fs2["y"][test_idx], rf2_pred)),
            "macro_f1": float(f1_score(fs2["y"][test_idx], rf2_pred, average="macro")),
            "weighted_f1": float(f1_score(fs2["y"][test_idx], rf2_pred, average="weighted")),
            "confusion_matrix": rf2_cm.tolist(),
        }
    )

    # The system-level decision is primarily about identifying the faulty
    # electronic layer. Evaluate this coarse target separately; fine fault
    # attribution is intentionally harder and remains a secondary metric.
    for name in (
        "passive_raw",
        "active_raw",
        "active_physics",
        "active_raw_plus_physics",
        "active_two_point_raw",
        "active_two_point_physics",
        "active_two_point_raw_plus_physics",
        "active_two_point_calibrated_raw",
        "active_two_point_calibrated_raw_plus_physics",
    ):
        fs = feature_sets[f"layer_{name}"]
        results.append(
            evaluate_model(
                f"layer_{name}", fs["x"], fs["y"], train_idx, test_idx, args.output, args.seed, LAYERS
            )
        )

    # Severity is evaluated only on non-healthy samples and is normalized by
    # the fault generator's own unit. This is a feasibility indicator, not a
    # final maintenance-grade severity estimator.
    severity_fs = feature_sets["fault_active_two_point_calibrated_raw_plus_physics"]
    nonhealthy_train = train_idx[severity_fs["y"][train_idx] != 0]
    nonhealthy_test = test_idx[severity_fs["y"][test_idx] != 0]
    sev_model = _severity_regressor(args.seed)
    sev_model.fit(severity_fs["x"][nonhealthy_train], severity_fs["severity"][nonhealthy_train])
    sev_pred = sev_model.predict(severity_fs["x"][nonhealthy_test])
    severity_mae = float(mean_absolute_error(severity_fs["severity"][nonhealthy_test], sev_pred))

    summary = {
        "seed": args.seed,
        "samples_per_class": args.samples_per_class,
        "faults": list(FAULTS),
        "layers": list(LAYERS),
        "n_total_per_mode": len(records["active"]),
        "train_condition_count": len(train_groups),
        "test_condition_count": len(test_groups),
        "train_groups": train_groups,
        "test_groups": test_groups,
        "models": results,
        "severity_mae_active_two_point_raw_plus_physics": severity_mae,
        "feature_dimensions": {k: int(v["x"].shape[1]) for k, v in feature_sets.items()},
        "notes": [
            "Behavioral simulator only; SPICE validation is the next stage.",
            "All evaluation groups are operating-condition disjoint.",
            "The active probe is injected after the physical sensor and before the AFE.",
        ],
    }
    (args.output / "feasibility_metrics.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    table = pd.DataFrame(
        [{"model": r["name"], "accuracy": r["accuracy"], "macro_f1": r["macro_f1"], "weighted_f1": r["weighted_f1"]} for r in results]
    )
    table.to_csv(args.output / "feasibility_summary.csv", index=False)
    print("\nFeasibility results (unseen operating conditions):")
    print(table.to_string(index=False, float_format=lambda v: f"{v:.4f}"))
    print(f"\nActive two-point raw+physics severity MAE: {severity_mae:.4f}")
    print(f"Results written to: {args.output}")


if __name__ == "__main__":
    main()
