"""Run the adaptive diagnostic-test selection experiment."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from sklearn.model_selection import GroupShuffleSplit

from .adaptive_policy import evaluate_adaptive, evaluate_fixed
from .features import feature_matrix
from .simulate import build_paired_dataset


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples-per-class", type=int, default=180)
    parser.add_argument("--seed", type=int, default=20261014)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "adaptive_results")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    dataset = build_paired_dataset(args.samples_per_class, args.seed)
    modes = {
        "passive": "passive",
        "active_afe_only": "active_afe_only",
        "active_adc_only": "active_adc_only",
        "active_two_point": "active_two_point",
    }
    feature_sets = {}
    for key, record_mode in modes.items():
        x, y, groups, severity = feature_matrix(dataset["records"][record_mode], "raw_plus_physics", target="layer")
        feature_sets[key] = {"x": x, "y": y, "groups": groups, "severity": severity}

    splitter = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=args.seed + 1)
    ref = feature_sets["passive"]
    train_idx, test_idx = next(splitter.split(ref["x"], ref["y"], ref["groups"]))

    fixed = {
        "fixed_passive": evaluate_fixed(feature_sets, "passive", train_idx, test_idx, args.seed),
        "fixed_afe_reference": evaluate_fixed(feature_sets, "active_afe_only", train_idx, test_idx, args.seed + 1),
        "fixed_adc_reference": evaluate_fixed(feature_sets, "active_adc_only", train_idx, test_idx, args.seed + 2),
        "fixed_two_point": evaluate_fixed(feature_sets, "active_two_point", train_idx, test_idx, args.seed + 3),
    }
    adaptive = evaluate_adaptive(feature_sets, train_idx, test_idx, args.seed + 10)
    summary = {
        "seed": args.seed,
        "samples_per_class": args.samples_per_class,
        "train_condition_count": len(set(ref["groups"][train_idx].tolist())),
        "test_condition_count": len(set(ref["groups"][test_idx].tolist())),
        "fixed": fixed,
        "adaptive": adaptive,
        "notes": [
            "Layer labels are healthy, sensor, AFE, and ADC.",
            "The adaptive policy sees passive probabilities only before choosing a test.",
            "Test cost is normalized: passive=0, one reference=1, two-point=2.",
        ],
    }
    (args.output / "adaptive_metrics.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
