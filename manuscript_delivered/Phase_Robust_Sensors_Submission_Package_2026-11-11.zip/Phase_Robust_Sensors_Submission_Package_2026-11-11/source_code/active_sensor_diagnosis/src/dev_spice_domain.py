"""DEVELOPMENT-ONLY (seed 20261098): SPICE chain vs behavioral simulator, matched settings (no extra noise)."""
import sys, time
from pathlib import Path
import numpy as np
from .ref_features import ref_descriptors, FEATURE_NAMES
from .simulate import FAULTS, make_condition, make_fault, simulate_sample
from .spice_domain import spice_record

wd = Path(sys.argv[1]); n_cond = int(sys.argv[2])
rng = np.random.default_rng(20261098)
rows = {f: [] for f in FAULTS}
t0 = time.time()
for cid in range(n_cond):
    cond = make_condition(rng)
    for name in FAULTS:
        f = make_fault(name, rng); sd = int(rng.integers(0, 2**31 - 1))
        b = simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point")
        s = spice_record(cond, f, sd + 4, wd, extra_noise=False)
        db, ds = ref_descriptors(b)[0], ref_descriptors(s)[0]
        rows[name].append((np.sqrt(np.mean((b["waveform"] - s["waveform"]) ** 2)), np.abs(b["waveform"] - s["waveform"]).max(), db, ds))
print(f"{n_cond*9} samples in {time.time()-t0:.1f}s")
print(f"{'fault':14s} rmse_V  max_V   | |desc diff| / std for: g_adc o_adc G_afe o_afe rise_10 sens_mean")
allb = np.array([r[2] for v in rows.values() for r in v]); sdv = allb.std(0) + 1e-9
idx = [FEATURE_NAMES.index(k) for k in ("g_adc", "o_adc", "G_afe", "o_afe", "rise_10", "sens_mean")]
for name, v in rows.items():
    d = np.mean([np.abs(r[2] - r[3]) for r in v], axis=0) / sdv
    print(f"{name:14s} {np.mean([r[0] for r in v]):.4f}  {np.max([r[1] for r in v]):.3f}  |", " ".join(f"{d[i]:.3f}" for i in idx))
