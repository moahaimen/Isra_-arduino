"""Assemble reference_monitor_final/FINAL_REFERENCE_MONITOR_REPORT.md from reference_monitor_results/ (tables generated)."""

import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "reference_monitor_final"
R = BASE / "reference_monitor_results"
dec = json.loads((R / "decision_rules.json").read_text())
curves = pd.read_csv(R / "amplitude_curves.csv")
sepa = pd.read_csv(R / "afe_adc_separation.csv")
p2 = pd.read_csv(R / "part2_domain_transfer.csv")
p2rec = pd.read_csv(R / "part2_per_class_recall.csv")
tim = json.loads((R / "timing_and_parameters.json").read_text())
diag_path = R / "exploratory_spice_gap_diagnostic.json"
diag = json.loads(diag_path.read_text()) if diag_path.exists() else None
al_path = R / "exploratory_spice_alignment.json"
al = json.loads(al_path.read_text()) if al_path.exists() else None
seeds = [20261023, 20261024, 20261025]
meta = {s: json.loads((R / f"seed_{s}" / "meta.json").read_text()) for s in seeds}
N = dec["N_nominal_known_layer_macro_f1"]
XS = ["known", "mon0", "mon1", "mon2", "mon5"]
XL = {"known": "known reference", "mon0": "monitor E=0%", "mon1": "monitor E=±1%", "mon2": "monitor E=±2%", "mon5": "monitor E=±5%"}
AMP = [0.8, 0.9, 1.0, 1.1, 1.2]
comp = pd.read_csv(R / "bootstrap_comparisons.csv")


def md(df):
    cols = list(df.columns)
    out = ["| " + " | ".join(map(str, cols)) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    out += ["| " + " | ".join(str(x) for x in r.values) + " |" for _, r in df.iterrows()]
    return "\n".join(out)


def cell(d):
    star = " ✓" if d["ci_low"] > 0 else (" ✗" if d["ci_high"] < 0 else "")
    return f"{d['diff']:+.3f} [{d['ci_low']:+.3f}, {d['ci_high']:+.3f}]{star}"


def ok(b):
    return "PASS" if b else "**FAIL**"


L = []
w = L.append
E2 = dec["E"]["primary_matched_E2"]
w("# Final Reference-Monitor Report")
w("")
w("Date: 14 October 2026 · Frozen protocol: `PROTOCOL_REFERENCE_MONITOR_FROZEN.md` (written before any validation-seed result; source hashes in `reference_monitor_results/source_hashes_at_freeze.txt`). "
  "Previous results (`FINAL_MULTISEED_REPORT.md`, `FINAL_REFERENCE_V2_REPORT.md`, `reference_v2_results/`, `spice_fixed/`) are untouched. Revision 1 (A1) is the method under test; Revision 2 conditioning appears only as an ablation.")
w("")
w("## Decision")
w("")
w(f"**{dec['decision']}.** The monitor works in the behavioral domain, but the frozen ngspice transfer criterion is not met.")
w("")
w(md(pd.DataFrame([
    {"criterion": "A retention ≥ 0.85·N at ±20% (known, E ≤ 2%)", "result": ok(dec["A"]["pass"]), "worst case": f"{min(v['retention_vs_N'] for v in dec['A']['detail'].values()):.3f} of N"},
    {"criterion": "B beats A0 and one-point baselines at ±20% (CI > 0)", "result": ok(dec["B"]["pass"]), "worst case": f"smallest CI lower bound {min(v['ci_low'] for v in dec['B']['detail'].values()):+.3f}"},
    {"criterion": "C AFE–ADC cross-confusion < 0.15 at ±20%", "result": ok(dec["C"]["pass"]), "worst case": f"{max(v['cross_confusion'] for v in dec['C']['detail'].values()):.3f}"},
    {"criterion": "D usable at E = ±5% (≥ 0.70·N; B and C also hold)", "result": ok(dec["D"]["pass"]), "worst case": f"{min(v['retention_vs_N'] for v in dec['D']['detail'].values()):.3f} of N"},
    {"criterion": "E behavioral→ngspice loss ≤ 0.10 (matched E=2%, pooled amplitudes)", "result": ok(dec["E"]["pass"]),
     "worst case": f"drop {E2['drop_BB_minus_BS']:.3f}, 95% CI [{E2['drop_ci'][0]:.3f}, {E2['drop_ci'][1]:.3f}]"},
    {"criterion": "F improvements supported by paired-bootstrap CI", "result": "PASS (applied to B and MS−BS)", "worst case": "—"},
])))
w("")
w(f"N (layer macro-F1, known reference, nominal amplitude, behavioral) = **{N:.3f}**. Failed criteria: **{', '.join(dec['failed_criteria'])}**.")
w("")
w(f"**The exact failure.** Trained on behavioral data and tested on ngspice samples, the two-point MLP loses {E2['drop_BB_minus_BS']:.3f} layer macro-F1 "
  f"(behavioral {E2['BB']:.3f} → ngspice {E2['BS']:.3f}); the CI lower bound ({E2['drop_ci'][0]:.3f}) is itself above 0.10, so this is not a borderline estimate. "
  f"The loss is {min(v['drop_BB_minus_BS'] for v in dec['E']['all_variants'].values()):.3f}–{max(v['drop_BB_minus_BS'] for v in dec['E']['all_variants'].values()):.3f} for every monitor variant (known reference, E = 0, 1, 2, 5%), "
  f"and the worst single amplitude loses {E2['worst_amplitude_drop'][0]:.3f} (×{E2['worst_amplitude_drop'][1] / 100:.1f}). "
  f"Training on a mixture of behavioral and ngspice rows removes the gap (MS {E2['MS']:.3f}, +{dec['F']['MS_minus_BS']['mon2']['MS_minus_BS']:.3f} over BS, CI [{dec['F']['MS_minus_BS']['mon2']['ci'][0]:.3f}, {dec['F']['MS_minus_BS']['mon2']['ci'][1]:.3f}]), "
  "i.e. the ngspice samples differ systematically from the behavioral ones in a way a behavioral-only classifier does not handle; ngspice-aware training fixes it. "
  "This route was not part of the frozen pass criterion and does not turn the decision into GO. "
  "A post-hoc development-seed diagnostic (section 4) attributes most of the gap to a sampling-phase convention between my ngspice edge placement and the behavioral filter, not to the extra noise.")
w("")

w("## 1. Setup")
w("")
w("* **Monitor circuit assumption** (details in the protocol): dedicated high-impedance buffered channel into its own 12-bit ADC, 16-sample averaging, 1 mV rms per sample (0.25 mV after averaging), 12-bit quantisation, gain error uniform in ±E common to the four levels, offset trimmed: `r_measured = Q(r_actual·(1+e) + n)`. E = 0% still includes noise and quantisation.")
w("* The measured levels replace the commanded levels in all Revision-1 descriptors (30% settling guard, unchanged). Matched-training models `A1m{E}` are the primary monitored method; clean-trained `A1c` is the sensitivity analysis; `assumed` = nominal levels given although the amplitude changed.")
w("* ngspice samples: per-sample netlist of the `spice_fixed/` circuit for all 9 fault classes, with tolerances, amplitudes ×0.8–×1.2, extra amplifier/rail noise (0.5 mV rms each), ADC noise, 12-bit quantisation and monitor error. Behavioral and ngspice samples are paired (same conditions, faults, noise streams, tolerance and monitor draws). A development-seed check of the SPICE chain (noise-free) gave ≈ 9 mV waveform RMSE against the behavioral model, identical ADC descriptors and AFE descriptors within 0.05σ.")
w("")
w(md(pd.DataFrame([{"dataset seed": s, "train / val / test conditions": f"{meta[s]['train_conditions']} / {meta[s]['val_conditions']} / {meta[s]['test_conditions']}", "overlap": meta[s]["overlap"],
                    "split rs (test / val)": f"{meta[s]['split_random_state']} / {meta[s]['val_random_state']}", "ngspice runs": meta[s]["n_ngspice_runs"], "ngspice wall s": meta[s]["ngspice_wall_seconds"]} for s in seeds])))
w("")
w("Two initialisation seeds (11, 22) per model; the validation split exists for protocol continuity but no early-stopped model is trained in this stage. 5000-resample paired condition-level bootstrap throughout.")
w("")

w("## 2. Part 1 — monitor validation (behavioral domain)")
w("")
w("**Layer macro-F1 versus actual reference amplitude (mean of 3 dataset seeds):**")
w("")
rows = []
for _, r in curves[curves.target == "layer"].iterrows():
    rows.append({"method": r.series, **{f"×{a:.1f}": f"{r[f'x{a:.1f}']:.3f}" for a in AMP}, "pooled": f"{r.pooled_all:.3f}"})
w(md(pd.DataFrame(rows)))
w("")
w("**Fine-fault macro-F1:**")
w("")
rows = []
for _, r in curves[curves.target == "fault"].iterrows():
    rows.append({"method": r.series, **{f"×{a:.1f}": f"{r[f'x{a:.1f}']:.3f}" for a in AMP}, "pooled": f"{r.pooled_all:.3f}"})
w(md(pd.DataFrame(rows)))
w("")
w("Figure: `reference_monitor_figures/fig1_amplitude_curves.png`.")
w("")
w("### A — retention (≥ 0.85·N)")
w("")
rows = [{"condition": XL[x], **{f"×{a / 100:.1f}": f"{dec['A']['detail'][f'{x}|a{a}']['f1']:.3f} ({dec['A']['detail'][f'{x}|a{a}']['retention_vs_N']:.2f})" for a in (80, 120)},
         "pass": ok(all(dec["A"]["detail"][f"{x}|a{a}"]["pass"] for a in (80, 120)))} for x in XS[:4]]
w(md(pd.DataFrame(rows)))
w("")
w("### B — two-point A1 minus each baseline, layer macro-F1 (pooled CI)")
w("")
bl = [("two_point_mlp@A0", "two-point A0"), ("passive_mlp@A0", "passive"), ("single_mlp@A0", "single probe"), ("afe_only_mlp@A0", "AFE-only A0"), ("adc_only_mlp@A0", "ADC-only A0")]
rows = []
for x in XS:
    for a in (80, 120):
        row = {"condition": XL[x], "amplitude": f"×{a / 100:.1f}"}
        for b, lab in bl:
            row[lab] = cell(dec["B"]["detail"][f"{x}|a{a}|vs {b}"])
        afe = f"afe_only_mlp@A1{'c' if x == 'known' else 'm' + x[3:]}"; adc = afe.replace("afe", "adc")
        row["AFE-only A1"] = cell(dec["B"]["detail"][f"{x}|a{a}|vs {afe}"])
        row["ADC-only A1"] = cell(dec["B"]["detail"][f"{x}|a{a}|vs {adc}"])
        rows.append(row)
w(md(pd.DataFrame(rows)))
w("")
w("### C — AFE–ADC cross-confusion at ±20%")
w("")
rows = [{"condition": XL[x], **{f"×{a / 100:.1f}": f"AFE {dec['C']['detail'][f'{x}|a{a}']['afe_recall']:.2f} / ADC {dec['C']['detail'][f'{x}|a{a}']['adc_recall']:.2f} / cross {dec['C']['detail'][f'{x}|a{a}']['cross_confusion']:.3f}" for a in (80, 120)}} for x in XS]
w(md(pd.DataFrame(rows)))
w("")
mx = max(dec["C"]["detail"].items(), key=lambda kv: kv[1]["cross_confusion"])
w(f"The criterion holds everywhere, but not with a wide margin at ×1.2: the largest cross-confusion is {mx[1]['cross_confusion']:.3f} ({mx[0]}), against the 0.15 limit.")
w("")
w("### D — monitor error up to ±5%")
w("")
w(md(pd.DataFrame([{"scope": k, "layer macro-F1": f"{v['f1']:.3f}", "fraction of N": f"{v['retention_vs_N']:.3f}", "≥ 0.70": ok(v["pass"])} for k, v in dec["D"]["detail"].items()])))
w("")
w("With matched training, monitor errors of ±1%, ±2% and ±5% cost essentially nothing relative to a perfect known reference: the monitor gain error is learned as part of the descriptor distribution. "
  "This is **not** true for a classifier trained on a clean reference and then used with a ±5% monitor (the `A1c clean-trained` rows above lose more). The monitor specification therefore has to be fixed before training.")
w("")
w("### Reported, not gating")
w("")
unm = curves[(curves.series == "A1 unmonitored (nominal assumed)") & (curves.target == "layer")].iloc[0]
w(f"* **Unmonitored nominal assumption** (same classifier, the system does not know the amplitude changed): layer macro-F1 {unm['x0.8']:.3f} at ×0.8 and {unm['x1.2']:.3f} at ×1.2 — the failure the monitor is meant to remove.")
a2 = curves[(curves.series == "A2m E=2% (ablation)") & (curves.target == "layer")].iloc[0]
a1m = curves[(curves.series == "A1m E=2%") & (curves.target == "layer")].iloc[0]
w(f"* **Revision 2 conditioning (ablation, E = 2%):** {a2['x0.8']:.3f} / {a2['x1.2']:.3f} at ×0.8 / ×1.2 against {a1m['x0.8']:.3f} / {a1m['x1.2']:.3f} for A1 — again not better than Revision 1 alone.")
w("")

w("## 3. Part 2 — ngspice cross-domain validation")
w("")
w("Settings: **BB** behavioral train / behavioral test; **BS** behavioral train / ngspice test; **MS** mixed behavioral + ngspice train / ngspice test. Same Revision-1 extractor and the same MLP in all three. Pooled over the five amplitudes, mean of 3 dataset seeds.")
w("")
rows = []
for _, r in p2.iterrows():
    rows.append({"variant": XL[r.variant], "setting": r.setting, "layer macro-F1": f"{r.layer_macro_f1:.3f}", "layer balanced acc.": f"{r.layer_balanced_accuracy:.3f}",
                 "fault macro-F1": f"{r.fault_macro_f1:.3f}", "fault balanced acc.": f"{r.fault_balanced_accuracy:.3f}",
                 "AFE recall": f"{r.afe_recall:.2f}", "ADC recall": f"{r.adc_recall:.2f}", "AFE↔ADC cross": f"{r.cross_confusion:.3f}"})
w(md(pd.DataFrame(rows)))
w("")
w("**Layer macro-F1 per amplitude (matched E = 2%):**")
w("")
w(md(pd.DataFrame([{"setting": r.setting, **{f"×{a:.1f}": f"{r[f'layer_f1_x{a:.1f}']:.3f}" for a in AMP}} for _, r in p2[p2.variant == "mon2"].iterrows()])))
w("")
w("### E — domain-transfer drop and F — mixed-training improvement")
w("")
rows = []
for x in XS:
    e, f = dec["E"]["all_variants"][x], dec["F"]["MS_minus_BS"][x]
    rows.append({"variant": XL[x], "BB": f"{e['BB']:.3f}", "BS": f"{e['BS']:.3f}", "MS": f"{e['MS']:.3f}", "drop BB−BS [95% CI]": f"{e['drop_BB_minus_BS']:.3f} [{e['drop_ci'][0]:.3f}, {e['drop_ci'][1]:.3f}]",
                 "worst amplitude drop": f"{e['worst_amplitude_drop'][0]:.3f} (×{e['worst_amplitude_drop'][1] / 100:.1f})", "≤ 0.10": ok(e["pass_le_0.10"]),
                 "MS−BS [95% CI]": f"{f['MS_minus_BS']:+.3f} [{f['ci'][0]:+.3f}, {f['ci'][1]:+.3f}]" + (" ✓" if f["improvement_supported"] else "")})
w(md(pd.DataFrame(rows)))
w("")
w("Figure: `reference_monitor_figures/fig3_domain_transfer.png`. The drop is nearly constant across amplitudes and monitor errors, so it is a property of the circuit domain, not of the reference handling.")
w("")
w("**Per-class recall (matched E = 2%, pooled amplitudes):**")
w("")
lay = p2rec[p2rec.target == "layer"].dropna(axis=1, how="all")
fau = p2rec[p2rec.target == "fault"].dropna(axis=1, how="all")
w(md(lay.drop(columns="target").round(2)))
w("")
w(md(fau.drop(columns="target").round(2)))
w("")
w("In ngspice the classifier loses sensor-fault and healthy recall and over-assigns samples to the ADC class (layer: sensor "
  f"{float(lay[lay.setting == 'BB'].sensor.iloc[0]):.2f} → {float(lay[lay.setting == 'BS'].sensor.iloc[0]):.2f}, ADC {float(lay[lay.setting == 'BB'].adc.iloc[0]):.2f} → {float(lay[lay.setting == 'BS'].adc.iloc[0]):.2f}); "
  "afe_offset recall also falls. The AFE-versus-ADC cross-confusion stays low in every setting (about 0.05 BB, 0.10 BS), so the separation that the reference path is designed for survives the domain change; the damage is to the sensor/healthy decision.")
w("")
w("### Cost")
w("")
first = tim[str(seeds[0])]
w(f"* Parameters of the two-point MLP: {first['params_two_point_layer']} (layer head) and {first['params_two_point_fault']} (fault head).")
w(f"* Descriptor extraction: {sum(tim[str(s)]['descriptor_extraction_ms_per_sample'] for s in seeds) / 3:.2f} ms per sample (single core, Python); MLP inference: {tim['mlp_predict_ms_per_sample_behavioral_spice_mon2_layer'][0]:.4f} ms per sample. Training of one MLP: about 1 s.")
w(f"* ngspice: {meta[seeds[0]]['n_ngspice_runs']} per-sample runs per dataset seed in about {meta[seeds[0]]['ngspice_wall_seconds']:.0f} s wall time on {meta[seeds[0]]['workers']} workers.")
w("")

if diag:
    w("## 4. Exploratory, post-hoc: what drives the ngspice gap (development seed 20261098, not part of the decision)")
    w("")
    f = diag["full"]
    w(f"On a separate development seed (200 conditions), with matched E = 2% training: BB {f['BB']:.3f}; BS with the extra circuit noise {f['BS_with_extra_noise']:.3f}; BS **without** the extra rail/amplifier noise {f['BS_circuit_only']:.3f}. "
      f"The loss ({f['BB'] - f['BS_with_extra_noise']:.3f}) is essentially unchanged when the extra noise is removed ({f['BB'] - f['BS_circuit_only']:.3f}), so the added voltage noise is not the cause; the circuit-domain dynamics are.")
    w("")
    rows = []
    for g in ("rise_fractions", "noise", "settling_error", "sensor_stats", "saturation", "calibration"):
        wo = diag[f"without_{g}"]
        rows.append({"descriptor group removed (train and test)": g, "BB": f"{wo['BB']:.3f}", "BS (with extra noise)": f"{wo['BS_with_extra_noise']:.3f}",
                     "BS (circuit only)": f"{wo['BS_circuit_only']:.3f}", "drop BB−BS": f"{diag['drop_' + g]:.3f}"})
    w(md(pd.DataFrame(rows)))
    w("")
    top = sorted(diag["mean_abs_shift_sigma"].items(), key=lambda kv: -kv[1])[:6]
    w("Descriptors with the largest paired behavioral→ngspice shift (mean |difference| in units of the behavioral standard deviation, ×1.0): " + ", ".join(f"{k} {v:.2f}σ" for k, v in top) + ".")
    w("")
    if al:
        w("**Sampling-phase test.** The behavioral filter `y[i] = y[i-1] + α(x[i] − y[i-1])` treats the new level as applied over the interval ending at sample i, whereas the frozen ngspice edges arrive 1 µs before sample i, so the circuit shows almost no settling at the step sample while the behavioral model shows one sample of it. "
          "Placing the reference and switch-control edges one sample earlier (zero-order-hold-consistent) gives, with the same matched E = 2% training:")
        w("")
        w(md(pd.DataFrame([{"test set": "behavioral (BB)", "layer macro-F1": f"{al['BB']:.3f}", "drop vs BB": "—"},
                           {"test set": "ngspice, frozen edge placement (BS)", "layer macro-F1": f"{al['BS_frozen_alignment']:.3f}", "drop vs BB": f"{al['BB'] - al['BS_frozen_alignment']:.3f}"},
                           {"test set": "ngspice, edges one sample earlier", "layer macro-F1": f"{al['BS_zoh_aligned']:.3f}", "drop vs BB": f"{al['BB'] - al['BS_zoh_aligned']:.3f}"}])))
        w("")
        fz, zo = al["mean_abs_shift_sigma_frozen"], al["mean_abs_shift_sigma_zoh_aligned"]
        w(f"The early-step descriptors rise_2 / rise_5 shift by {fz['rise_2']:.2f}σ / {fz['rise_5']:.2f}σ with the frozen placement and by {zo['rise_2']:.2f}σ / {zo['rise_5']:.2f}σ after realigning. "
          "So the failed criterion E is mostly an artefact of how the circuit and the discrete-time model are aligned in time — but it also exposes a real fragility: descriptors built from the first 2–5 ms after a reference step depend on the sampling phase relative to the step, which in hardware is a free (and uncertain) parameter. "
          "The frozen decision is not changed by this finding: the frozen ngspice set used the frozen edge placement, and the realigned test is a development-seed, post-hoc check.")
        w("")
    w("This is a single development seed with a smaller dataset and group ablations that retrain the classifier; treat it as a pointer to what to revise, not as validated evidence.")
    w("")

w("## 5. Limitations")
w("")
for t in [
    "The ngspice domain is still a model of the circuit that was written by the same author as the behavioral simulator (same topology and fault models); it checks sensitivity to continuous-time dynamics, switch edges and extra noise, not to unmodelled hardware effects (charge injection, op-amp non-idealities, reference settling, PCB leakage).",
    "The monitor is simulated: a single common gain error and white noise per level. Monitor offset error, nonlinearity, bandwidth, drift and a reference that is itself stepping (monitor sampling aligned to the plateau) are not modelled; offset is assumed trimmed.",
    "Matched training assumes the monitor's error bound is known when the classifier is trained; clean-trained classifiers lose accuracy at E = 5%.",
    "AFE–ADC cross-confusion at ×1.2 is 0.12–0.13 against a limit of 0.15, i.e. little margin; the ×1.2 case is the weakest point of the method in every variant.",
    "Three dataset seeds with 88 test conditions each; CIs resample conditions, not datasets. The reference scale is applied to all references of a sample together; independent AFE and ADC reference errors were not tested.",
    "Absolute performance remains modest (layer macro-F1 ≈ 0.69 nominal; healthy recall ≈ 0.2); this is not a deployable detector. No hardware, energy or cost measurement; no journal-acceptance claim.",
]:
    w(f"* {t}")
w("")

w("## 6. What to revise")
w("")
w("1. **The cross-domain criterion failed and the paper cannot yet claim behavioral-to-circuit transfer.** The pre-registered limit (≤ 0.10 loss) is missed by about 0.02 with a CI that excludes 0.10. Two candidate revisions, to be validated on new seeds: (a) make the descriptors robust to sampling phase — drop or phase-normalise the 2–5 ms step-response fractions (rise_2, rise_5), which the post-hoc diagnostic identifies as the dominant shifted features — and/or randomise the sampling phase in training; (b) fix the time alignment of the circuit model and state it as a modelling convention. Training on behavioral + circuit samples also removed the gap in the frozen experiment (MS ≥ BB) and is a fallback, but it should be reported as circuit-aware training.")
w("2. Re-validate whichever change is chosen on **new dataset seeds** under a new frozen protocol; the criteria of this round cannot be re-used after having seen these results.")
w("3. State the monitor claim exactly as supported: with a reference monitor of ±5% or better, trained for that error bound, the two-point method retains ≥ 0.93 of nominal layer macro-F1 at ±20% reference amplitude in the behavioral domain, with AFE–ADC cross-confusion ≤ 0.13; without a monitor it collapses.")
w("4. A hardware pilot (or at least a SPICE model with real op-amp/switch models) is needed before any statement about physical robustness.")
w("")
w("No journal-acceptance claim is made.")
w("")
w(f"FINAL DECISION: {dec['decision']}")
(BASE / "FINAL_REFERENCE_MONITOR_REPORT.md").write_text("\n".join(L) + "\n", encoding="utf-8")
print("wrote", len("\n".join(L)), "chars; decision:", dec["decision"])
