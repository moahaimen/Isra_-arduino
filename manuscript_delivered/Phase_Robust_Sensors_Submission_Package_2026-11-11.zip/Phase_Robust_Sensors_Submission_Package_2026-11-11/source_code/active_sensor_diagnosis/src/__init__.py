"""Simulation modules for the active sensor-interface project."""
