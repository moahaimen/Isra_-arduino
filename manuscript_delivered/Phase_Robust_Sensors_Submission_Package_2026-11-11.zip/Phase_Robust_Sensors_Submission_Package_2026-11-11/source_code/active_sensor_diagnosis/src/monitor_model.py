"""Reference-monitor channel model (see PROTOCOL_REFERENCE_MONITOR_FROZEN.md for the circuit assumption).

Circuit assumption: a dedicated, high-impedance monitor channel taps the reference node at the input of the test mux
(unity-gain buffer, input impedance >= 10 MOhm so loading error < 0.01%), feeding its own 12-bit SAR ADC channel
(0-3.3 V, LSB = 0.806 mV), sampled during each reference plateau. Each reported level is the mean of 16 samples with
1 mV rms input-referred noise per sample -> 0.25 mV rms after averaging, then quantised to the 12-bit grid.
The monitor's own gain error (reference/resistor tolerance) is bounded by +-E and drawn uniformly per sample; it is common
to the four levels of that sample (one channel). Offset error is assumed trimmed out.

    r_measured = Q( r_actual * (1 + e) + n ),   e ~ U(-E, +E),   n ~ N(0, (1 mV / sqrt(16))^2)
"""

from __future__ import annotations

import numpy as np

from .ref_features import ref_descriptors
from .simulate import _adc_reference, _afe_reference

LSB = 3.3 / 4095.0
SIGMA_N = 1.0e-3 / np.sqrt(16.0)
E_LEVELS = (0, 1, 2, 5)  # percent


def quantise(x: float) -> float:
    return float(np.clip(np.round(x / LSB), 0, 4095) * LSB)


def draw(seed: int, row: int, tag: int = 4242):
    """Per-sample random numbers (unit gain-error draw u in [-1, 1] and 4 noise values)."""
    rng = np.random.default_rng([int(seed), int(row), int(tag)])
    return float(rng.uniform(-1.0, 1.0)), rng.normal(0.0, SIGMA_N, 4)


def _replace(rec: dict, key: str, start_key: str, end_key: str, levels) -> dict:
    out = dict(rec)
    arr = np.zeros_like(np.asarray(rec[key], dtype=np.float32))
    s, e = int(rec[start_key]), int(rec[end_key])
    half = (e - s) // 2
    arr[s:s + half], arr[s + half:e] = levels
    out[key] = arr
    return out


def measured_record(rec: dict, u: float, nz: np.ndarray, E_percent: float) -> dict:
    """Record whose reference arrays carry the *measured* plateau levels."""
    E = E_percent / 100.0
    out = dict(rec)
    for i0, key, sk, ek in ((0, "afe_reference", "afe_ref_start", "afe_ref_end"), (2, "adc_reference", "adc_ref_start", "adc_ref_end")):
        arr = np.asarray(rec[key])
        if np.ptp(arr) < 1e-6:
            continue
        s, e = int(rec[sk]), int(rec[ek])
        half = (e - s) // 2
        low, high = float(arr[s]), float(arr[s + half])
        m = (quantise(low * (1 + u * E) + nz[i0]), quantise(high * (1 + u * E) + nz[i0 + 1]))
        out = _replace(out, key, sk, ek, m)
    return out


def assumed_record(rec: dict) -> dict:
    """Record whose reference arrays are the NOMINAL commanded ones (the system does not know the amplitude changed)."""
    out = dict(rec)
    if np.ptp(np.asarray(rec["afe_reference"])) > 1e-6:
        out["afe_reference"] = _afe_reference(len(rec["waveform"]), 1000.0)[0]
    if np.ptp(np.asarray(rec["adc_reference"])) > 1e-6:
        out["adc_reference"] = _adc_reference(len(rec["waveform"]), 1000.0)[0]
    return out


def variant_descriptors(rec: dict, u: float, nz: np.ndarray, variants, guard: float) -> dict:
    """{variant: (descriptors, conditioning)} for variants in {'known','assumed','mon0','mon1','mon2','mon5'}."""
    res = {}
    for v in variants:
        if v == "known":
            r = rec
        elif v == "assumed":
            r = assumed_record(rec)
        else:
            r = measured_record(rec, u, nz, float(v[3:]))
        d, c, _ = ref_descriptors(r, guard)
        res[v] = (d, c)
    return res
