"""Optional physics-guided temporal model for the sensor-interface study.

The fast feasibility runs intentionally use scikit-learn MLPs.  This module
contains the publication-facing model that can be trained when PyTorch is
available: a small causal TCN receives the ADC waveform, a separate branch
receives circuit descriptors, and the heads jointly predict fault layer,
fine fault, severity, and four identifiable transfer parameters.  The last
head is coupled to the measured reference responses through a physics loss.

PyTorch is optional so that the behavioral simulator remains runnable on a
minimal macOS Python installation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Mapping

import numpy as np

try:  # pragma: no cover - availability depends on the user's environment
    import torch
    from torch import Tensor, nn
    import torch.nn.functional as F

    TORCH_AVAILABLE = True
except Exception:  # pragma: no cover
    torch = None  # type: ignore[assignment]
    Tensor = object  # type: ignore[misc,assignment]
    nn = object  # type: ignore[assignment]
    F = None  # type: ignore[assignment]
    TORCH_AVAILABLE = False


@dataclass(frozen=True)
class TCNConfig:
    waveform_channels: int = 1
    physics_dim: int = 38
    hidden: int = 24
    kernel_size: int = 5
    blocks: int = 3
    layer_classes: int = 4
    fault_classes: int = 9


if TORCH_AVAILABLE:

    class CausalConv1d(nn.Module):
        """One-dimensional convolution with no future sample leakage."""

        def __init__(self, channels_in: int, channels_out: int, kernel: int, dilation: int) -> None:
            super().__init__()
            self.left_padding = (kernel - 1) * dilation
            self.conv = nn.Conv1d(
                channels_in,
                channels_out,
                kernel_size=kernel,
                dilation=dilation,
                padding=self.left_padding,
            )

        def forward(self, x: Tensor) -> Tensor:
            y = self.conv(x)
            return y[..., : x.shape[-1]]


    class TCNBlock(nn.Module):
        def __init__(self, channels: int, kernel: int, dilation: int) -> None:
            super().__init__()
            self.net = nn.Sequential(
                CausalConv1d(channels, channels, kernel, dilation),
                nn.GroupNorm(4, channels),
                nn.GELU(),
                nn.Dropout(0.08),
                CausalConv1d(channels, channels, kernel, dilation),
                nn.GroupNorm(4, channels),
            )
            self.activation = nn.GELU()

        def forward(self, x: Tensor) -> Tensor:
            return self.activation(x + self.net(x))


    class PhysicsGuidedTCN(nn.Module):
        """Causal waveform encoder with an explicit circuit-consistency head."""

        def __init__(self, config: TCNConfig = TCNConfig()) -> None:
            super().__init__()
            if config.hidden % 4:
                raise ValueError("hidden must be divisible by four for GroupNorm")
            self.config = config
            self.wave_stem = nn.Sequential(
                CausalConv1d(config.waveform_channels, config.hidden, config.kernel_size, 1),
                nn.GroupNorm(4, config.hidden),
                nn.GELU(),
            )
            self.tcn = nn.Sequential(
                *[
                    TCNBlock(config.hidden, config.kernel_size, 2**i)
                    for i in range(config.blocks)
                ]
            )
            self.physics_branch = nn.Sequential(
                nn.LayerNorm(config.physics_dim),
                nn.Linear(config.physics_dim, 32),
                nn.GELU(),
                nn.Linear(32, 32),
                nn.GELU(),
            )
            fused = config.hidden + 32
            self.fusion = nn.Sequential(nn.Linear(fused, 64), nn.GELU(), nn.Dropout(0.1))
            self.layer_head = nn.Linear(64, config.layer_classes)
            self.fault_head = nn.Linear(64, config.fault_classes)
            self.severity_head = nn.Linear(64, 1)
            # [ADC gain, ADC offset, AFE gain, AFE offset].  These quantities
            # are directly estimable only when the matching reference is run.
            self.parameter_head = nn.Linear(64, 4)

        def forward(self, waveform: Tensor, physics: Tensor) -> Dict[str, Tensor]:
            temporal = self.tcn(self.wave_stem(waveform))
            temporal = temporal.mean(dim=-1)
            fused = self.fusion(torch.cat([temporal, self.physics_branch(physics)], dim=-1))
            return {
                "layer_logits": self.layer_head(fused),
                "fault_logits": self.fault_head(fused),
                "severity": self.severity_head(fused).squeeze(-1),
                "parameters": self.parameter_head(fused),
            }


    def physics_guided_loss(
        outputs: Mapping[str, Tensor],
        layer_target: Tensor,
        fault_target: Tensor,
        severity_target: Tensor,
        physics_target: Tensor,
        *,
        physics_weight: float = 0.20,
        severity_weight: float = 0.20,
    ) -> Dict[str, Tensor]:
        """Joint classification/regression loss with reference-path supervision.

        The final eight physics descriptors are
        ``[adc_gain, adc_offset, adc_span, adc_noise, afe_gain, afe_offset,
        afe_span, afe_noise]``.  The parameter head is supervised against the
        gain/offset entries; passive samples naturally carry a zero mask and
        do not invent an unobserved transfer estimate.
        """
        ce_layer = F.cross_entropy(outputs["layer_logits"], layer_target)
        ce_fault = F.cross_entropy(outputs["fault_logits"], fault_target)
        severity = F.smooth_l1_loss(outputs["severity"], severity_target)
        target_params = torch.stack(
            [physics_target[:, 30], physics_target[:, 31], physics_target[:, 34], physics_target[:, 35]],
            dim=1,
        )
        # The reference windows are nonzero exactly when the corresponding
        # transfer parameter is observable.  Avoid penalising an unobserved
        # parameter in passive/single-point modes.
        observed = torch.stack(
            [physics_target[:, 32].abs(), physics_target[:, 33].abs(), physics_target[:, 36].abs(), physics_target[:, 37].abs()],
            dim=1,
        )
        observed = (observed > 1e-7).float()
        param_error = F.smooth_l1_loss(outputs["parameters"], target_params, reduction="none")
        param_loss = (param_error * observed).sum() / observed.sum().clamp_min(1.0)
        total = ce_layer + ce_fault + severity_weight * severity + physics_weight * param_loss
        return {
            "total": total,
            "layer": ce_layer,
            "fault": ce_fault,
            "severity": severity,
            "physics": param_loss,
        }


else:

    class PhysicsGuidedTCN:  # pragma: no cover - only an informative stub
        def __init__(self, config: TCNConfig = TCNConfig()) -> None:
            raise ImportError("PyTorch is not installed; install torch to train PhysicsGuidedTCN")


    def physics_guided_loss(*args, **kwargs):  # pragma: no cover
        raise ImportError("PyTorch is not installed; install torch to use physics_guided_loss")


def torch_ready() -> bool:
    """Return whether the optional temporal model can be trained."""
    return bool(TORCH_AVAILABLE)

