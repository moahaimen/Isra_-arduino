"""Per-sample ngspice simulation of the two-point sensor interface (cross-domain validation).

The circuit is the one in ``spice_fixed/`` (sensor -> AFE reference mux -> RC + gain/offset AFE -> ADC reference mux
-> ADC affine stage) generalised to arbitrary per-sample parameters:

* the physical sensor waveform (incl. operating-condition drift, bias/gain/noise faults) is a PWL source;
* AFE gain/offset/tau, ADC gain/offset and an ADC input clamp (clipping fault) are per-sample circuit parameters;
* reference levels are PWL sources with 1 us step edges, switch control signals are PWL with the same edges;
* extra circuit-domain noise (not present in the behavioral model): 0.5 mV rms on the sensor/amplifier input and
  0.5 mV rms on both reference rails (sampled at 1 kHz).
ADC voltage noise (2.5 mV rms) and 12-bit quantisation are applied after the circuit solve, in the same order and with the
same random stream as ``simulate_sample`` so that behavioral and ngspice samples are paired.
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path

import numpy as np

from .compare_spice import read_raw
from .simulate import _adc_reference, _afe_reference, _base_signal

N, FS = 512, 1000.0
EDGE = 1e-6
AMP_NOISE_V = 0.0005
REF_NOISE_V = 0.0005
NGSPICE = "ngspice"


def _pwl_from_levels(levels: np.ndarray, noise: np.ndarray | None = None, zero_outside: bool = False) -> str:
    """PWL(...) string sampling `levels` at 1 kHz with sharp (1 us) steps so that sample i sees levels[i]."""
    pts = []
    n = len(levels)
    for i in range(n):
        t = i / FS
        v = float(levels[i]) + (0.0 if noise is None or (zero_outside and levels[i] == 0.0) else float(noise[i]))
        if i > 0 and levels[i] != levels[i - 1]:
            pts.append((t - EDGE, pts[-1][1]))
        pts.append((t, v))
    body = " ".join(f"{t:.9g} {v:.6g}" for t, v in pts)
    # ngspice line continuation: chunk the long PWL
    toks = body.split(" ")
    lines, cur = [], []
    for k in range(0, len(toks), 10):
        lines.append(" ".join(toks[k:k + 10]))
    return "PWL(" + "\n+ ".join(lines) + ")"


def render(sensor, afe_gain, afe_offset, tau, adc_gain, adc_offset, clip_high, afe_ref, adc_ref, ref_noise_afe, ref_noise_adc) -> str:
    afe_ctrl = np.where(afe_ref > 0, 5.0, 0.0)
    adc_ctrl = np.where(adc_ref > 0, 5.0, 0.0)
    return f"""* two-point sensor interface (per-sample)
.title s
V_SENSOR sensor 0 {_pwl_from_levels(sensor)}
V_AFE_REF afe_ref 0 {_pwl_from_levels(afe_ref, ref_noise_afe, zero_outside=True)}
V_AFE_CTRL afe_ctrl 0 {_pwl_from_levels(afe_ctrl)}
B_AFE_CTRL_N afe_ctrl_n 0 V={{5-V(afe_ctrl)}}
S_SENSOR afe_src sensor afe_ctrl_n 0 SW_DIAG
S_AFE_REF afe_src afe_ref afe_ctrl 0 SW_DIAG
R_AFE afe_src afe_lpf 1k
C_AFE afe_lpf 0 {tau / 1000.0:.9g}
B_AFE_OUT afe_out 0 V={{{afe_gain:.9g}*V(afe_lpf)+({afe_offset:.9g})}}
V_ADC_REF adc_ref 0 {_pwl_from_levels(adc_ref, ref_noise_adc, zero_outside=True)}
V_ADC_CTRL adc_ctrl 0 {_pwl_from_levels(adc_ctrl)}
B_ADC_CTRL_N adc_ctrl_n 0 V={{5-V(adc_ctrl)}}
S_AFE_MAIN adc_src afe_out adc_ctrl_n 0 SW_DIAG
S_ADC_REF adc_src adc_ref adc_ctrl 0 SW_DIAG
B_ADC_OUT adc_out 0 V={{min(max({adc_gain:.9g}*V(adc_src)+({adc_offset:.9g}),0),{clip_high:.9g})}}
R_ADC_LOAD adc_out 0 1Meg
.model SW_DIAG SW(Ron=0.5 Roff=1Meg Vt=2.5 Vh=0.1)
.tran 0.1m 512m
.save v(adc_out)
.end
"""


def solve(netlist: str, workdir: Path) -> np.ndarray:
    """Run ngspice and return v(adc_out) interpolated on the 1 kHz sample grid."""
    fd, cir = tempfile.mkstemp(suffix=".cir", dir=workdir)
    os.close(fd)
    cir = Path(cir)
    raw, log = cir.with_suffix(".raw"), cir.with_suffix(".log")
    cir.write_text(netlist)
    try:
        subprocess.run([NGSPICE, "-b", "-r", str(raw), "-o", str(log), str(cir)], capture_output=True, text=True, check=True, timeout=120)
        r = read_raw(raw)
        return np.interp(np.arange(N) / FS, r["time"], r["v(adc_out)"])
    finally:
        for p in (cir, raw, log):
            p.unlink(missing_ok=True)


def spice_record(condition, fault, seed: int, workdir: Path, *, amp: float = 1.0, tol: dict | None = None,
                 extra_noise: bool = True) -> dict:
    """Circuit-level counterpart of ``simulate_sample(..., probe_mode='two_point')`` (same random stream for the shared parts)."""
    tol = tol or {}
    rng = np.random.default_rng(seed)
    physical = _base_signal(condition, N, FS, rng)
    sbs = tol.get("sensor_base_scale", 1.0)
    if sbs != 1.0:
        physical = physical + (sbs - 1.0) * condition.base
    sensor = physical.copy()
    if fault.name == "sensor_bias":
        sensor += fault.signed * fault.severity
    elif fault.name == "sensor_gain":
        sensor *= 1.0 + fault.signed * fault.severity
    elif fault.name == "sensor_noise":
        sensor += rng.normal(0.0, fault.severity, size=N)
    afe_gain = condition.nominal_gain * tol.get("afe_gain_scale", 1.0)
    tau = condition.nominal_tau_s * tol.get("afe_tau_scale", 1.0)
    afe_offset = 0.0
    if fault.name == "afe_offset":
        afe_offset = fault.signed * fault.severity
    elif fault.name == "afe_bandwidth":
        tau *= fault.severity
    adc_gain = tol.get("adc_gain_scale", 1.0)
    adc_offset = tol.get("adc_offset_extra", 0.0)
    clip_high = condition.adc_vref
    if fault.name == "adc_offset":
        adc_offset += fault.signed * fault.severity
    elif fault.name == "adc_gain":
        adc_gain *= 1.0 + fault.signed * fault.severity
    elif fault.name == "adc_clipping":
        clip_high = condition.adc_vref * fault.severity
    afe_ref, a0, a1 = _afe_reference(N, FS)
    adc_ref, d0, d1 = _adc_reference(N, FS)
    afe_ref, adc_ref = afe_ref * amp, adc_ref * amp
    rng_x = np.random.default_rng(seed + 777)
    if extra_noise:
        sensor_in = sensor + rng_x.normal(0.0, AMP_NOISE_V, N)
        nz_afe, nz_adc = rng_x.normal(0.0, REF_NOISE_V, N), rng_x.normal(0.0, REF_NOISE_V, N)
    else:
        sensor_in, nz_afe, nz_adc = sensor, None, None
    v = solve(render(sensor_in, afe_gain, afe_offset, tau, adc_gain, adc_offset, clip_high, afe_ref, adc_ref, nz_afe, nz_adc), workdir)
    analog = v + rng.normal(0.0, 0.0025, size=N)  # same stream position as the behavioral ADC noise
    analog = np.clip(analog, 0.0, clip_high)
    codes = np.round(analog / condition.adc_vref * 4095.0)
    measured = codes / 4095.0 * condition.adc_vref
    return {"waveform": measured.astype(np.float32), "afe_reference": afe_ref.astype(np.float32), "adc_reference": adc_ref.astype(np.float32),
            "afe_ref_start": a0, "afe_ref_end": a1, "adc_ref_start": d0, "adc_ref_end": d1,
            "probe": np.zeros(N, dtype=np.float32), "fault": fault.name, "severity": float(fault.severity)}
