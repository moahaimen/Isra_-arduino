"""Frozen reference-monitor + ngspice cross-domain validation for ONE dataset seed.

Usage: python3 -m src.run_reference_monitor --dataset-seed 20261023
Writes reference_monitor_final/reference_monitor_results/seed_<S>/{predictions.npz, model_info.json, meta.json}.
Protocol: reference_monitor_final/PROTOCOL_REFERENCE_MONITOR_FROZEN.md
"""

from __future__ import annotations

import argparse
import json
import tempfile
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
from sklearn.model_selection import GroupShuffleSplit

from .features import physics_features, raw_features
from .monitor_model import draw, variant_descriptors
from .ref_features import ref_descriptors
from .run_feasibility import _classifier
from .run_multiseed import INITS, LAYER_ID, MODE_OFFSET, MODES
from .simulate import FAULT_TO_LAYER, FAULTS, make_condition, make_fault, simulate_sample
from .spice_domain import spice_record

ROOT = Path(__file__).resolve().parents[1]
OUT_ROOT = ROOT / "reference_monitor_final" / "reference_monitor_results"
GUARD = 0.30  # frozen in the previous round, unchanged
AMPS = (0.8, 0.9, 1.0, 1.1, 1.2)
EP = (0, 1, 2, 5)
VARS = ("known", "assumed") + tuple(f"mon{e}" for e in EP)
TRAIN_VARS = ("known",) + tuple(f"mon{e}" for e in EP)
VARS2 = ("known",) + tuple(f"mon{e}" for e in EP)
REF_MODES = ("afe_only", "adc_only", "two_point")
JITTER = (0.90, 1.10)  # A2 ablation only
PATHS = ("passive", "single", "afe_only", "adc_only", "two_point")


def A(a: float) -> int:
    return int(round(a * 100))


def _draw_tol(rng: np.random.Generator) -> dict:
    return dict(afe_gain_scale=1 + rng.uniform(-0.05, 0.05), afe_tau_scale=1 + rng.uniform(-0.10, 0.10),
                adc_gain_scale=1 + rng.uniform(-0.02, 0.02), adc_offset_extra=rng.uniform(-0.010, 0.010),
                sensor_base_scale=1 + rng.uniform(-0.05, 0.05))


def _old(rec) -> np.ndarray:
    return np.concatenate([raw_features(rec), physics_features(rec)]).astype(np.float32)


def _spice_job(args):
    cond, fault, seed, amp, tol, wd = args
    r = spice_record(cond, fault, seed, Path(wd), amp=amp, tol=tol)
    return r


def build(seed: int, n_cond: int, workers: int, wd: Path) -> dict:
    n_rows = n_cond * len(FAULTS)
    groups = np.repeat(np.arange(n_cond), len(FAULTS))
    dev, test = next(GroupShuffleSplit(1, test_size=0.25, random_state=seed + 1).split(np.zeros(n_rows), groups=groups))
    sub = next(GroupShuffleSplit(1, test_size=0.15, random_state=seed + 2).split(dev, groups=groups[dev]))
    train, val = dev[sub[0]], dev[sub[1]]
    train_set, test_set = set(train.tolist()), set(test.tolist())
    rng = np.random.default_rng(seed)
    tol_rng, jit_rng = np.random.default_rng(seed + 10_000), np.random.default_rng(seed + 20_000)
    specs = []
    for cid in range(n_cond):
        cond = make_condition(rng)
        for ci, name in enumerate(FAULTS):
            fault = make_fault(name, rng)
            sd = int(rng.integers(0, 2**31 - 1))
            specs.append(dict(row=cid * len(FAULTS) + ci, cid=cid, ci=ci, cond=cond, fault=fault, sd=sd,
                              tol=_draw_tol(tol_rng), k=float(jit_rng.uniform(*JITTER))))
    S = {"train_old": {m: [] for m in PATHS}, "train_d": {(m, v): [] for m in REF_MODES for v in TRAIN_VARS},
         "jit_d": {v: [] for v in TRAIN_VARS[1:]}, "jit_c": {v: [] for v in TRAIN_VARS[1:]},
         "test_old": {a: {m: [] for m in PATHS} for a in AMPS}, "test_d": {a: {(m, v): [] for m in REF_MODES for v in VARS} for a in AMPS},
         "test_c": {a: {(m, v): [] for m in REF_MODES for v in VARS} for a in AMPS},
         "bh_d": {a: {v: [] for v in VARS2} for a in AMPS}, "sp_d": {a: {v: [] for v in VARS2} for a in AMPS},
         "sp_train_d": {v: [] for v in VARS2}}
    y_layer, y_fault, groups_test = [], [], []
    spice_tasks, spice_meta = [], []
    timing_recs = []
    for s in specs:
        r = s["row"]
        if r not in train_set and r not in test_set:
            continue
        u, nz = draw(seed, r)
        if r in train_set:
            for m in PATHS:
                rec = simulate_sample(s["cond"], s["fault"], active=(m != "passive"), seed=s["sd"] + MODE_OFFSET[m], probe_mode=MODES[m])
                S["train_old"][m].append(_old(rec))
                if m in REF_MODES:
                    for v, (d, c) in variant_descriptors(rec, u, nz, TRAIN_VARS, GUARD).items():
                        S["train_d"][(m, v)].append(d)
            recj = simulate_sample(s["cond"], s["fault"], active=True, seed=s["sd"] + MODE_OFFSET["two_point"], probe_mode="two_point", ref_scale=s["k"])
            for v, (d, c) in variant_descriptors(recj, u, nz, TRAIN_VARS[1:], GUARD).items():
                S["jit_d"][v].append(d); S["jit_c"][v].append(c)
            spice_tasks.append((s["cond"], s["fault"], s["sd"] + MODE_OFFSET["two_point"], 1.0, s["tol"], str(wd)))
            spice_meta.append(("train", r, None))
        else:
            y_layer.append(LAYER_ID[FAULT_TO_LAYER[FAULTS[s["ci"]]]]); y_fault.append(s["ci"]); groups_test.append(s["cid"])
            for a in AMPS:
                for m in PATHS:
                    rec = simulate_sample(s["cond"], s["fault"], active=(m != "passive"), seed=s["sd"] + MODE_OFFSET[m],
                                          probe_mode=MODES[m], ref_scale=a)
                    S["test_old"][a][m].append(_old(rec))
                    if m in REF_MODES:
                        for v, (d, c) in variant_descriptors(rec, u, nz, VARS, GUARD).items():
                            S["test_d"][a][(m, v)].append(d); S["test_c"][a][(m, v)].append(c)
                        if m == "two_point" and a == 1.0 and len(timing_recs) < 200:
                            timing_recs.append(rec)
                rec = simulate_sample(s["cond"], s["fault"], active=True, seed=s["sd"] + MODE_OFFSET["two_point"], probe_mode="two_point",
                                      ref_scale=a, **s["tol"])
                for v, (d, c) in variant_descriptors(rec, u, nz, VARS2, GUARD).items():
                    S["bh_d"][a][v].append(d)
                spice_tasks.append((s["cond"], s["fault"], s["sd"] + MODE_OFFSET["two_point"], a, s["tol"], str(wd)))
                spice_meta.append(("test", r, a))
    t0 = time.time()
    with Pool(workers) as pool:
        recs = pool.map(_spice_job, spice_tasks, chunksize=16)
    spice_seconds = time.time() - t0
    for (kind, r, a), rec in zip(spice_meta, recs):
        u, nz = draw(seed, r)
        for v, (d, c) in variant_descriptors(rec, u, nz, VARS2, GUARD).items():
            if kind == "train":
                S["sp_train_d"][v].append(d)
            else:
                S["sp_d"][a][v].append(d)

    def arr(x):
        return np.asarray(x, dtype=np.float32)

    D = {
        "groups": groups, "train": train, "val": val, "test": test,
        "y_train_layer": np.asarray([LAYER_ID[FAULT_TO_LAYER[FAULTS[i % len(FAULTS)]]] for i in sorted(train_set)]),
        "y_train_fault": np.asarray([i % len(FAULTS) for i in sorted(train_set)]),
        "y_layer": np.asarray(y_layer), "y_fault": np.asarray(y_fault), "test_cond": np.asarray(groups_test),
        "train_old": {m: arr(v) for m, v in S["train_old"].items()}, "train_d": {k: arr(v) for k, v in S["train_d"].items()},
        "jit_d": {v: arr(x) for v, x in S["jit_d"].items()}, "jit_c": {v: arr(x) for v, x in S["jit_c"].items()},
        "test_old": {a: {m: arr(v) for m, v in S["test_old"][a].items()} for a in AMPS},
        "test_d": {a: {k: arr(v) for k, v in S["test_d"][a].items()} for a in AMPS},
        "test_c": {a: {k: arr(v) for k, v in S["test_c"][a].items()} for a in AMPS},
        "bh_d": {a: {v: arr(x) for v, x in S["bh_d"][a].items()} for a in AMPS},
        "sp_d": {a: {v: arr(x) for v, x in S["sp_d"][a].items()} for a in AMPS},
        "sp_train_d": {v: arr(x) for v, x in S["sp_train_d"].items()},
        "timing_recs": timing_recs, "spice_seconds": spice_seconds, "n_spice": len(spice_tasks),
    }
    return D


def _n_params(est) -> int:
    m = est.named_steps["mlp"]
    return int(sum(w.size for w in m.coefs_) + sum(b.size for b in m.intercepts_))


def train_and_predict(D: dict) -> tuple[dict, dict]:
    ytr = {"layer": D["y_train_layer"], "fault": D["y_train_fault"]}
    preds, info = {}, {}
    ests = {}

    def fit(X, target, init):
        est = _classifier(init)
        t0 = time.time(); est.fit(X, ytr[target]); return est, time.time() - t0

    def put(scn, model, init, target, est, X):
        t0 = time.time(); p = est.predict(X); dt = time.time() - t0
        preds[f"{scn}|{model}|{init}|{target}"] = p.astype(np.int8)
        return dt / max(len(X), 1) * 1000

    # ---- Part 1 models (behavioral, tolerance-free test sets) ----
    for init in INITS:
        for target in ("layer", "fault"):
            # A0: previous method + passive/single/one-point baselines (old features, nominal training)
            for m in PATHS:
                est, ts = fit(D["train_old"][m], target, init)
                for a in AMPS:
                    for v in VARS:
                        put(f"p1_a{A(a)}_{v}", f"{m}_mlp@A0", init, target, est, D["test_old"][a][m])
                info[f"{m}_mlp@A0|{init}|{target}"] = {"train_seconds": ts, "params": _n_params(est)}
            # A1c: Revision 1, clean (known-reference) training
            for m in REF_MODES:
                est, ts = fit(D["train_d"][(m, "known")], target, init)
                ests[(f"{m}_mlp@A1c", init, target)] = est
                for a in AMPS:
                    for v in VARS:
                        put(f"p1_a{A(a)}_{v}", f"{m}_mlp@A1c", init, target, est, D["test_d"][a][(m, v)])
                info[f"{m}_mlp@A1c|{init}|{target}"] = {"train_seconds": ts, "params": _n_params(est)}
            # A1m(E): Revision 1, matched monitor-error training
            for E in EP:
                for m in REF_MODES:
                    est, ts = fit(D["train_d"][(m, f"mon{E}")], target, init)
                    ests[(f"{m}_mlp@A1m{E}", init, target)] = est
                    for a in AMPS:
                        put(f"p1_a{A(a)}_mon{E}", f"{m}_mlp@A1m{E}", init, target, est, D["test_d"][a][(m, f"mon{E}")])
                    info[f"{m}_mlp@A1m{E}|{init}|{target}"] = {"train_seconds": ts, "params": _n_params(est)}
                # A2m(E): Revision-2 conditioning ablation (jitter + monitor error), two-point only
                X = np.hstack([D["jit_d"][f"mon{E}"], D["jit_c"][f"mon{E}"]])
                est, ts = fit(X, target, init)
                for a in AMPS:
                    Xt = np.hstack([D["test_d"][a][("two_point", f"mon{E}")], D["test_c"][a][("two_point", f"mon{E}")]])
                    put(f"p1_a{A(a)}_mon{E}", f"two_point_mlp@A2m{E}", init, target, est, Xt)
                info[f"two_point_mlp@A2m{E}|{init}|{target}"] = {"train_seconds": ts, "params": _n_params(est)}

    # ---- Part 2: behavioral->behavioral (BB), behavioral->ngspice (BS), mixed->ngspice (MS) ----
    infer_ms = {}
    for init in INITS:
        for target in ("layer", "fault"):
            for v in VARS2:
                name = "A1c" if v == "known" else f"A1m{v[3:]}"
                est = ests[(f"two_point_mlp@{name}", init, target)]
                for a in AMPS:
                    dt = put(f"bh_a{A(a)}_{v}", f"two_point_mlp@{name}", init, target, est, D["bh_d"][a][v])
                    ds = put(f"sp_a{A(a)}_{v}", f"two_point_mlp@{name}", init, target, est, D["sp_d"][a][v])
                    infer_ms[(v, init, target)] = (dt, ds)
                # mixed training: behavioral clean/matched rows + ngspice rows (same descriptor variant)
                Xmix = np.vstack([D["train_d"][("two_point", v)], D["sp_train_d"][v]])
                ymix = np.concatenate([ytr[target], ytr[target]])
                mest = _classifier(init)
                t0 = time.time(); mest.fit(Xmix, ymix); ts = time.time() - t0
                mname = "MSc" if v == "known" else f"MS{v[3:]}"
                for a in AMPS:
                    put(f"sp_a{A(a)}_{v}", f"two_point_mlp@{mname}", init, target, mest, D["sp_d"][a][v])
                    put(f"bh_a{A(a)}_{v}", f"two_point_mlp@{mname}", init, target, mest, D["bh_d"][a][v])
                info[f"two_point_mlp@{mname}|{init}|{target}"] = {"train_seconds": ts, "params": _n_params(mest)}
    # descriptor extraction time (per sample) for the two-point path
    t0 = time.time()
    for rec in D["timing_recs"]:
        ref_descriptors(rec, GUARD)
    info["descriptor_extraction_ms_per_sample"] = (time.time() - t0) / max(len(D["timing_recs"]), 1) * 1000
    info["mlp_predict_ms_per_sample_behavioral|spice"] = {f"{k[0]}|{k[1]}|{k[2]}": list(v) for k, v in infer_ms.items()}
    info["spice_seconds_total"] = D["spice_seconds"]
    info["spice_seconds_per_sample_single_core_equivalent_note"] = "wall time of the pool; see meta for workers"
    return preds, info


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset-seed", type=int, required=True)
    ap.add_argument("--n-cond", type=int, default=350)
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--out-dir", type=Path, default=None)
    args = ap.parse_args()
    out = args.out_dir or OUT_ROOT / f"seed_{args.dataset_seed}"
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    with tempfile.TemporaryDirectory(prefix="spice_") as wd:
        D = build(args.dataset_seed, args.n_cond, args.workers, Path(wd))
    g = D["groups"]
    meta = {"dataset_seed": args.dataset_seed, "split_random_state": args.dataset_seed + 1, "val_random_state": args.dataset_seed + 2,
            "guard": GUARD, "amplitudes": list(AMPS), "monitor_error_percent": list(EP), "workers": args.workers,
            "conditions_total": int(len(set(g))), "train_conditions": int(len(set(g[D["train"]]))),
            "val_conditions": int(len(set(g[D["val"]]))), "test_conditions": int(len(set(g[D["test"]]))),
            "n_ngspice_runs": D["n_spice"], "ngspice_wall_seconds": round(D["spice_seconds"], 1), "build_seconds": round(time.time() - t0, 1),
            "overlap": int(len(set(g[D["train"]]) & set(g[D["test"]])) + len(set(g[D["val"]]) & set(g[D["test"]]))
                           + len(set(g[D["train"]]) & set(g[D["val"]])))}
    assert meta["overlap"] == 0
    print(meta, flush=True)
    preds, info = train_and_predict(D)
    arrays = {"y_layer": D["y_layer"].astype(np.int8), "y_fault": D["y_fault"].astype(np.int8), "cond": D["test_cond"].astype(np.int32)}
    arrays.update(preds)
    np.savez_compressed(out / "predictions.npz", **arrays)
    (out / "model_info.json").write_text(json.dumps(info, indent=1), encoding="utf-8")
    meta["total_seconds"] = round(time.time() - t0, 1)
    (out / "meta.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")
    print("DONE", meta, flush=True)


if __name__ == "__main__":
    main()
