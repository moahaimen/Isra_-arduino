"""Controlled TCN revision and fair MLP/RF baseline comparison.

Everything uses the *same* dataset (``build_paired_dataset``), the *same*
operating-condition-disjoint split as ``run_feasibility`` / ``run_tcn``
(``GroupShuffleSplit(test_size=0.25, random_state=seed+1)``), and the *same*
two-point active records.  Outputs go only to ``tcn_v2_results/`` and
``tcn_comparison/``; v1 outputs are never touched.

Variants (each adds exactly one change to the previous one):

  v1_repro            original PhysicsGuidedTCN, raw inputs, as in run_tcn
  v2a_standardize     + train-fit standardisation of waveform and physics
  v2b_binpool         + time-binned pooling instead of global mean
  v2c_refchannels     + known reference schedules as input channels
  v2d_earlystop       + group-wise validation split, best-epoch selection
  v2d_no_physloss     v2d with the parameter (physics) loss weight set to 0
  v2d_wave_only       v2d with the physics descriptors zeroed (waveform only)
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, recall_score
from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import StandardScaler

from .features import physics_features, raw_features
from .run_feasibility import _classifier, _rf_classifier
from .simulate import FAULTS, LAYERS, build_paired_dataset
from .tcn_model import PhysicsGuidedTCN, TCNConfig, physics_guided_loss
from .tcn_v2 import TCNv2, TCNv2Config

ROOT = Path(__file__).resolve().parents[1]
V1_RECORDED = {
    "layer_accuracy": 0.5744949494949495,
    "layer_macro_f1": 0.46699861953957245,
    "fault_accuracy": 0.31313131313131315,
    "fault_macro_f1": 0.2899544333649138,
}

VARIANTS = {
    # name: dict(std, pool, ref, early, phys_w, zero_phys)
    "v1_repro": dict(model="v1", std=False, pool="mean", ref=False, early=False, phys_w=0.20, zero_phys=False),
    "v2a_standardize": dict(model="v2", std=True, pool="mean", ref=False, early=False, phys_w=0.20, zero_phys=False),
    "v2b_binpool": dict(model="v2", std=True, pool="bins", ref=False, early=False, phys_w=0.20, zero_phys=False),
    "v2c_refchannels": dict(model="v2", std=True, pool="bins", ref=True, early=False, phys_w=0.20, zero_phys=False),
    "v2d_earlystop": dict(model="v2", std=True, pool="bins", ref=True, early=True, phys_w=0.20, zero_phys=False),
    "v2d_no_physloss": dict(model="v2", std=True, pool="bins", ref=True, early=True, phys_w=0.0, zero_phys=False),
    "v2d_wave_only": dict(model="v2", std=True, pool="bins", ref=True, early=True, phys_w=0.20, zero_phys=True),
}


def _downsample(arr: np.ndarray, n: int = 96) -> np.ndarray:
    idx = np.linspace(0, len(arr) - 1, n).astype(int)
    return np.asarray(arr, dtype=np.float32)[idx]


def load_data(samples_per_class: int, seed: int, cache: Path) -> dict[str, np.ndarray]:
    if cache.exists():
        with np.load(cache) as z:
            return {k: z[k] for k in z.files}
    t0 = time.time()
    records = build_paired_dataset(samples_per_class, seed)["records"]["active_two_point"]
    layer_ids = {name: i for i, name in enumerate(LAYERS)}
    data = {
        "wave": np.vstack([raw_features(r) for r in records]).astype(np.float32),
        "afe_ref": np.vstack([_downsample(r["afe_reference"]) for r in records]),
        "adc_ref": np.vstack([_downsample(r["adc_reference"]) for r in records]),
        "physics": np.vstack([physics_features(r) for r in records]).astype(np.float32),
        "y_layer": np.asarray([layer_ids[str(r["layer"])] for r in records], dtype=np.int64),
        "y_fault": np.asarray([int(r["class_id"]) for r in records], dtype=np.int64),
        "groups": np.asarray([int(r["condition_id"]) for r in records], dtype=np.int64),
        "severity": np.asarray([float(r["severity"]) for r in records], dtype=np.float32),
    }
    cache.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(cache, **data)
    print(f"built dataset in {time.time() - t0:.0f}s -> {cache}")
    return data


def metrics(y_layer, p_layer, y_fault, p_fault) -> dict[str, object]:
    return {
        "layer_accuracy": float(accuracy_score(y_layer, p_layer)),
        "layer_macro_f1": float(f1_score(y_layer, p_layer, average="macro")),
        "fault_accuracy": float(accuracy_score(y_fault, p_fault)),
        "fault_macro_f1": float(f1_score(y_fault, p_fault, average="macro")),
        "fault_per_class_recall": {
            FAULTS[i]: float(v)
            for i, v in enumerate(recall_score(y_fault, p_fault, labels=np.arange(len(FAULTS)), average=None, zero_division=0))
        },
    }


def _val_score(out, yl, yf) -> float:
    pl = out["layer_logits"].argmax(1).cpu().numpy()
    pf = out["fault_logits"].argmax(1).cpu().numpy()
    return 0.5 * (f1_score(yl, pl, average="macro") + f1_score(yf, pf, average="macro"))


def run_tcn_variant(name: str, cfg: dict, data: dict, train_idx, test_idx, init_seed: int, epochs: int) -> dict:
    import torch
    from torch.utils.data import DataLoader, TensorDataset

    torch.manual_seed(init_seed)
    np.random.seed(init_seed)
    device = torch.device("cpu")
    fit_idx = train_idx
    val_idx = None
    if cfg["early"]:
        gs = GroupShuffleSplit(n_splits=1, test_size=0.15, random_state=init_seed + 100)
        a, b = next(gs.split(train_idx, groups=data["groups"][train_idx]))
        fit_idx, val_idx = train_idx[a], train_idx[b]

    wave = data["wave"][:, None, :]
    physics = data["physics"].copy()
    if cfg["zero_phys"]:
        physics[:] = 0.0
    channels = [data["wave"]]
    if cfg["ref"]:
        channels += [data["afe_ref"], data["adc_ref"]]
    x = np.stack(channels, axis=1).astype(np.float32) if cfg["ref"] else wave.astype(np.float32)
    raw_phys = data["physics"]  # loss targets always use the unscaled descriptors

    if cfg["std"]:
        mu = x[fit_idx].mean(axis=(0, 2), keepdims=True)
        sd = x[fit_idx].std(axis=(0, 2), keepdims=True) + 1e-6
        x = (x - mu) / sd
        if not cfg["zero_phys"]:
            scaler = StandardScaler().fit(physics[fit_idx])
            physics = scaler.transform(physics).astype(np.float32)

    if cfg["model"] == "v1":
        model = PhysicsGuidedTCN(TCNConfig(physics_dim=physics.shape[1]))
    else:
        model = TCNv2(TCNv2Config(waveform_channels=x.shape[1], physics_dim=physics.shape[1], pool=cfg["pool"]))
    model.to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=1e-4)

    def tens(idx):
        return (
            torch.from_numpy(x[idx]), torch.from_numpy(physics[idx]),
            torch.from_numpy(data["y_layer"][idx]), torch.from_numpy(data["y_fault"][idx]),
            torch.from_numpy(data["severity"][idx]), torch.from_numpy(raw_phys[idx]),
        )

    gen = torch.Generator().manual_seed(init_seed)
    loader = DataLoader(TensorDataset(*tens(fit_idx)), batch_size=64, shuffle=True, generator=gen)
    best_score, best_state, best_epoch = -1.0, None, epochs
    for epoch in range(epochs):
        model.train()
        for xb, pb, lb, fb, sb, rb in loader:
            out = model(xb, pb)
            loss = physics_guided_loss(out, lb, fb, sb, rb, physics_weight=cfg["phys_w"])["total"]
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
        if val_idx is not None:
            model.eval()
            with torch.no_grad():
                v = tens(val_idx)
                score = _val_score(model(v[0], v[1]), data["y_layer"][val_idx], data["y_fault"][val_idx])
            if score > best_score:
                best_score, best_epoch = score, epoch + 1
                best_state = {k: t.detach().clone() for k, t in model.state_dict().items()}
    if best_state is not None:
        model.load_state_dict(best_state)

    model.eval()
    with torch.no_grad():
        t = tens(test_idx)
        out = model(t[0], t[1])
    res = metrics(
        data["y_layer"][test_idx], out["layer_logits"].argmax(1).numpy(),
        data["y_fault"][test_idx], out["fault_logits"].argmax(1).numpy(),
    )
    res.update(variant=name, init_seed=init_seed, epochs=epochs, selected_epoch=best_epoch,
               train_rows=int(len(fit_idx)), val_rows=int(0 if val_idx is None else len(val_idx)),
               test_rows=int(len(test_idx)))
    return res


def run_baselines(data: dict, train_idx, test_idx, seeds: list[int]) -> list[dict]:
    feats = {
        "raw": data["wave"],
        "physics": data["physics"],
        "raw_plus_physics": np.hstack([data["wave"], data["physics"]]),
    }
    runs = []
    for feat_name, x in feats.items():
        for kind in ("mlp", "rf"):
            for s in seeds:
                preds = {}
                for target in ("layer", "fault"):
                    y = data[f"y_{target}"]
                    model = _classifier(s) if kind == "mlp" else _rf_classifier(s)
                    model.fit(x[train_idx], y[train_idx])
                    preds[target] = model.predict(x[test_idx])
                res = metrics(data["y_layer"][test_idx], preds["layer"], data["y_fault"][test_idx], preds["fault"])
                res.update(variant=f"{kind}_{feat_name}", init_seed=s, test_rows=int(len(test_idx)))
                runs.append(res)
                print(f"  {res['variant']:24s} seed={s} layerF1={res['layer_macro_f1']:.3f} faultF1={res['fault_macro_f1']:.3f}", flush=True)
    return runs


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--samples-per-class", type=int, default=350)
    p.add_argument("--epochs", type=int, default=40)
    p.add_argument("--seed", type=int, default=20261014)
    p.add_argument("--init-seeds", type=int, default=3)
    p.add_argument("--variants", default=",".join(VARIANTS))
    p.add_argument("--skip-baselines", action="store_true")
    p.add_argument("--out-results", type=Path, default=ROOT / "tcn_v2_results")
    p.add_argument("--out-comparison", type=Path, default=ROOT / "tcn_comparison")
    args = p.parse_args()
    args.out_results.mkdir(parents=True, exist_ok=True)
    args.out_comparison.mkdir(parents=True, exist_ok=True)

    data = load_data(args.samples_per_class, args.seed, args.out_comparison / "dataset_cache.npz")
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=args.seed + 1)
    train_idx, test_idx = next(splitter.split(data["wave"], data["y_layer"], data["groups"]))
    split_info = {
        "train_conditions": int(len(set(data["groups"][train_idx]))),
        "test_conditions": int(len(set(data["groups"][test_idx]))),
        "train_rows": int(len(train_idx)),
        "test_rows": int(len(test_idx)),
        "overlap_conditions": int(len(set(data["groups"][train_idx]) & set(data["groups"][test_idx]))),
        "test_idx_sha": int(np.sum(test_idx.astype(np.int64) * np.arange(1, len(test_idx) + 1)) % 1_000_003),
    }
    print("split:", split_info, flush=True)
    assert split_info["overlap_conditions"] == 0
    seeds = [args.seed + i for i in range(args.init_seeds)]

    if not args.skip_baselines:
        base_path = args.out_comparison / "baseline_runs.json"
        print("baselines (same split):", flush=True)
        base_path.write_text(json.dumps(run_baselines(data, train_idx, test_idx, seeds), indent=2), encoding="utf-8")

    for name in args.variants.split(","):
        for s in seeds:
            path = args.out_results / f"{name}_seed{s}.json"
            if path.exists():
                continue
            t0 = time.time()
            res = run_tcn_variant(name, VARIANTS[name], data, train_idx, test_idx, s, args.epochs)
            res["seconds"] = round(time.time() - t0, 1)
            path.write_text(json.dumps(res, indent=2), encoding="utf-8")
            print(f"  {name:18s} seed={s} layerF1={res['layer_macro_f1']:.3f} faultF1={res['fault_macro_f1']:.3f} "
                  f"(epoch {res['selected_epoch']}, {res['seconds']}s)", flush=True)
    (args.out_comparison / "split_info.json").write_text(
        json.dumps({**split_info, "tcn_v1_recorded": V1_RECORDED}, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
