"""POST-HOC exploratory diagnostic of the behavioral->ngspice gap (development seed 20261098; NOT part of the frozen decision).

Decomposes the transfer drop into (i) circuit-domain effects and (ii) the extra circuit noise added to the ngspice samples, and
ranks descriptor groups by their contribution, using matched E=2% training on behavioral data.
"""
import json
import tempfile
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
from sklearn.metrics import f1_score
from sklearn.model_selection import GroupShuffleSplit

from .monitor_model import draw, variant_descriptors
from .ref_features import FEATURE_NAMES
from .run_feasibility import _classifier
from .run_multiseed import INITS, LAYER_ID, MODE_OFFSET
from .run_reference_monitor import GUARD, _draw_tol
from .simulate import FAULT_TO_LAYER, FAULTS, make_condition, make_fault, simulate_sample
from .spice_domain import spice_record

SEED, N_COND, AMPS = 20261098, 200, (0.8, 1.0, 1.2)
ROOT = Path(__file__).resolve().parents[1]


def _job(a):
    cond, fault, seed, amp, tol, wd, noise = a
    return spice_record(cond, fault, seed, Path(wd), amp=amp, tol=tol, extra_noise=noise)


def main():
    groups = np.repeat(np.arange(N_COND), 9)
    dev, test = next(GroupShuffleSplit(1, test_size=0.25, random_state=SEED + 1).split(np.zeros(N_COND * 9), groups=groups))
    sub = next(GroupShuffleSplit(1, test_size=0.15, random_state=SEED + 2).split(dev, groups=groups[dev]))
    train = dev[sub[0]]
    train_set, test_set = set(train.tolist()), set(test.tolist())
    rng, tol_rng = np.random.default_rng(SEED), np.random.default_rng(SEED + 10_000)
    specs = []
    for cid in range(N_COND):
        cond = make_condition(rng)
        for ci, name in enumerate(FAULTS):
            fault = make_fault(name, rng); sd = int(rng.integers(0, 2**31 - 1))
            specs.append((cid * 9 + ci, ci, cond, fault, sd, _draw_tol(tol_rng)))
    ytr = [];  Xtr = []
    Xbh = {a: [] for a in AMPS}; ylt = []
    tasks, meta = [], []
    for row, ci, cond, fault, sd, tol in specs:
        u, nz = draw(SEED, row)
        if row in train_set:
            rec = simulate_sample(cond, fault, active=True, seed=sd + MODE_OFFSET["two_point"], probe_mode="two_point")
            Xtr.append(variant_descriptors(rec, u, nz, ["mon2"], GUARD)["mon2"][0]); ytr.append(LAYER_ID[FAULT_TO_LAYER[FAULTS[ci]]])
        elif row in test_set:
            ylt.append(LAYER_ID[FAULT_TO_LAYER[FAULTS[ci]]])
            for a in AMPS:
                rec = simulate_sample(cond, fault, active=True, seed=sd + MODE_OFFSET["two_point"], probe_mode="two_point", ref_scale=a, **tol)
                Xbh[a].append(variant_descriptors(rec, u, nz, ["mon2"], GUARD)["mon2"][0])
                for noise in (True, False):
                    tasks.append((cond, fault, sd + MODE_OFFSET["two_point"], a, tol, None, noise)); meta.append((row, a, noise))
    t0 = time.time()
    with tempfile.TemporaryDirectory(prefix="spice_") as wd:
        tasks = [t[:5] + (wd,) + t[6:] for t in tasks]
        with Pool(6) as p:
            recs = p.map(_job, tasks, chunksize=16)
    print(f"{len(tasks)} ngspice runs in {time.time()-t0:.0f}s", flush=True)
    Xsp = {(a, n): [] for a in AMPS for n in (True, False)}
    for (row, a, noise), rec in zip(meta, recs):
        u, nz = draw(SEED, row)
        Xsp[(a, noise)].append(variant_descriptors(rec, u, nz, ["mon2"], GUARD)["mon2"][0])
    Xtr, ytr, ylt = np.asarray(Xtr), np.asarray(ytr), np.asarray(ylt)
    Xbh = {a: np.asarray(v) for a, v in Xbh.items()}; Xsp = {k: np.asarray(v) for k, v in Xsp.items()}

    def evaluate(cols):
        res = {"BB": [], "BS_with_extra_noise": [], "BS_circuit_only": []}
        for init in INITS:
            m = _classifier(init).fit(Xtr[:, cols], ytr)
            for key, X in (("BB", Xbh), ("BS_with_extra_noise", {a: Xsp[(a, True)] for a in AMPS}), ("BS_circuit_only", {a: Xsp[(a, False)] for a in AMPS})):
                pred = np.concatenate([m.predict(X[a][:, cols]) for a in AMPS]); y = np.concatenate([ylt] * len(AMPS))
                res[key].append(f1_score(y, pred, average="macro"))
        return {k: float(np.mean(v)) for k, v in res.items()}

    allc = list(range(len(FEATURE_NAMES)))
    out = {"full": evaluate(allc)}
    groups_ = {"rise_fractions": ["rise_2", "rise_5", "rise_10", "rise_20", "rise_30"], "noise": ["adc_noise", "afe_noise", "sens_hf"],
               "settling_error": ["settle_err1", "settle_err2"], "sensor_stats": ["sens_mean", "sens_std", "sens_ptp", "sens_slope"],
               "saturation": ["ymax_s", "top_frac_s"], "calibration": ["g_adc", "o_adc", "G_afe", "o_afe"]}
    for g, names in groups_.items():
        out[f"without_{g}"] = evaluate([i for i, n in enumerate(FEATURE_NAMES) if n not in names])
    for g, names in groups_.items():
        out[f"drop_{g}"] = out[f"without_{g}"]["BB"] - out[f"without_{g}"]["BS_with_extra_noise"]
    # paired descriptor shifts at x1.0 (ngspice with extra noise minus behavioral), in units of behavioral std
    sd = Xbh[1.0].std(0) + 1e-9
    shift = {n: float(np.mean(Xsp[(1.0, True)][:, i] - Xbh[1.0][:, i]) / sd[i]) for i, n in enumerate(FEATURE_NAMES)}
    shift_abs = {n: float(np.mean(np.abs(Xsp[(1.0, True)][:, i] - Xbh[1.0][:, i])) / sd[i]) for i, n in enumerate(FEATURE_NAMES)}
    out["mean_shift_sigma"] = shift; out["mean_abs_shift_sigma"] = shift_abs
    (ROOT / "reference_monitor_final" / "reference_monitor_results" / "exploratory_spice_gap_diagnostic.json").write_text(json.dumps(out, indent=1))
    print(json.dumps({k: v for k, v in out.items() if k in ("full",) or k.startswith("drop_")}, indent=1))
    print("largest mean |shift| (sigma):", sorted(shift_abs.items(), key=lambda kv: -kv[1])[:8])


if __name__ == "__main__":
    main()
