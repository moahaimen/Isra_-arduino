"""POST-HOC exploratory diagnostic (not part of the frozen protocol, does not alter the verdict).

Question: is the reference-amplitude failure a property of the measurement physics or of models that
consume the absolute waveform?  Tests small MLPs on (a) the 8 known-reference calibration descriptors
(ADC gain/offset/span/noise, AFE gain/offset/span/noise = physics columns 30-37) and (b) all 38 descriptors,
trained on nominal data and evaluated under the same shifted test sets.
"""
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import f1_score, recall_score

from .run_feasibility import _classifier
from .run_multiseed import INITS, build

ROOT = Path(__file__).resolve().parents[1]
out = {}
for seed in (20261017, 20261018, 20261019):
    d = build(seed)
    tr, te = d["train"], d["test"]
    yl = d["y_layer"]
    nom = d["nominal"]["two_point"]["phys"]
    res = {}
    # descriptor invariance: mean relative change of estimated gains/offsets under the shift
    for scn in ("ref_m20", "ref_p20", "tolerance"):
        sh = d["shifted"][scn]["two_point"]["phys"]
        res[f"descriptor_shift|{scn}"] = {
            name: float(np.mean(np.abs(sh[:, c] - nom[te][:, c])) / (np.std(nom[tr][:, c]) + 1e-9))
            for name, c in (("adc_gain", 30), ("adc_offset", 31), ("afe_gain", 34), ("afe_offset", 35))}
    for fname, cols in (("calib8", slice(30, 38)), ("physics38", slice(0, 38))):
        scores = {s: [] for s in ("nominal", "tolerance", "ref_m20", "ref_p20")}
        rec = {s: [] for s in scores}
        for init in INITS:
            m = _classifier(init).fit(nom[tr][:, cols], yl[tr])
            for scn in scores:
                x = nom[te] if scn == "nominal" else d["shifted"][scn]["two_point"]["phys"]
                p = m.predict(x[:, cols])
                scores[scn].append(f1_score(yl[te], p, average="macro"))
                rec[scn].append(recall_score(yl[te], p, labels=[0, 1, 2, 3], average=None, zero_division=0))
        res[fname] = {s: {"layer_macro_f1": float(np.mean(v)),
                          "recall_healthy_sensor_afe_adc": np.mean(rec[s], axis=0).round(3).tolist()}
                      for s, v in scores.items()}
    out[str(seed)] = res
    print(seed, json.dumps(res["calib8"]), flush=True)
agg = {}
for fname in ("calib8", "physics38"):
    agg[fname] = {scn: float(np.mean([out[s][fname][scn]["layer_macro_f1"] for s in out]))
                  for scn in ("nominal", "tolerance", "ref_m20", "ref_p20")}
out["mean_layer_macro_f1"] = agg
(ROOT / "multiseed_results" / "exploratory_ref_shift_diagnostic.json").write_text(json.dumps(out, indent=1))
print(json.dumps(agg, indent=1))
print(json.dumps(out["20261017"]["descriptor_shift|ref_m20"]), json.dumps(out["20261017"]["descriptor_shift|tolerance"]))
