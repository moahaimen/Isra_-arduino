"""Numbers and tables for the paper package, read ONLY from existing result files (no model is trained here).

Every scalar is registered with its source file and locator (see NUMBER_PROVENANCE.csv); every table row is written
to PAPER_TABLES.csv with its source.  Nothing is typed by hand except code constants of the simulator (Table T1),
which cite the source function.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PR = "phase_robust_final/phase_robust_results/"
RM = "reference_monitor_final/reference_monitor_results/"
V2 = "reference_v2_results/"
MS = "multiseed_results/"
SEEDS = (20261026, 20261027, 20261028)


def jload(rel):
    return json.loads((ROOT / rel).read_text())


def cload(rel):
    return pd.read_csv(ROOT / rel)


class Registry:
    def __init__(self):
        self.vals = {}       # token -> formatted string
        self.prov = []       # provenance rows
        self.tables = {}     # table id -> (title, DataFrame, source note)
        self.long = []       # long-format rows for PAPER_TABLES.csv

    def put(self, token, value, src, loc, fmt="{:.3f}"):
        s = fmt.format(value) if not isinstance(value, str) else value
        self.vals[token] = s
        self.prov.append({"token": token, "value": s, "raw_value": value if not isinstance(value, str) else s, "source_file": src, "locator": loc})
        return value

    def table(self, tid, title, df, sources, notes=""):
        self.tables[tid] = (title, df, sources, notes)
        for _, r in df.iterrows():
            row_label = " | ".join(str(r[c]) for c in df.columns[:df.attrs.get("n_keys", 1)])
            for c in df.columns[df.attrs.get("n_keys", 1):]:
                self.long.append({"table_id": tid, "table_title": title, "row": row_label, "column": c, "value": r[c], "source_files": sources})


def ci(d, key_lo="ci_low", key_hi="ci_high"):
    return f"{d['diff']:+.3f} [{d[key_lo]:+.3f}, {d[key_hi]:+.3f}]"


def build() -> Registry:
    R = Registry()
    dec = jload(PR + "decision_rules.json")
    att = cload(PR + "attribution_arms.csv")
    attc = cload(PR + "attribution_comparisons.csv")
    amp = cload(PR + "amplitude_curves.csv")
    sep = cload(PR + "afe_adc_separation.csv")
    pcl = cload(PR + "per_class_recall_layer.csv")
    pcf = cload(PR + "per_class_recall_fault.csv")
    ctl = jload(PR + "no_monitor_control.json")["no_monitor_control_layer_macro_f1"]
    tim = jload(PR + "timing_and_parameters.json")
    meta = {s: jload(PR + f"seed_{s}/meta.json") for s in SEEDS}
    rm = jload(RM + "decision_rules.json")
    rm_amp = cload(RM + "amplitude_curves.csv")
    v2 = jload(V2 + "decision_rules.json")
    ms = jload(MS + "decision_rules.json")
    rmal = jload(RM + "exploratory_spice_alignment.json")

    # ------------------------------------------------------------ protocol scalars
    R.put("SEEDS", ", ".join(map(str, SEEDS)), PR + "seed_*/meta.json", "dataset_seed")
    m0 = meta[SEEDS[0]]
    for k in ("train_conditions", "val_conditions", "test_conditions"):
        assert all(meta[s][k] == m0[k] for s in SEEDS)
        R.put(k.upper(), m0[k], PR + "seed_*/meta.json", k, "{:d}")
    R.put("N_SPICE_PER_SEED", m0["n_ngspice_runs"], PR + "seed_*/meta.json", "n_ngspice_runs", "{:,d}")
    R.put("N_SPICE_TOTAL", sum(meta[s]["n_ngspice_runs"] for s in SEEDS), PR + "seed_*/meta.json", "sum n_ngspice_runs", "{:,d}")
    R.put("N_TEST_ROWS", m0["test_conditions"] * 9, PR + "seed_*/meta.json", "test_conditions x 9 faults", "{:d}")
    R.put("N_BOOT", 5000, "phase_robust_final/PROTOCOL_PHASE_ROBUST_FROZEN.md", "section 4", "{:d}")

    # ------------------------------------------------------------ headline numbers
    R.put("N_BH", dec["N"]["bh"], PR + "decision_rules.json", "N.bh")
    R.put("N_SP", dec["N"]["sp"], PR + "decision_rules.json", "N.sp")
    R.put("DECISION", dec["decision"], PR + "decision_rules.json", "decision", "{}")
    E2 = dec["E"]["primary_E2"]
    R.put("E_BB", E2["BB"], PR + "decision_rules.json", "E.primary_E2.BB")
    R.put("E_BS", E2["BS"], PR + "decision_rules.json", "E.primary_E2.BS")
    R.put("E_MS", E2["MS"], PR + "decision_rules.json", "E.primary_E2.MS")
    R.put("E_DROP", E2["drop"], PR + "decision_rules.json", "E.primary_E2.drop")
    R.put("E_DROP_LO", E2["drop_ci"][0], PR + "decision_rules.json", "E.primary_E2.drop_ci[0]")
    R.put("E_DROP_HI", E2["drop_ci"][1], PR + "decision_rules.json", "E.primary_E2.drop_ci[1]")
    R.put("E_MS_GAIN", E2["MS_minus_BS"], PR + "decision_rules.json", "E.primary_E2.MS_minus_BS", "{:+.3f}")
    R.put("E_MS_GAIN_LO", E2["MS_minus_BS_ci"][0], PR + "decision_rules.json", "E.primary_E2.MS_minus_BS_ci[0]", "{:+.3f}")
    R.put("E_MS_GAIN_HI", E2["MS_minus_BS_ci"][1], PR + "decision_rules.json", "E.primary_E2.MS_minus_BS_ci[1]", "{:+.3f}")
    drops = [v["drop"] for v in dec["E"]["all"].values()]
    R.put("E_DROP_MIN", min(drops), PR + "decision_rules.json", "min E.all[*].drop")
    R.put("E_DROP_MAX", max(drops), PR + "decision_rules.json", "max E.all[*].drop")
    pE = rm["E"]["primary_matched_E2"]
    R.put("PREV_E_DROP", pE["drop_BB_minus_BS"], RM + "decision_rules.json", "E.primary_matched_E2.drop_BB_minus_BS")
    R.put("PREV_E_LO", pE["drop_ci"][0], RM + "decision_rules.json", "E.primary_matched_E2.drop_ci[0]")
    R.put("PREV_E_HI", pE["drop_ci"][1], RM + "decision_rules.json", "E.primary_matched_E2.drop_ci[1]")
    R.put("PREV_E_BB", pE["BB"], RM + "decision_rules.json", "E.primary_matched_E2.BB")
    R.put("PREV_E_BS", pE["BS"], RM + "decision_rules.json", "E.primary_matched_E2.BS")
    R.put("PREV_DECISION", rm["decision"], RM + "decision_rules.json", "decision", "{}")
    R.put("PREV_C_MAX", max(v["cross_confusion"] for v in rm["C"]["detail"].values()), RM + "decision_rules.json", "max C.detail[*].cross_confusion")
    # alignment diagnostic of the failed stage (development seed)
    R.put("ALIGN_BB", rmal["BB"], RM + "exploratory_spice_alignment.json", "BB")
    R.put("ALIGN_FROZEN", rmal["BS_frozen_alignment"], RM + "exploratory_spice_alignment.json", "BS_frozen_alignment")
    R.put("ALIGN_ZOH", rmal["BS_zoh_aligned"], RM + "exploratory_spice_alignment.json", "BS_zoh_aligned")
    R.put("ALIGN_RISE2_FROZEN", rmal["mean_abs_shift_sigma_frozen"]["rise_2"], RM + "exploratory_spice_alignment.json", "mean_abs_shift_sigma_frozen.rise_2", "{:.2f}")

    # A / C / D / B / G
    A_ = dec["A"]["detail"]
    amin = min(A_.items(), key=lambda kv: kv[1]["retention"])
    R.put("A_MIN_RET", amin[1]["retention"], PR + "decision_rules.json", f"A.detail['{amin[0]}'].retention")
    C_ = dec["C"]["detail"]
    cmax = max(C_.items(), key=lambda kv: kv[1]["cross_confusion"])
    R.put("C_MAX", cmax[1]["cross_confusion"], PR + "decision_rules.json", f"C.detail['{cmax[0]}'].cross_confusion")
    D_ = dec["D"]["detail"]
    dmin = min(D_.items(), key=lambda kv: kv[1]["retention"])
    R.put("D_MIN_RET", dmin[1]["retention"], PR + "decision_rules.json", f"D.detail['{dmin[0]}'].retention")
    B_ = dec["B"]["detail"]
    bmin = min(B_.items(), key=lambda kv: kv[1]["ci_low"])
    R.put("B_MIN_CI", bmin[1]["ci_low"], PR + "decision_rules.json", f"B.detail['{bmin[0]}'].ci_low", "{:+.3f}")
    R.put("B_N", len(B_), PR + "decision_rules.json", "len(B.detail)", "{:d}")
    G_ = dec["G"]["detail"]
    for key, tok in (("bh|PRr|mon2", "G_PRR_BH"), ("sp|PRr|mon2", "G_PRR_SP"), ("bh|R1|mon2", "G_R1_BH"), ("sp|R1|mon2", "G_R1_SP"),
                     ("bh|PRr|known", "G_PRR_BH_K"), ("sp|PRr|known", "G_PRR_SP_K")):
        R.put(tok, G_[key]["range"], PR + "decision_rules.json", f"G.detail['{key}'].range")
    g_prr = [G_[k]["range"] for k in ("bh|PRr|known", "bh|PRr|mon2", "sp|PRr|known", "sp|PRr|mon2")]
    R.put("G_PRR_MAX", max(g_prr), PR + "decision_rules.json", "max G.detail[*|PRr|*].range")
    R.put("G_PRR_MIN", min(g_prr), PR + "decision_rules.json", "min G.detail[*|PRr|*].range")

    # per-phase F1 of R1 and PRr
    def att_v(dom, arm, col):
        return float(att[(att.domain == dom) & (att.arm == arm)][col].iloc[0])
    for dom in ("bh", "sp"):
        for arm in ("A0", "R1", "R1r", "PR", "PRr", "PRrM"):
            if dom == "sp" and arm == "A0":
                continue
            for col, suf in (("layer_macro_f1", "L"), ("fault_macro_f1", "F"), ("layer_f1_p000", "P0"), ("layer_f1_p999", "P999"),
                             ("layer_balanced_accuracy", "LBA"), ("fault_balanced_accuracy", "FBA")):
                R.put(f"ARM_{dom.upper()}_{arm.upper()}_{suf}", att_v(dom, arm, col), PR + "attribution_arms.csv", f"domain={dom}, arm={arm}, {col}")
    # attribution comparisons
    names = {"PR - R1": "DESC", "R1r - R1": "RAND", "PRr - R1r": "DESC_GIVEN_RAND", "PRr - PR": "RAND_GIVEN_DESC", "PRr - R1": "COMB", "PRrM - PRr": "MIXED", "PRr - A0": "VS_A0"}
    for _, r in attc.iterrows():
        key = r.comparison.split(" (")[0]
        tok = f"ATT_{r.domain.upper()}_{names[key]}"
        R.put(tok, r["diff"], PR + "attribution_comparisons.csv", f"domain={r.domain}, comparison='{r.comparison}', diff", "{:+.3f}")
        R.put(tok + "_CI", f"[{r.ci_low:+.3f}, {r.ci_high:+.3f}]", PR + "attribution_comparisons.csv", f"domain={r.domain}, comparison='{r.comparison}', ci_low/ci_high", "{}")
    # amplitude curves
    def amp_v(dom, series, col, target="layer"):
        return float(amp[(amp.domain == dom) & (amp.series == series) & (amp.target == target)][col].iloc[0])
    for dom in ("bh", "sp"):
        for series, tok in (("PRr known", "K"), ("PRr E=0%", "E0"), ("PRr E=1%", "E1"), ("PRr E=2%", "E2"), ("PRr E=5%", "E5"), ("A0 old", "A0")):
            if dom == "sp" and tok == "A0":
                continue
            for col in ("x0.8", "x1.0", "x1.2", "pooled"):
                R.put(f"AMP_{dom.upper()}_{tok}_{col.replace('x', 'X').replace('.', '').upper()}", amp_v(dom, series, col), PR + "amplitude_curves.csv",
                      f"domain={dom}, series='{series}', target=layer, {col}")
        mons = [amp_v(dom, f"PRr E={e}%", "pooled") for e in (0, 1, 2, 5)]
        R.put(f"AMP_{dom.upper()}_MON_POOLED_MIN", min(mons), PR + "amplitude_curves.csv", f"domain={dom}, min over series PRr E=0/1/2/5%, pooled")
        R.put(f"AMP_{dom.upper()}_MON_POOLED_MAX", max(mons), PR + "amplitude_curves.csv", f"domain={dom}, max over series PRr E=0/1/2/5%, pooled")
    for a in ("x0.8", "x1.2"):
        R.put(f"CTL_K_{a.replace('x', 'X').replace('.', '')}", ctl[a]["known"], PR + "no_monitor_control.json", f"{a}.known")
        R.put(f"CTL_U_{a.replace('x', 'X').replace('.', '')}", ctl[a]["unmonitored"], PR + "no_monitor_control.json", f"{a}.unmonitored")
    # complexity
    R.put("PARAMS_LAYER", tim[str(SEEDS[0])]["params_layer"], PR + "timing_and_parameters.json", f"{SEEDS[0]}.params_layer", "{:,d}")
    R.put("PARAMS_FAULT", tim[str(SEEDS[0])]["params_fault"], PR + "timing_and_parameters.json", f"{SEEDS[0]}.params_fault", "{:,d}")
    n_in, h1, h2 = 20, 96, 48
    assert n_in * h1 + h1 + h1 * h2 + h2 + h2 * 4 + 4 == tim[str(SEEDS[0])]["params_layer"], "parameter count does not match the 20-96-48-4 architecture"
    R.put("MACS_LAYER", n_in * h1 + h1 * h2 + h2 * 4, "derived from the 20-96-48-4 architecture (checked against params_layer)", "multiply-accumulate count", "{:,d}")
    R.put("MACS_FAULT", n_in * h1 + h1 * h2 + h2 * 9, "derived from the 20-96-48-9 architecture", "multiply-accumulate count", "{:,d}")
    R.put("DESC_MS_R1", np.mean([tim[str(s)]["descriptor_extraction_ms_per_sample"]["revision1"] for s in SEEDS]), PR + "timing_and_parameters.json", "mean over seeds of descriptor_extraction_ms_per_sample.revision1", "{:.2f}")
    R.put("DESC_MS_PR", np.mean([tim[str(s)]["descriptor_extraction_ms_per_sample"]["phase_robust"] for s in SEEDS]), PR + "timing_and_parameters.json", "mean over seeds of descriptor_extraction_ms_per_sample.phase_robust", "{:.2f}")
    R.put("MLP_MS", np.mean([tim[str(s)]["mlp_predict_ms_per_sample"] for s in SEEDS]) * 1000, PR + "timing_and_parameters.json", "mean over seeds of mlp_predict_ms_per_sample x 1000 (microseconds)", "{:.2f}")
    R.put("SPICE_WALL", np.mean([tim[str(s)]["ngspice_wall_seconds"] for s in SEEDS]), PR + "timing_and_parameters.json", "mean ngspice_wall_seconds", "{:.0f}")
    R.put("SPICE_WORKERS", tim[str(SEEDS[0])]["workers"], PR + "timing_and_parameters.json", "workers", "{:d}")
    # Revision-2 ablations from earlier frozen stages
    for k, tok in (("ref_m20|two_point_mlp@A2-two_point_mlp@A1j", "V2_COND_M20"), ("ref_p20|two_point_mlp@A2-two_point_mlp@A1j", "V2_COND_P20")):
        d = v2["D5"][k]
        R.put(tok, d["diff"], V2 + "decision_rules.json", f"D5['{k}'].diff", "{:+.3f}")
        R.put(tok + "_CI", f"[{d['ci'][0]:+.3f}, {d['ci'][1]:+.3f}]", V2 + "decision_rules.json", f"D5['{k}'].ci", "{}")
    def rma(series, col):
        return float(rm_amp[(rm_amp.series == series) & (rm_amp.target == "layer")][col].iloc[0])
    for series, tok in (("A2m E=2% (ablation)", "RM_A2_E2"), ("A1m E=2%", "RM_A1_E2"), ("A2m E=5% (ablation)", "RM_A2_E5"), ("A1m E=5%", "RM_A1_E5")):
        for col in ("x0.8", "x1.2"):
            R.put(f"{tok}_{col.replace('x', 'X').replace('.', '')}", rma(series, col), RM + "amplitude_curves.csv", f"series='{series}', target=layer, {col}")
    # TCN vs MLP (earlier frozen multi-seed stage)
    for k, tok in (("nominal|layer", "TCN_NOM_L"), ("nominal|fault", "TCN_NOM_F"), ("tolerance|layer", "TCN_TOL_L"), ("severity|layer", "TCN_SEV_L")):
        d = ms["R2"][k]
        R.put(tok, d["diff"], MS + "decision_rules.json", f"R2['{k}'].diff", "{:+.3f}")
        R.put(tok + "_CI", f"[{d['ci'][0]:+.3f}, {d['ci'][1]:+.3f}]", MS + "decision_rules.json", f"R2['{k}'].ci", "{}")
    # netlist validation
    sf, so = jload("spice_fixed/spice_vs_behavioral.json"), jload("spice/spice_vs_behavioral.json")
    R.put("NETLIST_OLD_RMSE", so["healthy"]["adc_out"]["rmse_V"] * 1000, "spice/spice_vs_behavioral.json", "healthy.adc_out.rmse_V x1000 (mV)", "{:.0f}")
    R.put("NETLIST_FIX_RMSE", sf["healthy"]["adc_out"]["rmse_V"] * 1000, "spice_fixed/spice_vs_behavioral.json", "healthy.adc_out.rmse_V x1000 (mV)", "{:.1f}")

    # per-class recall, separation minima, percentages
    for dom in ("bh", "sp"):
        r = pcl[(pcl.domain == dom) & (pcl.arm == "PRr")].iloc[0]
        for c in ("healthy", "sensor", "afe", "adc"):
            R.put(f"REC_L_{dom.upper()}_PRR_{c.upper()}", float(r[c]), PR + "per_class_recall_layer.csv", f"domain={dom}, arm=PRr, {c}")
        r = pcf[(pcf.domain == dom) & (pcf.arm == "PRr")].iloc[0]
        for c in pcf.columns[2:]:
            R.put(f"REC_F_{dom.upper()}_PRR_{c.upper()}", float(r[c]), PR + "per_class_recall_fault.csv", f"domain={dom}, arm=PRr, {c}")
    r = pcl[(pcl.domain == "bh") & (pcl.arm.str.startswith("PRr known"))].iloc[0]
    for c in ("healthy", "sensor", "afe", "adc"):
        R.put(f"REC_L_UNMON_{c.upper()}", float(r[c]), PR + "per_class_recall_layer.csv", f"domain=bh, arm='{r.arm}', {c}")
    R.put("C_MIN_AFE_REC", min(v["afe_recall"] for v in C_.values()), PR + "decision_rules.json", "min C.detail[*].afe_recall")
    R.put("C_MIN_ADC_REC", min(v["adc_recall"] for v in C_.values()), PR + "decision_rules.json", "min C.detail[*].adc_recall")
    R.put("A_MIN_RET_PCT", 100 * amin[1]["retention"], PR + "decision_rules.json", f"100 x A.detail['{amin[0]}'].retention", "{:.1f}")
    R.put("D_MIN_RET_PCT", 100 * dmin[1]["retention"], PR + "decision_rules.json", f"100 x D.detail['{dmin[0]}'].retention", "{:.1f}")
    dv = ROOT / "paper_package/figure_data/dev_seed_verification.json"
    if dv.exists():
        d = json.loads(dv.read_text())
        ag = d["noise_free_agreement_per_phase"]
        src = "paper_package/figure_data/dev_seed_verification.json"
        R.put("DEV_AGREE_MIN", min(v["mean_rmse_mV"] for v in ag.values()), src, "min noise_free_agreement_per_phase[*].mean_rmse_mV", "{:.2f}")
        R.put("DEV_AGREE_MAX", max(v["mean_rmse_mV"] for v in ag.values()), src, "max noise_free_agreement_per_phase[*].mean_rmse_mV", "{:.2f}")
        R.put("DEV_AGREE_WORST", max(v["max_rmse_mV"] for v in ag.values()), src, "max noise_free_agreement_per_phase[*].max_rmse_mV", "{:.1f}")
        inv = d["descriptor_phase_invariance"]
        R.put("DEV_RISE2_SHIFT", max(inv["revision1"]["rise_2"]), src, "max descriptor_phase_invariance.revision1.rise_2", "{:.2f}")
        R.put("DEV_PR_MAX_SHIFT", max(max(v) for v in inv["phase_robust"].values()), src, "max over descriptor_phase_invariance.phase_robust[*]", "{:.2f}")
        fbp = ROOT / "paper_package/figure_data/fallback_check_dev_seed.json"
        if fbp.exists():
            fbd = json.loads(fbp.read_text())
            R.put("DEV_FALLBACK_N", fbd["n_records"], "paper_package/figure_data/fallback_check_dev_seed.json", "n_records", "{:,d}")
            R.put("DEV_FALLBACK_COUNT", fbd["fallback_activations"], "paper_package/figure_data/fallback_check_dev_seed.json", "fallback_activations", "{:d}")
        R.put("DEV_TAU_SHIFT", max(inv["phase_robust"]["tau_norm"]), src, "max descriptor_phase_invariance.phase_robust.tau_norm", "{:.2f}")

    # ------------------------------------------------------------ tables
    # T1 simulator constants (code)
    t1 = pd.DataFrame([
        ("Sampling", "1 kHz, 512 samples per record (0.512 s), 12-bit ADC over 0-3.3 V, ADC noise 2.5 mV rms", "src/simulate.py: simulate_sample"),
        ("Operating condition (per group)", "baseline U(0.78,1.18) V; carrier amplitude U(0.045,0.18) V; frequency U(0.45,3.0) Hz; sensor noise U(2,14) mV; AFE gain U(1.65,2.05); AFE tau U(8,16) ms; slow component 25 mV at 0.12 Hz; random-walk drift 1.5 mV/step", "src/simulate.py: make_condition, _base_signal"),
        ("AFE reference window", "140-260 ms; 0.90 V then 1.30 V (two 60 ms plateaus); replaces the sensor at the AFE input", "src/simulate.py: _afe_reference"),
        ("ADC reference window", "340-460 ms; 1.15 V then 1.75 V; bypasses the AFE at the ADC input", "src/simulate.py: _adc_reference"),
        ("Faults (severity)", "sensor bias / AFE offset / ADC offset: ±U(0.06,0.24) V; sensor gain / ADC gain: ±U(6,28)%; sensor noise: U(25,95) mV rms; AFE bandwidth: tau x U(1.8,4.5); ADC clipping: full scale x U(0.72,0.93)", "src/simulate.py: make_fault"),
        ("Component tolerances (test, both domains)", "AFE gain ±5%, AFE tau ±10%, ADC gain ±2%, ADC offset ±10 mV, sensor baseline ±5% (uniform per sample)", "src/run_reference_monitor.py: _draw_tol"),
        ("Reference amplitude", "x0.8, 0.9, 1.0, 1.1, 1.2 of nominal (behavioral); x0.8, 1.0, 1.2 (ngspice)", "phase_robust_final/PROTOCOL_PHASE_ROBUST_FROZEN.md, section 3"),
        ("Edge phase", "psi in {0, 0.25, 0.5, 0.75, 0.999} of one sampling period (test); U[0,1) per sample (training, randomised arms)", "phase_robust_final/PROTOCOL_PHASE_ROBUST_FROZEN.md, sections 1 and 3"),
        ("Reference monitor", "buffered 12-bit channel, 16-sample mean, 0.25 mV rms after averaging, common gain error U(-E,E), E in {0,1,2,5}%", "src/monitor_model.py"),
        ("ngspice-only noise", "0.5 mV rms amplifier-input noise and 0.5 mV rms on each reference rail", "src/spice_domain.py: AMP_NOISE_V, REF_NOISE_V"),
        ("Switch model (ngspice)", "Ron = 0.5 Ohm, Roff = 1 MOhm, threshold 2.5 V, hysteresis 0.1 V; 1 us edges", "src/spice_phase.py: render_phase"),
    ], columns=["item", "value", "source"])
    t1.attrs["n_keys"] = 1
    R.table("T1", "Simulation and circuit parameters (code constants)", t1, "src/simulate.py; src/monitor_model.py; src/spice_domain.py; src/spice_phase.py; src/run_reference_monitor.py")

    # T2 data and splits
    t2 = pd.DataFrame([{"dataset seed": s, "conditions (train/val/test)": f"{meta[s]['train_conditions']}/{meta[s]['val_conditions']}/{meta[s]['test_conditions']}",
                        "test samples per behavioral cell": meta[s]["test_conditions"] * 9, "ngspice runs": meta[s]["n_ngspice_runs"], "condition overlap": meta[s]["overlap"]} for s in SEEDS])
    t2.attrs["n_keys"] = 1
    R.table("T2", "Validation datasets and splits", t2, PR + "seed_*/meta.json")

    # T3 robustness vs amplitude (layer macro-F1)
    rows = []
    for dom in ("bh", "sp"):
        for series in ("A0 old", "R1 known", "PRr known", "PRr E=0%", "PRr E=1%", "PRr E=2%", "PRr E=5%"):
            d = amp[(amp.domain == dom) & (amp.series == series) & (amp.target == "layer")]
            if not len(d):
                continue
            d = d.iloc[0]
            cols = [c for c in ("x0.8", "x0.9", "x1.0", "x1.1", "x1.2") if not pd.isna(d.get(c, np.nan))]
            rows.append({"domain": {"bh": "behavioral", "sp": "ngspice"}[dom], "method": series, **{c.replace("x", "×"): round(float(d[c]), 3) for c in cols}, "pooled": round(float(d["pooled"]), 3)})
        if dom == "bh":
            rows.append({"domain": "behavioral", "method": "PRr, no monitor (nominal assumed)", **{f"×{k[1:]}": round(v["unmonitored"], 3) for k, v in ctl.items()}, "pooled": np.nan})
    t3 = pd.DataFrame(rows)
    t3.attrs["n_keys"] = 2
    R.table("T3", "Layer macro-F1 versus actual reference amplitude (pooled over the five phases; mean of three dataset seeds)", t3,
            PR + "amplitude_curves.csv; " + PR + "no_monitor_control.json")

    # T4 superiority (selected) — full list in decision_rules.json
    lab = {"two_point_mlp@A0": "two-point, old descriptors", "passive_mlp@A0": "passive", "single_mlp@A0": "single probe", "afe_only_mlp@A0": "AFE-only, old", "adc_only_mlp@A0": "ADC-only, old"}
    rows = []
    for x in ("known", "mon2", "mon5"):
        suf = "k" if x == "known" else "e" + x[3:]
        for a in (80, 120):
            row = {"monitor": {"known": "known reference", "mon2": "E = ±2%", "mon5": "E = ±5%"}[x], "amplitude": f"×{a / 100:.1f}"}
            for b, nm in list(lab.items()) + [(f"afe_only_mlp@PRr_{suf}", "AFE-only, phase-robust"), (f"adc_only_mlp@PRr_{suf}", "ADC-only, phase-robust")]:
                row[nm] = ci(B_[f"{x}|a{a}|vs {b}"])
            rows.append(row)
    t4 = pd.DataFrame(rows)
    t4.attrs["n_keys"] = 2
    R.table("T4", "Two-point PRr minus baseline, layer macro-F1 difference [95% CI], behavioral, pooled over phases", t4, PR + "decision_rules.json (B.detail; all 70 comparisons)")

    # T5 AFE/ADC separation
    rows = []
    for dom in ("bh", "sp"):
        for x in ("known", "mon0", "mon1", "mon2", "mon5"):
            for a in (80, 120):
                c = C_[f"{dom}|{x}|a{a}"]
                rows.append({"domain": {"bh": "behavioral", "sp": "ngspice"}[dom], "monitor": x, "amplitude": f"×{a / 100:.1f}",
                             "AFE recall": round(c["afe_recall"], 3), "ADC recall": round(c["adc_recall"], 3), "AFE-ADC cross-confusion": round(c["cross_confusion"], 3)})
    t5 = pd.DataFrame(rows)
    t5.attrs["n_keys"] = 3
    R.table("T5", "AFE/ADC separation of PRr at ±20% reference amplitude (pooled over phases)", t5, PR + "decision_rules.json (C.detail)")

    # T6 transfer
    rows = []
    for x, v in dec["E"]["all"].items():
        rows.append({"stage": "phase-robust (this work)", "monitor": x, "behavioral": round(v["BB"], 3), "ngspice": round(v["BS"], 3), "loss": round(v["drop"], 3),
                     "loss 95% CI": f"[{v['drop_ci'][0]:.3f}, {v['drop_ci'][1]:.3f}]", "mixed-trained on ngspice": round(v["MS"], 3)})
    for x, v in rm["E"]["all_variants"].items():
        rows.append({"stage": "Revision 1, frozen edge placement (previous, REVISE)", "monitor": x, "behavioral": round(v["BB"], 3), "ngspice": round(v["BS"], 3),
                     "loss": round(v["drop_BB_minus_BS"], 3), "loss 95% CI": f"[{v['drop_ci'][0]:.3f}, {v['drop_ci'][1]:.3f}]", "mixed-trained on ngspice": round(v["MS"], 3)})
    t6 = pd.DataFrame(rows)
    t6.attrs["n_keys"] = 2
    R.table("T6", "Behavioral-to-ngspice transfer (layer macro-F1, behavioral-trained classifier)", t6, PR + "decision_rules.json (E.all); " + RM + "decision_rules.json (E.all_variants)",
            "Grids differ: this work pools x0.8/1.0/1.2 x five phases; the previous stage pools x0.8-1.2 at its single (frozen) edge placement.")

    # T7 phase sensitivity
    pcols = ["layer_f1_p000", "layer_f1_p250", "layer_f1_p500", "layer_f1_p750", "layer_f1_p999"]
    rows = []
    for _, r in att.iterrows():
        vals = [float(r[c]) for c in pcols]
        rows.append({"domain": {"bh": "behavioral", "sp": "ngspice"}[r.domain], "arm": r.arm, **{f"ψ={p}": round(v, 3) for p, v in zip(("0", "0.25", "0.5", "0.75", "0.999"), vals)},
                     "range": round(max(vals) - min(vals), 3)})
    t7 = pd.DataFrame(rows)
    t7.attrs["n_keys"] = 2
    R.table("T7", "Layer macro-F1 per sampling phase (monitor E = ±2%, pooled over amplitudes)", t7, PR + "attribution_arms.csv")

    # T8 ablation
    rows = []
    for _, r in attc.iterrows():
        rows.append({"source": "phase-robust stage", "domain": {"bh": "behavioral", "sp": "ngspice"}[r.domain], "comparison": r.comparison, "difference [95% CI]": f"{r['diff']:+.3f} [{r.ci_low:+.3f}, {r.ci_high:+.3f}]",
                     "same sign in 3/3 seeds": bool(r.consistent_3_seeds)})
    for k, lbl in (("ref_m20|two_point_mlp@A2-two_point_mlp@A1j", "Revision-2 conditioning (A2 - A1j), ref x0.8"), ("ref_p20|two_point_mlp@A2-two_point_mlp@A1j", "Revision-2 conditioning (A2 - A1j), ref x1.2")):
        d = v2["D5"][k]
        rows.append({"source": "reference-v2 stage", "domain": "behavioral", "comparison": lbl, "difference [95% CI]": f"{d['diff']:+.3f} [{d['ci'][0]:+.3f}, {d['ci'][1]:+.3f}]", "same sign in 3/3 seeds": ""})
    for k, lbl in (("nominal|layer", "TCN - MLP, nominal, layer"), ("nominal|fault", "TCN - MLP, nominal, fault"), ("tolerance|layer", "TCN - MLP, tolerance, layer"), ("severity|layer", "TCN - MLP, unseen severity, layer")):
        d = ms["R2"][k]
        rows.append({"source": "multi-seed stage (old descriptors)", "domain": "behavioral", "comparison": lbl, "difference [95% CI]": f"{d['diff']:+.3f} [{d['ci'][0]:+.3f}, {d['ci'][1]:+.3f}]", "same sign in 3/3 seeds": ""})
    t8 = pd.DataFrame(rows)
    t8.attrs["n_keys"] = 3
    R.table("T8", "Ablation and attribution (layer macro-F1 differences, paired bootstrap)", t8,
            PR + "attribution_comparisons.csv; " + V2 + "decision_rules.json (D5); " + MS + "decision_rules.json (R2)")

    # T9 per-class recall
    rows = []
    for _, r in pcf.iterrows():
        rows.append({"domain": {"bh": "behavioral", "sp": "ngspice"}[r.domain], "arm": r.arm, **{c: round(float(r[c]), 3) for c in pcf.columns[2:]}})
    t9 = pd.DataFrame(rows)
    t9.attrs["n_keys"] = 2
    R.table("T9", "Fine-fault recall (monitor E = ±2%, pooled over amplitudes and phases)", t9, PR + "per_class_recall_fault.csv")
    rows = []
    for _, r in pcl.iterrows():
        rows.append({"domain": {"bh": "behavioral", "sp": "ngspice"}[r.domain], "arm": r.arm, "scope": r.scope, **{c: round(float(r[c]), 3) for c in ("healthy", "sensor", "afe", "adc")}})
    t9b = pd.DataFrame(rows)
    t9b.attrs["n_keys"] = 3
    R.table("T9b", "Layer recall (pooled; last row: no-monitor control at ×0.8/×1.2)", t9b, PR + "per_class_recall_layer.csv")

    # T10 complexity
    t10 = pd.DataFrame([
        ("Descriptor vector", "20 (15 settled-plateau / calibration / sensor-domain + 5 phase-robust transient)", "src/phase_features.py: PR_NAMES"),
        ("Classifier", "MLP 20-96-48-{4 or 9}, ReLU, Adam, early stopping", "src/run_feasibility.py: _classifier"),
        ("Parameters (layer / fault head)", f"{R.vals['PARAMS_LAYER']} / {R.vals['PARAMS_FAULT']}", PR + "timing_and_parameters.json"),
        ("Multiply-accumulates per inference (layer / fault)", f"{R.vals['MACS_LAYER']} / {R.vals['MACS_FAULT']}", "derived from the architecture"),
        ("Descriptor extraction per record (Python, 1 core)", f"Revision-1 {R.vals['DESC_MS_R1']} ms; phase-robust {R.vals['DESC_MS_PR']} ms", PR + "timing_and_parameters.json"),
        ("MLP inference per record (batched, Python)", f"{R.vals['MLP_MS']} µs", PR + "timing_and_parameters.json"),
        ("ngspice runs (per seed / total)", f"{R.vals['N_SPICE_PER_SEED']} / {R.vals['N_SPICE_TOTAL']} (≈{R.vals['SPICE_WALL']} s wall per seed on {R.vals['SPICE_WORKERS']} workers)", PR + "seed_*/meta.json; timing_and_parameters.json"),
    ], columns=["item", "value", "source"])
    t10.attrs["n_keys"] = 1
    R.table("T10", "Model size and computational cost", t10, PR + "timing_and_parameters.json")

    # T11 validation history
    hist = [
        ("Multi-seed validation (old descriptors)", jload(MS + "decision_rules.json")["tag"], "FINAL_MULTISEED_REPORT.md", MS + "decision_rules.json"),
        ("Reference-v2 (settled plateaus, known reference)", jload(V2 + "decision_rules.json")["tag"], "FINAL_REFERENCE_V2_REPORT.md", V2 + "decision_rules.json"),
        ("Reference monitor + ngspice", rm["decision"], "reference_monitor_final/FINAL_REFERENCE_MONITOR_REPORT.md", RM + "decision_rules.json"),
        ("Phase-robust descriptors (this method)", dec["decision"], "phase_robust_final/FINAL_PHASE_ROBUST_REPORT.md", PR + "decision_rules.json"),
    ]
    t11 = pd.DataFrame(hist, columns=["stage (each with its own frozen protocol and new seeds)", "pre-registered outcome", "report", "decision file"])
    t11.attrs["n_keys"] = 1
    R.table("T11", "Pre-registered validation history", t11, "; ".join(h[3] for h in hist))
    g = dec["gates"]
    gl = [("A", "≥ 0.85·N at ×0.8 and ×1.2 (known, E ≤ 2%)", "A_bh", "A_sp", f"worst retention {R.vals['A_MIN_RET']}"),
          ("B", "beats old method and one-point baselines (CI lower bound > 0)", "B", None, f"smallest CI lower bound {R.vals['B_MIN_CI']} ({R.vals['B_N']} comparisons)"),
          ("C", "AFE–ADC cross-confusion < 0.15 at ×0.8 and ×1.2", "C_bh", "C_sp", f"largest {R.vals['C_MAX']}"),
          ("D", "≥ 0.70·N at E = ±5%", "D_bh", "D_sp", f"worst retention {R.vals['D_MIN_RET']}"),
          ("E", "behavioral → ngspice loss ≤ 0.10 (E = ±2%)", "E", None, f"{R.vals['E_DROP']} [{R.vals['E_DROP_LO']}, {R.vals['E_DROP_HI']}]"),
          ("F", "improvements supported by paired 5000-resample bootstrap CIs", None, None, "applied to B and all attribution claims"),
          ("G", "layer macro-F1 range over five phases ≤ 0.05 (known, E = ±2%)", "G_bh", "G_sp", f"largest range {R.vals['G_PRR_MAX']}")]
    tg = pd.DataFrame([{"gate": a_, "criterion": c_, "behavioral": ("PASS" if g[b_] else "FAIL") if b_ else "—", "ngspice": ("PASS" if g[s_] else "FAIL") if s_ else "—", "margin": m_}
                       for a_, c_, b_, s_, m_ in gl])
    tg.attrs["n_keys"] = 1
    R.table("TG", "Pre-registered gates for the primary method (PRr)", tg, PR + "decision_rules.json (gates, A-G details)")
    return R


def md_table(df: pd.DataFrame) -> str:
    cols = list(df.columns)
    out = ["| " + " | ".join(map(str, cols)) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for _, r in df.iterrows():
        out.append("| " + " | ".join("" if (isinstance(x, float) and np.isnan(x)) else (f"{x:.3f}" if isinstance(x, float) else str(x)) for x in r.values) + " |")
    return "\n".join(out)
