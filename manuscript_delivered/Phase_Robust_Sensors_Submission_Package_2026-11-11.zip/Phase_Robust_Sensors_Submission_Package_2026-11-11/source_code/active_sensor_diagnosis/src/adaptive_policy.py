"""Uncertainty-aware adaptive selection of diagnostic reference tests."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable

import numpy as np
from sklearn.metrics import accuracy_score, f1_score
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


LAYERS = ("healthy", "sensor", "afe", "adc")


@dataclass(frozen=True)
class TestChoice:
    name: str
    cost: float


TESTS = {
    "passive": TestChoice("passive", 0.0),
    "afe_only": TestChoice("afe_only", 1.0),
    "adc_only": TestChoice("adc_only", 1.0),
    "two_point": TestChoice("two_point", 2.0),
}


def make_model(seed: int) -> Pipeline:
    return Pipeline(
        [
            ("scale", StandardScaler()),
            (
                "mlp",
                MLPClassifier(
                    hidden_layer_sizes=(64, 32),
                    max_iter=800,
                    early_stopping=True,
                    validation_fraction=0.15,
                    n_iter_no_change=40,
                    random_state=seed,
                ),
            ),
        ]
    )


def normalized_entropy(probabilities: np.ndarray) -> np.ndarray:
    p = np.clip(probabilities, 1e-8, 1.0)
    return -(p * np.log(p)).sum(axis=1) / np.log(probabilities.shape[1])


def choose_tests(passive_probabilities: np.ndarray) -> np.ndarray:
    """Select the cheapest test expected to resolve the current uncertainty.

    The policy is causal: it sees only passive-model probabilities at the
    current sample. It does not use the true fault label or future waveform.
    The two-point test is reserved for ambiguous cases; one-point references
    are used when the passive model identifies a likely affected layer.
    """
    confidence = passive_probabilities.max(axis=1)
    predicted = passive_probabilities.argmax(axis=1)
    entropy = normalized_entropy(passive_probabilities)
    choices = np.full(len(predicted), "two_point", dtype=object)

    confident_healthy = (predicted == 0) & (confidence >= 0.84) & (entropy <= 0.38)
    likely_adc = (predicted == 3) & (confidence >= 0.55)
    likely_afe_or_sensor = np.isin(predicted, [1, 2]) & (confidence >= 0.55)
    choices[confident_healthy] = "passive"
    choices[likely_adc] = "adc_only"
    choices[likely_afe_or_sensor] = "afe_only"
    return choices


def evaluate_adaptive(
    feature_sets: Dict[str, Dict[str, np.ndarray]], train_idx: np.ndarray, test_idx: np.ndarray, seed: int
) -> Dict[str, object]:
    """Train mode-specific layer models and evaluate the adaptive policy."""
    mode_map = {
        "passive": "passive",
        "afe_only": "active_afe_only",
        "adc_only": "active_adc_only",
        "two_point": "active_two_point",
    }
    models: Dict[str, Pipeline] = {}
    for i, (test_name, data_mode) in enumerate(mode_map.items()):
        model = make_model(seed + i)
        data = feature_sets[data_mode]
        model.fit(data["x"][train_idx], data["y"][train_idx])
        models[test_name] = model

    passive_data = feature_sets["passive"]
    passive_probs = models["passive"].predict_proba(passive_data["x"][test_idx])
    choices = choose_tests(passive_probs)
    predictions = np.zeros(len(test_idx), dtype=int)
    for test_name in TESTS:
        ids = np.flatnonzero(choices == test_name)
        if len(ids):
            data = feature_sets[mode_map[test_name]]
            predictions[ids] = models[test_name].predict(data["x"][test_idx[ids]])
    y_test = passive_data["y"][test_idx]
    usage = {name: int(np.sum(choices == name)) for name in TESTS}
    cost = float(sum(usage[name] * TESTS[name].cost for name in usage) / len(test_idx))
    return {
        "accuracy": float(accuracy_score(y_test, predictions)),
        "macro_f1": float(f1_score(y_test, predictions, average="macro")),
        "average_test_cost": cost,
        "usage": usage,
        "entropy_mean": float(normalized_entropy(passive_probs).mean()),
    }


def evaluate_fixed(
    feature_sets: Dict[str, Dict[str, np.ndarray]], mode: str, train_idx: np.ndarray, test_idx: np.ndarray, seed: int
) -> Dict[str, object]:
    data = feature_sets[mode]
    model = make_model(seed)
    model.fit(data["x"][train_idx], data["y"][train_idx])
    pred = model.predict(data["x"][test_idx])
    return {
        "accuracy": float(accuracy_score(data["y"][test_idx], pred)),
        "macro_f1": float(f1_score(data["y"][test_idx], pred, average="macro")),
        "average_test_cost": {"passive": 0.0, "active_afe_only": 1.0, "active_adc_only": 1.0, "active_two_point": 2.0}[mode],
    }
