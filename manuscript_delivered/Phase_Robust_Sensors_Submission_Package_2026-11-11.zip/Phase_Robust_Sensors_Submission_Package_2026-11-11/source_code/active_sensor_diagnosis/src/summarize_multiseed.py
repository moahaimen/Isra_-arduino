"""Aggregate the frozen multi-seed validation: tables, paired cluster bootstrap, plots, decision rules."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import binomtest

from .run_multiseed import INITS, MODELS
from .simulate import FAULTS, LAYERS

ROOT = Path(__file__).resolve().parents[1]
SCEN = ["nominal", "tolerance", "ref_m20", "ref_p20", "severity"]
SHIFTED = ["tolerance", "ref_m20", "ref_p20"]
TARGET_K = {"layer": 4, "fault": 9}
ONE_POINT = ["passive_mlp", "single_mlp", "afe_only_mlp", "adc_only_mlp"]
ORDER = ["passive_mlp", "single_mlp", "afe_only_mlp", "adc_only_mlp", "two_point_mlp", "two_point_rf",
         "tcn_v2a", "tcn_v2b", "tcn_v2b_nophys"]


def cond_cms(y, p, cond, k):
    conds = np.unique(cond)
    cm = np.zeros((len(conds), k, k), dtype=np.float64)
    idx = np.searchsorted(conds, cond)
    np.add.at(cm, (idx, y.astype(int), p.astype(int)), 1)
    return cm


def batch_metric(cm, metric):
    """cm: [B,K,K] (rows = true). Returns [B]."""
    tp = np.einsum("bkk->bk", cm)
    if metric == "accuracy":
        return tp.sum(1) / cm.sum((1, 2))
    row, col = cm.sum(2), cm.sum(1)
    den = row + col
    f1 = np.where(den > 0, 2 * tp / np.where(den > 0, den, 1), 0.0)
    return f1.mean(1)


class Store:
    def __init__(self, seed_dirs):
        self.seeds, self.preds, self.meta, self.info = [], {}, {}, {}
        for d in seed_dirs:
            m = json.loads((d / "meta.json").read_text())
            s = m["dataset_seed"]
            self.seeds.append(s)
            self.preds[s] = dict(np.load(d / "predictions.npz"))
            self.meta[s] = m
            self.info[s] = json.loads((d / "model_info.json").read_text())

    def has(self, s, scn, model):
        return f"{scn}|{model}|{INITS[0]}|layer" in self.preds[s]

    def cms(self, s, scn, model, target):
        P = self.preds[s]
        y, cond = P[f"y_{target}|{scn}"], P[f"cond|{scn}"]
        return [cond_cms(y, P[f"{scn}|{model}|{i}|{target}"], cond, TARGET_K[target]) for i in INITS]


def seed_weights(s, scn, target, n_boot, n_cond):
    rng = np.random.default_rng(int(s) * 1000 + SCEN.index(scn) * 10 + (0 if target == "layer" else 1))
    return rng.multinomial(n_cond, np.full(n_cond, 1.0 / n_cond), size=n_boot).astype(np.float64)


def model_metric_boot(store, s, scn, model, target, metric, W):
    vals = []
    for cm in store.cms(s, scn, model, target):
        vals.append(batch_metric(np.einsum("bn,nkl->bkl", W, cm), metric))
    return np.mean(vals, axis=0)


def point_metric(store, s, scn, model, target, metric):
    return float(np.mean([batch_metric(cm.sum(0, keepdims=True), metric)[0] for cm in store.cms(s, scn, model, target)]))


def compare(store, scn, target, a, b, metric, n_boot):
    per_seed_pt, per_seed_ci, boots = {}, {}, []
    for s in store.seeds:
        n_cond = len(np.unique(store.preds[s][f"cond|{scn}"]))
        W = seed_weights(s, scn, target, n_boot, n_cond)
        d = model_metric_boot(store, s, scn, a, target, metric, W) - model_metric_boot(store, s, scn, b, target, metric, W)
        boots.append(d)
        per_seed_pt[s] = point_metric(store, s, scn, a, target, metric) - point_metric(store, s, scn, b, target, metric)
        per_seed_ci[s] = (float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5)))
    pooled = np.mean(boots, axis=0)
    pt = float(np.mean(list(per_seed_pt.values())))
    lo, hi = float(np.percentile(pooled, 2.5)), float(np.percentile(pooled, 97.5))
    # per-condition correctness (pooled across seeds)
    better = worse = tie = 0
    for s in store.seeds:
        P = store.preds[s]
        y, cond = P[f"y_{target}|{scn}"], P[f"cond|{scn}"]
        conds = np.unique(cond)
        def corr(m):
            c = np.mean([(P[f"{scn}|{m}|{i}|{target}"] == y).astype(float) for i in INITS], axis=0)
            return np.array([c[cond == k].mean() for k in conds])
        d = corr(a) - corr(b)
        better += int((d > 1e-9).sum()); worse += int((d < -1e-9).sum()); tie += int((np.abs(d) <= 1e-9).sum())
    p_sign = float(binomtest(better, better + worse, 0.5).pvalue) if better + worse > 0 else 1.0
    signs = [np.sign(v) for v in per_seed_pt.values()]
    return {
        "scenario": scn, "target": target, "metric": metric, "A": a, "B": b,
        "diff_pooled": pt, "ci_low": lo, "ci_high": hi,
        "ci_excludes_zero": bool(lo > 0 or hi < 0),
        "consistent_positive": bool(all(x > 0 for x in signs)), "consistent_negative": bool(all(x < 0 for x in signs)),
        **{f"diff_seed_{s}": per_seed_pt[s] for s in store.seeds},
        **{f"ci_seed_{s}": f"[{per_seed_ci[s][0]:+.3f},{per_seed_ci[s][1]:+.3f}]" for s in store.seeds},
        "cond_A_better": better, "cond_B_better": worse, "cond_tie": tie, "sign_test_p": p_sign,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=Path, default=ROOT / "multiseed_results")
    ap.add_argument("--comparison", type=Path, default=ROOT / "multiseed_comparison")
    ap.add_argument("--seed-dirs", type=Path, nargs="*", default=None)
    ap.add_argument("--n-boot", type=int, default=5000)
    args = ap.parse_args()
    args.comparison.mkdir(parents=True, exist_ok=True)
    dirs = args.seed_dirs or sorted(args.results.glob("seed_*"))
    store = Store(dirs)
    print("seeds:", store.seeds)

    # ---------- per-seed and aggregate metrics ----------
    rows = []
    for s in store.seeds:
        mj = json.loads((Path(dirs[store.seeds.index(s)]) / "metrics.json").read_text())
        for key, m in mj.items():
            scn, model, init, target = key.split("|")
            regime = "severity" if scn == "severity" else "nominal"
            inf = store.info[s].get(f"{regime}|{model}|{init}", {})
            rows.append(dict(dataset_seed=s, scenario=scn, model=model, init_seed=int(init), target=target,
                             accuracy=m["accuracy"], macro_f1=m["macro_f1"], weighted_f1=m["weighted_f1"],
                             train_seconds=inf.get("train_seconds"), infer_ms_per_sample=inf.get("infer_ms_per_sample"),
                             **{f"recall_{k}": v for k, v in m["per_class_recall"].items()}))
    per_seed = pd.DataFrame(rows)
    per_seed.to_csv(args.results / "per_seed_metrics.csv", index=False)

    init_avg = per_seed.groupby(["dataset_seed", "scenario", "model", "target"], as_index=False).mean(numeric_only=True)
    agg = init_avg.groupby(["scenario", "model", "target"]).agg(
        n_dataset_seeds=("dataset_seed", "nunique"),
        accuracy_mean=("accuracy", "mean"), accuracy_std=("accuracy", "std"),
        macro_f1_mean=("macro_f1", "mean"), macro_f1_std=("macro_f1", "std"),
        weighted_f1_mean=("weighted_f1", "mean"), weighted_f1_std=("weighted_f1", "std"),
        train_seconds_mean=("train_seconds", "mean"), infer_ms_per_sample_mean=("infer_ms_per_sample", "mean"),
    ).reset_index()
    agg["model"] = pd.Categorical(agg["model"], ORDER, ordered=True)
    agg["scenario"] = pd.Categorical(agg["scenario"], SCEN, ordered=True)
    agg = agg.sort_values(["target", "scenario", "model"])
    agg.round(4).to_csv(args.results / "aggregate_metrics.csv", index=False)

    rec_cols = [c for c in init_avg.columns if c.startswith("recall_")]
    rec = init_avg.groupby(["scenario", "model", "target"])[rec_cols].mean().dropna(axis=1, how="all").reset_index()
    rec.round(4).to_csv(args.results / "per_class_recall.csv", index=False)

    # confusion matrices (summed over dataset seeds, averaged over inits) and AFE/ADC separation
    cmj, sep = {}, []
    for scn in SCEN:
        for model in ORDER:
            for target in ("layer", "fault"):
                tot = None
                for s in store.seeds:
                    if not store.has(s, scn, model):
                        continue
                    cm = np.mean([c.sum(0) for c in store.cms(s, scn, model, target)], axis=0)
                    tot = cm if tot is None else tot + cm
                if tot is None:
                    continue
                cmj[f"{scn}|{model}|{target}"] = np.round(tot, 1).tolist()
                if target == "layer":
                    a, d = LAYERS.index("afe"), LAYERS.index("adc")
                    n = tot[a].sum() + tot[d].sum()
                    sep.append(dict(scenario=scn, model=model,
                                    afe_recall=tot[a, a] / tot[a].sum(), adc_recall=tot[d, d] / tot[d].sum(),
                                    afe_adc_cross_confusion=(tot[a, d] + tot[d, a]) / n))
    (args.results / "confusion_matrices.json").write_text(json.dumps(cmj), encoding="utf-8")
    pd.DataFrame(sep).round(4).to_csv(args.results / "afe_adc_separation.csv", index=False)

    # ---------- best TCN by validation ----------
    val = {m: np.mean([store.info[s][f"nominal|{m}|{i}"]["val_score"] for s in store.seeds for i in INITS])
           for m in ("tcn_v2a", "tcn_v2b")}
    best_tcn = max(val, key=val.get)
    print("validation scores:", val, "-> best TCN:", best_tcn)

    # ---------- paired bootstrap comparisons ----------
    pairs = []
    for scn in SCEN:
        for ref in ONE_POINT:
            pairs.append((scn, "two_point_mlp", ref))
            pairs.append((scn, best_tcn, ref))
        pairs += [(scn, best_tcn, "two_point_mlp"), ("%s" % scn, "two_point_rf", "two_point_mlp"),
                  (scn, "tcn_v2a", "tcn_v2b")]
        if scn != "severity":
            pairs.append((scn, "tcn_v2b", "tcn_v2b_nophys"))
    results = []
    for scn, a, b in pairs:
        if not all(store.has(s, scn, m) for s in store.seeds for m in (a, b)):
            continue
        for target in ("layer", "fault"):
            for metric in ("macro_f1", "accuracy"):
                results.append(compare(store, scn, target, a, b, metric, args.n_boot))
    comp = pd.DataFrame(results)
    comp.round(4).to_csv(args.results / "bootstrap_comparisons.csv", index=False)

    # ---------- decision rules ----------
    def row(scn, target, a, b, metric="macro_f1"):
        r = comp[(comp.scenario == scn) & (comp.target == target) & (comp.A == a) & (comp.B == b) & (comp.metric == metric)]
        return r.iloc[0]
    decision = {"best_tcn_by_validation": best_tcn, "validation_scores": val, "R1": {}, "R2": {}, "R3": {}}
    r1_ok_all = True
    for scn in ["nominal", "tolerance", "ref_m20", "ref_p20", "severity"]:
        for target in ("layer", "fault"):
            ok = all(row(scn, target, "two_point_mlp", b).ci_low > 0 for b in ONE_POINT)
            cons = all(row(scn, target, "two_point_mlp", b).consistent_positive for b in ONE_POINT)
            decision["R1"][f"{scn}|{target}"] = {"ci_above_zero_vs_all_four": bool(ok), "consistent_positive_all_seeds": bool(cons),
                "min_ci_low": float(min(row(scn, target, "two_point_mlp", b).ci_low for b in ONE_POINT))}
            if target == "layer" and scn != "severity":
                r1_ok_all &= bool(ok)
    for scn in SCEN:
        for target in ("layer", "fault"):
            r = row(scn, target, best_tcn, "two_point_mlp")
            decision["R2"][f"{scn}|{target}"] = {"diff": float(r.diff_pooled), "ci": [float(r.ci_low), float(r.ci_high)],
                                               "similar_ci_contains_zero": bool(not r.ci_excludes_zero)}
    for scn in SCEN[:4]:
        for target in ("layer", "fault"):
            r = row(scn, target, "tcn_v2b", "tcn_v2b_nophys")
            decision["R3"][f"{scn}|{target}"] = {"diff_phys_minus_nophys": float(r.diff_pooled), "ci": [float(r.ci_low), float(r.ci_high)],
                                                "physics_loss_helps": bool(r.ci_low > 0)}
    tcn_worse = any(row(scn, t, best_tcn, "two_point_mlp").ci_high < 0
                    for scn, t in [("nominal", "layer"), ("nominal", "fault")] + [(s, "layer") for s in SHIFTED])
    decision["R1_holds_nominal_and_all_shifts_layer"] = bool(r1_ok_all)
    decision["best_tcn_significantly_worse_than_mlp"] = bool(tcn_worse)
    decision["tag"] = ("ROBUSTNESS FAILURE; REVISE BEFORE PAPER" if not r1_ok_all else
                       "ELECTRONIC ARCHITECTURE VALIDATED; MODEL REQUIRES REVISION" if tcn_worse else
                       "ELECTRONIC ARCHITECTURE VALIDATED")
    (args.results / "decision_rules.json").write_text(json.dumps(decision, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in decision.items() if k not in ("R2", "R3")}, indent=2))

    # ---------- figures ----------
    colors = {"passive_mlp": "#999999", "single_mlp": "#bbbb66", "afe_only_mlp": "#e0a060", "adc_only_mlp": "#d08080",
              "two_point_mlp": "#2f6db5", "two_point_rf": "#7aa6d6", "tcn_v2a": "#2a9d5c", "tcn_v2b": "#1b6e3d", "tcn_v2b_nophys": "#9bd0a8"}
    ia = init_avg
    def bars(ax, scn, target, models, title):
        for i, m in enumerate(models):
            d = ia[(ia.scenario == scn) & (ia.model == m) & (ia.target == target)]
            ax.bar(i, d.macro_f1.mean(), yerr=d.macro_f1.std(ddof=1) if len(d) > 1 else 0, color=colors[m], capsize=3)
            ax.scatter(np.full(len(d), i), d.macro_f1, color="k", s=10, zorder=3)
        ax.set_xticks(range(len(models))); ax.set_xticklabels(models, rotation=60, ha="right", fontsize=8)
        ax.set_title(title, fontsize=10); ax.set_ylim(0, 0.85)
    nominal_models = [m for m in ORDER if m != "tcn_v2b_nophys"]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), sharey=True)
    for ax, t in zip(axes, ("layer", "fault")):
        bars(ax, "nominal", t, ORDER, f"{t} macro-F1 (nominal)")
    axes[0].set_ylabel("macro-F1 (mean ± std over dataset seeds; dots = seeds)")
    fig.tight_layout(); fig.savefig(args.comparison / "nominal_macro_f1.png", dpi=150); plt.close(fig)

    fig, axes = plt.subplots(2, 4, figsize=(17, 8), sharey=True)
    for r, t in enumerate(("layer", "fault")):
        for c, scn in enumerate(["tolerance", "ref_m20", "ref_p20", "severity"]):
            bars(axes[r, c], scn, t, nominal_models, f"{t} macro-F1: {scn}")
    fig.tight_layout(); fig.savefig(args.comparison / "robustness_macro_f1.png", dpi=150); plt.close(fig)

    # console digest
    pd.set_option("display.width", 250)
    for t in ("layer", "fault"):
        p = agg[agg.target == t].pivot(index="model", columns="scenario", values="macro_f1_mean").reindex(ORDER)
        print(f"\nmacro-F1 ({t}), mean over dataset seeds\n", p.round(3).to_string())


if __name__ == "__main__":
    main()
