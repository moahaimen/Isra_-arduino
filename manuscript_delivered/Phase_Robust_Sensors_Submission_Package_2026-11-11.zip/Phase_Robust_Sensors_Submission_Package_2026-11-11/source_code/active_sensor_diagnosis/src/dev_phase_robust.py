"""DEVELOPMENT-ONLY (seed 20261097): behavioral-vs-ngspice agreement per phase, and invariance of the transient descriptors."""
import sys
from pathlib import Path
import numpy as np
from .phase_features import TF_NAMES, transient_features
from .ref_features import FEATURE_NAMES, ref_descriptors
from .simulate import FAULTS, make_condition, make_fault, simulate_sample
from .spice_phase import spice_record_phase

wd = Path(sys.argv[1]); n_sp = int(sys.argv[2]); n_beh = int(sys.argv[3])
PH = (0.0, 0.25, 0.5, 0.75, 0.999)
rng = np.random.default_rng(20261097)
specs = []
for cid in range(max(n_sp, n_beh)):
    cond = make_condition(rng)
    for name in FAULTS:
        specs.append((cond, make_fault(name, rng), int(rng.integers(0, 2**31 - 1))))
# (1) waveform agreement per phase (noise-free SPICE extras)
print("SPICE vs behavioral waveform RMSE (V) / |rise_2 diff| (sigma-free, raw) by phase:")
for ph in PH:
    rm, dr = [], []
    for cond, f, sd in specs[:n_sp * 9]:
        b = simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point", ref_phase=ph)
        s = spice_record_phase(cond, f, sd + 4, wd, phase=ph, extra_noise=False)
        rm.append(np.sqrt(np.mean((b["waveform"] - s["waveform"]) ** 2)))
        dr.append(abs(ref_descriptors(b)[0][FEATURE_NAMES.index("rise_2")] - ref_descriptors(s)[0][FEATURE_NAMES.index("rise_2")]))
    print(f"  phase {ph:5.3f}: rmse {np.mean(rm):.4f} V   mean |rise_2 diff| {np.mean(dr):.3f}")
# (2) invariance of descriptors across phase (behavioral, same sample, different phase)
sel = specs[:n_beh * 9]
R = {ph: [] for ph in PH}; T = {ph: [] for ph in PH}
for cond, f, sd in sel:
    for ph in PH:
        b = simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point", ref_phase=ph)
        R[ph].append(ref_descriptors(b)[0]); T[ph].append(transient_features(b))
R = {k: np.array(v) for k, v in R.items()}; T = {k: np.array(v) for k, v in T.items()}
sdR = R[0.0].std(0) + 1e-9; sdT = T[0.0].std(0) + 1e-9
print("\nmean |descriptor(phase) - descriptor(phase 0)| in units of the descriptor's std over samples:")
print("  Revision-1 rise fractions:", {n: [round(float(np.mean(np.abs(R[ph][:, FEATURE_NAMES.index(n)] - R[0.0][:, FEATURE_NAMES.index(n)])) / sdR[FEATURE_NAMES.index(n)]), 2) for ph in PH[1:]] for n in ("rise_2", "rise_5", "rise_10", "rise_20", "rise_30")})
print("  phase-robust transient   :", {n: [round(float(np.mean(np.abs(T[ph][:, i] - T[0.0][:, i])) / sdT[i]), 2) for ph in PH[1:]] for i, n in enumerate(TF_NAMES)})
print("  mean time per transient_features call (ms):", end=" ")
import time; t0 = time.time()
for cond, f, sd in sel[:200]: transient_features(simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point"))
print(round((time.time() - t0) / 200 * 1000, 2), "(incl. simulation)")
