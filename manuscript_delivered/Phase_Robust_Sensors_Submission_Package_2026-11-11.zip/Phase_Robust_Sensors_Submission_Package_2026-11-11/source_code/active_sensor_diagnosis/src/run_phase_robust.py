"""Frozen phase-robust validation for ONE dataset seed (see phase_robust_final/PROTOCOL_PHASE_ROBUST_FROZEN.md).

Usage: python3 -m src.run_phase_robust --dataset-seed 20261026
Writes phase_robust_final/phase_robust_results/seed_<S>/{predictions.npz, model_info.json, meta.json}.
"""

from __future__ import annotations

import argparse
import json
import tempfile
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
from sklearn.model_selection import GroupShuffleSplit

from .features import physics_features, raw_features
from .monitor_model import draw, variant_descriptors
from .phase_features import to_phase_robust, transient_features
from .ref_features import ref_descriptors
from .run_feasibility import _classifier
from .run_multiseed import INITS, LAYER_ID, MODE_OFFSET, MODES
from .run_reference_monitor import _draw_tol, _n_params
from .simulate import FAULT_TO_LAYER, FAULTS, make_condition, make_fault, simulate_sample
from .spice_phase import spice_record_phase

ROOT = Path(__file__).resolve().parents[1]
OUT_ROOT = ROOT / "phase_robust_final" / "phase_robust_results"
GUARD = 0.30
PH = (0.0, 0.25, 0.5, 0.75, 0.999)
PCODE = {0.0: "p000", 0.25: "p250", 0.5: "p500", 0.75: "p750", 0.999: "p999"}
AMPS_BH = (0.8, 0.9, 1.0, 1.1, 1.2)
AMPS_1PT = (0.8, 1.0, 1.2)  # one-point baselines and SPICE
AMPS_SP = (0.8, 1.0, 1.2)
EP = (0, 1, 2, 5)
TRAIN_VARS = ("known",) + tuple(f"mon{e}" for e in EP)
TEST_VARS = TRAIN_VARS
PATHS = ("passive", "single", "afe_only", "adc_only", "two_point")
REF_MODES = ("afe_only", "adc_only", "two_point")
ARMS = ("R1", "R1r", "PR", "PRr")  # R1: Revision-1 descriptors; PR: phase-robust; r: random-phase training


def A(a): return int(round(a * 100))


def vs(v): return "k" if v == "known" else "e" + v[3:]


def _old(rec): return np.concatenate([raw_features(rec), physics_features(rec)]).astype(np.float32)


def ref_feats(rec, u, nz, variants):
    """{variant: (r1_desc, pr_desc)}; the transient descriptors are affine-invariant, so computed once per record."""
    tf = transient_features(rec)
    out = {}
    for v, (d, _) in variant_descriptors(rec, u, nz, variants, GUARD).items():
        out[v] = (d, to_phase_robust(d, tf))
    return out


def _spice_job(args):
    cond, fault, seed, amp, tol, ph, wd = args
    return spice_record_phase(cond, fault, seed, Path(wd), amp=amp, tol=tol, phase=ph)


class Bag:
    def __init__(self): self.d = {}
    def add(self, key, x): self.d.setdefault(key, []).append(x)
    def arr(self): return {k: np.asarray(v, dtype=np.float32) for k, v in self.d.items()}


def build(seed: int, n_cond: int, workers: int, wd: Path) -> dict:
    n_rows = n_cond * len(FAULTS)
    groups = np.repeat(np.arange(n_cond), len(FAULTS))
    dev, test = next(GroupShuffleSplit(1, test_size=0.25, random_state=seed + 1).split(np.zeros(n_rows), groups=groups))
    sub = next(GroupShuffleSplit(1, test_size=0.15, random_state=seed + 2).split(dev, groups=groups[dev]))
    train, val = dev[sub[0]], dev[sub[1]]
    train_set, test_set = set(train.tolist()), set(test.tolist())
    rng = np.random.default_rng(seed)
    tol_rng, phase_rng = np.random.default_rng(seed + 10_000), np.random.default_rng(seed + 40_000)
    specs = []
    for cid in range(n_cond):
        cond = make_condition(rng)
        for ci, name in enumerate(FAULTS):
            fault = make_fault(name, rng)
            sd = int(rng.integers(0, 2**31 - 1))
            specs.append(dict(row=cid * len(FAULTS) + ci, cid=cid, ci=ci, cond=cond, fault=fault, sd=sd, tol=_draw_tol(tol_rng),
                              psi=float(phase_rng.uniform(0.0, 1.0))))
    # ---- ngspice tasks (run in the background while the behavioral part is computed) ----
    tasks, tmeta = [], []
    for s in specs:
        sdt = s["sd"] + MODE_OFFSET["two_point"]
        if s["row"] in train_set:
            tasks.append((s["cond"], s["fault"], sdt, 1.0, s["tol"], s["psi"], str(wd))); tmeta.append(("train", s["row"], None, None))
        elif s["row"] in test_set:
            for a in AMPS_SP:
                for ph in PH:
                    tasks.append((s["cond"], s["fault"], sdt, a, s["tol"], ph, str(wd))); tmeta.append(("test", s["row"], a, ph))
    pool = Pool(workers)
    t_sp0 = time.time()
    async_res = pool.map_async(_spice_job, tasks, chunksize=16)

    # ---- behavioral part ----
    TR = {"old": Bag(), "r1_0": Bag(), "pr_0": Bag(), "r1_r": Bag(), "pr_r": Bag()}
    TE = {"old": Bag(), "r1": Bag(), "pr": Bag()}
    y_layer, y_fault, groups_test, timing_recs = [], [], [], []
    for s in specs:
        r = s["row"]
        if r not in train_set and r not in test_set:
            continue
        u, nz = draw(seed, r)
        cond, fault, sd = s["cond"], s["fault"], s["sd"]
        if r in train_set:
            for m in PATHS:
                rec = simulate_sample(cond, fault, active=(m != "passive"), seed=sd + MODE_OFFSET[m], probe_mode=MODES[m])
                TR["old"].add(m, _old(rec))
                if m in REF_MODES:
                    for v, (d1, dp) in ref_feats(rec, u, nz, TRAIN_VARS).items():
                        TR["r1_0"].add((m, v), d1); TR["pr_0"].add((m, v), dp)
            for m in REF_MODES:
                rec = simulate_sample(cond, fault, active=True, seed=sd + MODE_OFFSET[m], probe_mode=MODES[m], ref_phase=s["psi"])
                for v, (d1, dp) in ref_feats(rec, u, nz, TRAIN_VARS).items():
                    TR["r1_r"].add((m, v), d1); TR["pr_r"].add((m, v), dp)
        else:
            y_layer.append(LAYER_ID[FAULT_TO_LAYER[FAULTS[s["ci"]]]]); y_fault.append(s["ci"]); groups_test.append(s["cid"])
            tol = s["tol"]
            rec = simulate_sample(cond, fault, active=False, seed=sd + MODE_OFFSET["passive"], probe_mode="passive", **tol)
            TE["old"].add(("passive", None, None), _old(rec))
            for a in AMPS_BH:
                if a in AMPS_1PT:
                    rec = simulate_sample(cond, fault, active=True, seed=sd + MODE_OFFSET["single"], probe_mode="single", ref_scale=a, **tol)
                    TE["old"].add(("single", a, None), _old(rec))
                for ph in PH:
                    for m in REF_MODES:
                        if m != "two_point" and a not in AMPS_1PT:
                            continue
                        rec = simulate_sample(cond, fault, active=True, seed=sd + MODE_OFFSET[m], probe_mode=MODES[m], ref_scale=a,
                                              ref_phase=ph, **tol)
                        TE["old"].add((m, a, ph), _old(rec))
                        variants = TEST_VARS + (("assumed",) if m == "two_point" else ())
                        for v, (d1, dp) in ref_feats(rec, u, nz, variants).items():
                            TE["r1"].add((m, a, ph, v), d1); TE["pr"].add((m, a, ph, v), dp)
                        if m == "two_point" and a == 1.0 and ph == 0.0 and len(timing_recs) < 200:
                            timing_recs.append(rec)
    beh_seconds = time.time() - t_sp0
    recs = async_res.get()
    pool.close(); pool.join()
    spice_seconds = time.time() - t_sp0
    SPtr, SPte = {"pr": Bag()}, {"r1": Bag(), "pr": Bag()}
    for (kind, r, a, ph), rec in zip(tmeta, recs):
        u, nz = draw(seed, r)
        f = ref_feats(rec, u, nz, TRAIN_VARS)
        if kind == "train":
            for v, (d1, dp) in f.items():
                SPtr["pr"].add(v, dp)
        else:
            for v, (d1, dp) in f.items():
                SPte["r1"].add((a, ph, v), d1); SPte["pr"].add((a, ph, v), dp)
    y_tr_layer = np.asarray([LAYER_ID[FAULT_TO_LAYER[FAULTS[i % len(FAULTS)]]] for i in sorted(train_set)])
    y_tr_fault = np.asarray([i % len(FAULTS) for i in sorted(train_set)])
    return {"groups": groups, "train": train, "val": val, "test": test, "y_tr_layer": y_tr_layer, "y_tr_fault": y_tr_fault,
            "y_layer": np.asarray(y_layer), "y_fault": np.asarray(y_fault), "test_cond": np.asarray(groups_test),
            "TR": {k: b.arr() for k, b in TR.items()}, "TE": {k: b.arr() for k, b in TE.items()},
            "SPtr": SPtr["pr"].arr(), "SPte": {k: b.arr() for k, b in SPte.items()}, "timing_recs": timing_recs,
            "spice_seconds": spice_seconds, "behavioral_seconds": beh_seconds, "n_spice": len(tasks)}


def train_and_predict(D: dict) -> tuple[dict, dict]:
    ytr = {"layer": D["y_tr_layer"], "fault": D["y_tr_fault"]}
    preds, info = {}, {}
    TR, TE, SPtr, SPte = D["TR"], D["TE"], D["SPtr"], D["SPte"]

    def fit(X, target, init, y=None):
        est = _classifier(init)
        t0 = time.time(); est.fit(X, ytr[target] if y is None else y); return est, time.time() - t0

    def put(scn, model, init, target, est, X):
        preds[f"{scn}|{model}|{init}|{target}"] = est.predict(X).astype(np.int8)

    for init in INITS:
        for target in ("layer", "fault"):
            # ---- A0 (old features, psi = 0 training): replicated under every variant label ----
            for m in PATHS:
                est, ts = fit(TR["old"][m], target, init)
                info[f"{m}_mlp@A0|{init}|{target}"] = {"train_seconds": ts, "params": _n_params(est)}
                for v in TEST_VARS:
                    if m == "passive":
                        X = TE["old"][("passive", None, None)]
                        for a in AMPS_BH:
                            for ph in PH:
                                put(f"bh_a{A(a)}_{PCODE[ph]}_{v}", f"{m}_mlp@A0", init, target, est, X)
                    elif m == "single":
                        for a in AMPS_1PT:
                            for ph in PH:
                                put(f"bh_a{A(a)}_{PCODE[ph]}_{v}", f"{m}_mlp@A0", init, target, est, TE["old"][("single", a, None)])
                    else:
                        for a in (AMPS_BH if m == "two_point" else AMPS_1PT):
                            for ph in PH:
                                put(f"bh_a{A(a)}_{PCODE[ph]}_{v}", f"{m}_mlp@A0", init, target, est, TE["old"][(m, a, ph)])
            # ---- descriptor arms ----
            for arm, trkey, tekey in (("R1", "r1_0", "r1"), ("R1r", "r1_r", "r1"), ("PR", "pr_0", "pr"), ("PRr", "pr_r", "pr")):
                for m in REF_MODES:
                    for v in TRAIN_VARS:
                        est, ts = fit(TR[trkey][(m, v)], target, init)
                        name = f"{m}_mlp@{arm}_{vs(v)}"
                        info[f"{name}|{init}|{target}"] = {"train_seconds": ts, "params": _n_params(est)}
                        for a in (AMPS_BH if m == "two_point" else AMPS_1PT):
                            for ph in PH:
                                put(f"bh_a{A(a)}_{PCODE[ph]}_{v}", name, init, target, est, TE[tekey][(m, a, ph, v)])
                                if m == "two_point" and a in AMPS_SP:
                                    put(f"sp_a{A(a)}_{PCODE[ph]}_{v}", name, init, target, est, SPte[tekey][(a, ph, v)])
                        # no-monitor control: the known-reference classifier applied with nominal-assumed levels
                        if arm == "PRr" and m == "two_point" and v == "known":
                            for a in AMPS_BH:
                                for ph in PH:
                                    put(f"bh_a{A(a)}_{PCODE[ph]}_assumed", name, init, target, est, TE["pr"][(m, a, ph, "assumed")])
            # ---- mixed behavioral + ngspice training (phase-robust descriptors, random phase) ----
            for v in TRAIN_VARS:
                X = np.vstack([TR["pr_r"][("two_point", v)], SPtr[v]])
                y = np.concatenate([ytr[target], ytr[target]])
                est, ts = fit(X, target, init, y)
                name = f"two_point_mlp@PRrM_{vs(v)}"
                info[f"{name}|{init}|{target}"] = {"train_seconds": ts, "params": _n_params(est)}
                for a in AMPS_BH:
                    for ph in PH:
                        put(f"bh_a{A(a)}_{PCODE[ph]}_{v}", name, init, target, est, TE["pr"][("two_point", a, ph, v)])
                        if a in AMPS_SP:
                            put(f"sp_a{A(a)}_{PCODE[ph]}_{v}", name, init, target, est, SPte["pr"][(a, ph, v)])
    # per-sample costs
    r1_t = pr_t = 0.0
    for rec in D["timing_recs"]:
        t0 = time.time(); ref_descriptors(rec, GUARD); r1_t += time.time() - t0
        t0 = time.time(); ref_descriptors(rec, GUARD); transient_features(rec); pr_t += time.time() - t0
    n = max(len(D["timing_recs"]), 1)
    info["descriptor_extraction_ms_per_sample"] = {"revision1": r1_t / n * 1000, "phase_robust": pr_t / n * 1000}
    est = _classifier(11).fit(TR["pr_r"][("two_point", "mon2")], ytr["layer"])
    X = TE["pr"][("two_point", 1.0, 0.0, "mon2")]
    t0 = time.time(); est.predict(X); info["mlp_predict_ms_per_sample"] = (time.time() - t0) / len(X) * 1000
    info["spice_wall_seconds"] = D["spice_seconds"]
    return preds, info


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset-seed", type=int, required=True)
    ap.add_argument("--n-cond", type=int, default=350)
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--out-dir", type=Path, default=None)
    args = ap.parse_args()
    out = args.out_dir or OUT_ROOT / f"seed_{args.dataset_seed}"
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    with tempfile.TemporaryDirectory(prefix="spice_") as wd:
        D = build(args.dataset_seed, args.n_cond, args.workers, Path(wd))
    g = D["groups"]
    meta = {"dataset_seed": args.dataset_seed, "split_random_state": args.dataset_seed + 1, "val_random_state": args.dataset_seed + 2,
            "guard": GUARD, "phases": list(PH), "amplitudes_behavioral": list(AMPS_BH), "amplitudes_ngspice": list(AMPS_SP),
            "monitor_error_percent": list(EP), "workers": args.workers, "conditions_total": int(len(set(g))),
            "train_conditions": int(len(set(g[D["train"]]))), "val_conditions": int(len(set(g[D["val"]]))),
            "test_conditions": int(len(set(g[D["test"]]))), "n_ngspice_runs": D["n_spice"],
            "ngspice_wall_seconds": round(D["spice_seconds"], 1), "behavioral_seconds": round(D["behavioral_seconds"], 1),
            "overlap": int(len(set(g[D["train"]]) & set(g[D["test"]])) + len(set(g[D["val"]]) & set(g[D["test"]])) + len(set(g[D["train"]]) & set(g[D["val"]])))}
    assert meta["overlap"] == 0
    print(meta, flush=True)
    preds, info = train_and_predict(D)
    arrays = {"y_layer": D["y_layer"].astype(np.int8), "y_fault": D["y_fault"].astype(np.int8), "cond": D["test_cond"].astype(np.int32)}
    arrays.update(preds)
    np.savez_compressed(out / "predictions.npz", **arrays)
    (out / "model_info.json").write_text(json.dumps(info, indent=1), encoding="utf-8")
    meta["total_seconds"] = round(time.time() - t0, 1)
    (out / "meta.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")
    print("DONE", meta, flush=True)


if __name__ == "__main__":
    main()
