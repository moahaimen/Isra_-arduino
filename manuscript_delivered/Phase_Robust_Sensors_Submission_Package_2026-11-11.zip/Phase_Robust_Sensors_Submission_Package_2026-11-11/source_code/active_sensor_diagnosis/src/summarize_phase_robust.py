"""Analysis of the frozen phase-robust validation: criteria A-G, attribution, figures, GO/REVISE."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .run_phase_robust import PCODE, PH, TEST_VARS
from .simulate import FAULTS, LAYERS
from .summarize_reference_monitor import (INITS, K, LABELS, Store, compare, cross_confusion, metric_from_cm, pooled_cm, point)

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "phase_robust_final"
XS = ("known", "mon0", "mon1", "mon2", "mon5")
AMP_BH = (80, 90, 100, 110, 120)
AMP_SP = (80, 100, 120)
BASE_NAMES = [("two_point_mlp@A0", "two-point A0"), ("passive_mlp@A0", "passive A0"), ("single_mlp@A0", "single A0"),
              ("afe_only_mlp@A0", "AFE-only A0"), ("adc_only_mlp@A0", "ADC-only A0")]


def vs(x): return "k" if x == "known" else "e" + x[3:]
def sc(dom, a, ph, v): return f"{dom}_a{a}_{PCODE[ph]}_{v}"
def cells(dom, amps, v, phases=PH): return [sc(dom, a, ph, v) for a in amps for ph in phases]
def M(arm, x, path="two_point"): return f"{path}_mlp@{arm}_{vs(x)}"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=Path, default=BASE / "phase_robust_results")
    ap.add_argument("--figures", type=Path, default=BASE / "phase_robust_figures")
    ap.add_argument("--seed-dirs", type=Path, nargs="*", default=None)
    ap.add_argument("--n-boot", type=int, default=5000)
    args = ap.parse_args()
    args.figures.mkdir(parents=True, exist_ok=True)
    dirs = args.seed_dirs or sorted(args.results.glob("seed_*"))
    st = Store(dirs)
    seeds = st.seeds
    print("seeds", seeds)
    nb = args.n_boot
    crit = {}

    # ----- reference nominal performance N per domain -----
    N = {"bh": point(st, cells("bh", (100,), "known"), M("PRr", "known"), "layer")[0],
         "sp": point(st, cells("sp", (100,), "known"), M("PRr", "known"), "layer")[0]}
    crit["N"] = N

    # ----- A retention, C confusion, D monitor error (both domains) -----
    A_, C_, D_ = {}, {}, {}
    for dom, amps in (("bh", AMP_BH), ("sp", AMP_SP)):
        for x in ("known", "mon0", "mon1", "mon2"):
            for a in (80, 120):
                v, _ = point(st, cells(dom, (a,), x), M("PRr", x), "layer")
                A_[f"{dom}|{x}|a{a}"] = {"f1": v, "retention": v / N[dom], "pass": bool(v >= 0.85 * N[dom])}
        for x in XS:
            for a in (80, 120):
                afe, adc, cross = cross_confusion(st, cells(dom, (a,), x), M("PRr", x))
                C_[f"{dom}|{x}|a{a}"] = {"afe_recall": afe, "adc_recall": adc, "cross_confusion": cross, "pass": bool(cross < 0.15)}
        for label, scns in (("a80", cells(dom, (80,), "mon5")), ("a120", cells(dom, (120,), "mon5")), ("pooled", cells(dom, amps, "mon5"))):
            v, _ = point(st, scns, M("PRr", "mon5"), "layer")
            D_[f"{dom}|{label}"] = {"f1": v, "retention": v / N[dom], "pass": bool(v >= 0.70 * N[dom])}
    crit["A"] = {"detail": A_, "pass_bh": all(v["pass"] for k, v in A_.items() if k.startswith("bh")), "pass_sp": all(v["pass"] for k, v in A_.items() if k.startswith("sp"))}
    crit["C"] = {"detail": C_, "pass_bh": all(v["pass"] for k, v in C_.items() if k.startswith("bh")), "pass_sp": all(v["pass"] for k, v in C_.items() if k.startswith("sp"))}
    crit["D"] = {"detail": D_, "pass_bh": all(v["pass"] for k, v in D_.items() if k.startswith("bh")), "pass_sp": all(v["pass"] for k, v in D_.items() if k.startswith("sp"))}

    # ----- B superiority (behavioral, +-20%, pooled phases) -----
    B_, comp_rows = {}, []
    for x in XS:
        for a in (80, 120):
            scns = cells("bh", (a,), x)
            bl = [b for b, _ in BASE_NAMES] + [M("PRr", x, "afe_only"), M("PRr", x, "adc_only")]
            for b in bl:
                r = compare(st, scns, M("PRr", x), scns, b, "layer", "macro_f1", nb)
                B_[f"{x}|a{a}|vs {b}"] = {**r, "pass": bool(r["ci_low"] > 0)}
                comp_rows.append(dict(rule="B", scenario=f"bh x{a / 100:.1f} pooled phases, {x}", A=M("PRr", x), B=b, target="layer", metric="macro_f1",
                                      diff=r["diff"], ci_low=r["ci_low"], ci_high=r["ci_high"]))
    crit["B"] = {"detail": B_, "pass": all(v["pass"] for v in B_.values())}

    # ----- E transfer, G phase variation -----
    grid_bh = lambda x: cells("bh", AMP_SP, x)
    grid_sp = lambda x: cells("sp", AMP_SP, x)
    E_ = {}
    for x in XS:
        m = M("PRr", x)
        drop = compare(st, grid_bh(x), m, grid_sp(x), m, "layer", "macro_f1", nb)
        mm = M("PRrM", x)
        drop_mixed = compare(st, grid_bh(x), m, grid_sp(x), mm, "layer", "macro_f1", nb)
        gain = compare(st, grid_sp(x), mm, grid_sp(x), m, "layer", "macro_f1", nb)
        E_[x] = {"BB": point(st, grid_bh(x), m, "layer")[0], "BS": point(st, grid_sp(x), m, "layer")[0], "MS": point(st, grid_sp(x), mm, "layer")[0],
                 "drop": drop["diff"], "drop_ci": [drop["ci_low"], drop["ci_high"]], "pass": bool(drop["diff"] <= 0.10),
                 "mixed_drop_vs_BB": drop_mixed["diff"], "mixed_drop_ci": [drop_mixed["ci_low"], drop_mixed["ci_high"]], "mixed_pass": bool(drop_mixed["diff"] <= 0.10),
                 "MS_minus_BS": gain["diff"], "MS_minus_BS_ci": [gain["ci_low"], gain["ci_high"]]}
        comp_rows.append(dict(rule="E", scenario=f"bh vs sp grid, {x}", A=m, B=m, target="layer", metric="macro_f1", diff=drop["diff"], ci_low=drop["ci_low"], ci_high=drop["ci_high"]))
        comp_rows.append(dict(rule="F-mixed", scenario=f"sp grid, {x}", A=mm, B=m, target="layer", metric="macro_f1", diff=gain["diff"], ci_low=gain["ci_low"], ci_high=gain["ci_high"]))
    crit["E"] = {"primary_E2": E_["mon2"], "all": E_, "pass": bool(E_["mon2"]["pass"])}
    G_ = {}
    for dom, amps in (("bh", AMP_BH), ("sp", AMP_SP)):
        for arm in ("PRr", "PRrM", "R1", "A0"):
            for x in ("known", "mon2"):
                model = "two_point_mlp@A0" if arm == "A0" else M(arm, x)
                if arm == "A0" and dom == "sp":
                    continue
                vals = {PCODE[ph]: point(st, [sc(dom, a, ph, x) for a in amps], model, "layer")[0] for ph in PH}
                G_[f"{dom}|{arm}|{x}"] = {"f1_by_phase": vals, "range": float(max(vals.values()) - min(vals.values())),
                                         "pass": bool(max(vals.values()) - min(vals.values()) <= 0.05)}
    crit["G"] = {"detail": G_, "pass_bh": all(G_[f"bh|PRr|{x}"]["pass"] for x in ("known", "mon2")), "pass_sp": all(G_[f"sp|PRr|{x}"]["pass"] for x in ("known", "mon2"))}

    # ----- decision -----
    gates = {"A_bh": crit["A"]["pass_bh"], "A_sp": crit["A"]["pass_sp"], "B": crit["B"]["pass"], "C_bh": crit["C"]["pass_bh"], "C_sp": crit["C"]["pass_sp"],
             "D_bh": crit["D"]["pass_bh"], "D_sp": crit["D"]["pass_sp"], "E": crit["E"]["pass"], "G_bh": crit["G"]["pass_bh"], "G_sp": crit["G"]["pass_sp"]}
    crit["gates"] = gates
    crit["failed"] = [k for k, v in gates.items() if not v]
    crit["decision"] = "GO" if not crit["failed"] else "REVISE"
    # mixed-training variant (reported only; the pre-registered primary is PRr)
    mixed = {"A_sp": all(point(st, cells("sp", (a,), x), M("PRrM", x), "layer")[0] >= 0.85 * N["sp"] for x in ("known", "mon0", "mon1", "mon2") for a in (80, 120)),
             "C_sp": all(cross_confusion(st, cells("sp", (a,), x), M("PRrM", x))[2] < 0.15 for x in XS for a in (80, 120)),
             "D_sp": all(point(st, sl, M("PRrM", "mon5"), "layer")[0] >= 0.70 * N["sp"] for sl in (cells("sp", (80,), "mon5"), cells("sp", (120,), "mon5"), cells("sp", AMP_SP, "mon5"))),
             "E_mixed": E_["mon2"]["mixed_pass"]}
    mixed["G_sp"] = all(max(v := [point(st, [sc("sp", a, ph, x) for a in AMP_SP], M("PRrM", x), "layer")[0] for ph in PH]) - min(v) <= 0.05 for x in ("known", "mon2"))
    mixed["all_pass"] = all(mixed.values())
    crit["mixed_variant_reported_only"] = mixed
    (args.results / "decision_rules.json").write_text(json.dumps(crit, indent=2, default=float))

    # ----- attribution (E=2%, pooled over phases) -----
    arms = [("A0", "two_point_mlp@A0"), ("R1", M("R1", "mon2")), ("R1r", M("R1r", "mon2")), ("PR", M("PR", "mon2")), ("PRr", M("PRr", "mon2")), ("PRrM", M("PRrM", "mon2"))]
    att_rows, att_cmp = [], []
    for dom, amps in (("bh", AMP_BH), ("sp", AMP_SP)):
        scns = cells(dom, amps, "mon2")
        for name, model in arms:
            if dom == "sp" and name == "A0":
                continue
            row = {"domain": dom, "arm": name}
            for target in ("layer", "fault"):
                row[f"{target}_macro_f1"] = point(st, scns, model, target)[0]
                row[f"{target}_balanced_accuracy"] = point(st, scns, model, target, "balanced_accuracy")[0]
            for ph in PH:
                row[f"layer_f1_{PCODE[ph]}"] = point(st, [sc(dom, a, ph, "mon2") for a in amps], model, "layer")[0]
            att_rows.append(row)
        pairs = [("PR - R1 (descriptors alone)", "PR", "R1"), ("R1r - R1 (phase randomisation alone)", "R1r", "R1"), ("PRr - R1r (descriptors, given randomisation)", "PRr", "R1r"),
                 ("PRr - PR (randomisation, given robust descriptors)", "PRr", "PR"), ("PRr - R1 (combination)", "PRr", "R1"), ("PRrM - PRr (mixed training)", "PRrM", "PRr")]
        if dom == "bh":
            pairs.append(("PRr - A0 (vs old method)", "PRr", "A0"))
        for label, a_, b_ in pairs:
            ma = dict(arms)[a_]; mb = dict(arms)[b_]
            r = compare(st, scns, ma, scns, mb, "layer", "macro_f1", nb)
            att_cmp.append({"domain": dom, "comparison": label, "diff": r["diff"], "ci_low": r["ci_low"], "ci_high": r["ci_high"], "consistent_3_seeds": r["all_seeds_positive"]})
            comp_rows.append(dict(rule="attribution", scenario=f"{dom} pooled, E=2%", A=ma, B=mb, target="layer", metric="macro_f1", diff=r["diff"], ci_low=r["ci_low"], ci_high=r["ci_high"]))
    pd.DataFrame(att_rows).round(4).to_csv(args.results / "attribution_arms.csv", index=False)
    pd.DataFrame(att_cmp).round(4).to_csv(args.results / "attribution_comparisons.csv", index=False)
    pd.DataFrame(comp_rows).round(4).to_csv(args.results / "bootstrap_comparisons.csv", index=False)

    # ----- control: no monitor -----
    ctl = {}
    for a in AMP_BH:
        ctl[f"x{a / 100:.1f}"] = {"known": point(st, cells("bh", (a,), "known"), M("PRr", "known"), "layer")[0],
                                  "unmonitored": point(st, cells("bh", (a,), "assumed"), M("PRr", "known"), "layer")[0]}
    crit_ctl = {"no_monitor_control_layer_macro_f1": ctl}
    (args.results / "no_monitor_control.json").write_text(json.dumps(crit_ctl, indent=2))

    # ----- tables: amplitude curves & per-class recall, aggregate metrics -----
    rows = []
    curve_models = [("A0 old", "two_point_mlp@A0", "known"), ("R1 known", M("R1", "known"), "known"), ("R1 E=2%", M("R1", "mon2"), "mon2"), ("PRr known", M("PRr", "known"), "known"),
                    ("PRr E=0%", M("PRr", "mon0"), "mon0"), ("PRr E=1%", M("PRr", "mon1"), "mon1"), ("PRr E=2%", M("PRr", "mon2"), "mon2"), ("PRr E=5%", M("PRr", "mon5"), "mon5")]
    for dom, amps in (("bh", AMP_BH), ("sp", AMP_SP)):
        for name, model, x in curve_models:
            if dom == "sp" and name == "A0 old":
                continue
            for target in ("layer", "fault"):
                rows.append({"domain": dom, "series": name, "target": target, **{f"x{a / 100:.1f}": point(st, cells(dom, (a,), x), model, target)[0] for a in amps},
                             "pooled": point(st, cells(dom, amps, x), model, target)[0]})
    pd.DataFrame(rows).round(4).to_csv(args.results / "amplitude_curves.csv", index=False)
    rows = []
    for dom, amps in (("bh", AMP_BH), ("sp", AMP_SP)):
        for name, model in arms + [("PRr known (no monitor, assumed levels)", None)]:
            if dom == "sp" and name in ("A0",) or (model is None and dom == "sp"):
                continue
            if model is None:
                cm = pooled_cm(st, [sc("bh", a, ph, "assumed") for a in (80, 120) for ph in PH], M("PRr", "known"), "layer")
                lab = "unmonitored x0.8/x1.2"
            else:
                cm = pooled_cm(st, cells(dom, amps, "mon2"), model, "layer"); lab = "pooled E=2%"
            rows.append({"domain": dom, "arm": name, "scope": lab, **{LABELS["layer"][k]: float(cm[k, k] / cm[k].sum()) for k in range(4)}})
    pd.DataFrame(rows).round(4).to_csv(args.results / "per_class_recall_layer.csv", index=False)
    rows = []
    for dom, amps in (("bh", AMP_BH), ("sp", AMP_SP)):
        for name, model in arms:
            if dom == "sp" and name == "A0":
                continue
            cm = pooled_cm(st, cells(dom, amps, "mon2"), model, "fault")
            rows.append({"domain": dom, "arm": name, **{LABELS["fault"][k]: float(cm[k, k] / cm[k].sum()) for k in range(9)}})
    pd.DataFrame(rows).round(4).to_csv(args.results / "per_class_recall_fault.csv", index=False)
    # phase sensitivity table (all arms, E=2%) and AFE/ADC separation
    rows = []
    for dom, amps in (("bh", AMP_BH), ("sp", AMP_SP)):
        for name, model in arms:
            if dom == "sp" and name == "A0":
                continue
            for a in (80, 100, 120):
                afe, adc, cross = cross_confusion(st, cells(dom, (a,), "mon2"), model)
                rows.append({"domain": dom, "arm": name, "amplitude": a / 100, "afe_recall": afe, "adc_recall": adc, "cross_confusion": cross})
    pd.DataFrame(rows).round(4).to_csv(args.results / "afe_adc_separation.csv", index=False)
    inf = {}
    for s in seeds:
        i = st.info[s]
        inf[s] = {"descriptor_extraction_ms_per_sample": i["descriptor_extraction_ms_per_sample"], "mlp_predict_ms_per_sample": i["mlp_predict_ms_per_sample"],
                  "params_layer": i["two_point_mlp@PRr_e2|11|layer"]["params"], "params_fault": i["two_point_mlp@PRr_e2|11|fault"]["params"],
                  "ngspice_wall_seconds": st.meta[s]["ngspice_wall_seconds"], "n_ngspice_runs": st.meta[s]["n_ngspice_runs"], "workers": st.meta[s]["workers"]}
    (args.results / "timing_and_parameters.json").write_text(json.dumps(inf, indent=2, default=float))
    # compact per-seed metrics (pooled per domain/arm/phase, E=2%) for transparency
    rows = []
    for s_i, s in enumerate(seeds):
        for dom, amps in (("bh", AMP_BH), ("sp", AMP_SP)):
            for name, model in arms:
                if dom == "sp" and name == "A0":
                    continue
                for ph in PH:
                    for target in ("layer", "fault"):
                        for ii, init in enumerate(INITS):
                            cm = sum(st.cm_cond(s, sc(dom, a, ph, "mon2"), model, target)[ii].sum(0) for a in amps)
                            rows.append(dict(dataset_seed=s, domain=dom, arm=name, phase=ph, target=target, init_seed=init, macro_f1=float(metric_from_cm(cm, "macro_f1")),
                                             balanced_accuracy=float(metric_from_cm(cm, "balanced_accuracy")), accuracy=float(metric_from_cm(cm, "accuracy"))))
    per_seed = pd.DataFrame(rows)
    per_seed.round(4).to_csv(args.results / "per_seed_metrics.csv", index=False)
    per_seed.groupby(["domain", "arm", "phase", "target"]).agg(macro_f1_mean=("macro_f1", "mean"), macro_f1_std=("macro_f1", "std"), balanced_accuracy_mean=("balanced_accuracy", "mean"),
                                                                accuracy_mean=("accuracy", "mean")).reset_index().round(4).to_csv(args.results / "aggregate_metrics.csv", index=False)

    # ----- figures -----
    att = pd.DataFrame(att_rows)
    colors = {"A0": "#888888", "R1": "#c0504d", "R1r": "#e0a060", "PR": "#7aa6d6", "PRr": "#1b6e3d", "PRrM": "#2f6db5"}
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), sharey=True)
    for ax, dom in zip(axes, ("bh", "sp")):
        for name, _ in arms:
            if dom == "sp" and name == "A0":
                continue
            r = att[(att.domain == dom) & (att.arm == name)].iloc[0]
            ax.plot(list(PH), [r[f"layer_f1_{PCODE[ph]}"] for ph in PH], marker="o", color=colors[name], label=name)
        ax.set_xlabel("reference-edge phase ψ (fraction of a sampling period)"); ax.set_title(f"{'behavioral' if dom == 'bh' else 'ngspice'} test, monitor E=2%, pooled amplitudes")
    axes[0].set_ylabel("layer macro-F1"); axes[0].legend(fontsize=8); axes[0].set_ylim(0, 0.85); fig.tight_layout()
    fig.savefig(args.figures / "fig1_phase_sensitivity.png", dpi=150); plt.close(fig)

    cur = pd.read_csv(args.results / "amplitude_curves.csv")
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), sharey=True)
    for ax, dom in zip(axes, ("bh", "sp")):
        amps = AMP_BH if dom == "bh" else AMP_SP
        for name, _, _ in curve_models:
            d = cur[(cur.domain == dom) & (cur.series == name) & (cur.target == "layer")]
            if len(d):
                ax.plot([a / 100 for a in amps], [d.iloc[0][f"x{a / 100:.1f}"] for a in amps], marker="o", label=name)
        ax.axhline(0.85 * N[dom], color="k", ls=":", lw=0.7); ax.set_xlabel("actual reference amplitude (× nominal)"); ax.set_title("behavioral" if dom == "bh" else "ngspice")
    ctl_x = [a / 100 for a in AMP_BH]
    axes[0].plot(ctl_x, [ctl[f"x{x:.1f}"]["unmonitored"] for x in ctl_x], "x--", color="#c0504d", label="PRr, no monitor (control)")
    axes[0].legend(fontsize=7); axes[0].set_ylabel("layer macro-F1 (pooled over phases)"); axes[0].set_ylim(0, 0.85); fig.tight_layout()
    fig.savefig(args.figures / "fig2_amplitude_curves.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 4.4))
    width = 0.4
    for j, dom in enumerate(("bh", "sp")):
        vals = [att[(att.domain == dom) & (att.arm == n)].layer_macro_f1.iloc[0] if len(att[(att.domain == dom) & (att.arm == n)]) else np.nan for n, _ in arms]
        ax.bar(np.arange(len(arms)) + (j - 0.5) * width, vals, width, label="behavioral test" if dom == "bh" else "ngspice test")
    ax.set_xticks(range(len(arms))); ax.set_xticklabels([n for n, _ in arms]); ax.set_ylabel("layer macro-F1 (E=2%, pooled)"); ax.legend(); ax.set_title("Attribution across arms")
    fig.tight_layout(); fig.savefig(args.figures / "fig3_attribution.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 4.2))
    for j, a in enumerate((80, 120)):
        vals = [C_[f"{dom}|{x}|a{a}"]["cross_confusion"] for dom in ("bh", "sp") for x in XS]
        ax.bar(np.arange(len(vals)) + (j - 0.5) * 0.4, vals, 0.4, label=f"×{a / 100:.1f}")
    ax.axhline(0.15, color="r", ls="--", lw=1)
    ax.set_xticks(range(10)); ax.set_xticklabels([f"{d}\n{x}" for d in ("bh", "sp") for x in ("known", "E0", "E1", "E2", "E5")], fontsize=7)
    ax.set_ylabel("AFE↔ADC cross-confusion"); ax.legend(); fig.tight_layout(); fig.savefig(args.figures / "fig4_cross_confusion.png", dpi=150); plt.close(fig)

    print(json.dumps({"N": N, "gates": gates, "failed": crit["failed"], "decision": crit["decision"], "mixed_variant": mixed}, indent=1))
    print("E primary:", json.dumps(E_["mon2"], default=float))
    print("G:", {k: round(v["range"], 3) for k, v in G_.items()})
    print(pd.DataFrame(att_cmp).round(3).to_string(index=False))


if __name__ == "__main__":
    main()
