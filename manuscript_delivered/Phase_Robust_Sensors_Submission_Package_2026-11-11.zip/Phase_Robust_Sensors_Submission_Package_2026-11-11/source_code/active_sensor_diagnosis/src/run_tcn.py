"""Train/evaluate the optional physics-guided causal TCN.

On a machine without PyTorch this command exits successfully with a clear
``SKIPPED`` message.  This keeps the simulator reproducible on macOS while
providing the exact publication-model entry point for a later CPU/GPU run.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import GroupShuffleSplit

from .features import feature_matrix, physics_features, raw_features
from .simulate import build_paired_dataset
from .tcn_model import PhysicsGuidedTCN, TCNConfig, physics_guided_loss, torch_ready


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples-per-class", type=int, default=180)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--seed", type=int, default=20261014)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "tcn_results")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    if not torch_ready():
        result = {
            "status": "SKIPPED",
            "reason": "PyTorch is not installed in this environment",
            "install": "python3 -m pip install torch",
        }
        (args.output / "tcn_metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(json.dumps(result, indent=2))
        return

    import torch
    from torch.utils.data import DataLoader, TensorDataset

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    data = build_paired_dataset(args.samples_per_class, args.seed)
    records = data["records"]["active_two_point"]
    raw, y_layer, groups, severity = feature_matrix(records, "raw_plus_physics", target="layer")
    _, y_fault, _, _ = feature_matrix(records, "raw_plus_physics", target="fault")
    physics = np.vstack([physics_features(r) for r in records]).astype(np.float32)
    waveform = np.vstack([raw_features(r) for r in records]).astype(np.float32)[:, None, :]
    split = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=args.seed + 1)
    train_idx, test_idx = next(split.split(waveform, y_layer, groups))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = PhysicsGuidedTCN(TCNConfig(physics_dim=physics.shape[1])).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=2e-3, weight_decay=1e-4)
    ds = TensorDataset(
        torch.from_numpy(waveform[train_idx]),
        torch.from_numpy(physics[train_idx]),
        torch.from_numpy(y_layer[train_idx]),
        torch.from_numpy(y_fault[train_idx]),
        torch.from_numpy(severity[train_idx]),
    )
    loader = DataLoader(ds, batch_size=64, shuffle=True)
    model.train()
    for _ in range(args.epochs):
        for xb, pb, lb, fb, sb in loader:
            out = model(xb.to(device), pb.to(device))
            losses = physics_guided_loss(out, lb.to(device), fb.to(device), sb.to(device), pb.to(device))
            opt.zero_grad(set_to_none=True)
            losses["total"].backward()
            opt.step()

    model.eval()
    with torch.no_grad():
        out = model(torch.from_numpy(waveform[test_idx]).to(device), torch.from_numpy(physics[test_idx]).to(device))
    pred_layer = out["layer_logits"].argmax(dim=1).cpu().numpy()
    pred_fault = out["fault_logits"].argmax(dim=1).cpu().numpy()
    result = {
        "status": "COMPLETED",
        "device": str(device),
        "epochs": args.epochs,
        "layer_accuracy": float(accuracy_score(y_layer[test_idx], pred_layer)),
        "layer_macro_f1": float(f1_score(y_layer[test_idx], pred_layer, average="macro")),
        "fault_accuracy": float(accuracy_score(y_fault[test_idx], pred_fault)),
        "fault_macro_f1": float(f1_score(y_fault[test_idx], pred_fault, average="macro")),
        "train_condition_count": int(len(set(groups[train_idx].tolist()))),
        "test_condition_count": int(len(set(groups[test_idx].tolist()))),
        "model": "causal TCN + physics branch + multi-task heads",
    }
    (args.output / "tcn_metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

