"""Build the paper package (paper_package/) from the frozen result files.

    python3 -m src.build_paper_package            # figures + tables + manuscript + package documents
    python3 -m src.build_paper_package --no-figures

Writes only inside paper_package/. Fails if any {{token}} in a template is unresolved.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import platform
import re
import subprocess
from pathlib import Path

import numpy as np
import pandas as pd

from .paper_values import PR, ROOT, build, cload, md_table
from .phase_features import PR_NAMES

PKG = ROOT / "paper_package"
TPL = PKG / "templates"

FIGURES = {
    "fig01": ("fig01_architecture", "Electronic architecture: two-point reference multiplexer, AFE, ADC and buffered reference-monitor channel; fault locations.", "schematic",
              [], "src/paper_figures.py::fig_architecture"),
    "fig02": ("fig02_timing", "Active self-test sequence: multiplexer states, reference levels and an illustrative ADC record with settling guards, settled plateaus, transient-fit window and sensor segments.", "illustrative (development seed 20261097)",
              ["paper_package/figure_data/fig02_timing_example.csv", "src/simulate.py (_afe_reference, _adc_reference, simulate_sample)"], "src/paper_figures.py::fig_timing"),
    "fig03": ("fig03_pipeline", "Processing pipeline and training procedure.", "schematic", [], "src/paper_figures.py::fig_pipeline"),
    "fig04": ("fig04_phase_effect", "Phase effect before/after the proposed descriptors: (a) analytic sampled step responses; (b, c) layer macro-F1 vs edge phase per arm (behavioral, ngspice); (d) descriptor shift vs phase.", "result (b, c); analytic (a); development-seed verification (d)",
              [PR + "attribution_arms.csv", "paper_package/figure_data/dev_seed_verification.json"], "src/paper_figures.py::fig_phase"),
    "fig05": ("fig05_afe_adc_separation", "AFE/ADC fault separation: (a) fault signatures of the descriptors; (b, c) pooled layer confusion matrices of PRr; (d) AFE–ADC cross-confusion per arm.", "development seed (a); result (b–d)",
              ["paper_package/figure_data/fig05_fault_signature_descriptors_dev_seed.csv", "paper_package/figure_data/fig05_fault_signatures_standardised_dev_seed.csv",
               "paper_package/figure_data/fig05_layer_confusion_PRr_E2.json (derived from " + PR + "seed_*/predictions.npz)", PR + "afe_adc_separation.csv"], "src/paper_figures.py::fig_separation"),
    "fig06": ("fig06_behavioral_vs_ngspice", "Behavioral versus ngspice: (a) one record in both domains; (b) noise-free agreement per phase; (c) transfer loss, previous vs phase-robust; (d) layer macro-F1 per phase in both domains.", "development seed (a, b); result (c, d)",
              ["paper_package/figure_data/fig06_example_waveforms_dev_seed.csv", "paper_package/figure_data/dev_seed_verification.json", PR + "decision_rules.json",
               "reference_monitor_final/reference_monitor_results/decision_rules.json", PR + "attribution_arms.csv"], "src/paper_figures.py::fig_domain"),
    "fig07": ("fig07_robustness", "Robustness: layer macro-F1 vs actual reference amplitude for known/monitored reference, old descriptors and the no-monitor control; AFE–ADC cross-confusion at ±20%.", "result",
              [PR + "amplitude_curves.csv", PR + "no_monitor_control.json", PR + "decision_rules.json"], "src/paper_figures.py::fig_robustness"),
    "fig08": ("fig08_ablation", "Ablation forest plot: descriptors, phase randomisation, mixed training, Revision-2 conditioning, TCN vs MLP.", "result",
              [PR + "attribution_comparisons.csv", "reference_v2_results/decision_rules.json", "multiseed_results/decision_rules.json"], "src/paper_figures.py::fig_ablation"),
    "fig09": ("fig09_per_class_recall", "Fine-fault recall per arm in both domains.", "result", [PR + "per_class_recall_fault.csv"], "src/paper_figures.py::fig_recall"),
}


def static_tables():
    arms = pd.DataFrame([
        ("A0", "old descriptors: 96 raw samples + 38 descriptors", "ψ = 0", "behavioral", "previous method; also passive, single-probe, AFE-only, ADC-only baselines"),
        ("R1", "Revision-1 (settled plateaus, fixed-sample rise fractions)", "ψ = 0", "behavioral", "descriptor ablation"),
        ("R1r", "Revision-1", "ψ ~ U[0,1)", "behavioral", "randomisation ablation"),
        ("PR", "phase-robust (whole-window transient fit)", "ψ = 0", "behavioral", "descriptor ablation"),
        ("PRr", "phase-robust", "ψ ~ U[0,1)", "behavioral", "**primary method**"),
        ("PRrM", "phase-robust", "ψ ~ U[0,1)", "behavioral + ngspice", "mixed-domain ablation"),
        ("control", "PRr known-reference model given nominal levels", "—", "—", "no-monitor control"),
    ], columns=["arm", "descriptors", "training phase", "training domain", "role"])
    arms.attrs["n_keys"] = 1
    desc_meaning = {
        "g_adc": "ADC gain from settled ADC plateaus (Eq. 1)", "o_adc": "ADC offset (Eq. 1)", "adc_noise": "detrended noise of the settled ADC plateaus",
        "G_afe": "AFE gain from settled AFE plateaus on the ADC-calibrated waveform (Eq. 2)", "o_afe": "AFE offset (Eq. 2)", "settle_err1": "settling error, AFE plateau 1",
        "settle_err2": "settling error, AFE plateau 2", "afe_noise": "detrended noise of the settled AFE plateaus", "sens_mean": "mean of the calibrated sensor-domain waveform",
        "sens_std": "standard deviation, sensor domain", "sens_hf": "high-frequency noise (first differences), sensor domain", "sens_ptp": "peak-to-peak, sensor domain",
        "sens_slope": "slope, first sensor segment", "ymax_s": "maximum raw level in the sensor segments", "top_frac_s": "fraction of sensor-segment samples at the top code (saturation)",
        "tau_norm": "fitted time constant / plateau length (Eqs. 5–6)", "rt_10_50_norm": "10–50% rise-time difference / plateau length", "rt_50_90_norm": "50–90% rise-time difference / plateau length",
        "area_norm": "transient area normalised by the fitted span", "fit_rms_norm": "fit residual / span"}
    desc = pd.DataFrame([(i + 1, n, desc_meaning[n]) for i, n in enumerate(PR_NAMES)], columns=["#", "descriptor", "definition"])
    desc.attrs["n_keys"] = 2
    return {"ARMS": ("Arms compared (all use the same MLP; monitored variants are trained with the matching monitor error)", arms, "phase_robust_final/PROTOCOL_PHASE_ROBUST_FROZEN.md, section 3"),
            "DESC": ("The 20 phase-robust descriptors", desc, "src/phase_features.py (PR_NAMES); src/ref_features.py")}


LIT_ROWS = ["analog_adc13", "combined08", "gyro_wafer18", "mems_bist_elec", "readout_bist07", "imprecise03", "vrefadc21", "testcore02", "ets23",
            "nn02", "cnn20", "resnet21", "mpcnn25"]


def load_refs():
    return json.loads((PKG / "literature" / "references.json").read_text())


def cite_numbers(text: str):
    order = []
    for m in re.finditer(r"\{\{CITE:([a-z0-9_,]+)\}\}", text):
        for k in m.group(1).split(","):
            if k not in order:
                order.append(k)
    return {k: i + 1 for i, k in enumerate(order)}


def cite_str(nums):
    nums = sorted(set(nums))
    out, i = [], 0
    while i < len(nums):
        j = i
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
            j += 1
        out.append(f"{nums[i]}–{nums[j]}" if j - i >= 2 else ",".join(str(n) for n in nums[i:j + 1]))
        i = j + 1
    return "[" + ",".join(out) + "]"


def first_author(ref):
    a = ref.get("authors") or ""
    fam = a.split(",")[0] if a else ref.get("title", "")[:20]
    return fam + (" et al." if a.count(";") >= 2 else (" and " + a.split(";")[1].split(",")[0].strip() if a.count(";") == 1 else ""))


def lit_table(cnum, refs):
    from .lit_build import CLASS, THIS_WORK
    cols = ["Work", "Electronic structure", "Active stimulus", "AFE/ADC separation", "Reference drift", "Sampling phase", "Neural network", "Validation"]
    rows = [[f"{first_author(refs[k])} {cite_str([cnum[k]])}"] + list(CLASS[k][:7]) for k in LIT_ROWS]
    rows.append(["This work"] + list(THIS_WORK[:7]))
    df = pd.DataFrame(rows, columns=cols)
    df.attrs["n_keys"] = 1
    return df


def ref_list_md(cnum, refs):
    out = []
    for k, n in sorted(cnum.items(), key=lambda kv: kv[1]):
        r = refs[k]
        if r["kind"] == "web":
            out.append(f"{n}. {r['text']}")
        elif r["kind"] == "book":
            out.append(f"{n}. {r['authors']} *{r['title']}*; {r['publisher']}: Cambridge, UK, {r['year']}. https://doi.org/{r['doi']}.")
        elif r["kind"] == "preprint":
            out.append(f"{n}. {r['authors']} {r['title']}. *arXiv* **{r['year']}**, arXiv:1412.6980. https://doi.org/{r['doi']}.")
        else:
            tail = f" https://doi.org/{r['doi']}." if r["doi"] else ""
            out.append(f"{n}. {r['authors']} {r['title']}. *{r['venue']}* **{r['year']}**, *{r['volume']}*, {r['pages']}.{tail}")
    return "\n".join(out)


def fill(text: str, R, tables: dict, out_name: str) -> str:
    refs = load_refs()
    cnum = cite_numbers(text)
    if cnum:
        missing_refs = [k for k in cnum if k not in refs]
        if missing_refs:
            raise SystemExit(f"{out_name}: citations without verified reference: {missing_refs}")
        if "LIT" in re.findall(r"\{\{TABLE:([A-Za-z0-9]+)\}\}", text):
            tables["LIT"] = ("Comparison with related work (attributes from the authors' reading of each abstract; n/r: not reported)", lit_table(cnum, refs),
                             "paper_package/LITERATURE_GAP_MATRIX.md; paper_package/VERIFIED_REFERENCES.csv", "")
        text = re.sub(r"\{\{CITE:([a-z0-9_,]+)\}\}", lambda m: cite_str([cnum[k] for k in m.group(1).split(",")]), text)
        text = text.replace("{{REFERENCES}}", ref_list_md(cnum, refs))
        fill.last_cnum = cnum
    # table numbering by order of placement ({{TABLE:x}}); appendix tables get letter prefixes
    order = re.findall(r"\{\{TABLE:([A-Za-z0-9]+)\}\}", text)
    app_start = text.find("## Appendix A")
    numbers, n_main, app = {}, 0, {}
    for m in re.finditer(r"\{\{TABLE:([A-Za-z0-9]+)\}\}", text):
        tid = m.group(1)
        if app_start >= 0 and m.start() > app_start:
            letter = "A" if m.start() < text.find("## Appendix B") else "B"
            app[letter] = app.get(letter, 0) + 1
            numbers[tid] = f"{letter}{app[letter]}"
        else:
            n_main += 1
            numbers[tid] = str(n_main)
    fig_order = re.findall(r"!\[\{\{FIGNUM:(fig\d+)\}\}\]", text)
    fnum = {k: i + 1 for i, k in enumerate(fig_order)}
    text = re.sub(r"\{\{TREF:([A-Za-z0-9]+)\}\}", lambda m: f"Table {numbers[m.group(1)]}", text)
    text = re.sub(r"\{\{FREF:(fig\d+)\}\}", lambda m: f"Figure {fnum[m.group(1)]}", text)
    text = re.sub(r"\{\{FIGNUM:(fig\d+)\}\}", lambda m: f"Figure {fnum[m.group(1)]}", text)

    def table_block(m):
        tid = m.group(1)
        title, df, src = tables[tid][0], tables[tid][1], tables[tid][2]
        note = tables[tid][3] if len(tables[tid]) > 3 and tables[tid][3] else ""
        return f"**Table {numbers[tid]}.** {title}.\n\n{md_table(df)}\n\n*Source: {src}.{(' ' + note) if note else ''}*"
    text = re.sub(r"\{\{TABLE:([A-Za-z0-9]+)\}\}", table_block, text)
    missing = sorted(set(re.findall(r"\{\{([A-Za-z0-9_]+)\}\}", text)) - set(R.vals))
    if missing:
        raise SystemExit(f"{out_name}: unresolved tokens: {missing}")
    text = re.sub(r"\{\{([A-Za-z0-9_]+)\}\}", lambda m: R.vals[m.group(1)], text)
    assert "{{" not in text, out_name
    return text, numbers, fnum


def versions() -> dict:
    import matplotlib, scipy, sklearn
    v = {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__, "scipy": scipy.__version__, "scikit-learn": sklearn.__version__,
         "matplotlib": matplotlib.__version__, "platform": platform.platform()}
    try:
        import torch
        v["torch"] = torch.__version__
    except Exception:
        v["torch"] = "not installed"
    try:
        out = subprocess.run(["ngspice", "-v"], capture_output=True, text=True, timeout=20).stdout
        v["ngspice"] = next((l.strip() for l in out.splitlines() if "ngspice-" in l), out.strip()[:60])
    except Exception:
        v["ngspice"] = "not found"
    return v


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-figures", action="store_true")
    args = ap.parse_args()
    if not args.no_figures:
        from .paper_figures import build_all
        build_all(PKG / "figures", PKG / "figure_data")
    R = build()
    att = cload(PR + "attribution_arms.csv")
    pc = [c for c in att.columns if c.startswith("layer_f1_p")]
    for _, r in att.iterrows():
        R.put(f"ARM_{r.domain.upper()}_{r.arm.upper()}_RANGE", float(max(r[c] for c in pc) - min(r[c] for c in pc)), PR + "attribution_arms.csv",
              f"domain={r.domain}, arm={r.arm}, max-min of layer_f1_p*")
    tables = dict(R.tables)
    for k, (title, df, src) in static_tables().items():
        tables[k] = (title, df, src, "")
        R.table(k, title, df, src)
    ver = versions()
    for k, v in ver.items():
        R.put(f"VER_{k.upper().replace('-', '_')}", str(v), "runtime environment", k, "{}")
    R.put("BUILD_DATE", dt.date.today().isoformat(), "build time", "date", "{}")

    man, tnum, fnum = fill((TPL / "MANUSCRIPT_TEMPLATE.md").read_text(), R, tables, "manuscript")
    (PKG / "MANUSCRIPT_SENSORS_DRAFT.md").write_text(man)
    cnum = fill.last_cnum
    vr = pd.read_csv(PKG / "literature" / "verified_references_all.csv")
    vr.insert(0, "ref_number", vr.key.map(lambda k: cnum.get(k)))
    vr.insert(1, "cited_in_manuscript", vr.key.map(lambda k: "yes" if k in cnum else "no"))
    vr = vr.sort_values("ref_number", na_position="last")
    vr.to_csv(PKG / "VERIFIED_REFERENCES.csv", index=False)
    import json as _j
    (PKG / "literature" / "citation_numbers.json").write_text(_j.dumps(cnum, indent=1))
    # figure map
    lines = ["# Paper figure map", "", f"Generated {R.vals['BUILD_DATE']} by `python3 -m src.build_paper_package`. Every figure exists as PDF (vector) and PNG (300 dpi) in `paper_package/figures/`.",
             "Result panels read only frozen validation outputs; illustrative and verification panels are marked and use the development seed 20261097 or analytic curves.", "",
             "| manuscript figure | file | content | type | data sources | generator |", "|---|---|---|---|---|---|"]
    for k, (fn, content, kind, srcs, gen) in FIGURES.items():
        lines.append(f"| Figure {fnum.get(k, '—')} | `figures/{fn}.pdf` / `.png` | {content} | {kind} | {'<br>'.join('`' + s + '`' for s in srcs) or '—'} | `{gen}` |")
    lines += ["", "Requested figure types and where they are:", "",
              "| requested | manuscript figure |", "|---|---|"]
    for req, k in (("electronic block/circuit diagram", "fig01"), ("active self-test timing diagram", "fig02"), ("complete processing pipeline", "fig03"),
                   ("phase effect before and after the proposed descriptors", "fig04"), ("AFE/ADC fault-separation diagram", "fig05"),
                   ("behavioral-versus-ngspice comparison", "fig06"), ("robustness results", "fig07"), ("ablation comparison", "fig08"), ("per-class recall (additional)", "fig09")):
        lines.append(f"| {req} | Figure {fnum[k]} (`{FIGURES[k][0]}`) |")
    import shutil
    num_dir = PKG / "figures_manuscript_numbering"
    num_dir.mkdir(exist_ok=True)
    for k, (fn, *_rest) in FIGURES.items():
        for ext in ("pdf", "png"):
            shutil.copy2(PKG / "figures" / f"{fn}.{ext}", num_dir / f"Figure{fnum[k]:02d}_{fn.split('_', 1)[1]}.{ext}")
    lines += ["", "Copies named in manuscript order are in `paper_package/figures_manuscript_numbering/` (e.g. `Figure05_robustness.pdf`)."]
    (PKG / "PAPER_FIGURE_MAP.md").write_text("\n".join(lines) + "\n")
    # tables csv and provenance
    long = pd.DataFrame(R.long)
    long.insert(0, "manuscript_table", long.table_id.map(lambda t: f"Table {tnum[t]}" if t in tnum else "not in manuscript"))
    long.to_csv(PKG / "PAPER_TABLES.csv", index=False)
    pd.DataFrame(R.prov).drop_duplicates("token", keep="last").to_csv(PKG / "NUMBER_PROVENANCE.csv", index=False)
    # package and checklist documents
    for name in ("FINAL_PAPER_PACKAGE", "REPRODUCIBILITY_CHECKLIST"):
        txt, _, _ = fill((TPL / f"{name}_TEMPLATE.md").read_text(), R, tables, name)
        txt = txt.replace("[[TABLE_NUMBERS]]", ", ".join(f"{k} → Table {v}" for k, v in tnum.items())).replace("[[FIGURE_NUMBERS]]", ", ".join(f"{k} → Figure {v}" for k, v in fnum.items()))
        (PKG / f"{name}.md").write_text(txt)
    print(f"manuscript: {len(man.split())} words, {len(tnum)} tables, {len(fnum)} figures; tokens used: {len(set(re.findall(r'{{([A-Za-z0-9_]+)}}', (TPL / 'MANUSCRIPT_TEMPLATE.md').read_text())))}")
    print("tables:", tnum); print("figures:", fnum)


if __name__ == "__main__":
    main()
