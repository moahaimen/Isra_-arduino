"""POST-HOC exploratory check (not part of the frozen protocol): UNMONITORED reference error.

The frozen reference-v2 test scales the actual reference and tells the descriptors the scaled (true) commanded values.
Here the actual reference is scaled but the descriptors are still given the NOMINAL commanded arrays, i.e. the
system does not know the reference has drifted.  Two-point MLP, arms A1 (nominal-trained) and A2 (jitter + conditioning).
"""
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import f1_score
from sklearn.model_selection import GroupShuffleSplit

from .ref_features import ref_descriptors
from .run_feasibility import _classifier
from .run_multiseed import INITS, LAYER_ID
from .run_reference_v2 import GUARD, JITTER
from .simulate import FAULT_TO_LAYER, FAULTS, _adc_reference, _afe_reference, make_condition, make_fault, simulate_sample

ROOT = Path(__file__).resolve().parents[1]
out = {}
for seed in (20261020, 20261021, 20261022):
    n = 350
    groups = np.repeat(np.arange(n), 9)
    dev, test = next(GroupShuffleSplit(1, test_size=0.25, random_state=seed + 1).split(np.zeros(n * 9), groups=groups))
    sub = next(GroupShuffleSplit(1, test_size=0.15, random_state=seed + 2).split(dev, groups=groups[dev]))
    train = dev[sub[0]]
    rng, jit = np.random.default_rng(seed), np.random.default_rng(seed + 20000)
    nom_arr = {"afe_reference": _afe_reference(512, 1000.0)[0], "adc_reference": _adc_reference(512, 1000.0)[0]}
    feats = {k: [] for k in ("nom", "jit", "m20", "p20", "m10", "p10")}
    yl, rows = [], 0
    test_set = set(test.tolist())
    train_set = set(train.tolist())
    for cid in range(n):
        cond = make_condition(rng)
        for ci, name in enumerate(FAULTS):
            f = make_fault(name, rng)
            sd = int(rng.integers(0, 2**31 - 1))
            k = float(jit.uniform(*JITTER))
            yl.append(LAYER_ID[FAULT_TO_LAYER[name]])
            r = rows; rows += 1
            if r in train_set:
                feats["nom"].append(ref_descriptors(simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point"), GUARD))
                feats["jit"].append(ref_descriptors(simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point", ref_scale=k), GUARD))
            elif r in test_set:
                for key, sc in (("m20", 0.8), ("p20", 1.2), ("m10", 0.9), ("p10", 1.1)):
                    rec = simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point", ref_scale=sc)
                    rec.update(nom_arr)  # the system still believes the nominal commanded levels
                    feats[key].append(ref_descriptors(rec, GUARD))
    yl = np.asarray(yl)
    res = {}
    for arm, tr_key, use_cond in (("A1", "nom", False), ("A2", "jit", True)):
        mk = lambda L: np.asarray([np.hstack([d, c]) if use_cond else d for d, c, _ in L])
        Xtr = mk(feats[tr_key])
        f1s = {key: [] for key in ("m20", "p20", "m10", "p10")}
        rec = {key: [] for key in f1s}
        for init in INITS:
            m = _classifier(init).fit(Xtr, yl[train])
            for key in f1s:
                p = m.predict(mk(feats[key]))
                f1s[key].append(f1_score(yl[test], p, average="macro"))
                cm = np.bincount(yl[test] * 4 + p, minlength=16).reshape(4, 4)
                rec[key].append([cm[2, 2] / cm[2].sum(), cm[3, 3] / cm[3].sum(), (cm[2, 3] + cm[3, 2]) / (cm[2].sum() + cm[3].sum())])
        res[arm] = {k: {"layer_macro_f1": float(np.mean(v)), "afe_recall_adc_recall_cross": np.mean(rec[k], axis=0).round(3).tolist()}
                    for k, v in f1s.items()}
    out[str(seed)] = res
    print(seed, json.dumps(res), flush=True)
mean = {arm: {k: float(np.mean([out[s][arm][k]["layer_macro_f1"] for s in out])) for k in ("m20", "p20", "m10", "p10")} for arm in ("A1", "A2")}
out["mean_layer_macro_f1"] = mean
(ROOT / "reference_v2_results" / "exploratory_unmonitored_reference.json").write_text(json.dumps(out, indent=1))
print(json.dumps(mean, indent=1))
