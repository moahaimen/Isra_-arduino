"""Feature extraction for passive and active sensor-interface diagnosis."""

from __future__ import annotations

from typing import Dict, Iterable, Tuple

import numpy as np


def _safe_scale(x: np.ndarray) -> float:
    scale = float(np.std(x))
    return max(scale, 1e-5)


def physics_features(record: Dict[str, object], fs_hz: float = 1000.0) -> np.ndarray:
    """Extract interpretable circuit/measurement descriptors.

    These are not arbitrary statistics: baseline level, probe response, step
    area, settling proxy, slope, clipping, and quantization behavior correspond
    to observable properties of the simulated sensor chain.
    """
    y = np.asarray(record["waveform"], dtype=float)
    windows = record.get("probe_windows", [(record["probe_start"], record["probe_end"])])
    descriptors = []
    for start_raw, end_raw in windows:
        start, end = int(start_raw), int(end_raw)
        pre = y[max(0, start - 45) : max(0, start - 5)]
        probe_window = y[start:end]
        post = y[min(len(y), end + 12) : min(len(y), end + 55)]
        if len(post) == 0:
            post = y[-40:]
        baseline = float(np.mean(pre)) if len(pre) else float(np.mean(y))
        baseline_std = float(np.std(pre)) if len(pre) else float(np.std(y))
        centered = y - baseline
        scale = _safe_scale(pre if len(pre) else y)

        half = max(1, len(probe_window) // 2)
        pos = probe_window[:half]
        neg = probe_window[half:]
        pos_delta = float(np.mean(pos) - baseline) if len(pos) else 0.0
        neg_delta = float(np.mean(neg) - baseline) if len(neg) else 0.0
        differential_probe = pos_delta - neg_delta
        response_area = float(np.sum(np.abs(probe_window - baseline)) / max(len(probe_window), 1))
        local_slope = float(np.polyfit(np.arange(len(probe_window)), probe_window, 1)[0]) if len(probe_window) > 1 else 0.0
        post_shift = float(np.mean(post) - baseline)
        post_std = float(np.std(post))
        peak_to_peak = float(np.ptp(y))
        rms = float(np.sqrt(np.mean(centered**2)))
        clipped = float(np.mean((y <= 1e-5) | (y >= 3.299)))
        unique_ratio = float(len(np.unique(np.round(y, 5))) / max(len(y), 1))

        target = float(np.mean(post))
        probe_peak = float(np.max(probe_window)) if len(probe_window) else baseline
        threshold = abs(probe_peak - target) * 0.37
        settle_idx = len(probe_window)
        if threshold > 1e-6 and len(probe_window):
            for i in range(len(probe_window)):
                tail = probe_window[i:]
                if len(tail) and np.all(np.abs(tail - target) <= threshold):
                    settle_idx = i
                    break
        settling_ms = float(settle_idx / fs_hz * 1000.0)
        descriptors.extend(
            [
                baseline,
                baseline_std,
                differential_probe,
                pos_delta,
                neg_delta,
                response_area,
                local_slope,
                post_shift,
                post_std,
                peak_to_peak,
                rms,
                clipped,
                unique_ratio,
                settling_ms,
                scale,
            ]
        )

    # Estimate the ADC transfer function from the known reference bypass. For
    # the passive/single-point modes the values are zero by construction. For
    # the two-point mode these descriptors directly expose ADC gain and offset,
    # while AFE faults do not affect the calibration window.
    adc_ref = np.asarray(record.get("adc_reference", np.zeros_like(y)), dtype=float)
    ref_start = int(record.get("adc_ref_start", 0))
    ref_end = int(record.get("adc_ref_end", 0))
    cal_y = y[ref_start:ref_end]
    cal_ref = adc_ref[ref_start:ref_end]
    if len(cal_y) and np.ptp(cal_ref) > 1e-6:
        half = max(1, len(cal_ref) // 2)
        ref1, ref2 = float(np.mean(cal_ref[:half])), float(np.mean(cal_ref[half:]))
        y1, y2 = float(np.mean(cal_y[:half])), float(np.mean(cal_y[half:]))
        cal_gain = (y2 - y1) / max(ref2 - ref1, 1e-6)
        cal_offset = y1 - cal_gain * ref1
        cal_span = y2 - y1
        cal_noise = float(np.std(cal_y))
    else:
        cal_gain = cal_offset = cal_span = cal_noise = 0.0

    # Estimate the AFE transfer function from its known reference-replacement
    # window. In two-point mode, ADC calibration and AFE calibration are
    # separately observable; in the other modes these values are zero.
    afe_ref = np.asarray(record.get("afe_reference", np.zeros_like(y)), dtype=float)
    afe_start = int(record.get("afe_ref_start", 0))
    afe_end = int(record.get("afe_ref_end", 0))
    afe_y = y[afe_start:afe_end]
    afe_known = afe_ref[afe_start:afe_end]
    if len(afe_y) and np.ptp(afe_known) > 1e-6:
        half = max(1, len(afe_known) // 2)
        ref1, ref2 = float(np.mean(afe_known[:half])), float(np.mean(afe_known[half:]))
        y1, y2 = float(np.mean(afe_y[:half])), float(np.mean(afe_y[half:]))
        afe_gain = (y2 - y1) / max(ref2 - ref1, 1e-6)
        afe_offset = y1 - afe_gain * ref1
        afe_span = y2 - y1
        afe_noise = float(np.std(afe_y))
    else:
        afe_gain = afe_offset = afe_span = afe_noise = 0.0
    descriptors.extend([cal_gain, cal_offset, cal_span, cal_noise, afe_gain, afe_offset, afe_span, afe_noise])

    return np.asarray(descriptors, dtype=np.float32)


def calibrated_waveform(record: Dict[str, object]) -> np.ndarray:
    """Undo the estimated ADC affine error using the known calibration window."""
    y = np.asarray(record["waveform"], dtype=float)
    adc_ref = np.asarray(record.get("adc_reference", np.zeros_like(y)), dtype=float)
    ref_start = int(record.get("adc_ref_start", 0))
    ref_end = int(record.get("adc_ref_end", 0))
    cal_y = y[ref_start:ref_end]
    cal_ref = adc_ref[ref_start:ref_end]
    if len(cal_y) and np.ptp(cal_ref) > 1e-6:
        half = max(1, len(cal_ref) // 2)
        ref1, ref2 = float(np.mean(cal_ref[:half])), float(np.mean(cal_ref[half:]))
        y1, y2 = float(np.mean(cal_y[:half])), float(np.mean(cal_y[half:]))
        gain = (y2 - y1) / max(ref2 - ref1, 1e-6)
        offset = y1 - gain * ref1
        if abs(gain) > 1e-4:
            return ((y - offset) / gain).astype(np.float32)
    return y.astype(np.float32)


def raw_features(record: Dict[str, object], target_length: int = 96, calibrated: bool = False) -> np.ndarray:
    """Downsample the measured ADC waveform, optionally ADC-calibrated."""
    y = calibrated_waveform(record) if calibrated else np.asarray(record["waveform"], dtype=float)
    idx = np.linspace(0, len(y) - 1, target_length).astype(int)
    return y[idx].astype(np.float32)


def feature_matrix(
    records: Iterable[Dict[str, object]], mode: str, target: str = "fault"
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    records = list(records)
    calibrated = mode.startswith("calibrated_")
    raw = np.vstack([raw_features(r, calibrated=calibrated) for r in records])
    phys = np.vstack([physics_features(r) for r in records])
    if mode in {"raw", "calibrated_raw"}:
        x = raw
    elif mode in {"raw_plus_physics", "calibrated_raw_plus_physics"}:
        x = np.hstack([raw, phys])
    elif mode == "physics":
        x = phys
    else:
        raise ValueError(f"Unknown feature mode: {mode}")
    if target == "fault":
        y = np.asarray([int(r["class_id"]) for r in records], dtype=int)
    elif target == "layer":
        layer_ids = {"healthy": 0, "sensor": 1, "afe": 2, "adc": 3}
        y = np.asarray([layer_ids[str(r["layer"])] for r in records], dtype=int)
    else:
        raise ValueError(f"Unknown target: {target}")
    groups = np.asarray([int(r["condition_id"]) for r in records], dtype=int)
    severity = np.asarray([float(r["severity"]) for r in records], dtype=np.float32)
    return x, y, groups, severity
