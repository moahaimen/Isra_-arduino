"""Generate and optionally execute the circuit-level validation netlists."""

from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path

from .spice_netlist import DEFAULT_CASES, write_case


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "spice")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    ngspice = shutil.which("ngspice")
    print(f"ngspice executable: {ngspice or 'not found'}")
    for case in DEFAULT_CASES:
        netlist = write_case(case, args.output)
        print(f"generated {netlist.name}")
        if ngspice:
            raw_path = args.output / f"{case.name}.raw"
            log_path = args.output / f"{case.name}.log"
            cmd = [ngspice, "-b", "-r", str(raw_path), "-o", str(log_path), str(netlist)]
            completed = subprocess.run(cmd, text=True, capture_output=True)
            if completed.returncode != 0:
                print(f"  FAILED returncode={completed.returncode}; inspect {log_path}")
            else:
                print(f"  completed: {raw_path.name}")
        else:
            print("  skipped execution; install ngspice to run the transient circuit model")


if __name__ == "__main__":
    main()
