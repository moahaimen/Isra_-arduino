"""Aggregate the frozen reference-v2 validation (tables, paired bootstrap, figures, decision rules D1-D6)."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from . import summarize_multiseed as sm
from .simulate import LAYERS

ROOT = Path(__file__).resolve().parents[1]
SCN = ["nominal", "tolerance", "ref_m20", "ref_p20", "ref_m10", "ref_p10", "severity"]
PRIMARY = ["nominal", "tolerance", "ref_m20", "ref_p20"]
sm.SCEN = SCN  # seed_weights() indexes into this list
ARM_ORDER = ["A0", "A0j", "A1", "A1j", "A2"]
ARM_LABEL = {"A0": "A0 previous", "A0j": "A0j previous+jitter", "A1": "A1 settled", "A1j": "A1j settled+jitter", "A2": "A2 settled+cond+jitter"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=Path, default=ROOT / "reference_v2_results")
    ap.add_argument("--comparison", type=Path, default=ROOT / "reference_v2_comparison")
    ap.add_argument("--seed-dirs", type=Path, nargs="*", default=None)
    ap.add_argument("--n-boot", type=int, default=5000)
    args = ap.parse_args()
    args.comparison.mkdir(parents=True, exist_ok=True)
    dirs = args.seed_dirs or sorted(args.results.glob("seed_*"))
    store = sm.Store(dirs)
    seeds = store.seeds

    # ---------------- per-seed / aggregate metrics ----------------
    rows = []
    for s, d in zip(seeds, dirs):
        mj = json.loads((Path(d) / "metrics.json").read_text())
        for key, m in mj.items():
            scn, model, init, target = key.split("|")
            name, arm = model.split("@")
            regime = "severity" if scn == "severity" else "nominal"
            inf = store.info[s].get(f"{regime}|{model}|{init}", {})
            rows.append(dict(dataset_seed=s, scenario=scn, model=name, arm=arm, init_seed=int(init), target=target,
                             accuracy=m["accuracy"], macro_f1=m["macro_f1"], weighted_f1=m["weighted_f1"],
                             train_seconds=inf.get("train_seconds"), infer_ms_per_sample=inf.get("infer_ms_per_sample"),
                             **{f"recall_{k}": v for k, v in m["per_class_recall"].items()}))
    per_seed = pd.DataFrame(rows)
    per_seed.to_csv(args.results / "per_seed_metrics.csv", index=False)
    ia = per_seed.groupby(["dataset_seed", "scenario", "model", "arm", "target"], as_index=False).mean(numeric_only=True)
    agg = ia.groupby(["scenario", "model", "arm", "target"]).agg(
        accuracy_mean=("accuracy", "mean"), accuracy_std=("accuracy", "std"),
        macro_f1_mean=("macro_f1", "mean"), macro_f1_std=("macro_f1", "std"),
        weighted_f1_mean=("weighted_f1", "mean"), train_seconds_mean=("train_seconds", "mean"),
        infer_ms_per_sample_mean=("infer_ms_per_sample", "mean")).reset_index()
    agg.round(4).to_csv(args.results / "aggregate_metrics.csv", index=False)
    rc = [c for c in ia.columns if c.startswith("recall_")]
    ia.groupby(["scenario", "model", "arm", "target"])[rc].mean().dropna(axis=1, how="all").round(4).reset_index().to_csv(
        args.results / "per_class_recall.csv", index=False)

    # AFE/ADC separation and confusion matrices
    sep, cmj = [], {}
    for scn in SCN:
        for model in sorted({k.split("|")[1] for k in store.preds[seeds[0]] if k.startswith(scn + "|")}):
            for target in ("layer", "fault"):
                tot = None
                for s in seeds:
                    if not store.has(s, scn, model):
                        continue
                    cm = np.mean([c.sum(0) for c in store.cms(s, scn, model, target)], axis=0)
                    tot = cm if tot is None else tot + cm
                if tot is None:
                    continue
                cmj[f"{scn}|{model}|{target}"] = np.round(tot, 1).tolist()
                if target == "layer":
                    a, d_ = LAYERS.index("afe"), LAYERS.index("adc")
                    sep.append(dict(scenario=scn, model=model, afe_recall=tot[a, a] / tot[a].sum(), adc_recall=tot[d_, d_] / tot[d_].sum(),
                                    afe_adc_cross=(tot[a, d_] + tot[d_, a]) / (tot[a].sum() + tot[d_].sum()),
                                    healthy_recall=tot[0, 0] / tot[0].sum(), sensor_recall=tot[1, 1] / tot[1].sum()))
    (args.results / "confusion_matrices.json").write_text(json.dumps(cmj))
    pd.DataFrame(sep).round(4).to_csv(args.results / "afe_adc_separation.csv", index=False)

    # ---------------- paired bootstrap ----------------
    pairs = []
    baselines = {"A2": ["passive_mlp@A0", "single_mlp@A2", "afe_only_mlp@A2", "adc_only_mlp@A2"],
                 "A1": ["passive_mlp@A0", "single_mlp@A0", "afe_only_mlp@A1", "adc_only_mlp@A1"],
                 "A0": ["passive_mlp@A0", "single_mlp@A0", "afe_only_mlp@A0", "adc_only_mlp@A0"]}
    for scn in SCN:
        for arm, bl in baselines.items():
            for b in bl:
                pairs.append((scn, f"two_point_mlp@{arm}", b, "D1"))
        for a_, b_, tag in (("two_point_mlp@A2", "two_point_mlp@A0", "D2/D4"), ("two_point_mlp@A2", "two_point_mlp@A0j", "D5"),
                            ("two_point_mlp@A1", "two_point_mlp@A0", "D5"), ("two_point_mlp@A1j", "two_point_mlp@A0j", "D5"),
                            ("two_point_mlp@A2", "two_point_mlp@A1j", "D5"), ("two_point_mlp@A0j", "two_point_mlp@A0", "D5"),
                            ("two_point_rf@A2", "two_point_rf@A0", "RF"), ("tcn_v2a@A2", "two_point_mlp@A2", "D6"),
                            ("tcn_v2a@A2", "tcn_v2a@A0", "D6"), ("tcn_v2a@A1", "tcn_v2a@A0", "D6")):
            pairs.append((scn, a_, b_, tag))
    results = []
    for scn, a_, b_, tag in pairs:
        if not all(store.has(s, scn, m) for s in seeds for m in (a_, b_)):
            continue
        for target in ("layer", "fault"):
            for metric in ("macro_f1", "accuracy"):
                r = sm.compare(store, scn, target, a_, b_, metric, args.n_boot)
                r["rule"] = tag
                results.append(r)
    comp = pd.DataFrame(results)
    comp.round(4).to_csv(args.results / "bootstrap_comparisons.csv", index=False)

    def row(scn, target, a_, b_, metric="macro_f1"):
        r = comp[(comp.scenario == scn) & (comp.target == target) & (comp.A == a_) & (comp.B == b_) & (comp.metric == metric)]
        return r.iloc[0]

    def mean_f1(scn, model, target="layer"):
        r = agg[(agg.scenario == scn) & (agg.model + "@" + agg.arm == model) & (agg.target == target)]
        return float(r.macro_f1_mean.iloc[0])

    # ---------------- decision rules ----------------
    dec = {"D1": {}, "D2": {}, "D3": {}, "D4": {}, "D5": {}, "D6": {}}
    A2 = "two_point_mlp@A2"
    for scn in PRIMARY:
        lows = {b: float(row(scn, "layer", A2, b).ci_low) for b in baselines["A2"]}
        dec["D1"][scn] = {"min_ci_low": min(lows.values()), "ci_low_by_baseline": lows, "holds": bool(min(lows.values()) > 0)}
    for scn in ("ref_m20", "ref_p20"):
        r = row(scn, "layer", A2, "two_point_mlp@A0")
        dec["D2"][scn] = {"diff": float(r.diff_pooled), "ci": [float(r.ci_low), float(r.ci_high)], "holds": bool(r.ci_low > 0)}
        nom = mean_f1("nominal", A2)
        dec["D3"][scn] = {"f1": mean_f1(scn, A2), "nominal_f1": nom, "retention": mean_f1(scn, A2) / nom,
                          "holds": bool(mean_f1(scn, A2) / nom >= 0.85)}
    r = row("nominal", "layer", A2, "two_point_mlp@A0")
    dec["D4"] = {"diff": float(r.diff_pooled), "ci": [float(r.ci_low), float(r.ci_high)], "holds": bool(r.ci_low > -0.03)}
    for scn in ("ref_m20", "ref_p20"):
        for a_, b_ in (("two_point_mlp@A2", "two_point_mlp@A0j"), ("two_point_mlp@A1", "two_point_mlp@A0"),
                       ("two_point_mlp@A2", "two_point_mlp@A1j"), ("two_point_mlp@A0j", "two_point_mlp@A0")):
            r = row(scn, "layer", a_, b_)
            dec["D5"][f"{scn}|{a_}-{b_}"] = {"diff": float(r.diff_pooled), "ci": [float(r.ci_low), float(r.ci_high)]}
    for scn in SCN:
        r = row(scn, "layer", "tcn_v2a@A2", A2)
        dec["D6"][scn] = {"diff": float(r.diff_pooled), "ci": [float(r.ci_low), float(r.ci_high)]}
    d1 = all(v["holds"] for v in dec["D1"].values())
    d2 = all(v["holds"] for v in dec["D2"].values())
    d3 = all(v["holds"] for v in dec["D3"].values())
    d4 = dec["D4"]["holds"]
    dec["summary"] = {"D1": d1, "D2": d2, "D3": d3, "D4": d4}
    dec["tag"] = ("REFERENCE REVISION VALIDATED" if (d1 and d2 and d3 and d4) else
                  "REFERENCE REVISION PARTIALLY VALIDATED" if (d1 and d2) else "REFERENCE REVISION NOT VALIDATED")
    (args.results / "decision_rules.json").write_text(json.dumps(dec, indent=2))
    print(json.dumps({k: dec[k] for k in ("D1", "D2", "D3", "D4", "summary", "tag")}, indent=1))

    # ---------------- figures ----------------
    pd.set_option("display.width", 250)
    for t in ("layer", "fault"):
        p = agg[(agg.target == t) & (agg.model == "two_point_mlp")].pivot(index="arm", columns="scenario", values="macro_f1_mean")
        print(f"\ntwo_point_mlp macro-F1 ({t}) by arm\n", p.reindex(ARM_ORDER)[SCN].round(3).to_string())
    pal = {"A0": "#999999", "A0j": "#c9a66b", "A1": "#7aa6d6", "A1j": "#4f81bd", "A2": "#1b6e3d"}
    for target in ("layer", "fault"):
        fig, ax = plt.subplots(figsize=(11, 4.6))
        w = 0.16
        for i, arm in enumerate(ARM_ORDER):
            vals, errs = [], []
            for scn in SCN:
                d = ia[(ia.scenario == scn) & (ia.model == "two_point_mlp") & (ia.arm == arm) & (ia.target == target)]
                vals.append(d.macro_f1.mean()); errs.append(d.macro_f1.std(ddof=1))
            ax.bar(np.arange(len(SCN)) + (i - 2) * w, vals, w, yerr=errs, color=pal[arm], capsize=2, label=ARM_LABEL[arm])
        ax.set_xticks(range(len(SCN))); ax.set_xticklabels(["nominal", "tolerance", "ref x0.8", "ref x1.2", "ref x0.9", "ref x1.1", "unseen severity"])
        ax.set_ylabel(f"{target} macro-F1"); ax.set_title(f"Two-point MLP by arm ({target}); mean ± std over 3 dataset seeds")
        ax.legend(fontsize=8, ncol=3); ax.set_ylim(0, 0.8); fig.tight_layout()
        fig.savefig(args.comparison / f"arms_{target}_macro_f1.png", dpi=150); plt.close(fig)
    models = ["passive_mlp@A0", "single_mlp@A2", "afe_only_mlp@A2", "adc_only_mlp@A2", "two_point_mlp@A2", "two_point_rf@A2", "tcn_v2a@A2"]
    cols = ["#999999", "#bbbb66", "#e0a060", "#d08080", "#2f6db5", "#7aa6d6", "#2a9d5c"]
    for target in ("layer", "fault"):
        fig, ax = plt.subplots(figsize=(12, 4.6))
        w = 0.12
        for i, m in enumerate(models):
            name, arm = m.split("@")
            vals = [ia[(ia.scenario == s) & (ia.model == name) & (ia.arm == arm) & (ia.target == target)].macro_f1.mean() for s in SCN]
            ax.bar(np.arange(len(SCN)) + (i - 3) * w, vals, w, color=cols[i], label=m)
        ax.set_xticks(range(len(SCN))); ax.set_xticklabels(["nominal", "tolerance", "ref x0.8", "ref x1.2", "ref x0.9", "ref x1.1", "unseen severity"])
        ax.set_ylabel(f"{target} macro-F1"); ax.set_title(f"Arm A2 (full revision) vs one-point baselines ({target})")
        ax.legend(fontsize=7, ncol=4); ax.set_ylim(0, 0.8); fig.tight_layout()
        fig.savefig(args.comparison / f"a2_vs_baselines_{target}_macro_f1.png", dpi=150); plt.close(fig)


if __name__ == "__main__":
    main()
