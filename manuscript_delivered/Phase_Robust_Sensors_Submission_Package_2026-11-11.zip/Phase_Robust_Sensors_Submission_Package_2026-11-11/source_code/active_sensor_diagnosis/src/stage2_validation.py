"""Multi-seed and disturbance validation for the active sensor interface.

This is the decision gate between a promising behavioral experiment and the
more expensive circuit/TCN study.  It keeps the split by operating-condition
group, trains only on nominal training conditions, and evaluates both nominal
and held-out ADC-noise disturbances.  The two-point reference path is treated
as the proposed electronic architecture; the adaptive selector is reported
as an exploratory ablation rather than silently promoted to a contribution.
"""

from __future__ import annotations

import argparse
import copy
import json
import warnings
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import GroupShuffleSplit

from .adaptive_policy import evaluate_adaptive, make_model
from .features import feature_matrix
from .simulate import build_paired_dataset


MODE_INFO = {
    "passive": ("passive", 0.0),
    "single_probe": ("active", 1.0),
    "afe_reference": ("active_afe_only", 1.0),
    "adc_reference": ("active_adc_only", 1.0),
    "two_point": ("active_two_point", 2.0),
}


def _disturb(records: Iterable[Dict[str, object]], seed: int, noise_multiplier: float = 3.0) -> List[Dict[str, object]]:
    """Add an unseen ADC-noise condition without changing labels or references."""
    rng = np.random.default_rng(seed)
    out: List[Dict[str, object]] = []
    for record in records:
        item = copy.copy(record)
        y = np.asarray(record["waveform"], dtype=np.float32).copy()
        # The nominal model uses approximately 2.5 mV analog noise.  The test
        # shift is intentionally outside the training distribution.
        y += rng.normal(0.0, 0.0025 * (noise_multiplier - 1.0), size=len(y)).astype(np.float32)
        y = np.clip(y, 0.0, 3.3).astype(np.float32)
        item["waveform"] = y
        out.append(item)
    return out


def _evaluate_model(
    train_data: Dict[str, np.ndarray],
    test_data: Dict[str, np.ndarray],
    train_idx: np.ndarray,
    test_idx: np.ndarray,
    seed: int,
) -> Dict[str, float]:
    model = make_model(seed)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        model.fit(train_data["x"][train_idx], train_data["y"][train_idx])
    pred = model.predict(test_data["x"][test_idx])
    return {
        "accuracy": float(accuracy_score(test_data["y"][test_idx], pred)),
        "macro_f1": float(f1_score(test_data["y"][test_idx], pred, average="macro")),
    }


def _one_seed(seed: int, samples_per_class: int, output: Path) -> Dict[str, object]:
    dataset = build_paired_dataset(samples_per_class, seed)
    nominal: Dict[str, Dict[str, np.ndarray]] = {}
    disturbed: Dict[str, Dict[str, np.ndarray]] = {}
    for name, (record_mode, cost) in MODE_INFO.items():
        x, y, groups, severity = feature_matrix(dataset["records"][record_mode], "raw_plus_physics", target="layer")
        nominal[name] = {"x": x, "y": y, "groups": groups, "severity": severity}
        shifted_records = _disturb(dataset["records"][record_mode], seed + 2000, noise_multiplier=3.0)
        sx, sy, sg, ss = feature_matrix(shifted_records, "raw_plus_physics", target="layer")
        disturbed[name] = {"x": sx, "y": sy, "groups": sg, "severity": ss}

    reference = nominal["two_point"]
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=seed + 1)
    train_idx, test_idx = next(splitter.split(reference["x"], reference["y"], reference["groups"]))
    methods: List[Dict[str, object]] = []
    for offset, (name, (_, cost)) in enumerate(MODE_INFO.items()):
        nominal_metric = _evaluate_model(nominal[name], nominal[name], train_idx, test_idx, seed + offset)
        shifted_metric = _evaluate_model(nominal[name], disturbed[name], train_idx, test_idx, seed + offset)
        methods.append(
            {
                "method": name,
                "cost": cost,
                "nominal": nominal_metric,
                "noise_shift": shifted_metric,
                "noise_f1_drop": nominal_metric["macro_f1"] - shifted_metric["macro_f1"],
            }
        )

    # The selector is deliberately evaluated with the same group split.  Its
    # result is kept separate because the current passive model is not yet
    # calibrated enough to claim cost savings.
    adaptive_features = {
        key: nominal[key]
        for key in ("passive", "afe_reference", "adc_reference", "two_point")
    }
    adaptive_features = {
        "passive": adaptive_features["passive"],
        "active_afe_only": adaptive_features["afe_reference"],
        "active_adc_only": adaptive_features["adc_reference"],
        "active_two_point": adaptive_features["two_point"],
    }
    adaptive = evaluate_adaptive(adaptive_features, train_idx, test_idx, seed + 50)
    return {
        "seed": seed,
        "samples_per_class": samples_per_class,
        "train_condition_count": int(len(set(reference["groups"][train_idx].tolist()))),
        "test_condition_count": int(len(set(reference["groups"][test_idx].tolist()))),
        "methods": methods,
        "adaptive_exploratory": adaptive,
    }


def _aggregate(runs: List[Dict[str, object]]) -> pd.DataFrame:
    rows = []
    for run in runs:
        for item in run["methods"]:
            rows.append(
                {
                    "seed": run["seed"],
                    "method": item["method"],
                    "cost": item["cost"],
                    "nominal_accuracy": item["nominal"]["accuracy"],
                    "nominal_macro_f1": item["nominal"]["macro_f1"],
                    "noise_accuracy": item["noise_shift"]["accuracy"],
                    "noise_macro_f1": item["noise_shift"]["macro_f1"],
                    "noise_f1_drop": item["noise_f1_drop"],
                }
            )
    return pd.DataFrame(rows)


def _plot(summary: pd.DataFrame, path: Path) -> None:
    grouped = summary.groupby("method", sort=False)
    fig, ax = plt.subplots(figsize=(8.4, 5.4))
    for name, frame in grouped:
        x = frame["cost"].iloc[0]
        y = frame["nominal_macro_f1"].mean()
        e = frame["nominal_macro_f1"].std(ddof=1) if len(frame) > 1 else 0.0
        ax.errorbar(x, y, yerr=e, marker="o", capsize=4, linewidth=1.5, label=name)
        y_shift = frame["noise_macro_f1"].mean()
        ax.plot(x, y_shift, marker="x", markersize=8, color=ax.lines[-1].get_color(), alpha=0.8)
    ax.set_xlabel("Normalized reference-test cost")
    ax.set_ylabel("Layer macro-F1 (circle: nominal, x: noise shift)")
    ax.set_title("Active reference paths: multi-seed feasibility and robustness")
    ax.grid(alpha=0.25)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--samples-per-class", type=int, default=180)
    parser.add_argument("--seeds", default="20261014,20261015,20261016")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "stage2_results")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    seeds = [int(s.strip()) for s in args.seeds.split(",") if s.strip()]
    runs = [_one_seed(seed, args.samples_per_class, args.output) for seed in seeds]
    summary = _aggregate(runs)
    summary.to_csv(args.output / "stage2_summary.csv", index=False)
    _plot(summary, args.output / "stage2_pareto.png")
    aggregate = (
        summary.groupby(["method", "cost"], as_index=False)
        .agg(
            nominal_accuracy_mean=("nominal_accuracy", "mean"),
            nominal_accuracy_std=("nominal_accuracy", "std"),
            nominal_macro_f1_mean=("nominal_macro_f1", "mean"),
            nominal_macro_f1_std=("nominal_macro_f1", "std"),
            noise_macro_f1_mean=("noise_macro_f1", "mean"),
            noise_macro_f1_std=("noise_macro_f1", "std"),
            noise_f1_drop_mean=("noise_f1_drop", "mean"),
        )
        .fillna(0.0)
    )
    result = {
        "status": "COMPLETED",
        "samples_per_class": args.samples_per_class,
        "seeds": seeds,
        "runs": runs,
        "aggregate": aggregate.to_dict(orient="records"),
        "interpretation": [
            "The two-point architecture is the primary electronic contribution; adaptive selection is exploratory.",
            "The noise-shift split is generated only after the group split and is never used for training.",
            "These are behavioral-simulation results, not hardware or final-paper metrics.",
        ],
    }
    (args.output / "stage2_metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(aggregate.to_string(index=False, float_format=lambda v: f"{v:.4f}"))
    print(f"Results written to: {args.output}")


if __name__ == "__main__":
    main()

