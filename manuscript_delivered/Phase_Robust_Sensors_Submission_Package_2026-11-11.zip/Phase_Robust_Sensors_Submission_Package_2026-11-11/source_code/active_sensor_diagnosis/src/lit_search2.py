"""Second, precision round: OpenAlex filter title_and_abstract.search (appends to search_log.json)."""
import json, time
from pathlib import Path
import requests, pandas as pd
from .lit_search import inv
OUT = Path(__file__).resolve().parents[1] / "paper_package" / "literature"
Q2 = {
 "T1 active self-test of sensor interfaces": ["sensor interface built-in self-test calibration", "smart sensor self-diagnosis front-end", "oscillation-based test sensor"],
 "T2 AFE and ADC fault diagnosis": ["analog and ADC combined self-test", "transient response test analog circuit ADC", "analog front end ADC fault localization"],
 "T4 reference monitoring / drift": ["reference voltage monitoring functional safety ADC", "ADC reference voltage error detection", "redundant reference measurement sensor interface safety"],
 "T5 phase-robust transient descriptors": ["variable projection separable nonlinear least squares", "time constant estimation exponential step response least squares", "equivalent-time sampling step response timing"],
 "M methods": ["bootstrap confidence intervals clustered data", "scikit-learn machine learning in Python"],
}
log = json.loads((OUT / "search_log.json").read_text())
rows = []
for theme, qs in Q2.items():
    for q in qs:
        r = requests.get("https://api.openalex.org/works", params={"filter": f"title_and_abstract.search:{q},publication_year:>1979", "sort": "cited_by_count:desc", "per-page": 15}, timeout=60)
        r.raise_for_status(); js = r.json()
        log["queries"].append({"theme": theme, "query": q, "mode": "title_and_abstract.search, sorted by citations", "total_hits": js["meta"]["count"], "retrieved": len(js["results"])})
        for w in js["results"]:
            src = (w.get("primary_location") or {}).get("source") or {}
            rows.append({"theme": theme, "query": q, "openalex_id": w["id"], "doi": (w.get("doi") or "").replace("https://doi.org/", ""), "title": w.get("title"), "year": w.get("publication_year"),
                         "venue": src.get("display_name"), "publisher": src.get("host_organization_name"), "type": w.get("type"), "cited_by": w.get("cited_by_count"),
                         "authors": "; ".join(a["author"]["display_name"] for a in w.get("authorships", [])[:8]), "abstract": inv(w.get("abstract_inverted_index"))[:3000]})
        time.sleep(0.25)
df = pd.DataFrame(rows); df.to_csv(OUT / "candidates_round2.csv", index=False)
log["n_records_round2"] = len(df); (OUT / "search_log.json").write_text(json.dumps(log, indent=1))
for _, r in df.iterrows():
    print(f"{r.theme[:2]}|{r.year}|{int(r.cited_by):5d}|{str(r.title)[:105]}|{str(r.venue)[:35]}|{r.doi}")
