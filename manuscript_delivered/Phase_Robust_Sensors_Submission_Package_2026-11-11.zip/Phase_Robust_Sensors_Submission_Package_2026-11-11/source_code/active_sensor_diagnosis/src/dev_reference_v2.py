"""DEVELOPMENT-ONLY check on a dedicated development seed (20261099); never used in validation.

Purpose: (1) quantify the invariance of the settled-plateau descriptors to the reference scale for the
pre-declared guard options, (2) sanity-check that the full pipeline is not degenerate before freezing.
"""
import json
import sys
from pathlib import Path

import numpy as np
from sklearn.metrics import f1_score
from sklearn.model_selection import GroupShuffleSplit

from .features import physics_features, raw_features
from .ref_features import FEATURE_NAMES, ref_descriptors
from .run_feasibility import _classifier
from .simulate import FAULT_TO_LAYER, FAULTS, LAYERS, make_condition, make_fault, simulate_sample

SEED, N = 20261099, 220
LAYER_ID = {n: i for i, n in enumerate(LAYERS)}
rng = np.random.default_rng(SEED)
jit = np.random.default_rng(SEED + 1)
specs = []
for cid in range(N):
    cond = make_condition(rng)
    for ci, name in enumerate(FAULTS):
        f = make_fault(name, rng)
        specs.append((cid, ci, cond, f, int(rng.integers(0, 2**31 - 1)), float(jit.uniform(0.9, 1.1))))
groups = np.array([s[0] for s in specs]); yl = np.array([LAYER_ID[FAULT_TO_LAYER[FAULTS[s[1]]]] for s in specs])
tr, te = next(GroupShuffleSplit(1, test_size=0.25, random_state=SEED + 1).split(np.zeros(len(specs)), groups=groups))


def sim(scale_fn):
    return [simulate_sample(c, f, active=True, seed=sd + 4, probe_mode="two_point", ref_scale=scale_fn(k)) for (_, _, c, f, sd, k) in specs]


recs = {"nominal": sim(lambda k: 1.0), "m20": sim(lambda k: 0.8), "p20": sim(lambda k: 1.2), "jitter": sim(lambda k: k)}
out = {}
for guard in (0.3, 0.5):
    D = {k: np.array([ref_descriptors(r, guard)[0] for r in v]) for k, v in recs.items()}
    sd_nom = D["nominal"][te].std(0) + 1e-9
    inv = {}
    for scn in ("m20", "p20"):
        dev = np.abs(D[scn][te] - D["nominal"][te]).mean(0) / sd_nom
        inv[scn] = {n: round(float(v), 3) for n, v in zip(FEATURE_NAMES, dev)}
    # absolute shifts of the physically meaningful estimates vs smallest fault size
    ab = {scn: {n: round(float(np.abs(D[scn][te][:, i] - D["nominal"][te][:, i]).mean()), 4)
                for i, n in enumerate(FEATURE_NAMES) if n in ("g_adc", "o_adc", "G_afe", "o_afe")} for scn in ("m20", "p20")}
    res = {"invariance_sigma": inv, "abs_shift": ab}
    for arm, (trk) in (("A1_nominal_train", "nominal"), ("A1j_jitter_train", "jitter")):
        f1 = {}
        for init in (11, 22):
            m = _classifier(init).fit(D[trk][tr], yl[tr])
            for scn in ("nominal", "m20", "p20"):
                f1.setdefault(scn, []).append(f1_score(yl[te], m.predict(D[scn][te]), average="macro"))
        res[arm] = {k: round(float(np.mean(v)), 3) for k, v in f1.items()}
    out[f"guard_{guard}"] = res
    print(f"guard {guard}:", json.dumps({k: v for k, v in res.items() if k.startswith("A1")}), flush=True)
    print("  abs shift (V or unit):", json.dumps(ab))
    print("  worst invariance (sigma) m20:", sorted(inv["m20"].items(), key=lambda kv: -kv[1])[:6])
Path(__file__).resolve().parents[1].joinpath("reference_v2_results").mkdir(exist_ok=True)
Path(__file__).resolve().parents[1].joinpath("reference_v2_results", "development_check_seed20261099.json").write_text(json.dumps(out, indent=1))
