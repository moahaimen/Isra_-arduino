"""Publication figures for the paper package.

Result panels read the frozen validation outputs (no retraining). Illustrative / verification panels use either analytic
curves or the disclosed DEVELOPMENT seed 20261097 and are labelled as such; their data are written to figure_data/.
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon, Rectangle

from .monitor_model import draw, variant_descriptors
from .phase_features import PR_NAMES, to_phase_robust, transient_features
from .ref_features import FEATURE_NAMES, ref_descriptors
from .simulate import FAULT_TO_LAYER, FAULTS, LAYERS, _adc_reference, _afe_reference, make_condition, make_fault, simulate_sample

ROOT = Path(__file__).resolve().parents[1]
PR = ROOT / "phase_robust_final/phase_robust_results"
RM = ROOT / "reference_monitor_final/reference_monitor_results"
DEV_SEED = 20261097
OI = {"black": "#000000", "orange": "#E69F00", "sky": "#56B4E9", "green": "#009E73", "yellow": "#F0E442", "blue": "#0072B2", "red": "#D55E00", "purple": "#CC79A7", "grey": "#888888"}
ARM_C = {"A0": OI["grey"], "R1": OI["red"], "R1r": OI["orange"], "PR": OI["sky"], "PRr": OI["blue"], "PRrM": OI["green"]}
PH = (0.0, 0.25, 0.5, 0.75, 0.999)
PCOLS = ["layer_f1_p000", "layer_f1_p250", "layer_f1_p500", "layer_f1_p750", "layer_f1_p999"]

plt.rcParams.update({"font.size": 8.5, "axes.titlesize": 9, "axes.labelsize": 8.5, "legend.fontsize": 7.5, "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
                     "axes.spines.top": False, "axes.spines.right": False, "font.family": "DejaVu Sans", "savefig.bbox": "tight", "savefig.pad_inches": 0.03})


def save(fig, out: Path, name: str):
    fig.savefig(out / f"{name}.pdf")
    fig.savefig(out / f"{name}.png", dpi=300)
    plt.close(fig)


def _box(ax, x, y, w, h, text, fc="#f4f6f8", ec="#333333", fs=7.5, bold=False, ls="-"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08", fc=fc, ec=ec, lw=1.0, ls=ls))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, weight="bold" if bold else "normal", wrap=True)


def _arrow(ax, p0, p1, color="#333333", lw=1.0, ls="-", style="-|>"):
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle=style, mutation_scale=8, color=color, lw=lw, ls=ls, shrinkA=0, shrinkB=0))


def _switch(ax, x, y, label, closed=False):
    ax.plot([x, x + 0.18], [y, y], color="k", lw=0)
    ax.add_patch(plt.Circle((x, y), 0.03, fc="white", ec="k", lw=0.9))
    ax.add_patch(plt.Circle((x + 0.3, y), 0.03, fc="white", ec="k", lw=0.9))
    ax.plot([x + 0.03, x + 0.28], [y, y + (0.0 if closed else 0.12)], color="k", lw=1.0)
    ax.text(x + 0.15, y + 0.17, label, ha="center", fontsize=7)


# ---------------------------------------------------------------------------------------------- Fig. 1
def fig_architecture(out: Path):
    fig, ax = plt.subplots(figsize=(7.4, 3.9))
    ax.set_xlim(0, 12); ax.set_ylim(0, 6.2); ax.axis("off")
    fs = 6.8
    _box(ax, 0.2, 3.7, 1.4, 0.8, "Sensor\n(measurand)", fc="#fdf3e1", fs=fs)
    _box(ax, 0.2, 1.9, 1.4, 0.8, "AFE ref.\n0.90 / 1.30 V", fc="#e8f1fa", fs=fs)
    _switch(ax, 1.9, 4.1, "S1"); _switch(ax, 1.9, 2.3, "S2")
    _arrow(ax, (1.6, 4.1), (1.87, 4.1)); _arrow(ax, (1.6, 2.3), (1.87, 2.3))
    ax.plot([2.23, 2.55, 2.55], [4.1, 4.1, 3.2], color="k", lw=1.0); ax.plot([2.23, 2.55, 2.55], [2.3, 2.3, 3.2], color="k", lw=1.0)
    _arrow(ax, (2.55, 3.2), (2.85, 3.2))
    _box(ax, 2.85, 2.75, 2.1, 0.9, "AFE: RC low-pass τ\ngain G, offset", fc="#eaf6ee", fs=fs)
    ax.plot([4.95, 5.27], [3.2, 3.2], color="k", lw=1.0); _switch(ax, 5.3, 3.2, "S3")
    ax.plot([5.63, 7.15], [3.2, 3.2], color="k", lw=1.0)
    _box(ax, 5.05, 1.6, 1.3, 0.8, "ADC ref.\n1.15 / 1.75 V", fc="#e8f1fa", fs=fs)
    _arrow(ax, (6.35, 2.0), (6.62, 2.0)); _switch(ax, 6.65, 2.0, "S4")
    ax.plot([6.98, 7.15, 7.15], [2.0, 2.0, 3.2], color="k", lw=1.0)
    _arrow(ax, (7.15, 3.2), (7.4, 3.2))
    _box(ax, 7.4, 2.75, 1.5, 0.9, "ADC\n12-bit, 1 kS/s", fc="#fbeaea", fs=fs)
    _arrow(ax, (8.9, 3.2), (9.3, 3.2))
    _box(ax, 9.3, 2.4, 2.55, 1.6, "Digital diagnosis\nsettled-plateau calibration\nphase-robust descriptors\nneural-network classifier\n→ fault layer + fine fault", fc="#f1ecf8", fs=6.5)
    # reference monitor (dashed taps on two separate buses, no crossings)
    pc = OI["purple"]
    ax.plot([0.9, 0.9, 6.7], [1.9, 0.45, 0.45], color=pc, lw=1.0, ls="--")
    ax.plot([5.7, 5.7, 6.7], [1.6, 0.85, 0.85], color=pc, lw=1.0, ls="--")
    _box(ax, 6.7, 0.3, 0.55, 0.7, "S5\n2:1", fc="white", ec=pc, fs=6)
    _arrow(ax, (7.25, 0.65), (7.45, 0.65), color=pc)
    ax.add_patch(Polygon([[7.45, 0.38], [7.45, 0.92], [7.9, 0.65]], closed=True, fc="white", ec=pc, lw=1.1))
    ax.text(7.52, 0.65, "×1", fontsize=5.8, va="center", color=pc)
    _arrow(ax, (7.9, 0.65), (8.1, 0.65), color=pc)
    _box(ax, 8.1, 0.3, 1.45, 0.7, "monitor ADC\n12-bit, 16-avg", fc="#f7eef5", ec=pc, fs=6)
    ax.plot([9.55, 10.55], [0.65, 0.65], color=pc, lw=1.0); _arrow(ax, (10.55, 0.65), (10.55, 2.4), color=pc)
    ax.text(10.65, 1.45, "measured\nlevels r̂", fontsize=6, color=pc)
    ax.text(1.2, 0.12, "high-impedance buffered taps of both reference nodes", fontsize=6, color=pc)
    # sequencer
    _box(ax, 1.25, 5.25, 8.5, 0.6, "Test sequencer: timing of S1–S5; edges fall ψ·T after an ADC sample (ψ unknown, 0 ≤ ψ < 1)", fc="#ffffff", ls="--", fs=6.3)
    for (x, y) in ((2.05, 4.32), (5.45, 3.42), (6.8, 2.22)):
        _arrow(ax, (x, 5.25), (x, y), color=OI["grey"], lw=0.7, ls=":")
    ax.plot([2.05, 2.05], [4.0, 2.55], color=OI["grey"], lw=0.7, ls=":")
    # fault locations
    ax.text(0.9, 4.75, "sensor faults:\nbias, gain, noise", ha="center", fontsize=6.2, color=OI["orange"], weight="bold")
    ax.text(3.9, 3.85, "AFE faults: offset, bandwidth", ha="center", fontsize=6.2, color=OI["green"], weight="bold")
    ax.text(8.15, 3.85, "ADC faults:\noffset, gain, clipping", ha="center", fontsize=6.2, color=OI["red"], weight="bold")
    save(fig, out, "fig01_architecture")


# ---------------------------------------------------------------------------------------------- Fig. 2
def fig_timing(out: Path, data: Path):
    n, fs = 512, 1000.0
    t = np.arange(n) / fs * 1000
    afe, s0, e0 = _afe_reference(n, fs)
    adc, s1, e1 = _adc_reference(n, fs)
    rng = np.random.default_rng(DEV_SEED)
    cond = make_condition(rng)
    rec = simulate_sample(cond, make_fault("healthy", rng), active=True, seed=4, probe_mode="two_point")
    y = rec["waveform"]
    pd.DataFrame({"t_ms": t, "afe_ref_V": afe, "adc_ref_V": adc, "afe_ctrl": (afe > 0).astype(int), "adc_ctrl": (adc > 0).astype(int), "adc_output_V": y}).to_csv(data / "fig02_timing_example.csv", index=False)
    fig, axs = plt.subplots(4, 1, figsize=(7.2, 4.6), sharex=True, gridspec_kw={"height_ratios": [0.6, 0.6, 1.1, 1.8]})
    axs[0].step(t, (afe > 0).astype(int), where="post", color=OI["blue"]); axs[0].set_yticks([0, 1]); axs[0].set_yticklabels(["sensor", "ref"]); axs[0].set_ylabel("AFE mux", rotation=0, ha="right", va="center")
    axs[1].step(t, (adc > 0).astype(int), where="post", color=OI["red"]); axs[1].set_yticks([0, 1]); axs[1].set_yticklabels(["AFE", "ref"]); axs[1].set_ylabel("ADC mux", rotation=0, ha="right", va="center")
    axs[2].step(t, np.where(afe > 0, afe, np.nan), where="post", color=OI["blue"], label="AFE reference")
    axs[2].step(t, np.where(adc > 0, adc, np.nan), where="post", color=OI["red"], label="ADC reference")
    axs[2].set_ylabel("level (V)", rotation=0, ha="right", va="center"); axs[2].legend(loc="upper left", ncol=2, frameon=False); axs[2].set_ylim(0.7, 2.0)
    axs[3].plot(t, y, color="k", lw=0.8)
    axs[3].set_ylabel("ADC output\ny[n] (V)", rotation=0, ha="right", va="center"); axs[3].set_xlabel("time (ms)")
    half = (e0 - s0) // 2
    for (s, e) in ((s0, s0 + half), (s0 + half, e0), (s1, s1 + (e1 - s1) // 2), (s1 + (e1 - s1) // 2, e1)):
        g = int(round(0.3 * (e - s)))
        axs[3].axvspan(s, s + g, color=OI["orange"], alpha=0.25, lw=0)
        axs[3].axvspan(s + g, e, color=OI["sky"], alpha=0.22, lw=0)
    axs[3].axvspan(s0 + half, e0, ymin=0.0, ymax=0.07, color=OI["green"], alpha=0.8, lw=0)
    for seg in ((40, 130), (470, 512)):
        axs[3].axvspan(*seg, ymin=0.0, ymax=0.07, color=OI["purple"], alpha=0.6, lw=0)
    from matplotlib.patches import Patch
    axs[3].legend(handles=[Patch(color=OI["orange"], alpha=0.4, label="30% settling guard"), Patch(color=OI["sky"], alpha=0.4, label="settled plateau"),
                           Patch(color=OI["green"], alpha=0.8, label="transient-fit window"), Patch(color=OI["purple"], alpha=0.6, label="sensor-domain segments")],
                  loc="upper right", fontsize=6, frameon=False, ncol=2)
    axs[0].set_title("Active self-test sequence (illustrative healthy record, development seed)")
    save(fig, out, "fig02_timing")


# ---------------------------------------------------------------------------------------------- Fig. 3
def fig_pipeline(out: Path):
    fig, ax = plt.subplots(figsize=(7.2, 2.9))
    ax.set_xlim(0, 12); ax.set_ylim(0, 4.6); ax.axis("off")
    steps = [("ADC record y[n]\n+ monitored\nlevels r̂", "#fbeaea"), ("ADC calibration\nfrom settled\nADC plateaus\n(ĝ_ADC, ô_ADC)", "#e8f1fa"),
             ("AFE calibration\nfrom settled\nAFE plateaus\n(Ĝ_AFE, ô_AFE)", "#eaf6ee"), ("phase-robust\ntransient fit\n(τ, rise times,\narea, residual)", "#e8f1fa"),
             ("20 descriptors\n+ settling error,\nnoise, sensor-\ndomain statistics", "#f4f6f8"), ("MLP 20-96-48\n→ 4 layers\n→ 9 faults", "#f1ecf8")]
    x = 0.15
    for i, (txt, c) in enumerate(steps):
        _box(ax, x, 2.4, 1.75, 1.75, txt, fc=c, fs=6.6)
        if i < len(steps) - 1:
            _arrow(ax, (x + 1.75, 3.27), (x + 2.0, 3.27))
        x += 2.0
    _box(ax, 0.15, 0.2, 11.7, 1.55, "Training (behavioral simulator, nominal amplitude, 222 conditions per seed):\n"
                                     "reference-edge phase ψ ~ U[0,1) drawn per record; monitor error drawn from the deployed bound E (matched training);\n"
                                     "standardisation fitted on training data only. Ablation PRrM: mixed behavioral + ngspice training rows.", fc="#ffffff", ls="--", fs=6.5)
    _arrow(ax, (11.0, 1.75), (11.0, 2.4), color=OI["grey"], ls=":")
    ax.text(0.15, 4.35, "Processing pipeline of the proposed phase-robust, reference-monitored self-test", fontsize=8.5, weight="bold")
    save(fig, out, "fig03_pipeline")


# ---------------------------------------------------------------------------------------------- dev-seed verification data
def dev_verification(data: Path, n_sp: int = 6, n_beh: int = 40) -> dict:
    """Descriptor phase invariance (behavioral) and noise-free behavioral/ngspice agreement per phase (development seed)."""
    from .spice_phase import spice_record_phase
    rng = np.random.default_rng(DEV_SEED)
    specs = []
    for cid in range(max(n_sp, n_beh)):
        cond = make_condition(rng)
        for name in FAULTS:
            specs.append((cond, make_fault(name, rng), int(rng.integers(0, 2**31 - 1))))
    R, T = {p: [] for p in PH}, {p: [] for p in PH}
    for cond, f, sd in specs[:n_beh * 9]:
        for p in PH:
            b = simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point", ref_phase=p)
            R[p].append(ref_descriptors(b)[0]); T[p].append(transient_features(b))
    R = {k: np.array(v) for k, v in R.items()}; T = {k: np.array(v) for k, v in T.items()}
    sdR, sdT = R[0.0].std(0) + 1e-9, T[0.0].std(0) + 1e-9
    from .phase_features import TF_NAMES
    inv = {"revision1": {n: [float(np.mean(np.abs(R[p][:, FEATURE_NAMES.index(n)] - R[0.0][:, FEATURE_NAMES.index(n)])) / sdR[FEATURE_NAMES.index(n)]) for p in PH]
                         for n in ("rise_2", "rise_5", "rise_10", "rise_20", "rise_30")},
           "phase_robust": {n: [float(np.mean(np.abs(T[p][:, i] - T[0.0][:, i])) / sdT[i]) for p in PH] for i, n in enumerate(TF_NAMES)},
           "phases": list(PH), "n_records": n_beh * 9, "seed": DEV_SEED, "unit": "mean |d(psi) - d(0)| / std_over_records(d(0))"}
    agree = {}
    wave = {}
    with tempfile.TemporaryDirectory(prefix="spv_") as wd:
        for p in PH:
            rm = []
            for k, (cond, f, sd) in enumerate(specs[:n_sp * 9]):
                b = simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point", ref_phase=p)
                s = spice_record_phase(cond, f, sd + 4, Path(wd), phase=p, extra_noise=False)
                rm.append(float(np.sqrt(np.mean((b["waveform"] - s["waveform"]) ** 2))))
            agree[str(p)] = {"mean_rmse_mV": float(np.mean(rm) * 1000), "max_rmse_mV": float(np.max(rm) * 1000), "n": len(rm)}
        cond, f, sd = specs[0]
        b = simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point", ref_phase=0.5, **{"afe_gain_scale": 1.02})
        s = spice_record_phase(cond, f, sd + 4, Path(wd), phase=0.5, tol={"afe_gain_scale": 1.02}, extra_noise=True)
        wave = {"t_ms": list(range(512)), "behavioral_V": [float(v) for v in b["waveform"]], "ngspice_V": [float(v) for v in s["waveform"]], "fault": f.name, "phase": 0.5}
    out = {"descriptor_phase_invariance": inv, "noise_free_agreement_per_phase": agree}
    (data / "dev_seed_verification.json").write_text(json.dumps(out, indent=1))
    pd.DataFrame(wave).drop(columns=["fault", "phase"]).to_csv(data / "fig06_example_waveforms_dev_seed.csv", index=False)
    # fault signatures (behavioral, known reference, psi random) for Fig. 5a
    rng2 = np.random.default_rng(DEV_SEED + 1)
    rows = []
    for cid in range(60):
        cond = make_condition(rng2)
        for name in FAULTS:
            f = make_fault(name, rng2); sd = int(rng2.integers(0, 2**31 - 1))
            rec = simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point", ref_phase=float(rng2.uniform()))
            d = to_phase_robust(ref_descriptors(rec)[0], transient_features(rec))
            rows.append({"fault": name, **{n: float(v) for n, v in zip(PR_NAMES, d)}})
    sig = pd.DataFrame(rows)
    sig.to_csv(data / "fig05_fault_signature_descriptors_dev_seed.csv", index=False)
    return {"inv": inv, "agree": agree, "wave": wave, "sig": sig}


# ---------------------------------------------------------------------------------------------- Fig. 4
def fig_phase(out: Path, data: Path, dev: dict):
    att = pd.read_csv(PR / "attribution_arms.csv")
    fig, axs = plt.subplots(1, 4, figsize=(7.4, 2.4), gridspec_kw={"width_ratios": [1.15, 1, 1, 1.1]})
    tau, T = 12.0, 1.0
    tt = np.linspace(-1.5, 12, 500)
    for p, c in zip((0.0, 0.5, 0.999), (OI["blue"], OI["orange"], OI["red"])):
        r = np.where(tt >= p - 1, 1 - np.exp(-(tt - (p - 1)) / tau), 0.0)
        axs[0].plot(tt, r, color=c, lw=0.9, label=f"ψ = {p:g}")
        j = np.arange(0, 12)
        rj = np.where(j >= p - 1 + 1e-9, 1 - np.exp(-(j - (p - 1)) / tau), 0.0)
        axs[0].plot(j, rj, "o", ms=2.5, color=c)
    for j in (2, 5):
        axs[0].axvline(j, color=OI["grey"], lw=0.6, ls=":"); axs[0].text(j + 0.15, 0.61 if j == 5 else 0.54, f"rise_{j}", fontsize=6, color=OI["grey"])
    axs[0].set_xlabel("sample index after the step"); axs[0].set_ylabel("normalised response"); axs[0].set_title("(a) same step, different edge phase\n(analytic, τ = 12 ms)", fontsize=8)
    axs[0].legend(frameon=False, fontsize=6.3, loc="center left", bbox_to_anchor=(0.0, 0.62)); axs[0].set_ylim(0, 0.65)
    for ax, dom, title in ((axs[1], "bh", "(b) behavioral test"), (axs[2], "sp", "(c) ngspice test")):
        for arm in ("R1", "R1r", "PR", "PRr", "PRrM"):
            r = att[(att.domain == dom) & (att.arm == arm)].iloc[0]
            ax.plot(PH, [r[c] for c in PCOLS], marker="o", ms=3, color=ARM_C[arm], label=arm)
        ax.set_xlabel("edge phase ψ (× T)"); ax.set_title(title + "\nlayer macro-F1, E = ±2%", fontsize=8); ax.set_ylim(0.54, 0.70)
    axs[1].set_ylabel("layer macro-F1"); axs[1].legend(frameon=False, fontsize=6.3, ncol=1, loc="lower left")
    inv = dev["inv"]
    for n, v in inv["revision1"].items():
        if n in ("rise_2", "rise_5", "rise_10"):
            axs[3].plot(PH, v, "--", color=OI["red"], alpha={"rise_2": 1, "rise_5": 0.7, "rise_10": 0.45}[n], label=f"R1 {n}")
    for n, v in inv["phase_robust"].items():
        axs[3].plot(PH, v, "-", color=OI["blue"], alpha=0.35 + 0.13 * list(inv["phase_robust"]).index(n), label=f"PR {n}")
    axs[3].set_xlabel("edge phase ψ (× T)"); axs[3].set_ylabel("|Δ descriptor| / σ"); axs[3].set_title("(d) descriptor shift\n(development seed)", fontsize=8)
    axs[3].legend(frameon=False, fontsize=5.3, loc="upper left")
    fig.tight_layout(); save(fig, out, "fig04_phase_effect")


# ---------------------------------------------------------------------------------------------- Fig. 5
def fig_separation(out: Path, data: Path, dev: dict):
    from .summarize_reference_monitor import Store, pooled_cm
    sig = dev["sig"]
    cols = ["g_adc", "o_adc", "G_afe", "o_afe", "tau_norm", "area_norm", "sens_mean", "sens_hf", "top_frac_s", "ymax_s"]
    h = sig[sig.fault == "healthy"][cols]
    mu, sd = h.mean(), h.std() + 1e-9
    # mean absolute deviation from the healthy mean, in units of the healthy spread (signed faults would cancel in a signed mean)
    M = np.array([((sig[sig.fault == f][cols] - mu).abs() / sd).mean().values for f in FAULTS])
    pd.DataFrame(M, index=FAULTS, columns=cols).round(3).to_csv(data / "fig05_fault_signatures_standardised_dev_seed.csv")
    st = Store(sorted(PR.glob("seed_*")))
    from .run_phase_robust import PCODE
    cms = {}
    for dom, amps in (("bh", (80, 90, 100, 110, 120)), ("sp", (80, 100, 120))):
        scns = [f"{dom}_a{a}_{PCODE[p]}_mon2" for a in amps for p in PH]
        cms[dom] = pooled_cm(st, scns, "two_point_mlp@PRr_e2", "layer")
    (data / "fig05_layer_confusion_PRr_E2.json").write_text(json.dumps({k: np.round(v, 2).tolist() for k, v in cms.items()}))
    sep = pd.read_csv(PR / "afe_adc_separation.csv")
    fig = plt.figure(figsize=(7.4, 2.7))
    gs = fig.add_gridspec(1, 4, width_ratios=[1.5, 0.85, 0.85, 1.1])
    ax = fig.add_subplot(gs[0])
    im = ax.imshow(np.log10(np.clip(M, 0.1, 100)), cmap="magma_r", vmin=-0.3, vmax=2, aspect="auto")
    ax.set_xticks(range(len(cols))); ax.set_xticklabels(cols, rotation=60, ha="right", fontsize=6); ax.set_yticks(range(len(FAULTS))); ax.set_yticklabels(FAULTS, fontsize=6)
    ax.set_title("(a) fault signatures: mean |Δ| / healthy σ\n(log10 scale; development seed)", fontsize=7.5)
    cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02); cb.set_ticks([0, 1, 2]); cb.set_ticklabels(["1", "10", "100"])
    for i, dom in enumerate(("bh", "sp")):
        a2 = fig.add_subplot(gs[1 + i])
        cm = cms[dom]; cmn = cm / cm.sum(1, keepdims=True)
        a2.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
        for r in range(4):
            for c in range(4):
                a2.text(c, r, f"{cmn[r, c]:.2f}", ha="center", va="center", fontsize=6, color="white" if cmn[r, c] > 0.5 else "black")
        a2.set_xticks(range(4)); a2.set_xticklabels(LAYERS, rotation=45, fontsize=6); a2.set_yticks(range(4)); a2.set_yticklabels(LAYERS if i == 0 else [], fontsize=6)
        a2.set_title(f"({'b' if i == 0 else 'c'}) {'behavioral' if dom == 'bh' else 'ngspice'}\nPRr, E = ±2%", fontsize=8); a2.set_xlabel("predicted", fontsize=7)
    a3 = fig.add_subplot(gs[3])
    w = 0.13
    arms = ["A0", "R1", "R1r", "PR", "PRr", "PRrM"]
    for k, arm in enumerate(arms):
        v = [sep[(sep.domain == "bh") & (sep.arm == arm) & (sep.amplitude == a)].cross_confusion.iloc[0] for a in (0.8, 1.0, 1.2)]
        a3.bar(np.arange(3) + (k - 2.5) * w, v, w, color=ARM_C[arm], label=arm)
    a3.axhline(0.15, color=OI["red"], ls="--", lw=0.8); a3.set_xticks(range(3)); a3.set_xticklabels(["×0.8", "×1.0", "×1.2"])
    a3.set_ylabel("AFE↔ADC cross-confusion"); a3.set_title("(d) behavioral, E = ±2%", fontsize=8); a3.legend(frameon=False, fontsize=5.5, ncol=1, loc="upper center", bbox_to_anchor=(0.5, 1.0))
    fig.tight_layout(); save(fig, out, "fig05_afe_adc_separation")


# ---------------------------------------------------------------------------------------------- Fig. 6
def fig_domain(out: Path, data: Path, dev: dict):
    dec = json.loads((PR / "decision_rules.json").read_text())
    rmd = json.loads((RM / "decision_rules.json").read_text())
    att = pd.read_csv(PR / "attribution_arms.csv")
    fig, axs = plt.subplots(1, 4, figsize=(7.4, 2.5), gridspec_kw={"width_ratios": [1.3, 0.8, 1.0, 1.0]})
    w = dev["wave"]
    t = np.array(w["t_ms"]); b = np.array(w["behavioral_V"]); s = np.array(w["ngspice_V"])
    axs[0].plot(t, b, color=OI["blue"], lw=0.8, label="behavioral"); axs[0].plot(t, s, color=OI["red"], lw=0.8, ls="--", label="ngspice")
    axs[0].set_xlim(120, 280); axs[0].set_xlabel("time (ms)"); axs[0].set_ylabel("ADC output (V)"); axs[0].legend(frameon=False, fontsize=6.5, loc="upper left")
    ax2 = axs[0].inset_axes([0.55, 0.12, 0.42, 0.3]); ax2.plot(t, (s - b) * 1000, color="k", lw=0.5); ax2.set_xlim(120, 280); ax2.set_title("ngspice − behavioral (mV)", fontsize=5.5); ax2.tick_params(labelsize=5)
    axs[0].set_title(f"(a) one record, ψ = 0.5 (dev. seed;\nngspice incl. extra noise)", fontsize=8)
    ag = dev["agree"]
    axs[1].bar(range(len(PH)), [ag[str(p)]["mean_rmse_mV"] for p in PH], color=OI["sky"]); axs[1].set_xticks(range(len(PH))); axs[1].set_xticklabels([f"{p:g}" for p in PH], fontsize=6, rotation=45)
    axs[1].set_xlabel("ψ"); axs[1].set_ylabel("RMSE (mV)"); axs[1].set_title("(b) noise-free agreement\n(dev. seed)", fontsize=8)
    lab = ["known", "mon0", "mon1", "mon2", "mon5"]
    prev = [rmd["E"]["all_variants"][x] for x in lab]; cur = [dec["E"]["all"][x] for x in lab]
    xx = np.arange(len(lab))
    axs[2].bar(xx - 0.2, [p["drop_BB_minus_BS"] for p in prev], 0.4, yerr=np.array([[p["drop_BB_minus_BS"] - p["drop_ci"][0], p["drop_ci"][1] - p["drop_BB_minus_BS"]] for p in prev]).T,
               color=OI["red"], capsize=2, label="Revision 1, previous edge placement")
    axs[2].bar(xx + 0.2, [c["drop"] for c in cur], 0.4, yerr=np.array([[c["drop"] - c["drop_ci"][0], c["drop_ci"][1] - c["drop"]] for c in cur]).T, color=OI["blue"], capsize=2, label="phase-robust PRr")
    axs[2].axhline(0.10, color="k", ls="--", lw=0.7); axs[2].set_xticks(xx); axs[2].set_xticklabels(["known", "0%", "±1%", "±2%", "±5%"], fontsize=6.3, rotation=45)
    axs[2].set_ylabel("transfer loss (layer macro-F1)"); axs[2].set_title("(c) transfer loss [95% CI]", fontsize=8); axs[2].legend(frameon=False, fontsize=5.6, loc="upper center", bbox_to_anchor=(0.5, -0.3), ncol=1)
    for arm, ls in (("PRr", "-"), ("PRrM", "--"), ("R1", ":")):
        for dom, c in (("bh", OI["blue"]), ("sp", OI["red"])):
            r = att[(att.domain == dom) & (att.arm == arm)].iloc[0]
            axs[3].plot(PH, [r[cc] for cc in PCOLS], ls=ls, color=c, marker="o", ms=2.5, label=f"{arm}, {'behav.' if dom == 'bh' else 'ngspice'}")
    axs[3].set_xlabel("ψ (× T)"); axs[3].set_ylabel("layer macro-F1"); axs[3].set_title("(d) per phase, E = ±2%", fontsize=8); axs[3].legend(frameon=False, fontsize=5.3, ncol=2, loc="upper center", bbox_to_anchor=(0.5, -0.3))
    fig.tight_layout(); save(fig, out, "fig06_behavioral_vs_ngspice")


# ---------------------------------------------------------------------------------------------- Fig. 7
def fig_robustness(out: Path):
    amp = pd.read_csv(PR / "amplitude_curves.csv")
    ctl = json.loads((PR / "no_monitor_control.json").read_text())["no_monitor_control_layer_macro_f1"]
    dec = json.loads((PR / "decision_rules.json").read_text())
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.6), gridspec_kw={"width_ratios": [1, 1, 0.9]})
    sty = [("A0 old", OI["grey"], "s", "-"), ("R1 known", OI["red"], "^", ":"), ("PRr known", OI["black"], "o", "-"), ("PRr E=0%", OI["sky"], "o", "-"),
           ("PRr E=1%", OI["green"], "o", "-"), ("PRr E=2%", OI["blue"], "o", "-"), ("PRr E=5%", OI["purple"], "o", "-")]
    for ax, dom, title in ((axs[0], "bh", "(a) behavioral"), (axs[1], "sp", "(b) ngspice")):
        for name, c, m, ls in sty:
            d = amp[(amp.domain == dom) & (amp.series == name) & (amp.target == "layer")]
            if not len(d):
                continue
            d = d.iloc[0]
            xs = [x for x in (0.8, 0.9, 1.0, 1.1, 1.2) if not pd.isna(d.get(f"x{x:.1f}", np.nan))]
            ax.plot(xs, [d[f"x{x:.1f}"] for x in xs], color=c, marker=m, ms=3, ls=ls, label=name, lw=1)
        if dom == "bh":
            xs = [0.8, 0.9, 1.0, 1.1, 1.2]
            ax.plot(xs, [ctl[f"x{x:.1f}"]["unmonitored"] for x in xs], color=OI["red"], marker="x", ls="--", lw=1, label="PRr, no monitor")
        ax.axhline(0.85 * dec["N"][dom], color="k", lw=0.6, ls=":")
        ax.set_xlabel("actual reference amplitude (× nominal)"); ax.set_title(title + " (dotted: 0.85·N)", fontsize=8); ax.set_ylim(0.0, 0.75)
    axs[0].set_ylabel("layer macro-F1 (pooled over ψ)"); axs[0].legend(frameon=False, fontsize=5.8, loc="lower center", ncol=2)
    C = dec["C"]["detail"]
    lab = ["known", "mon0", "mon1", "mon2", "mon5"]
    for j, (dom, a, c) in enumerate((("bh", 80, OI["sky"]), ("bh", 120, OI["blue"]), ("sp", 80, OI["orange"]), ("sp", 120, OI["red"]))):
        axs[2].bar(np.arange(5) + (j - 1.5) * 0.2, [C[f"{dom}|{x}|a{a}"]["cross_confusion"] for x in lab], 0.2, color=c, label=f"{'behav.' if dom == 'bh' else 'ngspice'} ×{a / 100:.1f}")
    axs[2].axhline(0.15, color=OI["red"], ls="--", lw=0.8); axs[2].set_xticks(range(5)); axs[2].set_xticklabels(["known", "0%", "±1%", "±2%", "±5%"], fontsize=6.5)
    axs[2].set_ylabel("AFE↔ADC cross-confusion"); axs[2].set_ylim(0, 0.18); axs[2].set_title("(c) separation at ±20% (dashed: limit 0.15)", fontsize=8); axs[2].legend(frameon=False, fontsize=5.6, ncol=2)
    fig.tight_layout(); save(fig, out, "fig07_robustness")


# ---------------------------------------------------------------------------------------------- Fig. 8
def fig_ablation(out: Path):
    attc = pd.read_csv(PR / "attribution_comparisons.csv")
    v2 = json.loads((ROOT / "reference_v2_results/decision_rules.json").read_text())
    ms = json.loads((ROOT / "multiseed_results/decision_rules.json").read_text())
    rows = []
    for _, r in attc.iterrows():
        rows.append((f"{r.comparison} [{'behav.' if r.domain == 'bh' else 'ngspice'}]", r["diff"], r.ci_low, r.ci_high, OI["blue"] if r.domain == "bh" else OI["red"]))
    for k, lbl in (("ref_m20|two_point_mlp@A2-two_point_mlp@A1j", "Revision-2 conditioning (A2 − A1j), ref ×0.8"), ("ref_p20|two_point_mlp@A2-two_point_mlp@A1j", "Revision-2 conditioning (A2 − A1j), ref ×1.2")):
        d = v2["D5"][k]; rows.append((lbl, d["diff"], d["ci"][0], d["ci"][1], OI["purple"]))
    for k, lbl in (("nominal|layer", "TCN − MLP, nominal (multi-seed stage)"), ("tolerance|layer", "TCN − MLP, tolerance (multi-seed stage)")):
        d = ms["R2"][k]; rows.append((lbl, d["diff"], d["ci"][0], d["ci"][1], OI["grey"]))
    rows = [r for r in rows if "vs old method" not in r[0]]
    fig, ax = plt.subplots(figsize=(7.2, 4.2))
    for i, (lbl, d, lo, hi, c) in enumerate(rows[::-1]):
        ax.errorbar(d, i, xerr=[[d - lo], [hi - d]], fmt="o", color=c, ms=3.5, capsize=2, lw=1)
    ax.axvline(0, color="k", lw=0.7)
    ax.set_yticks(range(len(rows))); ax.set_yticklabels([r[0] for r in rows[::-1]], fontsize=6.5)
    ax.set_xlabel("difference in layer macro-F1 [95% paired-bootstrap CI]")
    ax.set_title("Ablation: which ingredient matters (blue: behavioral, red: ngspice; purple/grey: earlier frozen stages)", fontsize=8)
    fig.tight_layout(); save(fig, out, "fig08_ablation")


# ---------------------------------------------------------------------------------------------- Fig. 9
def fig_recall(out: Path):
    pcf = pd.read_csv(PR / "per_class_recall_fault.csv")
    fig, axs = plt.subplots(1, 2, figsize=(7.4, 2.6), sharey=False)
    for ax, dom, title in ((axs[0], "bh", "(a) behavioral"), (axs[1], "sp", "(b) ngspice")):
        d = pcf[pcf.domain == dom].set_index("arm")[list(FAULTS)]
        im = ax.imshow(d.values, cmap="viridis", vmin=0, vmax=1, aspect="auto")
        for r in range(d.shape[0]):
            for c in range(d.shape[1]):
                ax.text(c, r, f"{d.values[r, c]:.2f}", ha="center", va="center", fontsize=5.6, color="white" if d.values[r, c] < 0.6 else "black")
        ax.set_xticks(range(len(FAULTS))); ax.set_xticklabels(FAULTS, rotation=50, ha="right", fontsize=6); ax.set_yticks(range(d.shape[0])); ax.set_yticklabels(d.index, fontsize=6.5)
        ax.set_title(title + ", fine-fault recall, E = ±2%", fontsize=8)
    fig.colorbar(im, ax=axs, fraction=0.025, pad=0.02)
    save(fig, out, "fig09_per_class_recall")


def fallback_check(data: Path):
    """Count activations of the documented fit fallback on development-seed records (300 conditions x 9 faults x 3 phases x 2 amplitudes)."""
    rng = np.random.default_rng(DEV_SEED)
    n = fb = 0
    mx = 0.0
    for cid in range(300):
        cond = make_condition(rng)
        for name in FAULTS:
            f = make_fault(name, rng); sd = int(rng.integers(0, 2**31 - 1))
            for ph in (0.0, 0.5, 0.999):
                for amp in (0.8, 1.2):
                    t = transient_features(simulate_sample(cond, f, active=True, seed=sd + 4, probe_mode="two_point", ref_scale=amp, ref_phase=ph))
                    n += 1; fb += bool(t[1] == 0.0 and t[2] == 0.0 and t[4] == 1.0); mx = max(mx, float(np.abs(t).max()))
    (data / "fallback_check_dev_seed.json").write_text(json.dumps({"seed": DEV_SEED, "n_records": n, "fallback_activations": fb, "max_abs_descriptor": mx}, indent=1))


def build_all(out: Path, data: Path) -> dict:
    out.mkdir(parents=True, exist_ok=True); data.mkdir(parents=True, exist_ok=True)
    fig_architecture(out)
    fig_timing(out, data)
    fig_pipeline(out)
    dev = dev_verification(data)
    fig_phase(out, data, dev)
    fig_separation(out, data, dev)
    fig_domain(out, data, dev)
    fig_robustness(out)
    fig_ablation(out)
    fig_recall(out)
    fallback_check(data)
    return dev
