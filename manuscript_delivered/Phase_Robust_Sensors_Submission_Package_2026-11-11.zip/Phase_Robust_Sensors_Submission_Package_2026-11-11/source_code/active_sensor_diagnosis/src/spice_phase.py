"""Phase-aware ngspice sample generator (reference/control edges at a chosen fraction of one sampling period).

Same circuit, tolerances, noise and ADC model as ``src.spice_domain`` (which stays untouched).  The only change: every
reference-level step and switch-control step occurs ``phase`` * T after the previous ADC sample instant,

    t_edge = t_{i-1} + phase*T + 1 us ,   0 <= phase < 1,

so the first new-level sample i has been exposed to the new level for (1 - phase)*T.  phase = 0 is the zero-order-hold convention of
the behavioral model; phase = 0.999 reproduces the edge placement (1 us before the sample) that was used in the failed
reference-monitor stage.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from .simulate import _adc_reference, _afe_reference, _base_signal
from .spice_domain import AMP_NOISE_V, EDGE, FS, N, REF_NOISE_V, solve


def _pwl_phase(levels: np.ndarray, noise: np.ndarray | None, zero_outside: bool, phase: float) -> str:
    pts = []
    for i in range(len(levels)):
        t = i / FS
        v = float(levels[i]) + (0.0 if noise is None or (zero_outside and levels[i] == 0.0) else float(noise[i]))
        if i > 0 and levels[i] != levels[i - 1]:
            t_hold = t - 1.0 / FS + phase / FS  # keep the OLD level until the edge, then step within EDGE
            if t_hold > pts[-1][0] + 1e-12:
                pts.append((t_hold, pts[-1][1]))
            pts.append((t_hold + EDGE, v))
        if not pts or t > pts[-1][0] + 1e-12:
            pts.append((t, v))
    toks = " ".join(f"{t:.9g} {v:.6g}" for t, v in pts).split(" ")
    return "PWL(" + "\n+ ".join(" ".join(toks[k:k + 10]) for k in range(0, len(toks), 10)) + ")"


def render_phase(sensor, afe_gain, afe_offset, tau, adc_gain, adc_offset, clip_high, afe_ref, adc_ref, nz_afe, nz_adc, phase) -> str:
    afe_ctrl = np.where(afe_ref > 0, 5.0, 0.0)
    adc_ctrl = np.where(adc_ref > 0, 5.0, 0.0)
    sens = _pwl_phase(sensor, None, False, 0.0)
    return f"""* two-point sensor interface (per-sample, edge phase {phase})
.title s
V_SENSOR sensor 0 {sens}
V_AFE_REF afe_ref 0 {_pwl_phase(afe_ref, nz_afe, True, phase)}
V_AFE_CTRL afe_ctrl 0 {_pwl_phase(afe_ctrl, None, False, phase)}
B_AFE_CTRL_N afe_ctrl_n 0 V={{5-V(afe_ctrl)}}
S_SENSOR afe_src sensor afe_ctrl_n 0 SW_DIAG
S_AFE_REF afe_src afe_ref afe_ctrl 0 SW_DIAG
R_AFE afe_src afe_lpf 1k
C_AFE afe_lpf 0 {tau / 1000.0:.9g}
B_AFE_OUT afe_out 0 V={{{afe_gain:.9g}*V(afe_lpf)+({afe_offset:.9g})}}
V_ADC_REF adc_ref 0 {_pwl_phase(adc_ref, nz_adc, True, phase)}
V_ADC_CTRL adc_ctrl 0 {_pwl_phase(adc_ctrl, None, False, phase)}
B_ADC_CTRL_N adc_ctrl_n 0 V={{5-V(adc_ctrl)}}
S_AFE_MAIN adc_src afe_out adc_ctrl_n 0 SW_DIAG
S_ADC_REF adc_src adc_ref adc_ctrl 0 SW_DIAG
B_ADC_OUT adc_out 0 V={{min(max({adc_gain:.9g}*V(adc_src)+({adc_offset:.9g}),0),{clip_high:.9g})}}
R_ADC_LOAD adc_out 0 1Meg
.model SW_DIAG SW(Ron=0.5 Roff=1Meg Vt=2.5 Vh=0.1)
.tran 0.1m 512m
.save v(adc_out)
.end
"""


def spice_record_phase(condition, fault, seed: int, workdir: Path, *, amp: float = 1.0, tol: dict | None = None,
                       phase: float = 0.0, extra_noise: bool = True) -> dict:
    tol = tol or {}
    rng = np.random.default_rng(seed)
    physical = _base_signal(condition, N, FS, rng)
    sbs = tol.get("sensor_base_scale", 1.0)
    if sbs != 1.0:
        physical = physical + (sbs - 1.0) * condition.base
    sensor = physical.copy()
    if fault.name == "sensor_bias":
        sensor += fault.signed * fault.severity
    elif fault.name == "sensor_gain":
        sensor *= 1.0 + fault.signed * fault.severity
    elif fault.name == "sensor_noise":
        sensor += rng.normal(0.0, fault.severity, size=N)
    afe_gain = condition.nominal_gain * tol.get("afe_gain_scale", 1.0)
    tau = condition.nominal_tau_s * tol.get("afe_tau_scale", 1.0)
    afe_offset = 0.0
    if fault.name == "afe_offset":
        afe_offset = fault.signed * fault.severity
    elif fault.name == "afe_bandwidth":
        tau *= fault.severity
    adc_gain = tol.get("adc_gain_scale", 1.0)
    adc_offset = tol.get("adc_offset_extra", 0.0)
    clip_high = condition.adc_vref
    if fault.name == "adc_offset":
        adc_offset += fault.signed * fault.severity
    elif fault.name == "adc_gain":
        adc_gain *= 1.0 + fault.signed * fault.severity
    elif fault.name == "adc_clipping":
        clip_high = condition.adc_vref * fault.severity
    afe_ref, a0, a1 = _afe_reference(N, FS)
    adc_ref, d0, d1 = _adc_reference(N, FS)
    afe_ref, adc_ref = afe_ref * amp, adc_ref * amp
    rng_x = np.random.default_rng(seed + 777)
    if extra_noise:
        sensor_in = sensor + rng_x.normal(0.0, AMP_NOISE_V, N)
        nz_afe, nz_adc = rng_x.normal(0.0, REF_NOISE_V, N), rng_x.normal(0.0, REF_NOISE_V, N)
    else:
        sensor_in, nz_afe, nz_adc = sensor, None, None
    v = solve(render_phase(sensor_in, afe_gain, afe_offset, tau, adc_gain, adc_offset, clip_high, afe_ref, adc_ref, nz_afe, nz_adc, phase), workdir)
    analog = np.clip(v + rng.normal(0.0, 0.0025, size=N), 0.0, clip_high)
    measured = np.round(analog / condition.adc_vref * 4095.0) / 4095.0 * condition.adc_vref
    return {"waveform": measured.astype(np.float32), "afe_reference": afe_ref.astype(np.float32), "adc_reference": adc_ref.astype(np.float32),
            "afe_ref_start": a0, "afe_ref_end": a1, "adc_ref_start": d0, "adc_ref_end": d1, "probe": np.zeros(N, dtype=np.float32),
            "fault": fault.name, "severity": float(fault.severity)}
