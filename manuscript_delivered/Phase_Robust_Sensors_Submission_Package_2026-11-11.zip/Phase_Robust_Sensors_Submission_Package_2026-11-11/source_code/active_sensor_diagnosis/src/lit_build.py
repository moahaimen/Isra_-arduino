"""Build VERIFIED_REFERENCES.csv, LITERATURE_GAP_MATRIX.md and references.json (MDPI-formatted) from the verified metadata.

Bibliographic fields are copied from Crossref / DataCite / the JMLR article page (see verified_raw.json, verified_extra*.json).
The comparison attributes in CLASS are the authors' assessment from each work's title and abstract (stated per row); they are
not bibliographic data.
"""
from __future__ import annotations

import html
import json
import re
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
LIT = ROOT / "paper_package" / "literature"
ACCESS_DATE = "14 October 2026"

KEYS = {
    "mems_review": "10.3390/mi12010040", "mems_bist_elec": "10.1109/jsen.2016.2636861", "readout_bist07": "10.1109/jsen.2007.897957", "sd_bist18": "10.3390/mi9090444",
    "gyro_quad21": "10.3390/mi12091115", "charge_bist13": "10.1109/tcad.2012.2218602", "gyro_wafer18": "10.1109/tcsi.2017.2767199", "hotplate11": "10.6028/jres.116.025",
    "selfx22": "10.3390/chips1020008", "selfcal97": "10.1109/19.650794", "analog_adc13": "10.1109/tim.2013.2272867", "combined08": "10.1093/ietisy/e91-d.8.2134",
    "adcbist07": "10.1109/tim.2007.908343", "adcbist05": "10.1007/s10836-005-6357-5", "imprecise03": "10.1145/944027.944035", "adcbist19": "10.1109/mim.2019.8917897",
    "hier01": "10.1109/81.940182", "testcore02": "10.1109/4.991388", "gainoff24": "10.1155/jece/8824886", "sarcal15": "10.1109/tvlsi.2014.2321761",
    "svs12": "10.1109/tim.2012.2205509", "svs02": "10.1049/cce:20020508", "svs25": "10.1016/j.measurement.2024.116025", "vref01": "10.1109/jsen.2001.954835",
    "vrefadc21": "10.1109/tim.2020.3031208", "varpro03": "10.1088/0266-5611/19/2/201", "ets23": "10.1016/j.measurement.2023.113392", "nn00": "10.1109/82.823545",
    "nn02": "10.1109/tim.2002.1017726", "nn10": "10.1109/tim.2009.2025068", "cnn20": "10.1109/access.2020.2968744", "dbn17": "10.1109/tii.2017.2690940",
    "resnet21": "10.1109/tcsi.2021.3076282", "mstcnn25": "10.1016/j.vlsi.2025.102631", "mpcnn25": "10.1109/tim.2025.3588964", "bitcn25": "10.1007/s10836-025-06190-6",
    "evo09": "10.1016/j.microrel.2008.12.002", "dlrev23": "10.3390/s23031305", "fieldwelsh07": "10.1111/j.1467-9868.2007.00593.x", "davison97": "10.1017/cbo9780511802843",
    "adam14": "10.48550/arxiv.1412.6980", "sklearn11": "JMLR:v12/pedregosa11a", "ngspice": "URL:https://ngspice.sourceforge.io/",
}
EXCLUDED = {"10.1109/imtc.2003.1207897": "Crossref record has no publication date; year not verifiable from the registry, so the work is not cited."}

# attribute order: structure, active stimulus, AFE/ADC separation, reference drift, sampling phase, neural network, validation, basis
CLASS = {
    "mems_review": ("MEMS sensors (review)", "surveyed (electrical/physical)", "no", "n/r", "n/r", "no", "review", "abstract"),
    "mems_bist_elec": ("capacitive MEMS accelerometer + readout AFE", "yes, electrical excitation", "no (sensor sensitivity)", "no", "no", "no (linear regression)", "fabricated IC (hardware)", "abstract"),
    "readout_bist07": ("capacitive-sensor readout IC", "yes, electrostatic self-test", "no", "partial (on-line calibration)", "no", "no", "fabricated IC (hardware)", "abstract"),
    "sd_bist18": ("ΣΔ closed-loop MEMS accelerometer interface", "yes, digital electrostatic excitation", "no (loop distortion)", "no", "n/r", "no", "on-chip design (abstract)", "abstract"),
    "gyro_quad21": ("MEMS gyroscope", "no (monitors quadrature signal)", "no", "n/r", "no", "no", "gyroscope experiments", "abstract"),
    "charge_bist13": ("capacitive MEMS readout + BIST", "yes, charge-controlled stimulus", "no", "no", "no", "no", "65-nm prototype (hardware)", "abstract"),
    "gyro_wafer18": ("MEMS gyroscope ΔΣ readout", "yes, electrical feedback path", "partial (sensor element vs ASIC)", "no", "no", "no", "simulation + measurement", "abstract"),
    "hotplate11": ("microhotplate temperature sensor", "yes, thermal", "no", "partial (sensor recalibration over time)", "no", "no", "hardware", "abstract"),
    "selfx22": ("integrated sensor AFEs with self-X functions (perspective)", "n/r", "n/r", "n/r", "n/r", "discussed", "perspective/review", "abstract"),
    "selfcal97": ("smart capacitive angular-position sensor", "no external reference", "no", "no", "no", "no", "hardware", "abstract"),
    "analog_adc13": ("analog part terminated by ADC (µC system)", "yes, square impulse", "no (faults within the analog part)", "n/r", "no (sampled time response)", "no", "experimental (hardware)", "abstract"),
    "combined08": ("analog portion + ADC (mixed-signal IC)", "yes, oscillation-based reconfiguration", "partial (both tested)", "no", "no", "no", "fault-coverage experiments", "abstract"),
    "adcbist07": ("high-speed ADC", "yes, on-chip generated signals", "ADC only", "no", "no", "no", "simulation + DAC measurement", "abstract"),
    "adcbist05": ("ADC", "n/r", "ADC only", "n/r", "n/r", "n/r", "n/r", "title only (no abstract available)"),
    "imprecise03": ("ADC", "yes, imprecise ramp stimuli", "ADC only", "partial (stimulus imprecision)", "no", "no", "simulation + production tester", "abstract"),
    "adcbist19": ("high-speed ADC (tutorial)", "yes", "ADC only", "n/r", "n/r", "no", "tutorial", "abstract"),
    "hier01": ("analog ICs", "n/r", "no", "no", "no", "no", "n/r", "abstract"),
    "testcore02": ("mixed-signal test core", "yes, arbitrary waveforms", "no", "no", "controlled clock delay (equivalent-time)", "no", "prototypes (hardware)", "abstract"),
    "gainoff24": ("SAR ADC", "yes, sinusoidal test", "ADC gain/offset only", "partial (gain error)", "no", "no", "n/r", "abstract"),
    "sarcal15": ("SAR ADC", "self-calibration", "ADC only", "no", "no", "no", "n/r", "abstract"),
    "svs12": ("multifunctional self-validating sensor", "no (data-driven)", "no (sensor channels)", "n/r", "no", "no (RVM + PCA)", "n/r", "abstract"),
    "svs02": ("self-validating sensors and actuators", "n/r", "n/r", "n/r", "n/r", "n/r", "n/r", "title only (no abstract available)"),
    "svs25": ("self-validating sensors (review)", "n/r", "n/r", "n/r", "n/r", "n/r", "review", "title only (no abstract available)"),
    "vref01": ("CMOS temperature sensors and voltage references", "no", "no", "background (reference accuracy)", "no", "no", "review", "abstract"),
    "vrefadc21": ("ADC static BIST", "yes, ramp (SEIR)", "ADC only", "yes (non-stationary reference estimated)", "no", "no", "simulation", "abstract"),
    "ets23": ("microcontroller ADC + PWM generator", "yes, PWM test signal", "no", "no", "controlled phase shift (equivalent-time sampling)", "no", "hardware (MCUs)", "abstract"),
    "nn00": ("analog circuits", "yes, impulse", "no", "no", "no", "yes (MLP)", "n/r", "abstract"),
    "nn02": ("analog circuits (actual boards)", "yes, impulse", "no", "no", "no", "yes (MLP)", "hardware + SPICE comparison", "abstract"),
    "nn10": ("analog circuits", "n/r", "no", "no", "no", "yes (MLP)", "data-acquisition board (hardware)", "abstract"),
    "cnn20": ("analog circuits", "n/r", "no", "no", "no", "yes (1-D CNN)", "SIMULINK simulation", "abstract"),
    "dbn17": ("electronics-rich analog systems (filters)", "n/r", "no", "no", "no", "yes (DBN)", "experimental (two filter circuits)", "abstract"),
    "resnet21": ("analog filter circuits", "n/r", "no", "no", "no", "yes (ResNet)", "simulation", "abstract"),
    "mstcnn25": ("analog and digital VLSI circuits", "n/r", "n/r", "n/r", "n/r", "yes (temporal CNN)", "n/r", "title only (no abstract available)"),
    "mpcnn25": ("analog circuits", "yes, optimised test stimuli", "no", "no", "no", "yes (CNN)", "benchmark circuits", "abstract"),
    "bitcn25": ("analog circuits", "n/r", "n/r", "n/r", "n/r", "yes (BiTCN + BiLSTM)", "n/r", "title only (no abstract available)"),
    "evo09": ("analog and mixed-signal circuits", "yes, optimised test sets", "n/r", "n/r", "n/r", "yes", "n/r", "title only (no abstract available)"),
    "dlrev23": ("industrial systems (review)", "n/r", "no", "no", "no", "yes (review)", "review", "abstract"),
}
THIS_WORK = ("sensor → AFE → ADC chain with two-point reference mux", "yes, two known two-level references", "yes (two injection points)",
             "yes (monitored levels, E ≤ ±5%)", "yes (phase-robust descriptors, ψ ∈ [0,1))", "yes (MLP)", "behavioral + per-sample ngspice (no hardware)", "this study")


ISO4 = {  # ISO 4 journal abbreviations (formatting convention, not bibliographic data)
    "IEEE Sensors Journal": "IEEE Sens. J.", "IEEE Transactions on Circuits and Systems I: Regular Papers": "IEEE Trans. Circuits Syst. I Regul. Pap.",
    "IEICE Transactions on Information and Systems": "IEICE Trans. Inf. Syst.", "Journal of Electronic Testing": "J. Electron. Test.",
    "IEEE Transactions on Circuits and Systems I: Fundamental Theory and Applications": "IEEE Trans. Circuits Syst. I Fundam. Theory Appl.",
    "Journal of Electrical and Computer Engineering": "J. Electr. Comput. Eng.", "IEEE Transactions on Very Large Scale Integration (VLSI) Systems": "IEEE Trans. Very Large Scale Integr. (VLSI) Syst.",
    "Computing & Control Engineering Journal": "Comput. Control Eng. J.", "Inverse Problems": "Inverse Probl.",
    "IEEE Transactions on Circuits and Systems II: Analog and Digital Signal Processing": "IEEE Trans. Circuits Syst. II Analog Digit. Signal Process.",
    "IEEE Transactions on Industrial Informatics": "IEEE Trans. Ind. Inform.", "Microelectronics Reliability": "Microelectron. Reliab.",
    "Journal of the Royal Statistical Society Series B: Statistical Methodology": "J. R. Stat. Soc. Ser. B Stat. Methodol.",
}


def initials(given: str) -> str:
    if not given:
        return ""
    parts = re.split(r"\s+", given.strip())
    out = []
    for p in parts:
        if "-" in p:
            out.append("-".join(q[0] + "." for q in p.split("-") if q))
        elif p.endswith(".") and len(p) <= 3:
            out.append(p if p.endswith(".") else p + ".")
        else:
            out.append(p[0] + ".")
    return "".join(out)


def fmt_authors(auth) -> str:
    names = []
    for a in auth:
        fam = a.get("family") or ""
        if fam.isupper() and len(fam) > 1:
            fam = fam.title()
        if fam:
            names.append(f"{fam}, {initials(a.get('given') or '')}".strip().rstrip(","))
        elif a.get("name"):
            names.append(a["name"])
    return "; ".join(names)


def pages(r) -> str:
    p = r.get("page") or ""
    if p:
        return p.replace("-", "–")
    return str(r.get("article_number") or "")


def clean_title(t: str) -> str:
    t = html.unescape(t)
    t = re.sub(r"\$\\Delta\s*\\Sigma\$", "ΔΣ", t)
    return re.sub(r"\s+", " ", t).strip()


def main():
    raw = {r["doi"]: r for r in json.loads((LIT / "verified_raw.json").read_text())}
    ex = json.loads((LIT / "verified_extra.json").read_text())
    ex2 = json.loads((LIT / "verified_extra2.json").read_text())
    refs, rows = {}, []
    for key, doi in KEYS.items():
        if doi.startswith("JMLR:"):
            au = "; ".join(f"{n.split(' ')[-1]}, {initials(' '.join(n.split(' ')[:-1]))}" for n in ex2["jmlr_authors"])
            s = f"{au} Scikit-learn: Machine Learning in Python. J. Mach. Learn. Res. 2011, 12, 2825–2830."
            rows.append(dict(key=key, doi="", url="https://jmlr.org/papers/v12/pedregosa11a.html", title="Scikit-learn: Machine Learning in Python", authors=au, year=2011,
                             venue="Journal of Machine Learning Research", volume="12", issue="", pages="2825–2830", type="journal-article", publisher="JMLR",
                             verified_via="JMLR article page (citation_* metadata)", doi_resolves="n/a (no DOI)", title_match_openalex="", mdpi_citation=s))
        elif doi.startswith("URL:"):
            s = f"Ngspice, the Open Source Spice Circuit Simulator. Available online: https://ngspice.sourceforge.io/ (accessed on {ACCESS_DATE})."
            rows.append(dict(key=key, doi="", url="https://ngspice.sourceforge.io/", title="Ngspice, the open source Spice circuit simulator", authors="", year="", venue="website",
                             verified_via="HTTP 200 and page title checked", doi_resolves="n/a", mdpi_citation=s))
        elif doi.startswith("10.48550"):
            e = ex[doi]
            au = "; ".join(f"{a['family']}, {initials(a['given'])}" for a in e["authors"])
            s = f"{au} {e['title']}. arXiv {e['year']}, arXiv:1412.6980. https://doi.org/{doi}."
            rows.append(dict(key=key, doi=doi, title=e["title"], authors=au, year=e["year"], venue="arXiv", type="preprint", publisher="arXiv",
                             verified_via="DataCite API", doi_resolves="302", mdpi_citation=s))
        else:
            r = raw[doi]
            au = fmt_authors(r.get("authors", []))
            title = clean_title(r["title"])
            cont = html.unescape(r.get("container") or "")
            venue = ISO4.get(cont) or html.unescape(r.get("short_container") or "") or cont
            year = r.get("year_issue") or r.get("year")
            r["year"] = year
            if r.get("type") in ("book", "monograph", "edited-book"):
                loc = r.get("publisher_location") or "Cambridge, UK"
                s = f"{au} {title}; {r.get('publisher')}: {loc}, {year}. https://doi.org/{r.get('crossref_doi')}."
            elif r.get("type") == "proceedings-article":
                s = f"{au} {title}. In {r.get('container')}; {r.get('year')}; pp. {pages(r)}. https://doi.org/{r.get('crossref_doi')}."
            else:
                vol = r.get("volume") or ""
                s = f"{au} {title}. {venue} {r.get('year')}, {vol}, {pages(r)}. https://doi.org/{r.get('crossref_doi')}."
            s = re.sub(r"\s+", " ", s).replace(" ,", ",").replace(", ,", ",")
            rows.append(dict(key=key, doi=r.get("crossref_doi"), title=title, authors=au, year=r.get("year"), venue=cont, venue_abbrev=venue,
                             volume=r.get("volume"), issue=r.get("issue"), pages=pages(r), type=r.get("type"), publisher=r.get("publisher"),
                             verified_via="Crossref REST API", doi_resolves=str(r.get("doi_org_status")), title_match_openalex=r.get("title_match_ratio"), mdpi_citation=s,
                             notes=("publisher location (Cambridge, UK) not in Crossref; taken from the publisher name" if r.get("type") in ("book", "monograph") else "")
                             + ("; journal abbreviation applied (ISO 4)" if cont in ISO4 else "")))
        rw = rows[-1]
        kind = "web" if key == "ngspice" else ("preprint" if key == "adam14" else ("book" if rw.get("type") in ("book", "monograph") else "journal"))
        refs[key] = {"text": rw["mdpi_citation"], "kind": kind, "authors": rw.get("authors", ""), "title": rw.get("title", ""),
                     "venue": rw.get("venue_abbrev") or ("J. Mach. Learn. Res." if key == "sklearn11" else rw.get("venue", "")), "year": str(rw.get("year") or ""),
                     "volume": str(rw.get("volume") or "") if key != "sklearn11" else "12", "pages": rw.get("pages") or ("2825–2830" if key == "sklearn11" else ""),
                     "doi": rw.get("doi") or "", "url": rw.get("url", ""), "publisher": rw.get("publisher", "")}
    df = pd.DataFrame(rows)
    for k, v in EXCLUDED.items():
        df = pd.concat([df, pd.DataFrame([{"key": "EXCLUDED", "doi": k, "title": raw[k]["title"], "verified_via": "Crossref REST API", "notes": v}])], ignore_index=True)
    df.to_csv(LIT / "verified_references_all.csv", index=False)
    (LIT / "references.json").write_text(json.dumps(refs, indent=1, ensure_ascii=False))
    # gap matrix
    log = json.loads((LIT / "search_log.json").read_text())
    cols = ["electronic structure", "active stimulus", "AFE/ADC fault separation", "reference-drift handling", "sampling-phase robustness", "neural network", "SPICE / hardware validation", "basis of assessment"]
    mat = [{"work": f"[{k}] " + clean_title(raw[KEYS[k]]["title"])[:80] + f" ({raw[KEYS[k]].get('year')})", **dict(zip(cols, v))} for k, v in CLASS.items()]
    mat.append({"work": "**This work**", **dict(zip(cols, THIS_WORK))})
    md = pd.DataFrame(mat)
    q = pd.DataFrame(log["queries"])
    lines = ["# Literature gap matrix", "",
             f"Search performed {log['date']} (and two precision rounds the same day) through the **OpenAlex** open scholarly index, with bibliographic verification against **Crossref** (and DataCite / the JMLR article page where no Crossref record exists) and DOI resolution checked at doi.org.",
             "OpenAlex indexes the IEEE (Xplore), Elsevier (ScienceDirect), Springer, MDPI, IET and IOP literature by DOI. **Scopus and the IEEE Xplore search interface themselves were not queried** (no institutional access from this environment); a Scopus/IEEE Xplore re-run of the same queries is recommended before submission (see FINAL_SUBMISSION_CHECKLIST.md).", "",
             "## Search protocol", "",
             f"* Themes and queries: {len(q)} queries in 6 themes + methods (table below). Round 1: OpenAlex relevance search (`search=`, publication year > 1999, type article/review, 25 records per query). Rounds 2–3: `title_and_abstract.search` filter sorted by citations (12–15 per query).",
             f"* Records: {log['n_records']} (round 1, {log['n_unique']} unique) + {log.get('n_records_round2', 0)} (round 2) + round 3 (printed in the session log).",
             "* Inclusion: the work addresses (a) self-test / BIST of sensors, sensor interfaces, AFEs or ADCs, (b) fault isolation in sensor measurement chains, (c) reference accuracy or drift in ADC-based measurement, (d) sampling-phase / timing in step-response measurement, or (e) neural-network fault diagnosis of electronic circuits; plus method references actually used (variable projection, bootstrap, scikit-learn, Adam, ngspice).",
             "* Exclusion: off-topic hits of the broad queries (biomedical, power systems, RF/radar, software reliability), works without a resolvable DOI or verifiable year (one excluded, see VERIFIED_REFERENCES.csv), and non-English-language venues without abstracts.",
             "* Screening: titles of all records, then abstracts (OpenAlex, Semantic Scholar) of the shortlisted works. Six works had no retrievable abstract; their rows are marked *title only* and should be checked against the full text.",
             "* Verification: for every cited work the title, authors, year, venue, volume, pages/article number and DOI were taken from the registry record; title agreement with OpenAlex was 1.000 for all Crossref records; every DOI resolved (HTTP 302).", "",
             "| theme | query | hits |", "|---|---|---|"]
    for _, r in q.iterrows():
        lines.append(f"| {r.theme} | `{r.query}` | {r.total_hits} |")
    lines += ["", "## Comparison table", "",
              "Attributes are the authors' reading of each work's title and abstract (column *basis*); \"n/r\" = not reported in the abstract; \"no\" = the abstract describes a method that does not include the feature.", ""]
    lines.append("| " + " | ".join(["work"] + cols) + " |")
    lines.append("|" + "|".join("---" for _ in range(len(cols) + 1)) + "|")
    for _, r in md.iterrows():
        lines.append("| " + " | ".join(str(r[c]) for c in ["work"] + cols) + " |")
    lines += ["", "## Gap assessment", "",
              "* **Active self-test of sensors and readouts** is well established, mainly for MEMS (electrical/electrostatic/charge stimuli) [mems_review, mems_bist_elec, readout_bist07, sd_bist18, charge_bist13, gyro_wafer18]; these works target the sensor element or the readout loop, not a separation of AFE from ADC faults.",
              "* **Analog-plus-ADC self-test** exists [analog_adc13, combined08] but uses one observation path (impulse response of the analog part, or oscillation-based reconfiguration feeding the ADC); we found no work that injects **two known references at two physically separated points** to make AFE and ADC transfer errors separately identifiable.",
              "* **ADC BIST and self-calibration** are mature [adcbist07, adcbist05, imprecise03, adcbist19, gainoff24, sarcal15]. Reference accuracy appears as a design topic [vref01] and as a nuisance in ADC static testing [vrefadc21]; we found no sensor-interface self-test that **monitors the reference amplitude** and propagates the measured levels into fault descriptors.",
              "* **Sampling phase** is exploited deliberately in equivalent-time sampling / delayed-clock test cores [testcore02, ets23]; we found no fault-diagnosis method that makes reference-step descriptors **invariant to the unknown edge-to-sample phase**.",
              "* **Neural-network circuit fault diagnosis** is extensive (MLP, CNN, DBN, ResNet, temporal CNN; increasingly with optimised stimuli) [nn00, nn02, nn10, cnn20, dbn17, resnet21, mstcnn25, mpcnn25, bitcn25, evo09, dlrev23], mostly for component-level faults in benchmark analog filters validated in simulation or on boards; none of the screened works addresses layer-level sensor/AFE/ADC localisation under reference drift and sampling-phase variation.",
              "* **Conclusion:** within the screened literature, no prior work combined all of: two-point reference injection for AFE/ADC separation, monitored reference drift, sampling-phase robustness and a neural-network classifier with circuit-level (SPICE) cross-validation. Because the search used open indexes rather than Scopus/IEEE Xplore directly and six records were assessed by title only, the manuscript **does not claim to be first**; it states that no such combination was found in the screened literature.", "",
              "## Search limitations", "",
              "* OpenAlex relevance ranking and coverage differ from Scopus; conference papers without DOIs and non-indexed theses can be missed.",
              "* Abstract-level classification can miss features described only in the full text (for example SPICE validation reported in the body).",
              "* Grey literature (application notes on functional-safety reference monitoring in automotive ADCs) was not searched; such documents may describe reference-monitor circuits."]
    (ROOT / "paper_package" / "LITERATURE_GAP_MATRIX.md").write_text("\n".join(lines) + "\n")
    print(len(df), "rows;", len(refs), "references formatted")


if __name__ == "__main__":
    main()
