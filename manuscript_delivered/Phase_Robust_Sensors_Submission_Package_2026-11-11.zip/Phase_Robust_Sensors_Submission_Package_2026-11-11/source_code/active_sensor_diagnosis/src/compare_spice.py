"""Compare ngspice transient waveforms with the behavioral simulator.

The behavioral chain is evaluated noise-free and without ADC quantization, using
the same sensor sine, AFE/ADC parameters, and reference windows as the netlist,
so any residual is attributable to the circuit-level model.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .simulate import _adc_reference, _afe_reference, _first_order_lowpass
from .spice_netlist import DEFAULT_CASES

FS_HZ = 1000.0
N = 512


def read_raw(path: Path) -> dict[str, np.ndarray]:
    """Parse an ngspice binary raw file (real, transient)."""
    data = path.read_bytes()
    marker = b"Binary:\n"
    head, body = data[: data.index(marker)], data[data.index(marker) + len(marker):]
    lines = head.decode("ascii", errors="replace").splitlines()
    n_vars = int(next(l for l in lines if l.startswith("No. Variables")).split(":")[1])
    n_pts = int(next(l for l in lines if l.startswith("No. Points")).split(":")[1])
    start = lines.index("Variables:") + 1
    names = [lines[start + i].split()[1] for i in range(n_vars)]
    arr = np.frombuffer(body, dtype="<f8", count=n_vars * n_pts).reshape(n_pts, n_vars)
    return {name: arr[:, i] for i, name in enumerate(names)}


def behavioral(case) -> dict[str, np.ndarray]:
    t = np.arange(N) / FS_HZ
    sensor = 1.0 + 0.10 * np.sin(2 * np.pi * 2.0 * t)
    afe_ref, _, _ = _afe_reference(N, FS_HZ)
    adc_ref, _, _ = _adc_reference(N, FS_HZ)
    afe_in = sensor.copy()
    m = afe_ref > 0
    afe_in[m] = afe_ref[m]
    afe_out = case.afe_gain * _first_order_lowpass(afe_in, case.tau_s, FS_HZ) + case.afe_offset
    adc_in = afe_out.copy()
    m = adc_ref > 0
    adc_in[m] = adc_ref[m]
    return {"afe_src": afe_in, "afe_out": afe_out, "adc_src": adc_in,
            "adc_out": case.adc_gain * adc_in + case.adc_offset}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--spice-dir", type=Path, default=Path(__file__).resolve().parents[1] / "spice")
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()
    out_path = args.output or args.spice_dir / "spice_vs_behavioral.json"
    t_grid = np.arange(N) / FS_HZ
    # Exclude +/-2 ms around reference/control edges: the netlist edge is 1 us
    # while the comparison grid is 1 ms, so edge samples are grid-aliased.
    edges_s = (0.140, 0.200, 0.260, 0.340, 0.400, 0.460)
    keep = np.all([np.abs(t_grid - e) > 0.002 for e in edges_s], axis=0)
    report = {}
    for case in DEFAULT_CASES:
        raw = read_raw(args.spice_dir / f"{case.name}.raw")
        beh = behavioral(case)
        t = raw["time"]
        row = {}
        for node, ref in beh.items():
            sp = np.interp(t_grid, t, raw[f"v({node})"])
            err = (sp - ref)[keep]
            row[node] = {
                "rmse_V": float(np.sqrt(np.mean(err**2))),
                "max_abs_V": float(np.max(np.abs(err))),
                "max_abs_at_s": float(t_grid[keep][np.argmax(np.abs(err))]),
            }
        row["adc_out_signal_rms_V"] = float(np.sqrt(np.mean(beh["adc_out"] ** 2)))
        report[case.name] = row
        print(f"{case.name:14s} " + "  ".join(
            f"{k}: rmse={v['rmse_V']:.4f} max={v['max_abs_V']:.4f}" for k, v in row.items() if isinstance(v, dict)))
    out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"wrote {out_path}")


if __name__ == "__main__":
    main()
