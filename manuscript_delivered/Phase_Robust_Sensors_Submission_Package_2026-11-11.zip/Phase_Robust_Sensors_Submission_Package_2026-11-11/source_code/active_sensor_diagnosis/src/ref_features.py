"""Reference-v2 descriptors: settled-plateau calibration + explicit reference conditioning.

Everything is computed from a simulated record's measured waveform and the *commanded*
(known) reference arrays; nothing uses fault labels.

Revision 1 (settled plateaus).  Each two-level reference window is split into its two
plateaus.  The first ``guard`` fraction of every plateau is discarded and the rest is
averaged.  ADC gain/offset come from the ADC reference window (bypass path, no
dynamics).  The waveform is then ADC-calibrated and the AFE gain/offset are estimated
from the AFE reference window with the same guard.  Settling error and residual noise
are reported separately; the discarded transient of the second AFE plateau is used
only as scale-free rise fractions (bandwidth information).

Revision 2 (conditioning + normalisation).  The commanded levels and a normalised
reference scale are exposed as inputs; responses are normalised by the commanded
reference difference (gain = response / commanded difference).  Offsets are absolute
intercepts and are deliberately *not* divided by the reference amplitude.
"""

from __future__ import annotations

import numpy as np

AFE_NOMINAL_DIFF = 0.40  # 1.30 - 0.90
ADC_NOMINAL_DIFF = 0.60  # 1.75 - 1.15
PROBE_NOMINAL_AMP = 0.075
RISE_OFFSETS = (2, 5, 10, 20, 30)  # samples after the plateau-2 step (1 kHz -> ms)
SENSOR_SEGMENTS = (slice(40, 130), slice(470, 512))
FEATURE_NAMES = (
    "g_adc", "o_adc", "adc_noise",
    "G_afe", "o_afe", "settle_err1", "settle_err2", "afe_noise",
    "rise_2", "rise_5", "rise_10", "rise_20", "rise_30",
    "sens_mean", "sens_std", "sens_hf", "sens_ptp", "sens_slope",
    "ymax_s", "top_frac_s",
)
COND_NAMES = ("afe_low", "afe_high", "adc_low", "adc_high", "ref_scale")
N_DESC, N_COND = len(FEATURE_NAMES), len(COND_NAMES)


def _plateaus(ref: np.ndarray, start: int, end: int, guard: float):
    """Return (low, high, settled1, settled2, plateau1, plateau2) or None if no reference."""
    if end <= start:
        return None
    half = (end - start) // 2
    low, high = float(ref[start]), float(ref[start + half])
    if abs(high - low) < 1e-6:
        return None
    p1, p2 = (start, start + half), (start + half, end)
    g1, g2 = int(round(guard * (p1[1] - p1[0]))), int(round(guard * (p2[1] - p2[0])))
    return low, high, (p1[0] + g1, p1[1]), (p2[0] + g2, p2[1]), p1, p2


def _detrended_std(y: np.ndarray) -> float:
    if len(y) < 3:
        return 0.0
    x = np.arange(len(y))
    return float(np.std(y - np.polyval(np.polyfit(x, y, 1), x)))


def ref_descriptors(rec: dict, guard: float = 0.30):
    """Return (descriptors[N_DESC], conditioning[N_COND], waveform96)."""
    y = np.asarray(rec["waveform"], dtype=np.float64)
    n = len(y)
    afe_ref = np.asarray(rec["afe_reference"], dtype=np.float64)
    adc_ref = np.asarray(rec["adc_reference"], dtype=np.float64)
    afe = _plateaus(afe_ref, int(rec["afe_ref_start"]), int(rec["afe_ref_end"]), guard) if np.ptp(afe_ref) > 1e-6 else None
    adc = _plateaus(adc_ref, int(rec["adc_ref_start"]), int(rec["adc_ref_end"]), guard) if np.ptp(adc_ref) > 1e-6 else None
    d = dict.fromkeys(FEATURE_NAMES, 0.0)
    cond = np.zeros(N_COND)

    # --- ADC stage (bypass: no dynamics, but the same guard is applied for uniformity)
    y_cal = y.copy()
    g_adc, o_adc = 1.0, 0.0
    if adc is not None:
        low, high, s1, s2, _, _ = adc
        m1, m2 = y[s1[0]:s1[1]].mean(), y[s2[0]:s2[1]].mean()
        g_adc = (m2 - m1) / (high - low)
        o_adc = m1 - g_adc * low
        d["g_adc"], d["o_adc"] = g_adc, o_adc
        d["adc_noise"] = 0.5 * (_detrended_std(y[s1[0]:s1[1]]) + _detrended_std(y[s2[0]:s2[1]]))
        if abs(g_adc) > 0.2:
            y_cal = (y - o_adc) / g_adc
        cond[2], cond[3] = low, high
    # --- AFE stage on the ADC-calibrated waveform
    G, o_afe = 1.0, 0.0
    if afe is not None:
        low, high, s1, s2, p1, p2 = afe
        a1, a2 = y_cal[s1[0]:s1[1]].mean(), y_cal[s2[0]:s2[1]].mean()
        G = (a2 - a1) / (high - low)
        o_afe = a1 - G * low
        span = abs(a2 - a1) + 1e-6
        tail = 6
        d["G_afe"], d["o_afe"] = G, o_afe
        d["settle_err1"] = (y_cal[p1[1] - tail:p1[1]].mean() - a1) / span
        d["settle_err2"] = (y_cal[p2[1] - tail:p2[1]].mean() - a2) / span
        d["afe_noise"] = 0.5 * (_detrended_std(y_cal[s1[0]:s1[1]]) + _detrended_std(y_cal[s2[0]:s2[1]]))
        base = y_cal[p2[0] - 1]
        den = a2 - base
        den = den if abs(den) > 1e-3 else (1e-3 if den >= 0 else -1e-3)
        for name, off in zip(("rise_2", "rise_5", "rise_10", "rise_20", "rise_30"), RISE_OFFSETS):
            d[name] = float(np.clip((y_cal[p2[0] + off] - base) / den, -1.0, 2.0))
        cond[0], cond[1] = low, high
    # --- sensor-domain statistics (self-calibrated through the estimated chain)
    z = (y_cal - o_afe) / G if (afe is not None and abs(G) > 0.2) else y_cal.copy()
    zs = np.concatenate([z[s] for s in SENSOR_SEGMENTS])
    z1 = z[SENSOR_SEGMENTS[0]]
    d["sens_mean"], d["sens_std"], d["sens_ptp"] = float(zs.mean()), float(zs.std()), float(np.ptp(zs))
    d["sens_hf"] = float(np.std(np.diff(z1)) / np.sqrt(2.0))
    d["sens_slope"] = float(np.polyfit(np.arange(len(z1)), z1, 1)[0])
    ys = np.concatenate([y[s] for s in SENSOR_SEGMENTS])
    d["ymax_s"] = float(ys.max())
    d["top_frac_s"] = float(np.mean(ys >= ys.max() - 1.5 * 3.3 / 4095.0))

    scales = []
    if afe is not None:
        scales.append((afe[1] - afe[0]) / AFE_NOMINAL_DIFF)
    if adc is not None:
        scales.append((adc[1] - adc[0]) / ADC_NOMINAL_DIFF)
    cond[4] = float(np.mean(scales)) if scales else 0.0

    # --- reference-normalised waveform for the temporal model
    w = z.copy()
    if afe is not None:
        low, high, _, _, p1, p2 = afe
        w[p1[0]:p2[1]] = (z[p1[0]:p2[1]] - low) / (high - low)
    if adc is not None:
        low, high, _, _, p1, p2 = adc
        w[p1[0]:p2[1]] = (y_cal[p1[0]:p2[1]] - low) / (high - low)
    idx = np.linspace(0, n - 1, 96).astype(int)
    vec = np.asarray([d[k] for k in FEATURE_NAMES], dtype=np.float32)
    return vec, cond.astype(np.float32), w[idx].astype(np.float32)


def probe_scale(rec: dict) -> float:
    """Commanded additive-probe amplitude relative to nominal (single-probe path)."""
    p = np.asarray(rec.get("probe", 0.0))
    return float(np.max(np.abs(p)) / PROBE_NOMINAL_AMP) if p.size else 0.0
