"""Assemble FINAL_REFERENCE_V2_REPORT.md from reference_v2_results/ (tables generated, never typed)."""

import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
R = ROOT / "reference_v2_results"
agg = pd.read_csv(R / "aggregate_metrics.csv")
comp = pd.read_csv(R / "bootstrap_comparisons.csv")
rec = pd.read_csv(R / "per_class_recall.csv")
sep = pd.read_csv(R / "afe_adc_separation.csv")
dec = json.loads((R / "decision_rules.json").read_text())
dev = json.loads((R / "development_check_seed20261099.json").read_text())
unm = json.loads((R / "exploratory_unmonitored_reference.json").read_text())
seeds = [20261020, 20261021, 20261022]
meta = {s: json.loads((R / f"seed_{s}" / "meta.json").read_text()) for s in seeds}
SCN = ["nominal", "tolerance", "ref_m20", "ref_p20", "ref_m10", "ref_p10", "severity"]
SCN_LABEL = {"nominal": "nominal", "tolerance": "tolerance", "ref_m20": "ref ×0.8", "ref_p20": "ref ×1.2",
             "ref_m10": "ref ×0.9", "ref_p10": "ref ×1.1", "severity": "unseen severity"}
ARMS = ["A0", "A0j", "A1", "A1j", "A2"]
agg["key"] = agg.model + "@" + agg.arm


def v(scn, key, target, col="macro_f1_mean"):
    r = agg[(agg.scenario == scn) & (agg.key == key) & (agg.target == target)]
    return float(r[col].iloc[0])


def ms(scn, key, target):
    return f"{v(scn, key, target):.3f} ± {v(scn, key, target, 'macro_f1_std'):.3f}"


def cr(scn, target, A, B, metric="macro_f1"):
    r = comp[(comp.scenario == scn) & (comp.target == target) & (comp.A == A) & (comp.B == B) & (comp.metric == metric)]
    return r.iloc[0]


def cell(r):
    star = " ✓" if r.ci_low > 0 else (" ✗" if r.ci_high < 0 else "")
    cons = " (3/3 seeds)" if (r.consistent_positive or r.consistent_negative) else ""
    return f"{r.diff_pooled:+.3f} [{r.ci_low:+.3f}, {r.ci_high:+.3f}]{star}{cons}"


def md(df):
    cols = list(df.columns)
    out = ["| " + " | ".join(map(str, cols)) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    out += ["| " + " | ".join(str(x) for x in r.values) + " |" for _, r in df.iterrows()]
    return "\n".join(out)


L = []
w = L.append
A2, A1, A0 = "two_point_mlp@A2", "two_point_mlp@A1", "two_point_mlp@A0"
ret = {a: {s: v(s, f"two_point_mlp@{a}", "layer") / v("nominal", f"two_point_mlp@{a}", "layer") for s in ("ref_m20", "ref_p20")} for a in ARMS}

w("# Final Reference-v2 Report")
w("")
w("Date: 14 October 2026 · Revision of the reference handling of the two-point self-test (settled-plateau calibration + explicit reference conditioning).")
w("")
w("The official baseline remains `FINAL_MULTISEED_REPORT.md` (`ROBUSTNESS FAILURE; REVISE BEFORE PAPER`); it and `multiseed_results/` are untouched. "
  "The protocol and decision rules are in `PROTOCOL_REFERENCE_V2_FROZEN.md`, written before any validation-seed data existed (source hashes in `reference_v2_results/source_hashes_at_freeze.txt`).")
w("")
w("## Verdict in brief")
w("")
w(f"* **By the pre-specified rules the revision is validated** (D1–D4 all hold; tag at the end). Under the previously fatal ±20% reference-amplitude shift, "
  f"the two-point MLP's layer macro-F1 goes from {v('ref_m20', A0, 'layer'):.3f} / {v('ref_p20', A0, 'layer'):.3f} (previous method, ×0.8 / ×1.2) to "
  f"{v('ref_m20', A2, 'layer'):.3f} / {v('ref_p20', A2, 'layer'):.3f} (full revision, arm A2) and {v('ref_m20', A1, 'layer'):.3f} / {v('ref_p20', A1, 'layer'):.3f} (Revision 1 alone, arm A1), against nominal {v('nominal', A1, 'layer'):.3f} (A1).")
w("* **The effective ingredient is Revision 1** (settled-plateau calibration with commanded-level normalisation), which is invariant by construction and needs no augmentation. "
  "**Revision 2's conditioning inputs plus amplitude-jitter training did not help**: A2 is slightly worse than the same features without conditioning (A1j) at the shifted references (§4, D5).")
w("* **Scope of the claim — important.** Robustness holds when the reference amplitude is *known* (commanded = actual). In a post-hoc check where the actual amplitude drifts but the system still assumes the nominal value, layer macro-F1 drops back to about "
  f"{unm['mean_layer_macro_f1']['A1']['m20']:.2f} / {unm['mean_layer_macro_f1']['A1']['p20']:.2f} (±20%). The revision does not remove the need to know or monitor the reference.")
w("* Nominal, tolerance and unseen-severity performance also improved, and the one-point/passive baselines are still beaten in every primary scenario.")
w("")

w("## 1. Protocol summary")
w("")
w("* **Revision 1.** Each reference window is split into two plateaus; the first 30% of each (`GUARD = 0.30`, frozen) is discarded and the rest averaged. ADC gain/offset from the commanded ADC levels; the waveform is ADC-calibrated; AFE gain from the settled outputs divided by the commanded difference, AFE offset from the first settled output. Settling error and residual noise are separate descriptors; the discarded transient is used only as scale-free rise fractions (bandwidth). 20 descriptors (`src/ref_features.py`).")
w("* **Revision 2.** Commanded AFE/ADC low and high levels and a normalised reference scale as inputs; responses normalised by the commanded difference (offsets stay absolute intercepts). Because these inputs are constant at one training amplitude, arms with conditioning are trained with amplitude jitter U(0.9, 1.1); the ±20% test shifts are outside that range.")
w("* **Arms:** A0 previous method (raw + 38 old descriptors, nominal training); A0j previous features + jitter training (control); A1 Revision 1 only (nominal training); A1j Revision 1 + jitter (no conditioning); A2 full revision (conditioning + jitter).")
w("* Same statistics as the previous round: 5000-resample condition-level paired bootstrap, per-seed and pooled CIs, 2 inits averaged, tests never used for any design choice.")
w("")
w("**Assumptions I added** (the request text was cut off after Revision 2): the jitter training, the arm structure and controls, the scenario set, the seeds (20261020–22, new), the decision rules D1–D6 and the tags. All were fixed in the protocol file before the validation run.")
w("")
w("### Group counts")
w("")
w(md(pd.DataFrame([{"dataset seed": s, "train / val / test conditions": f"{meta[s]['train_conditions']} / {meta[s]['val_conditions']} / {meta[s]['test_conditions']}",
                    "overlap": meta[s]["overlap"], "severity train / val / test rows": f"{meta[s]['severity_train_rows']} / {meta[s]['severity_val_rows']} / {meta[s]['severity_test_rows']}",
                    "split rs (test / val)": f"{meta[s]['split_random_state']} / {meta[s]['val_random_state']}"} for s in seeds])))
w("")
w("### Development check (separate seed 20261099, not in validation)")
w("")
for g in ("guard_0.3", "guard_0.5"):
    d = dev[g]
    w(f"* guard {g.split('_')[1]}: mean AFE-estimate shift at ×0.8 = {d['abs_shift']['m20']['G_afe']:.3f} (gain) / {d['abs_shift']['m20']['o_afe']:.3f} V (offset); ADC estimates shift ≤ {max(d['abs_shift']['m20']['g_adc'], d['abs_shift']['m20']['o_adc']):.4f}; "
      f"nominal-trained layer macro-F1 nominal / ×0.8 / ×1.2 = {d['A1_nominal_train']['nominal']:.3f} / {d['A1_nominal_train']['m20']:.3f} / {d['A1_nominal_train']['p20']:.3f}.")
w("* The ADC path is invariant by construction (bypass, no dynamics). The AFE estimates are only partly invariant (residual settling bias that depends on the sensor-to-reference step), which the 50% guard reduces but did not change in classification terms; 30% was kept as suggested.")
w("")

w("## 2. Two-point MLP by arm (macro-F1, mean ± std over 3 dataset seeds)")
w("")
for target in ("layer", "fault"):
    w(f"**{target}**")
    w("")
    w(md(pd.DataFrame([{"arm": a, **{SCN_LABEL[s]: ms(s, f"two_point_mlp@{a}", target) for s in SCN}} for a in ARMS])))
    w("")
w("Figures: `reference_v2_comparison/arms_layer_macro_f1.png`, `arms_fault_macro_f1.png`, `a2_vs_baselines_layer_macro_f1.png`, `a2_vs_baselines_fault_macro_f1.png`.")
w("")
w("**Retention under the ±20% reference shift (layer macro-F1 at shift / nominal):**")
w("")
w(md(pd.DataFrame([{"arm": a, "ref ×0.8": f"{ret[a]['ref_m20']:.2f}", "ref ×1.2": f"{ret[a]['ref_p20']:.2f}"} for a in ARMS])))
w("")

w("## 3. All models, layer macro-F1")
w("")
keys = ["passive_mlp@A0", "single_mlp@A0", "single_mlp@A2", "afe_only_mlp@A0", "afe_only_mlp@A2", "adc_only_mlp@A0", "adc_only_mlp@A2",
        "two_point_mlp@A0", "two_point_mlp@A2", "two_point_rf@A0", "two_point_rf@A2", "tcn_v2a@A0", "tcn_v2a@A1", "tcn_v2a@A2"]
w(md(pd.DataFrame([{"model@arm": k, **{SCN_LABEL[s]: ms(s, k, "layer") for s in SCN}} for k in keys])))
w("")

w("## 4. Decision rules")
w("")
w("**D1 — architecture retained (A2, layer macro-F1; two-point MLP minus each baseline, pooled CI lower bound):**")
w("")
bl = ["passive_mlp@A0", "single_mlp@A2", "afe_only_mlp@A2", "adc_only_mlp@A2"]
w(md(pd.DataFrame([{"scenario": SCN_LABEL[s], **{b: cell(cr(s, "layer", A2, b)) for b in bl}} for s in SCN])))
w("")
w(f"D1 holds in nominal, tolerance, ref ×0.8 and ref ×1.2: **{dec['summary']['D1']}**. The fine-fault counterpart:")
w("")
w(md(pd.DataFrame([{"scenario": SCN_LABEL[s], **{b: cell(cr(s, "fault", A2, b)) for b in bl}} for s in SCN])))
w("")
w("**D2 / D4 — improvement over the previous method (two-point MLP, A2 − A0 and A1 − A0, layer macro-F1):**")
w("")
w(md(pd.DataFrame([{"scenario": SCN_LABEL[s], "A2 − A0": cell(cr(s, "layer", A2, A0)), "A1 − A0": cell(cr(s, "layer", A1, A0))} for s in SCN])))
w("")
w(f"D2 (CI > 0 at both ×0.8 and ×1.2): **{dec['summary']['D2']}**. D4 (nominal non-inferiority, margin −0.03): **{dec['summary']['D4']}** — nominal A2 − A0 is {dec['D4']['diff']:+.3f}, i.e. the revision also *improved* nominal performance.")
w("")
w(f"**D3 — retention ≥ 0.85 (A2):** ×0.8 {dec['D3']['ref_m20']['retention']:.2f}, ×1.2 {dec['D3']['ref_p20']['retention']:.2f} → **{dec['summary']['D3']}**. "
  f"(Revision 1 alone retains {ret['A1']['ref_m20']:.2f} / {ret['A1']['ref_p20']:.2f}.)")
w("")
w("**D5 — attribution (two-point MLP, layer macro-F1):**")
w("")
pairs = [("A2 − A0j (features+conditioning vs augmentation alone)", A2, "two_point_mlp@A0j"), ("A1j − A0j (new features vs old features, both jittered)", "two_point_mlp@A1j", "two_point_mlp@A0j"),
         ("A1 − A0 (Revision 1 alone, no augmentation)", A1, A0), ("A0j − A0 (augmentation alone)", "two_point_mlp@A0j", A0),
         ("A2 − A1j (effect of conditioning inputs)", A2, "two_point_mlp@A1j")]
w(md(pd.DataFrame([{"comparison": n, **{SCN_LABEL[s]: cell(cr(s, "layer", a, b)) for s in ("nominal", "tolerance", "ref_m20", "ref_p20")}} for n, a, b in pairs])))
w("")
w("Reading: augmentation alone recovers part of the loss (A0j − A0 is large and positive at the shifts) but not all of it, and the new features add a further large, CI-significant gain even when both are jittered. "
  "The conditioning inputs do **not** help: A2 is below A1j at the shifted references (CI excludes zero), so Revision 2 as implemented is not supported by the data; the benefit comes from Revision 1.")
w("")
w("**D6 — TCN (reported, not gating):**")
w("")
w(md(pd.DataFrame([{"scenario": SCN_LABEL[s], "tcn@A2 − two_point_mlp@A2 (layer)": cell(cr(s, "layer", "tcn_v2a@A2", A2)),
                    "tcn@A2 − two_point_mlp@A2 (fault)": cell(cr(s, "fault", "tcn_v2a@A2", A2)),
                    "tcn@A1 − tcn@A0 (layer)": cell(cr(s, "layer", "tcn_v2a@A1", "tcn_v2a@A0"))} for s in SCN])))
w("")
w("The TCN benefits from the revision as much as the MLP does. Against the MLP it is better on layer macro-F1 in nominal and in the reference-shift scenarios but equal under tolerance and unseen severity, and the fine-fault comparison is mixed; this is not a consistent superiority, and the earlier conclusion (no claim that the TCN architecture is superior) stands.")
w("")

w("## 5. AFE / ADC separation (layer target)")
w("")
sp = sep[sep.model.isin(["two_point_mlp@A0", "two_point_mlp@A1", "two_point_mlp@A2", "tcn_v2a@A2"]) & sep.scenario.isin(["nominal", "ref_m20", "ref_p20"])]
w(md(pd.DataFrame([{"scenario": SCN_LABEL[r.scenario], "model": r.model, "AFE recall": f"{r.afe_recall:.2f}", "ADC recall": f"{r.adc_recall:.2f}",
                    "AFE↔ADC cross-confusion": f"{r.afe_adc_cross:.2f}", "healthy recall": f"{r.healthy_recall:.2f}", "sensor recall": f"{r.sensor_recall:.2f}"} for _, r in sp.iterrows()])))
w("")
w("With the revision the two-point method again separates AFE from ADC faults under ±20% reference shifts (cross-confusion ≈ 0.02–0.12, previously ≈ 0.4 with almost no AFE recall).")
w("")

w("## 6. Per-class recall, fine fault (two-point MLP, mean over 3 dataset seeds)")
w("")
fc = ["healthy", "sensor_bias", "sensor_gain", "sensor_noise", "afe_offset", "afe_bandwidth", "adc_offset", "adc_gain", "adc_clipping"]
rows = []
for scn in ("nominal", "ref_m20"):
    for a in ("A0", "A1", "A2"):
        r = rec[(rec.scenario == scn) & (rec.model == "two_point_mlp") & (rec.arm == a) & (rec.target == "fault")].iloc[0]
        rows.append({"scenario": SCN_LABEL[scn], "arm": a, **{c: f"{r['recall_' + c]:.2f}" for c in fc}})
w(md(pd.DataFrame(rows)))
w("")
w("The hard classes are unchanged in kind: `healthy`, `sensor_bias`, `sensor_gain` and `adc_clipping` remain the weakest. Per-scenario recall for every model/arm: `reference_v2_results/per_class_recall.csv`.")
w("")

w("## 7. Exploratory, post-hoc: unmonitored reference error")
w("")
w("Not part of the frozen protocol; it bounds the claim. The actual reference amplitude is scaled, but the descriptors are still handed the **nominal** commanded levels (the system does not know the reference drifted). Two-point MLP, layer macro-F1, mean over 3 dataset seeds:")
w("")
w(md(pd.DataFrame([{"arm": a, "×0.8": f"{unm['mean_layer_macro_f1'][a]['m20']:.3f}", "×1.2": f"{unm['mean_layer_macro_f1'][a]['p20']:.3f}",
                    "×0.9": f"{unm['mean_layer_macro_f1'][a]['m10']:.3f}", "×1.1": f"{unm['mean_layer_macro_f1'][a]['p10']:.3f}"} for a in ("A1", "A2")])))
w("")
w("An unseen reference error is physically indistinguishable from an AFE/ADC gain or offset fault unless the reference itself is measured, so this is expected rather than a modelling defect. It means the paper must either state a reference-accuracy bound or add a reference-monitor path.")
w("")

w("## 8. Limitations")
w("")
for t in [
    "Simulator-only evidence; the learned models have not been run on SPICE-generated or hardware data, and the descriptors assume the simulator's structure (first-order AFE, affine ADC, switched references).",
    "The reference-shift test assumes the actual amplitude is known to the system (commanded = actual). Unmonitored reference error is not handled (§7).",
    "Three dataset seeds, 88 test conditions each; CIs resample conditions, not datasets.",
    "The residual AFE-estimate sensitivity to the settling transient is reduced, not eliminated, by the 30% guard; slow AFE bandwidth faults (tau up to 72 ms in a 60 ms plateau) never settle by design, which is why settling descriptors are separate.",
    "The nominal improvement of the new descriptors (+0.065 to +0.081 layer macro-F1 for A2 and A1) is large and was not decomposed; plausible contributors are the self-calibrated sensor-domain statistics and the saturation descriptors, but this was not isolated.",
    "Revision 2's conditioning was tested only with jitter in [0.9, 1.1] and extrapolation to ±20%; other training ranges might change its effect. It is therefore 'not supported in this form', not 'proven useless'.",
    "Weak classes persist (healthy ≈ 0.15 layer recall, sensor_bias/sensor_gain/adc_clipping fine recall); this is not a deployable detector.",
    "No hardware, energy or cost measurement; no journal-acceptance claim.",
]:
    w(f"* {t}")
w("")

w("## 9. Recommendation")
w("")
w("1. Adopt Revision 1 (settled-plateau, commanded-level-normalised descriptors) as the reference-handling method; it fixes the ±20% failure without needing augmentation and also improves nominal and shifted performance.")
w("2. Do not claim a benefit from the explicit conditioning inputs (Revision 2) or the physics loss; report conditioning as tested and unsupported.")
w("3. State the robustness claim precisely: **robust to reference-amplitude changes that the system knows about**. For unknown reference drift, add a reference-monitor measurement (measure the reference through the ADC or a dedicated tap) or specify a reference-accuracy tolerance; validate that variant before submission.")
w("4. Next validation: SPICE-generated test data through the same descriptors, then (if available) a hardware pilot.")
w("")
w("No journal-acceptance claim is made.")
w("")
w(dec["tag"])
(ROOT / "FINAL_REFERENCE_V2_REPORT.md").write_text("\n".join(L) + "\n", encoding="utf-8")
print("wrote", len("\n".join(L)), "chars; tag:", dec["tag"])
