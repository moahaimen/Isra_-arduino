"""Analysis of the frozen reference-monitor + ngspice cross-domain validation (criteria A-F, GO/REVISE)."""

from __future__ import annotations

import argparse
import json
from functools import lru_cache
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import binomtest

from .simulate import FAULTS, LAYERS

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "reference_monitor_final"
AMPS = (80, 90, 100, 110, 120)
XS = ("known", "mon0", "mon1", "mon2", "mon5")
INITS = (11, 22)
K = {"layer": 4, "fault": 9}
LABELS = {"layer": LAYERS, "fault": FAULTS}
BASELINES_A0 = ["two_point_mlp@A0", "passive_mlp@A0", "single_mlp@A0", "afe_only_mlp@A0", "adc_only_mlp@A0"]


def a1(path: str, x: str) -> str:
    return f"{path}_mlp@A1c" if x == "known" else f"{path}_mlp@A1m{x[3:]}"


class Store:
    def __init__(self, seed_dirs):
        self.seeds, self.P, self.meta, self.info = [], {}, {}, {}
        for d in seed_dirs:
            m = json.loads((d / "meta.json").read_text())
            s = m["dataset_seed"]
            self.seeds.append(s)
            self.meta[s] = m
            self.info[s] = json.loads((d / "model_info.json").read_text())
            self.P[s] = dict(np.load(d / "predictions.npz"))
        self.cache = {}

    def cm_cond(self, s, scn, model, target):
        """list over inits of per-condition confusion matrices [n_cond, K, K]."""
        key = (s, scn, model, target)
        if key not in self.cache:
            P = self.P[s]
            y, cond = P[f"y_{target}"].astype(int), P["cond"]
            conds = np.unique(cond)
            idx = np.searchsorted(conds, cond)
            out = []
            for i in INITS:
                cm = np.zeros((len(conds), K[target], K[target]))
                np.add.at(cm, (idx, y, P[f"{scn}|{model}|{i}|{target}"].astype(int)), 1)
                out.append(cm)
            self.cache[key] = out
        return self.cache[key]

    def cm_multi(self, s, scns, model, target):
        parts = [self.cm_cond(s, sc, model, target) for sc in scns]
        return [sum(p[i] for p in parts) for i in range(len(INITS))]

    def has(self, scn, model):
        return all(f"{scn}|{model}|{INITS[0]}|layer" in self.P[s] for s in self.seeds)


def f1_from_cm(cm):
    tp = np.einsum("...kk->...k", cm)
    row, col = cm.sum(-1), cm.sum(-2)
    den = row + col
    return np.where(den > 0, 2 * tp / np.where(den > 0, den, 1), 0.0).mean(-1)


def metric_from_cm(cm, metric):
    if metric == "accuracy":
        return np.einsum("...kk->...", cm) / cm.sum((-1, -2))
    if metric == "balanced_accuracy":
        row = cm.sum(-1)
        rec = np.where(row > 0, np.einsum("...kk->...k", cm) / np.where(row > 0, row, 1), np.nan)
        return np.nanmean(rec, axis=-1)
    return f1_from_cm(cm)


def point(store, scns, model, target, metric="macro_f1"):
    """mean over seeds of (mean over inits of metric from the summed per-condition CM)."""
    vals = []
    for s in store.seeds:
        cms = store.cm_multi(s, scns, model, target)
        vals.append(np.mean([metric_from_cm(c.sum(0), metric) for c in cms]))
    return float(np.mean(vals)), vals


def pooled_cm(store, scns, model, target):
    tot = 0
    for s in store.seeds:
        tot = tot + np.mean([c.sum(0) for c in store.cm_multi(s, scns, model, target)], axis=0)
    return tot


def cross_confusion(store, scns, model):
    cm = pooled_cm(store, scns, model, "layer")
    a, d = LAYERS.index("afe"), LAYERS.index("adc")
    n = cm[a].sum() + cm[d].sum()
    return float(cm[a, a] / cm[a].sum()), float(cm[d, d] / cm[d].sum()), float((cm[a, d] + cm[d, a]) / n)


def compare(store, scnA, mA, scnB, mB, target, metric, n_boot):
    boots, pts, cis = [], [], []
    for s in store.seeds:
        A_ = store.cm_multi(s, scnA, mA, target)
        B_ = store.cm_multi(s, scnB, mB, target)
        nc = A_[0].shape[0]
        W = np.random.default_rng([int(s), 0 if target == "layer" else 1]).multinomial(nc, np.full(nc, 1.0 / nc), size=n_boot).astype(float)
        fa = np.mean([metric_from_cm(np.einsum("bn,nkl->bkl", W, c), metric) for c in A_], axis=0)
        fb = np.mean([metric_from_cm(np.einsum("bn,nkl->bkl", W, c), metric) for c in B_], axis=0)
        d = fa - fb
        boots.append(d)
        pts.append(float(np.mean([metric_from_cm(c.sum(0), metric) for c in A_]) - np.mean([metric_from_cm(c.sum(0), metric) for c in B_])))
        cis.append((float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))))
    pooled = np.mean(boots, axis=0)
    return {"diff": float(np.mean(pts)), "ci_low": float(np.percentile(pooled, 2.5)), "ci_high": float(np.percentile(pooled, 97.5)),
            "per_seed": pts, "per_seed_ci": cis, "all_seeds_positive": bool(all(p > 0 for p in pts))}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=Path, default=BASE / "reference_monitor_results")
    ap.add_argument("--figures", type=Path, default=BASE / "reference_monitor_figures")
    ap.add_argument("--seed-dirs", type=Path, nargs="*", default=None)
    ap.add_argument("--n-boot", type=int, default=5000)
    args = ap.parse_args()
    args.figures.mkdir(parents=True, exist_ok=True)
    dirs = args.seed_dirs or sorted(args.results.glob("seed_*"))
    st = Store(dirs)
    seeds = st.seeds
    print("seeds", seeds)

    # ---------------- per-seed and aggregate tables ----------------
    rows = []
    keys = sorted({tuple(k.split("|")[:2]) for k in st.P[seeds[0]] if "|" in k})
    for s in seeds:
        for scn, model in keys:
            for target in ("layer", "fault"):
                for ii, init in enumerate(INITS):
                    cm = st.cm_cond(s, scn, model, target)[ii].sum(0)
                    row = dict(dataset_seed=s, scenario=scn, model=model, target=target, init_seed=init,
                               accuracy=float(metric_from_cm(cm, "accuracy")), macro_f1=float(metric_from_cm(cm, "macro_f1")),
                               balanced_accuracy=float(metric_from_cm(cm, "balanced_accuracy")))
                    rr = cm.sum(1)
                    row.update({f"recall_{LABELS[target][k]}": float(cm[k, k] / rr[k]) if rr[k] else np.nan for k in range(K[target])})
                    rows.append(row)
    per_seed = pd.DataFrame(rows)
    per_seed.to_csv(args.results / "per_seed_metrics.csv", index=False)
    ia = per_seed.groupby(["dataset_seed", "scenario", "model", "target"], as_index=False).mean(numeric_only=True)
    agg = ia.groupby(["scenario", "model", "target"]).agg(
        accuracy_mean=("accuracy", "mean"), accuracy_std=("accuracy", "std"), macro_f1_mean=("macro_f1", "mean"), macro_f1_std=("macro_f1", "std"),
        balanced_accuracy_mean=("balanced_accuracy", "mean"), balanced_accuracy_std=("balanced_accuracy", "std")).reset_index()
    agg.round(4).to_csv(args.results / "aggregate_metrics.csv", index=False)
    rcols = [c for c in ia.columns if c.startswith("recall_")]
    ia.groupby(["scenario", "model", "target"])[rcols].mean().dropna(axis=1, how="all").round(4).reset_index().to_csv(args.results / "per_class_recall.csv", index=False)

    # ---------------- criteria ----------------
    def sc(x, a):  # Part-1 scenario name
        return f"p1_a{a}_{x}"
    N, _ = point(st, [sc("known", 100)], "two_point_mlp@A1c", "layer")
    crit = {"N_nominal_known_layer_macro_f1": N}
    # A retention
    A_ = {}
    for x in ("known", "mon0", "mon1", "mon2"):
        for a in (80, 120):
            v, _ = point(st, [sc(x, a)], a1("two_point", x), "layer")
            A_[f"{x}|a{a}"] = {"f1": v, "retention_vs_N": v / N, "pass": bool(v >= 0.85 * N)}
    crit["A"] = {"detail": A_, "pass": all(v["pass"] for v in A_.values())}
    # B superiority (paired bootstrap)
    B_ = {}
    comp_rows = []
    for x in XS:
        for a in (80, 120):
            scn = sc(x, a)
            base = BASELINES_A0 + [a1("afe_only", x), a1("adc_only", x)]
            for b in base:
                r = compare(st, [scn], a1("two_point", x), [scn], b, "layer", "macro_f1", args.n_boot)
                B_[f"{x}|a{a}|vs {b}"] = {**r, "pass": bool(r["ci_low"] > 0)}
                comp_rows.append(dict(rule="B", scenario=scn, A=a1("two_point", x), B=b, target="layer", metric="macro_f1", **{k: r[k] for k in ("diff", "ci_low", "ci_high")}))
    crit["B"] = {"detail": B_, "pass": all(v["pass"] for v in B_.values())}
    # C confusion
    C_ = {}
    for x in XS:
        for a in (80, 120):
            afe, adc, cross = cross_confusion(st, [sc(x, a)], a1("two_point", x))
            C_[f"{x}|a{a}"] = {"afe_recall": afe, "adc_recall": adc, "cross_confusion": cross, "pass": bool(cross < 0.15)}
    crit["C"] = {"detail": C_, "pass": all(v["pass"] for v in C_.values())}
    # D monitor error up to +-5% (retention >= 0.70 at E=5; B and C at E=5 are already inside B and C)
    D_ = {}
    for label, scns in (("a80", [sc("mon5", 80)]), ("a120", [sc("mon5", 120)]), ("pooled_all_amplitudes", [sc("mon5", a) for a in AMPS])):
        v, _ = point(st, scns, a1("two_point", "mon5"), "layer")
        D_[label] = {"f1": v, "retention_vs_N": v / N, "pass": bool(v >= 0.70 * N)}
    d_b = all(v["pass"] for k, v in B_.items() if k.startswith("mon5|"))
    d_c = all(v["pass"] for k, v in C_.items() if k.startswith("mon5|"))
    crit["D"] = {"detail": D_, "B_holds_at_E5": d_b, "C_holds_at_E5": d_c, "pass": bool(all(v["pass"] for v in D_.values()) and d_b and d_c)}
    # E transfer (matched E=2, pooled over amplitudes) and other variants; F (MS - BS)
    E_, F_ = {}, {}
    for x in XS:
        model = a1("two_point", x)
        bb = [f"bh_a{a}_{x}" for a in AMPS]
        bs = [f"sp_a{a}_{x}" for a in AMPS]
        ms_model = "two_point_mlp@MSc" if x == "known" else f"two_point_mlp@MS{x[3:]}"
        f_bb, _ = point(st, bb, model, "layer"); f_bs, _ = point(st, bs, model, "layer"); f_ms, _ = point(st, bs, ms_model, "layer")
        drop = compare(st, bb, model, bs, model, "layer", "macro_f1", args.n_boot)
        gain = compare(st, bs, ms_model, bs, model, "layer", "macro_f1", args.n_boot)
        worst = max(((f1 := point(st, [f"bh_a{a}_{x}"], model, "layer")[0]) - point(st, [f"sp_a{a}_{x}"], model, "layer")[0], a) for a in AMPS)
        E_[x] = {"BB": f_bb, "BS": f_bs, "MS": f_ms, "drop_BB_minus_BS": drop["diff"], "drop_ci": [drop["ci_low"], drop["ci_high"]],
                 "worst_amplitude_drop": [float(worst[0]), worst[1]], "pass_le_0.10": bool(drop["diff"] <= 0.10)}
        F_[x] = {"MS_minus_BS": gain["diff"], "ci": [gain["ci_low"], gain["ci_high"]], "improvement_supported": bool(gain["ci_low"] > 0)}
        comp_rows.append(dict(rule="E", scenario="bh vs sp pooled", A=model, B=model, target="layer", metric="macro_f1", diff=drop["diff"], ci_low=drop["ci_low"], ci_high=drop["ci_high"]))
        comp_rows.append(dict(rule="F", scenario="sp pooled", A=ms_model, B=model, target="layer", metric="macro_f1", diff=gain["diff"], ci_low=gain["ci_low"], ci_high=gain["ci_high"]))
    crit["E"] = {"primary_matched_E2": E_["mon2"], "all_variants": E_, "pass": bool(E_["mon2"]["pass_le_0.10"])}
    crit["F"] = {"MS_minus_BS": F_, "note": "improvement claimed only where improvement_supported is true; B is CI-based by construction"}
    failed = [k for k in ("A", "B", "C", "D", "E") if not crit[k]["pass"]]
    crit["failed_criteria"] = failed
    crit["decision"] = "GO" if not failed else "REVISE"
    (args.results / "decision_rules.json").write_text(json.dumps(crit, indent=2, default=float))
    pd.DataFrame(comp_rows).round(4).to_csv(args.results / "bootstrap_comparisons.csv", index=False)

    # ---------------- extra reporting tables ----------------
    extra = {}
    # unmonitored / clean-trained sensitivity / A0 / ablation by amplitude (layer & fault)
    series = {
        "A0 old method": ("two_point_mlp@A0", "known"),
        "A1 known reference": ("two_point_mlp@A1c", "known"),
        "A1 unmonitored (nominal assumed)": ("two_point_mlp@A1c", "assumed"),
        "A1c clean-trained, monitor E=2%": ("two_point_mlp@A1c", "mon2"),
        "A1c clean-trained, monitor E=5%": ("two_point_mlp@A1c", "mon5"),
        "A1m E=0%": ("two_point_mlp@A1m0", "mon0"), "A1m E=1%": ("two_point_mlp@A1m1", "mon1"),
        "A1m E=2%": ("two_point_mlp@A1m2", "mon2"), "A1m E=5%": ("two_point_mlp@A1m5", "mon5"),
        "A2m E=2% (ablation)": ("two_point_mlp@A2m2", "mon2"), "A2m E=5% (ablation)": ("two_point_mlp@A2m5", "mon5"),
    }
    rows = []
    for name, (model, x) in series.items():
        for target in ("layer", "fault"):
            rows.append({"series": name, "target": target, **{f"x{a / 100:.1f}": point(st, [sc(x, a)], model, target)[0] for a in AMPS},
                         "pooled_all": point(st, [sc(x, a) for a in AMPS], model, target)[0]})
    pd.DataFrame(rows).round(4).to_csv(args.results / "amplitude_curves.csv", index=False)
    # separation table for key series
    rows = []
    for name, (model, x) in series.items():
        for a in (80, 100, 120):
            afe, adc, cross = cross_confusion(st, [sc(x, a)], model)
            rows.append({"series": name, "amplitude": a / 100, "afe_recall": afe, "adc_recall": adc, "cross_confusion": cross})
    pd.DataFrame(rows).round(4).to_csv(args.results / "afe_adc_separation.csv", index=False)
    # Part 2 table
    rows = []
    for x in XS:
        model = a1("two_point", x)
        ms_model = "two_point_mlp@MSc" if x == "known" else f"two_point_mlp@MS{x[3:]}"
        for setting, scns, mdl in (("BB", [f"bh_a{a}_{x}" for a in AMPS], model), ("BS", [f"sp_a{a}_{x}" for a in AMPS], model), ("MS", [f"sp_a{a}_{x}" for a in AMPS], ms_model)):
            afe, adc, cross = cross_confusion(st, scns, mdl)
            row = {"variant": x, "setting": setting}
            for target in ("layer", "fault"):
                row[f"{target}_macro_f1"] = point(st, scns, mdl, target)[0]
                row[f"{target}_balanced_accuracy"] = point(st, scns, mdl, target, "balanced_accuracy")[0]
            row.update(afe_recall=afe, adc_recall=adc, cross_confusion=cross)
            for a in AMPS:
                row[f"layer_f1_x{a / 100:.1f}"] = point(st, [scns[AMPS.index(a)]], mdl, "layer")[0]
            rows.append(row)
    part2 = pd.DataFrame(rows)
    part2.round(4).to_csv(args.results / "part2_domain_transfer.csv", index=False)
    # per-class recall for Part 2 (layer and fault) at matched E=2
    rec_rows = []
    for setting, scns, mdl in (("BB", [f"bh_a{a}_{'mon2'}" for a in AMPS], "two_point_mlp@A1m2"), ("BS", [f"sp_a{a}_mon2" for a in AMPS], "two_point_mlp@A1m2"),
                               ("MS", [f"sp_a{a}_mon2" for a in AMPS], "two_point_mlp@MS2")):
        for target in ("layer", "fault"):
            cm = pooled_cm(st, scns, mdl, target)
            rec_rows.append({"setting": setting, "target": target, **{LABELS[target][k]: float(cm[k, k] / cm[k].sum()) for k in range(K[target])}})
    pd.DataFrame(rec_rows).round(4).to_csv(args.results / "part2_per_class_recall.csv", index=False)
    # parameter count and timings
    inf = {}
    for s in seeds:
        i = st.info[s]
        inf[s] = {"descriptor_extraction_ms_per_sample": i["descriptor_extraction_ms_per_sample"],
                  "params_two_point_layer": i["two_point_mlp@A1m2|11|layer"]["params"], "params_two_point_fault": i["two_point_mlp@A1m2|11|fault"]["params"],
                  "train_seconds_two_point_layer": i["two_point_mlp@A1m2|11|layer"]["train_seconds"],
                  "ngspice_wall_seconds": st.meta[s]["ngspice_wall_seconds"], "n_ngspice_runs": st.meta[s]["n_ngspice_runs"], "workers": st.meta[s]["workers"]}
    pk = [v for k, v in st.info[seeds[0]]["mlp_predict_ms_per_sample_behavioral|spice"].items() if k.startswith("mon2|11|layer")]
    inf["mlp_predict_ms_per_sample_behavioral_spice_mon2_layer"] = pk[0] if pk else None
    (args.results / "timing_and_parameters.json").write_text(json.dumps(inf, indent=2, default=float))

    # ---------------- figures ----------------
    cur = pd.read_csv(args.results / "amplitude_curves.csv")
    xa = [a / 100 for a in AMPS]
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), sharey=True)
    sty = {"A0 old method": ("#888888", "s", "-"), "A1 known reference": ("#1b6e3d", "o", "-"), "A1 unmonitored (nominal assumed)": ("#c0504d", "x", "--"),
           "A1m E=0%": ("#7aa6d6", "o", "-"), "A1m E=1%": ("#4f81bd", "o", "-"), "A1m E=2%": ("#2f6db5", "o", "-"), "A1m E=5%": ("#17375e", "o", "-"),
           "A1c clean-trained, monitor E=5%": ("#e0a060", "^", ":")}
    for ax, target in zip(axes, ("layer", "fault")):
        for name, (c, m, ls) in sty.items():
            r = cur[(cur.series == name) & (cur.target == target)].iloc[0]
            ax.plot(xa, [r[f"x{a:.1f}"] for a in xa], color=c, marker=m, ls=ls, label=name)
        ax.axhline(0.85 * N, color="k", lw=0.6, ls=":")
        ax.set_xlabel("actual reference amplitude (× nominal)"); ax.set_title(f"{target} macro-F1"); ax.set_ylim(0, 0.85)
    axes[0].legend(fontsize=7, loc="lower center"); axes[0].set_ylabel("macro-F1 (mean of 3 dataset seeds)")
    fig.suptitle("Two-point MLP vs reference amplitude (dotted line = 0.85 × nominal-known layer F1)"); fig.tight_layout()
    fig.savefig(args.figures / "fig1_amplitude_curves.png", dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 4.2))
    w = 0.38
    for j, a in enumerate((80, 120)):
        vals = [C_[f"{x}|a{a}"]["cross_confusion"] for x in XS]
        ax.bar(np.arange(len(XS)) + (j - 0.5) * w, vals, w, label=f"×{a / 100:.1f}")
    ax.axhline(0.15, color="r", ls="--", lw=1, label="criterion C (0.15)")
    unm = [cross_confusion(st, [sc("assumed", a)], "two_point_mlp@A1c")[2] for a in (80, 120)]
    ax.set_xticks(range(len(XS))); ax.set_xticklabels(["known", "E=0%", "E=1%", "E=2%", "E=5%"]); ax.set_ylabel("AFE↔ADC cross-confusion")
    ax.set_title(f"Cross-confusion at ±20% reference (unmonitored: {unm[0]:.2f} / {unm[1]:.2f})"); ax.legend(fontsize=8); fig.tight_layout()
    fig.savefig(args.figures / "fig2_cross_confusion.png", dpi=150); plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.4), sharey=True)
    for ax, x in zip(axes, ("mon2", "known")):
        p = part2[part2.variant == x]
        for setting, c in (("BB", "#2a9d5c"), ("BS", "#c0504d"), ("MS", "#2f6db5")):
            r = p[p.setting == setting].iloc[0]
            ax.plot(xa, [r[f"layer_f1_x{a:.1f}"] for a in xa], marker="o", color=c, label=setting)
        ax.set_xlabel("actual reference amplitude (× nominal)"); ax.set_title(f"layer macro-F1, {'monitor E=2% (matched)' if x == 'mon2' else 'known reference'}")
    axes[0].set_ylabel("macro-F1"); axes[0].legend(); axes[0].set_ylim(0, 0.85); fig.tight_layout()
    fig.savefig(args.figures / "fig3_domain_transfer.png", dpi=150); plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.4), sharey=True)
    names = [("two_point_mlp@A1m2", "two-point A1"), ("two_point_mlp@A0", "two-point A0"), ("afe_only_mlp@A1m2", "AFE-only A1"), ("adc_only_mlp@A1m2", "ADC-only A1"),
             ("single_mlp@A0", "single probe"), ("passive_mlp@A0", "passive")]
    for ax, a in zip(axes, (80, 120)):
        vals = [point(st, [sc("mon2", a)], m, "layer")[0] for m, _ in names]
        ax.bar(range(len(names)), vals, color=["#2f6db5", "#888888", "#e0a060", "#d08080", "#bbbb66", "#bbbbbb"])
        ax.set_xticks(range(len(names))); ax.set_xticklabels([n for _, n in names], rotation=40, ha="right", fontsize=8); ax.set_title(f"layer macro-F1 at ×{a / 100:.1f}, monitor E=2%")
    axes[0].set_ylabel("macro-F1"); fig.tight_layout(); fig.savefig(args.figures / "fig4_baselines_mon2.png", dpi=150); plt.close(fig)

    print(json.dumps({k: crit[k] for k in ("N_nominal_known_layer_macro_f1", "failed_criteria", "decision")}, indent=1))
    for k in ("A", "C", "D"):
        print(k, "pass" if crit[k]["pass"] else "FAIL")
    print("B", "pass" if crit["B"]["pass"] else "FAIL", "| failed B items:", [k for k, v in crit["B"]["detail"].items() if not v["pass"]][:12])
    print("E primary:", json.dumps(crit["E"]["primary_matched_E2"], default=float))


if __name__ == "__main__":
    main()
