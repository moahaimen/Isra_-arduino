"""Regenerate the number registry, the evidence verification, Figures 1-10 and the preparation tables
from the frozen evidence package (no simulation, no training).

    python3 mdpi_sensors_preparation/scripts/build_figures_tables.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import figures  # noqa: E402
import tables  # noqa: E402
import verify  # noqa: E402
from common import OUT  # noqa: E402
from registry_build import build  # noqa: E402

R, extra = build()
summary, ff, rec = verify.main(R)
if summary["evidence_files_hash_mismatch"] or summary["recomputed_mismatches"] or summary["facts_mismatch"]:
    raise SystemExit(f"verification failed: {summary}")
print(f"evidence verified: {summary['recomputed_quantities']} quantities recomputed from predictions, 0 mismatches")
figures.build_all(R, extra)
tables.build_all(R)
R.to_csv(OUT / "NUMBER_PROVENANCE_MDPI.csv")
print("figures and tables written to", OUT)
