"""Exact decimal rounding for reported numbers.

Binary floating point stores many exact decimal ties slightly below or above the tie (for example
1287/13200 = 0.0975 is stored as 0.09749999...), so format(x, ".3f") can round in the wrong direction.
Every reported number is therefore rounded in two steps:
  1. the binary value is converted to a decimal with 12 significant digits, which removes representation
     noise (all reported quantities are computed with errors far below 1e-12);
  2. that decimal is rounded once to the reported number of places, half to even (ROUND_HALF_EVEN), the same
     rule as mdpi_sensors_preparation/scripts/common.py.
Differences are always computed from unrounded values first.
"""
from __future__ import annotations

from decimal import ROUND_HALF_EVEN, Decimal


def exact_decimal(x: float) -> Decimal:
    return Decimal(format(float(x), ".12g"))


TIES: list = []   # every exact tie met while formatting (value, decimals, printed)


def round_str(x: float, decimals: int = 3, signed: bool = False) -> str:
    q = Decimal(1).scaleb(-decimals)
    if is_tie(x, decimals):
        TIES.append((format(float(x), ".12g"), decimals))
    d = exact_decimal(x).quantize(q, rounding=ROUND_HALF_EVEN)
    if d == 0:
        d = abs(d)
    s = f"{d:f}"
    if signed and not s.startswith("-"):
        s = "+" + s
    return s


def is_tie(x: float, decimals: int = 3) -> bool:
    """True if the 12-significant-digit value lies exactly half-way between two reportable values."""
    d = exact_decimal(x).scaleb(decimals)
    return (d - d.to_integral_value(rounding="ROUND_FLOOR")) == Decimal("0.5")
