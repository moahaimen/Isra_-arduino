"""Recompute every number used in the manuscript from the saved per-record predictions.

Run from this folder:  python3 values.py
Writes values.json (unrounded values) and values_check.csv (comparison with the stored summary files).

Aggregation follows the frozen analysis code (src/summarize_reference_monitor.py):
  * per dataset seed and initialisation seed, the confusion matrices of all pooled cells
    (amplitudes x phases) are summed and the metric is computed once;
  * the metric is averaged over the two initialisations and then over the three dataset seeds;
  * paired differences use a condition-level cluster bootstrap (5000 multinomial resamples of the
    88 test conditions per seed, the same weights for both arms); the pooled CI is the 2.5/97.5
    percentile of the mean of the three per-seed bootstrap differences.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
RES = HERE.parent / "evidence_package_2026-10-26" / "phase_robust_final" / "phase_robust_results"
SEEDS = (20261026, 20261027, 20261028)
INITS = (11, 22)
PH = ("000", "250", "500", "750", "999")
PHV = (0.0, 0.25, 0.5, 0.75, 0.999)
AMP_BH = (80, 90, 100, 110, 120)
AMP_SP = (80, 100, 120)
K = {"layer": 4, "fault": 9}
NB = 5000

P = {s: dict(np.load(RES / f"seed_{s}" / "predictions.npz")) for s in SEEDS}
_cache = {}


def cm_cond(s, scn, model, target):
    key = (s, scn, model, target)
    if key not in _cache:
        z = P[s]
        y, cond = z[f"y_{target}"].astype(int), z["cond"]
        conds = np.unique(cond)
        idx = np.searchsorted(conds, cond)
        out = []
        for i in INITS:
            cm = np.zeros((len(conds), K[target], K[target]))
            np.add.at(cm, (idx, y, z[f"{scn}|{model}|{i}|{target}"].astype(int)), 1)
            out.append(cm)
        _cache[key] = out
    return _cache[key]


def cm_multi(s, scns, model, target):
    parts = [cm_cond(s, sc, model, target) for sc in scns]
    return [sum(p[i] for p in parts) for i in range(len(INITS))]


def f1(cm):
    tp = np.einsum("...kk->...k", cm)
    den = cm.sum(-1) + cm.sum(-2)
    return np.where(den > 0, 2 * tp / np.where(den > 0, den, 1), 0.0).mean(-1)


def bacc(cm):
    row = cm.sum(-1)
    return np.nanmean(np.where(row > 0, np.einsum("...kk->...k", cm) / np.where(row > 0, row, 1), np.nan), -1)


def recall_vec(cm):
    return np.einsum("...kk->...k", cm) / cm.sum(-1)


MET = {"f1": f1, "bacc": bacc}


def point(scns, model, target, metric="f1"):
    vals = [np.mean([MET[metric](c.sum(0)) for c in cm_multi(s, scns, model, target)]) for s in SEEDS]
    return float(np.mean(vals)), [float(v) for v in vals]


def recall_point(scns, model, target):
    return np.mean([np.mean([recall_vec(c.sum(0)) for c in cm_multi(s, scns, model, target)], 0) for s in SEEDS], 0)


def pooled_cm(scns, model, target="layer"):
    tot = 0
    for s in SEEDS:
        tot = tot + np.mean([c.sum(0) for c in cm_multi(s, scns, model, target)], axis=0)
    return tot


def cross(scns, model):
    cm = pooled_cm(scns, model)
    return float(cm[2, 2] / cm[2].sum()), float(cm[3, 3] / cm[3].sum()), float((cm[2, 3] + cm[3, 2]) / (cm[2].sum() + cm[3].sum()))


def compare(scnA, mA, scnB, mB, target="layer", metric="f1"):
    boots, pts = [], []
    for s in SEEDS:
        A_, B_ = cm_multi(s, scnA, mA, target), cm_multi(s, scnB, mB, target)
        nc = A_[0].shape[0]
        W = np.random.default_rng([int(s), 0 if target == "layer" else 1]).multinomial(nc, np.full(nc, 1.0 / nc), size=NB).astype(float)
        fa = np.mean([MET[metric](np.einsum("bn,nkl->bkl", W, c)) for c in A_], axis=0)
        fb = np.mean([MET[metric](np.einsum("bn,nkl->bkl", W, c)) for c in B_], axis=0)
        boots.append(fa - fb)
        pts.append(float(np.mean([MET[metric](c.sum(0)) for c in A_]) - np.mean([MET[metric](c.sum(0)) for c in B_])))
    pooled = np.mean(boots, axis=0)
    return {"diff": float(np.mean(pts)), "lo": float(np.percentile(pooled, 2.5)), "hi": float(np.percentile(pooled, 97.5)),
            "per_seed": pts, "consistent": bool(all(p > 0 for p in pts) or all(p < 0 for p in pts))}


def vs(v):
    return "k" if v in ("known", "assumed") else "e" + v[3:]


def M(arm, v, path="two_point"):
    return "two_point_mlp@A0" if arm == "A0" and path == "two_point" else f"{path}_mlp@{arm}_{vs(v)}"


def cells(dom, amps, v, phases=PH):
    return [f"{dom}_a{a}_p{p}_{v}" for a in amps for p in phases]


AMPS = {"bh": AMP_BH, "sp": AMP_SP}
V = {}

# ---- headline and attribution arms (E = 2 %, pooled over the domain's amplitudes and phases)
for dom in ("bh", "sp"):
    for arm in ("A0", "R1", "R1r", "PR", "PRr", "PRrM"):
        if dom == "sp" and arm == "A0":
            continue
        m = M(arm, "mon2")
        sc = cells(dom, AMPS[dom], "mon2")
        d = {"layer_f1": point(sc, m, "layer")[0], "layer_bacc": point(sc, m, "layer", "bacc")[0],
             "fault_f1": point(sc, m, "fault")[0], "fault_bacc": point(sc, m, "fault", "bacc")[0],
             "layer_f1_per_seed": point(sc, m, "layer")[1], "fault_f1_per_seed": point(sc, m, "fault")[1]}
        d["per_phase"] = [point(cells(dom, AMPS[dom], "mon2", (p,)), m, "layer")[0] for p in PH]
        d["spread"] = max(d["per_phase"]) - min(d["per_phase"])
        d["fault_recall"] = recall_point(sc, m, "fault").tolist()
        d["layer_recall"] = recall_point(sc, m, "layer").tolist()
        V[f"arm|{dom}|{arm}"] = d
    # gate G variants
    for arm in ("R1", "PRr", "PRrM", "A0"):
        if dom == "sp" and arm == "A0":
            continue
        for v in ("known", "mon2"):
            pp = [point(cells(dom, AMPS[dom], v, (p,)), M(arm, v), "layer")[0] for p in PH]
            V[f"G|{dom}|{arm}|{v}"] = {"per_phase": pp, "spread": max(pp) - min(pp)}

V["N"] = {dom: point(cells(dom, (100,), "known"), M("PRr", "known"), "layer")[0] for dom in ("bh", "sp")}

# ---- amplitude curves (pooled over phases)
for dom in ("bh", "sp"):
    for arm, v in (("PRr", "known"), ("PRr", "mon0"), ("PRr", "mon1"), ("PRr", "mon2"), ("PRr", "mon5"), ("R1", "known"), ("A0", "known"), ("PRrM", "mon2")):
        if dom == "sp" and arm == "A0":
            continue
        V[f"amp|{dom}|{arm}|{v}"] = {a: point(cells(dom, (a,), v), M(arm, v), "layer")[0] for a in AMPS[dom]}
        V[f"ampfault|{dom}|{arm}|{v}"] = {a: point(cells(dom, (a,), v), M(arm, v), "fault")[0] for a in AMPS[dom]}
V["amp|bh|nomon"] = {a: point(cells("bh", (a,), "assumed"), M("PRr", "known"), "layer")[0] for a in AMP_BH}
V["ampfault|bh|nomon"] = {a: point(cells("bh", (a,), "assumed"), M("PRr", "known"), "fault")[0] for a in AMP_BH}
V["recall|bh|nomon"] = recall_point(cells("bh", (80, 120), "assumed"), M("PRr", "known"), "layer").tolist()

# ---- gates A, C, D (PRr)
for dom in ("bh", "sp"):
    for v in ("known", "mon0", "mon1", "mon2", "mon5"):
        for a in (80, 120):
            f = point(cells(dom, (a,), v), M("PRr", v), "layer")[0]
            afe, adc, x = cross(cells(dom, (a,), v), M("PRr", v))
            V[f"AC|{dom}|{v}|{a}"] = {"f1": f, "ret": f / V["N"][dom], "afe": afe, "adc": adc, "cross": x}
    f = point(cells(dom, AMPS[dom], "mon5"), M("PRr", "mon5"), "layer")[0]
    V[f"D|{dom}|pooled"] = {"f1": f, "ret": f / V["N"][dom]}
for a in (80, 120):
    afe, adc, x = cross(cells("bh", (a,), "assumed"), M("PRr", "known"))
    V[f"AC|bh|assumed|{a}"] = {"afe": afe, "adc": adc, "cross": x}

# ---- baselines (behavioral, known reference unless stated, pooled over phases)
BL = [("passive", "passive_mlp@A0"), ("single", "single_mlp@A0"), ("afe_only_A0", "afe_only_mlp@A0"), ("adc_only_A0", "adc_only_mlp@A0"),
      ("two_point_A0", "two_point_mlp@A0"), ("afe_only_PRr", "afe_only_mlp@PRr_k"), ("adc_only_PRr", "adc_only_mlp@PRr_k"),
      ("R1", "two_point_mlp@R1_k"), ("R1r", "two_point_mlp@R1r_k"), ("PR", "two_point_mlp@PR_k"), ("PRr", "two_point_mlp@PRr_k"),
      ("PRrM", "two_point_mlp@PRrM_k")]
for name, m in BL:
    V[f"base|{name}"] = {a: point(cells("bh", (a,), "known"), m, "layer")[0] for a in (80, 120)}
for a in (80, 120):
    for name, m in BL[:7]:
        V[f"B|known|{a}|{name}"] = compare(cells("bh", (a,), "known"), M("PRr", "known"), cells("bh", (a,), "known"), m)
# full B over every monitor variant (supplementary table)
for v in ("known", "mon0", "mon1", "mon2", "mon5"):
    for a in (80, 120):
        bl = [("two_point_A0", "two_point_mlp@A0"), ("passive", "passive_mlp@A0"), ("single", "single_mlp@A0"), ("afe_only_A0", "afe_only_mlp@A0"),
              ("adc_only_A0", "adc_only_mlp@A0"), ("afe_only_PRr", M("PRr", v, "afe_only")), ("adc_only_PRr", M("PRr", v, "adc_only"))]
        for name, m in bl:
            V[f"Bfull|{v}|{a}|{name}"] = compare(cells("bh", (a,), v), M("PRr", v), cells("bh", (a,), v), m)

# ---- attribution (E = 2 %, pooled)
ATT = [("PR-R1", "PR", "R1"), ("R1r-R1", "R1r", "R1"), ("PRr-R1r", "PRr", "R1r"), ("PRr-PR", "PRr", "PR"), ("PRr-R1", "PRr", "R1"),
       ("PRrM-PRr", "PRrM", "PRr"), ("PRr-A0", "PRr", "A0")]
for dom in ("bh", "sp"):
    sc = cells(dom, AMPS[dom], "mon2")
    for name, a, b in ATT:
        if dom == "sp" and "A0" in (a, b):
            continue
        V[f"att|{dom}|{name}"] = compare(sc, M(a, "mon2"), sc, M(b, "mon2"))
        V[f"attfault|{dom}|{name}"] = compare(sc, M(a, "mon2"), sc, M(b, "mon2"), "fault")

# ---- transfer (matched grid x0.8, x1.0, x1.2 x five phases)
for v in ("known", "mon0", "mon1", "mon2", "mon5"):
    gb, gs = cells("bh", AMP_SP, v), cells("sp", AMP_SP, v)
    m, mm = M("PRr", v), M("PRrM", v)
    V[f"E|{v}"] = {"BB": point(gb, m, "layer")[0], "BS": point(gs, m, "layer")[0], "MS": point(gs, mm, "layer")[0],
                   "MB": point(gb, mm, "layer")[0],
                   "BBf": point(gb, m, "fault")[0], "BSf": point(gs, m, "fault")[0],
                   "drop": compare(gb, m, gs, m), "drop_fault": compare(gb, m, gs, m, "fault"),
                   "MS_BS": compare(gs, mm, gs, m), "mixed_drop": compare(gb, m, gs, mm)}
    V[f"Ephase|{v}"] = {dom: {arm: [point(cells(dom, AMP_SP, v, (p,)), M(arm, v), "layer")[0] for p in PH] for arm in ("PRr", "PRrM", "R1")}
                        for dom in ("bh", "sp")}

(HERE / "values.json").write_text(json.dumps(V, indent=1, default=float))

# ---- check against the stored summary files
rows = []
dr = json.loads((RES / "decision_rules.json").read_text())
def chk(name, mine, stored, tol):
    rows.append(dict(quantity=name, recomputed=mine, stored=stored, abs_diff=abs(mine - stored), ok=abs(mine - stored) <= tol))
chk("N bh", V["N"]["bh"], dr["N"]["bh"], 1e-12); chk("N sp", V["N"]["sp"], dr["N"]["sp"], 1e-12)
for v in ("known", "mon0", "mon1", "mon2", "mon5"):
    for q in ("BB", "BS", "MS"):
        chk(f"E {v} {q}", V[f"E|{v}"][q], dr["E"]["all"][v][q], 1e-12)
    chk(f"E {v} drop", V[f"E|{v}"]["drop"]["diff"], dr["E"]["all"][v]["drop"], 1e-12)
    chk(f"E {v} drop lo", V[f"E|{v}"]["drop"]["lo"], dr["E"]["all"][v]["drop_ci"][0], 1e-12)
    chk(f"E {v} drop hi", V[f"E|{v}"]["drop"]["hi"], dr["E"]["all"][v]["drop_ci"][1], 1e-12)
for k, d in dr["B"]["detail"].items():
    x, a, b = k.split("|")
    b = b.replace("vs ", "")
    name = {"two_point_mlp@A0": "two_point_A0", "passive_mlp@A0": "passive", "single_mlp@A0": "single", "afe_only_mlp@A0": "afe_only_A0",
            "adc_only_mlp@A0": "adc_only_A0"}.get(b, "afe_only_PRr" if b.startswith("afe_only") else "adc_only_PRr")
    mine = V[f"Bfull|{x}|{a[1:]}|{name}"]
    chk(f"B {k} diff", mine["diff"], d["diff"], 1e-12); chk(f"B {k} lo", mine["lo"], d["ci_low"], 1e-12); chk(f"B {k} hi", mine["hi"], d["ci_high"], 1e-12)
for k, d in dr["C"]["detail"].items():
    dom, v, a = k.split("|")
    mine = V[f"AC|{dom}|{v}|{a[1:]}"]
    chk(f"C {k}", mine["cross"], d["cross_confusion"], 1e-12); chk(f"C {k} afe", mine["afe"], d["afe_recall"], 1e-12)
for k, d in dr["A"]["detail"].items():
    dom, v, a = k.split("|")
    chk(f"A {k}", V[f"AC|{dom}|{v}|{a[1:]}"]["f1"], d["f1"], 1e-12)
for k, d in dr["G"]["detail"].items():
    dom, arm, v = k.split("|")
    chk(f"G {k}", V[f"G|{dom}|{arm}|{v}"]["spread"], d["range"], 1e-12)
att = pd.read_csv(RES / "attribution_comparisons.csv")
amap = {"PR - R1 (descriptors alone)": "PR-R1", "R1r - R1 (phase randomisation alone)": "R1r-R1", "PRr - R1r (descriptors, given randomisation)": "PRr-R1r",
        "PRr - PR (randomisation, given robust descriptors)": "PRr-PR", "PRr - R1 (combination)": "PRr-R1", "PRrM - PRr (mixed training)": "PRrM-PRr",
        "PRr - A0 (vs old method)": "PRr-A0"}
for _, r in att.iterrows():
    mine = V[f"att|{r.domain}|{amap[r.comparison]}"]
    for q, col in (("diff", "diff"), ("lo", "ci_low"), ("hi", "ci_high")):
        chk(f"att {r.domain} {r.comparison} {q}", mine[q], r[col], 5.1e-5)
arms = pd.read_csv(RES / "attribution_arms.csv")
for _, r in arms.iterrows():
    mine = V[f"arm|{r.domain}|{r.arm}"]
    chk(f"arm {r.domain} {r.arm} layer", mine["layer_f1"], r.layer_macro_f1, 5.1e-5)
    chk(f"arm {r.domain} {r.arm} fault", mine["fault_f1"], r.fault_macro_f1, 5.1e-5)
    chk(f"arm {r.domain} {r.arm} lbacc", mine["layer_bacc"], r.layer_balanced_accuracy, 5.1e-5)
rf = pd.read_csv(RES / "per_class_recall_fault.csv")
for _, r in rf.iterrows():
    mine = V[f"arm|{r.domain}|{r.arm}"]["fault_recall"]
    for j, c in enumerate(rf.columns[2:]):
        chk(f"recall {r.domain} {r.arm} {c}", mine[j], r[c], 5.1e-5)
nm = json.loads((RES / "no_monitor_control.json").read_text())["no_monitor_control_layer_macro_f1"]
for a in AMP_BH:
    chk(f"nomon x{a/100:g}", V["amp|bh|nomon"][a], nm[f"x{a/100:.1f}"]["unmonitored"], 1e-12)
df = pd.DataFrame(rows)
df.to_csv(HERE / "values_check.csv", index=False)
print(f"{len(df)} checks, {int((~df.ok).sum())} failures")
if (~df.ok).any():
    print(df[~df.ok].to_string())


# ======================================================================================================
# Exact counts, last-digit report and tie scan (rounding: analysis/rounding.py)
# ======================================================================================================
import sys as _sys  # noqa: E402
from fractions import Fraction  # noqa: E402

_sys.path.insert(0, str(HERE))
from rounding import is_tie, round_str  # noqa: E402

# confusion matrices used by the manuscript build (fine-fault confusion of PRr, E = 2 %)
for _dom in ("bh", "sp"):
    np.save(HERE / f"cm_fault_PRr_{_dom}_E2.npy", pooled_cm(cells(_dom, AMPS[_dom], "mon2"), "two_point_mlp@PRr_e2", "fault"))


def _run_counts(scns, model, target="layer"):
    """Integer confusion matrix summed over all 3 dataset seeds x 2 initializations."""
    tot = np.zeros((K[target], K[target]))
    for s in SEEDS:
        for c in cm_multi(s, scns, model, target):
            tot += c.sum(0)
    return tot


def recall_fraction(scns, model, target, k):
    cm = _run_counts(scns, model, target)
    return (int(round(cm[k, k])), int(round(cm[k].sum())))


def cross_fraction(scns, model):
    cm = _run_counts(scns, model)
    return (int(round(cm[2, 3] + cm[3, 2])), int(round(cm[2].sum() + cm[3].sum())))


def _equal_denominators(scns, model, target, rows):
    """Recall/cross averaged over runs equals the pooled count ratio only if every run has the same row totals."""
    ns = [c.sum(0)[rows].sum() for s in SEEDS for c in cm_multi(s, scns, model, target)]
    return max(ns) == min(ns)


G = lambda d, a: cells(d, AMPS[d], "mon2")
FAULT_IDX = {"healthy": 0, "sensor_bias": 1, "sensor_gain": 2, "sensor_noise": 3, "afe_offset": 4, "afe_bandwidth": 5,
             "adc_offset": 6, "adc_gain": 7, "adc_clipping": 8}
LAYER_IDX = {"healthy": 0, "sensor": 1, "afe": 2, "adc": 3}
TOK = []   # token, description, stored 4-decimal value, full value, exact fraction or ''
stored = {"arms": pd.read_csv(RES / "attribution_arms.csv"), "amp": pd.read_csv(RES / "amplitude_curves.csv"),
          "sep": pd.read_csv(RES / "afe_adc_separation.csv"), "rl": pd.read_csv(RES / "per_class_recall_layer.csv"),
          "rf": pd.read_csv(RES / "per_class_recall_fault.csv"), "att": pd.read_csv(RES / "attribution_comparisons.csv")}
ARMNAME = {"R1": "R1", "R1r": "R1r", "PR": "PR", "PRr": "PRr", "PRrM": "PRrM", "A0": "A0"}


def _stored(tab, **kw):
    d = stored[tab]
    for k, v in kw.items():
        d = d[d[k] == v] if not isinstance(v, float) else d[np.isclose(d[k], v)]
    return d


def add(tok, desc, st, full, frac=None):
    TOK.append(dict(token=tok, quantity=desc, stored_four_decimal_value=st, full_precision_value=full,
                    exact_fraction=(f"{frac[0]}/{frac[1]} (counts over 3 seeds x 2 initializations)" if frac is not None else ""),
                    print_from_stored_value=round_str(st, 3), correct_print=round_str(full, 3),
                    exact_tie_at_3_decimals=is_tie(full) or (frac is not None and Fraction(frac[0], frac[1]) * 2000 % 2 == 1)))


a = V["arm|bh|R1r"]; add("ARM_bh_R1R_LBA", "FSr (R1r) behavioral layer balanced accuracy, E=2%, pooled", float(_stored("arms", domain="bh", arm="R1r").layer_balanced_accuracy.iloc[0]), a["layer_bacc"])
a = V["arm|sp|R1"]; add("ARM_sp_R1_FBA", "FS (R1) ngspice fault balanced accuracy, E=2%, pooled", float(_stored("arms", domain="sp", arm="R1").fault_balanced_accuracy.iloc[0]), a["fault_bacc"])
add("ARM_sp_PRR_P999", "PRr ngspice layer macro-F1 at psi=0.999, E=2%", float(_stored("arms", domain="sp", arm="PRr").layer_f1_p999.iloc[0]), V["arm|sp|PRr"]["per_phase"][4])
_att = stored["att"]
add("ATT_bh_MIXED", "PRrM - PRr behavioral, layer macro-F1", float(_att[(_att.domain == "bh") & _att.comparison.str.startswith("PRrM - PRr")]["diff"].iloc[0]), V["att|bh|PRrM-PRr"]["diff"])
add("ATT_sp_DESC", "PR - FS (R1) ngspice, layer macro-F1", float(_att[(_att.domain == "sp") & _att.comparison.str.startswith("PR - R1")]["diff"].iloc[0]), V["att|sp|PR-R1"]["diff"])
_amp = stored["amp"]
def _ampst(dom, series, target, col):
    return float(_amp[(_amp.domain == dom) & (_amp.series == series) & (_amp.target == target)][col].iloc[0])
add("AMP_bh_A0_old_fault_x11", "A0 behavioral fault macro-F1 at x1.1", _ampst("bh", "A0 old", "fault", "x1.1"), V["ampfault|bh|A0|known"][110])
for a_, col in ((90, "x0.9"), (100, "x1.0"), (120, "x1.2")):
    add(f"AMP_bh_PRr_known_layer_x{a_ // 10:02d}" if a_ != 100 else "AMP_bh_PRr_known_layer_x10", f"PRr known levels, behavioral layer macro-F1 at {col}", _ampst("bh", "PRr known", "layer", col), V["amp|bh|PRr|known"][a_])
add("AMP_bh_PRr_E5_layer_x10", "PRr E=5%, behavioral layer macro-F1 at x1.0", _ampst("bh", "PRr E=5%", "layer", "x1.0"), V["amp|bh|PRr|mon5"][100])
add("AMP_sp_PRr_E2_fault_x10", "PRr E=2%, ngspice fault macro-F1 at x1.0", _ampst("sp", "PRr E=2%", "fault", "x1.0"), V["ampfault|sp|PRr|mon2"][100])
add("AMP_sp_PRr_E5_fault_x12", "PRr E=5%, ngspice fault macro-F1 at x1.2", _ampst("sp", "PRr E=5%", "fault", "x1.2"), V["ampfault|sp|PRr|mon5"][120])
_sep = stored["sep"]
for tok, dom, arm, amp, q in (("SEP_bh_PRR_x1_ADC", "bh", "PRr", 100, "adc_recall"), ("SEP_sp_R1R_x08_X", "sp", "R1r", 80, "cross_confusion"),
                              ("SEP_sp_R1R_x12_AFE", "sp", "R1r", 120, "afe_recall"), ("SEP_sp_R1R_x12_ADC", "sp", "R1r", 120, "adc_recall"),
                              ("SEP_sp_PR_x08_ADC", "sp", "PR", 80, "adc_recall"), ("SEP_sp_PRR_x08_X", "sp", "PRr", 80, "cross_confusion"),
                              ("SEP_sp_PRR_x1_ADC", "sp", "PRr", 100, "adc_recall")):
    sc, m = cells(dom, (amp,), "mon2"), M(arm, "mon2")
    afe, adc, x = cross(sc, m)
    full = {"afe_recall": afe, "adc_recall": adc, "cross_confusion": x}[q]
    frac = cross_fraction(sc, m) if q == "cross_confusion" else recall_fraction(sc, m, "layer", 2 if q == "afe_recall" else 3)
    assert abs(frac[0] / frac[1] - full) < 1e-12, (tok, frac, full)
    st = float(_sep[(_sep.domain == dom) & (_sep.arm == arm) & np.isclose(_sep.amplitude, amp / 100)][q].iloc[0])
    add(tok, f"{'FSr' if arm == 'R1r' else arm} {dom} E=2% x{amp / 100:.1f} {q.replace('_', ' ')}", st, full, frac)
_rl, _rf = stored["rl"], stored["rf"]
for tok, dom, arm, cls in (("RL_bh_R1_HEALTHY", "bh", "R1", "healthy"), ("RL_bh_PR_AFE", "bh", "PR", "afe")):
    sc, m = G(dom, arm), M(arm, "mon2")
    assert _equal_denominators(sc, m, "layer", LAYER_IDX[cls])
    frac = recall_fraction(sc, m, "layer", LAYER_IDX[cls])
    full = V[f"arm|{dom}|{arm}"]["layer_recall"][LAYER_IDX[cls]]
    assert abs(frac[0] / frac[1] - full) < 1e-12
    st = float(_rl[(_rl.domain == dom) & (_rl.arm == arm) & (_rl.scope == "pooled E=2%")][cls].iloc[0])
    add(tok, f"{'FS' if arm == 'R1' else arm} {dom} layer recall, {cls}, E=2% pooled", st, full, frac)
for tok, dom, arm, cls in (("RF_bh_R1R_SENSOR_BIAS", "bh", "R1r", "sensor_bias"), ("RF_bh_PRRM_HEALTHY", "bh", "PRrM", "healthy"),
                           ("RF_bh_PRRM_SENSOR_BIAS", "bh", "PRrM", "sensor_bias"), ("RF_sp_PR_ADC_GAIN", "sp", "PR", "adc_gain")):
    sc, m = G(dom, arm), M(arm, "mon2")
    frac = recall_fraction(sc, m, "fault", FAULT_IDX[cls])
    full = V[f"arm|{dom}|{arm}"]["fault_recall"][FAULT_IDX[cls]]
    assert abs(frac[0] / frac[1] - full) < 1e-12
    st = float(_rf[(_rf.domain == dom) & (_rf.arm == arm)][cls].iloc[0])
    add(tok, f"{'FSr' if arm == 'R1r' else arm} {dom} fault recall, {cls}, E=2% pooled", st, full, frac)
for tok, key, q, desc, comp in (("ATT_bh_RAND_GIVEN_DESC_LO", "att|bh|PRr-PR", "lo", "PRr - PR behavioral, 95% CI lower bound", "PRr - PR ("),
                                ("ATT_bh_MIXED_HI", "att|bh|PRrM-PRr", "hi", "PRrM - PRr behavioral, 95% CI upper bound", "PRrM - PRr")):
    row = _att[(_att.domain == "bh") & _att.comparison.str.startswith(comp)]
    add(tok, desc + " (bootstrap recomputed with the original resampling seeds)", float(row["ci_low" if q == "lo" else "ci_high"].iloc[0]), V[key][q])
ld = pd.DataFrame(TOK)
ld["full_precision_value"] = ld.full_precision_value.map(lambda x: f"{x:.12g}")
ld.to_csv(HERE / "exact_fraction_crosscheck.csv", index=False)


# tie scan over every value stored in values.json (all reported numbers are drawn from it)
def _walk(o, path=""):
    if isinstance(o, dict):
        for k, v in o.items():
            yield from _walk(v, f"{path}|{k}" if path else str(k))
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from _walk(v, f"{path}[{i}]")
    elif isinstance(o, (int, float)) and not isinstance(o, bool):
        yield path, float(o)


ties = [dict(key=p, value=f"{x:.12g}", decimals=d, rounded=round_str(x, d)) for p, x in _walk(V) for d in (2, 3) if is_tie(x, d)]
pd.DataFrame(ties, columns=["key", "value", "decimals", "rounded"]).to_csv(HERE / "exact_ties.csv", index=False)
print(f"last-digit rows: {len(ld)}; exact ties at 2 or 3 decimals among stored values: {len(ties)}")
