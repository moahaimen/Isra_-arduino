#!/bin/sh
# Regenerate every result, figure, table and document of this package from the saved predictions.
# No simulation is rerun and no model is retrained.  Run from any directory:
#   sh run_all.sh                    everything except PDFs (any platform with Python 3.11+ and pandoc)
#   sh run_all.sh --pdf              plus PDFs through Microsoft Word for Mac (macOS only; route used for the delivered PDFs)
#   sh run_all.sh --pdf=libreoffice  plus PDFs through LibreOffice (any platform; layout may differ slightly)
set -e
cd "$(dirname "$0")"
PDF="$1"
command -v python3 >/dev/null 2>&1 || { echo "ERROR: python3 not found"; exit 1; }
command -v pandoc  >/dev/null 2>&1 || { echo "ERROR: pandoc not found on PATH (needed for the DOCX files)"; exit 1; }
python3 manuscript_build/check_environment.py
python3 source_code/verify_source_hashes.py
python3 analysis/values.py
python3 mdpi_sensors_preparation/scripts/build_figures_tables.py
python3 mdpi_sensors_preparation/scripts/last_digit_report.py
python3 manuscript_build/build_manuscript.py
python3 manuscript_build/build_supplementary.py
python3 manuscript_build/build_bib.py
python3 manuscript_build/build_reference_report.py
python3 manuscript_build/build_cover_letter.py
python3 manuscript_build/qc_manuscript.py
if [ -n "$PDF" ]; then
  python3 manuscript_build/export_pdfs.py "$PDF"
fi
echo "done"
