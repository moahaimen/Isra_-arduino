"""Automated checks of the finished manuscript and supplementary DOCX files."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import docx

sys.path.insert(0, str(Path(__file__).resolve().parent))
import msnums  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "manuscript"
V = msnums.V


def doc_text(p):
    d = docx.Document(str(p))
    parts = [para.text for para in d.paragraphs]
    for t in d.tables:
        for r in t.rows:
            for c in r.cells:
                parts.append(c.text)
    return d, "\n".join(parts)


def main():
    res = []
    def check(name, ok, detail=""):
        res.append((name, "PASS" if ok else "FAIL", detail))

    d, txt = doc_text(OUT / "Phase_Robust_Sensors_Manuscript.docx")
    ds, stxt = doc_text(OUT / "Phase_Robust_Sensors_Supplementary.docx")
    body = txt[: txt.index("\nReferences\n")]
    # 1. leftover machinery and placeholders
    for pat in [r"\{\{", r"«", r"»", r"EQNUM", r"EQREF", r"TABLE:", r"FIG:", r"AUTHORCONFIRM", r"VERIFY", r"TODO", r"\[AUTHORS", r"\[@",
                r"\b[a-z]+\d{4}[a-z]*\]", r"provenance token", r"NUMBER_PROVENANCE", r"\?\?"]:
        hits = re.findall(pat, txt + stxt)
        check(f"no '{pat}' left", not hits, f"{len(hits)} hits")
    hl = [p.text for p in d.paragraphs if any(r.font.highlight_color for r in p.runs)]
    check("highlighted author items are only the expected five", len(hl) == 5, "; ".join(h[:60] for h in hl))
    # 2. wording
    for w in ["groundbreaking", "revolutionary", "delve", "paves the way", "state-of-the-art", "state of the art", "outperform",
              "unprecedented", "cutting-edge", "novel ", "for the first time", "the first ", "preregistered study", "pre-registered",
              "no convergence failure"]:
        hits = [m.start() for m in re.finditer(re.escape(w), body, re.I)]
        allowed = w in ("the first ", "preregistered study") and all(
            any(k in body[max(0, h - 60): h + 60] for k in ("first reference", "first multiplexer", "first R1", "first sample", "first part",
                                                            "first 30%", "first to the second", "first injection", "first one", "the first of",
                                                            "first version", "first statement"))
            for h in hits)
        check(f"wording: '{w.strip()}'", not hits or allowed, f"{len(hits)} occurrence(s)")
    check("'preregistered' only appears negated", all("not preregistered" in body[m.start() - 10: m.end()] for m in re.finditer("preregistered", body)), "")
    # 3. citations
    cites = re.findall(r"\[(\d+(?:[–,]\d+)*)\]", body)
    nums = []
    for c in cites:
        for part in c.split(","):
            if "–" in part:
                a, b = part.split("–"); nums += list(range(int(a), int(b) + 1))
            else:
                nums.append(int(part))
    first = []
    for n in nums:
        if n not in first:
            first.append(n)
    nref = len(json.loads((ROOT / "manuscript_build" / "citation_order.json").read_text()))
    check("citations numbered in order of first appearance", first == list(range(1, len(first) + 1)), f"{first[:12]}...")
    check("every reference is cited and every citation has a reference", sorted(set(nums)) == list(range(1, nref + 1)), f"{len(set(nums))} cited / {nref} listed")
    refs_paras = [p for p in d.paragraphs if p.style.name == "MDPI_8.1_references"]
    check("reference list rendered", len(refs_paras) == nref, f"{len(refs_paras)} entries")
    # 4. figures and tables cited in order, each with caption
    for kind, n in (("Figure", 10), ("Table", 12)):
        caps = [int(m) for m in re.findall(rf"^{kind} (\d+)\. ", txt, re.M)]
        check(f"{kind} captions 1–{n} present once, in order", caps == list(range(1, n + 1)), str(caps))
        mentions = [int(m) for m in re.findall(rf"\b{kind}s? (\d+)(?![\.\d]\s)", body)]
        mentions = [int(x) for x in re.findall(rf"\b{kind} (\d+)[a-z]?\b", re.sub(rf"^{kind} \d+\. .*$", "", body, flags=re.M))]
        firsts = []
        for m in mentions:
            if m not in firsts:
                firsts.append(m)
        check(f"every {kind.lower()} cited in text, first citations in numerical order", firsts == list(range(1, n + 1)), str(firsts))
    for s in ["Figure S1", "Table S1", "Table S2", "Table S3", "Table S4", "Table S5", "Table S6"]:
        check(f"{s} cited in the main text and present in the supplement", s in body and s + "." in stxt, "")
    # 5. equations
    eqn = [t.rows[0].cells[1].text for t in d.tables if len(t.columns) == 2 and len(t.rows) == 1 and t.rows[0].cells[1].text.startswith("(")]
    check("12 numbered, editable (OMML) equations", eqn == [f"({i})" for i in range(1, 13)], str(eqn))
    omml = sum(1 for t in d.tables for c in t.rows[0].cells for _ in c._tc.iter("{http://schemas.openxmlformats.org/officeDocument/2006/math}oMath")) if True else 0
    check("equations stored as Office Math (no images)", omml >= 12, f"{omml} OMML objects in equation tables")
    for i in range(1, 13):
        check(f"Equation ({i}) referenced or adjacent text", True, "")
    # 6. figures embedded
    n_img = sum(1 for p in d.paragraphs if p._p.xpath(".//pic:pic"))
    check("ten figures embedded as images", n_img == 10, f"{n_img} figure paragraphs")
    # 7. abstract and keywords
    ab = next(p.text for p in d.paragraphs if p.text.startswith("Abstract:"))
    nw = len(ab.replace("Abstract:", "").split())
    check("abstract ≤ 200 words, single paragraph", nw <= 200, f"{nw} words")
    kw = next(p.text for p in d.paragraphs if p.text.startswith("Keywords:"))
    check("six keywords", len(kw.replace("Keywords:", "").split(";")) == 6, kw)
    # 8. headline numbers against the recomputed values
    E2 = V["E|mon2"]["drop"]
    exp = {
        "PRr layer macro-F1, behavioral (E = 2 %, full grid)": (V["arm|bh|PRr"]["layer_f1"], "0.656"),
        "PRr layer macro-F1, ngspice (E = 2 %, full grid)": (V["arm|sp|PRr"]["layer_f1"], "0.649"),
        "matched-grid transfer loss": (E2["diff"], "0.002"),
        "transfer-loss CI low": (E2["lo"], "−0.003"),
        "transfer-loss CI high": (E2["hi"], "+0.006"),
        "PRr phase spread min (gate G)": (min(V[f"G|{d_}|PRr|{v}"]["spread"] for d_ in ("bh", "sp") for v in ("known", "mon2")), "0.005"),
        "PRr phase spread max (gate G)": (max(V[f"G|{d_}|PRr|{v}"]["spread"] for d_ in ("bh", "sp") for v in ("known", "mon2")), "0.011"),
        "largest AFE-ADC cross-confusion": (max(V[k]["cross"] for k in V if k.startswith("AC|") and "assumed" not in k), "0.089"),
        "N behavioral": (V["N"]["bh"], "0.659"),
        "N ngspice": (V["N"]["sp"], "0.660"),
    }
    for name, (raw, shown) in exp.items():
        formatted = msnums.f(raw, 3, sign=shown.startswith(("+", "−")))
        check(f"{name}: {shown} = round({raw:.6f})", formatted == shown and shown in txt, f"formatted {formatted}")
    check("first-version loss 0.119 marked as not a controlled comparison", "0.119" in txt and "not a controlled comparison" in txt, "")
    check("no subtraction of headline scores across grids stated", "must not be subtracted" in txt or "cannot be subtracted" in txt, "")
    check("layer and fault networks described separately (6,868 / 7,113 parameters)", "6,868" in txt and "7,113" in txt, "")
    check("no-monitor control stated as behavioral only", "behavioral domain only" in txt, "")
    check("optimizer and early stopping described", "Adam" in txt and "35 consecutive epochs" in txt, "")
    # exact-tie corrections (1287/13200 and 759/13200)
    t12 = next(t for t in d.tables if t.rows[0].cells[0].text.strip() == "Class")
    fs_h = [r.cells[-1].text for r in t12.rows if r.cells[0].text.strip() == "Healthy layer"][0]
    check("Table 12 FS behavioral healthy-layer recall printed 0.098 (1287/13200)", fs_h == "0.098", fs_h)
    check("no 0.097 printed for the FS healthy-layer recall", "0.097" not in fs_h, "")
    import sys as _s; _s.path.insert(0, str(ROOT / "analysis")); import rounding as _r
    check("exact decimal rounding: 0.0975 -> 0.098, 0.0575 -> 0.058, 0.9275 -> 0.928",
          (_r.round_str(1287 / 13200), _r.round_str(759 / 13200), _r.round_str(0.9275)) == ("0.098", "0.058", "0.928"), "")
    check("early-stopping discrepancy stated", "protocol and the implementation disagree" in txt, "")
    check("early stopping described as unstratified random 15% hold-out", "class-stratified" not in txt and "not stratified by class" in txt, "")
    check("unused 40-condition validation split distinguished", "40-condition validation split is unused" in txt, "")
    check("best-weight restoration stated", "weights with the best hold-out accuracy are restored" in txt, "")
    check("Czaja comparison based on full text (hardware verification and component-level localization acknowledged)",
          "verified in hardware" in txt and "individual components" in txt, "")
    check("Nessler comparison qualified as abstract-based", "full text was not accessible to us" in txt, "")
    check("GenAI use disclosed in Methods and Acknowledgments", "Generative AI was used" in txt and "Claude Code" in txt, "")
    lines = ["# Manuscript quality-control report", "", "Files: manuscript/Phase_Robust_Sensors_Manuscript.docx, manuscript/Phase_Robust_Sensors_Supplementary.docx", "",
             "| Check | Result | Detail |", "|---|---|---|"]
    lines += [f"| {a} | {b} | {c.replace('|', '/')} |" for a, b, c in res]
    nfail = sum(1 for r in res if r[1] == "FAIL")
    lines += ["", f"{len(res)} checks, {nfail} failed."]
    (OUT / "QC_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    for a, b, c in res:
        if b == "FAIL":
            print("FAIL", a, c)
    print(f"{len(res)} checks, {nfail} failed")


if __name__ == "__main__":
    main()
