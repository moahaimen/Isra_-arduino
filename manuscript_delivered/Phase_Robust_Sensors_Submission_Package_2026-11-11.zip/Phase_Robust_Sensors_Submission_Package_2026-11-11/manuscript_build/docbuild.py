"""Shared machinery: token filling, citations, equations, pandoc conversion, Word post-processing, PDF export."""
from __future__ import annotations

import re
import shutil
import subprocess
import time
from copy import deepcopy
from pathlib import Path

import docx
from docx.enum.text import WD_COLOR_INDEX
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt

import msnums
import refs

ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = ROOT / "manuscript_build" / "template" / "tmpl.docx"
WORD_DIR = Path.home() / "Library" / "Containers" / "com.microsoft.Word" / "Data" / "Documents" / "pr_build"
TEXT_W = 10466      # full text width, dxa (21 cm - 2 x 1.27 cm)
COL_W, COL_IND = 7859, 2608   # MDPI text column


# ------------------------------------------------------------------ text preparation

def fill_tokens(s: str, extra: dict | None = None) -> str:
    vals = dict(msnums.N)
    if extra:
        vals.update(extra)

    def rep(m):
        key = m.group(1)
        if "." in key:
            a, b = key.split(".")
            return str(vals[a][int(b)])
        if key not in vals:
            raise KeyError(f"unknown token {key}")
        return str(vals[key])
    out = re.sub(r"\{\{([A-Za-z0-9_\-\.]+)\}\}", rep, s)
    assert "{{" not in out, "unfilled token"
    return out


def number_equations(s: str):
    labels = re.findall(r"#EQ:([a-z0-9]+)#", s)
    num = {lab: i + 1 for i, lab in enumerate(labels)}
    assert len(num) == len(labels), "duplicate equation label"
    s = re.sub(r"#EQ:([a-z0-9]+)#", lambda m: f"EQNUM{num[m.group(1)]}EQNUM", s)
    s = re.sub(r"EQREF:([a-z0-9]+)", lambda m: str(num[m.group(1)]), s)
    return s, num


def compress(nums):
    nums = sorted(set(nums))
    out, i = [], 0
    while i < len(nums):
        j = i
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
            j += 1
        out.append(f"{nums[i]}–{nums[j]}" if j - i >= 2 else ",".join(str(n) for n in nums[i:j + 1]))
        i = j + 1
    return "[" + ",".join(out) + "]"


def number_citations(s: str, order: list | None = None):
    order = list(order or [])
    def rep(m):
        keys = [k.strip() for k in m.group(1).split(",")]
        for k in keys:
            if k not in refs.REFS:
                raise KeyError(f"unknown reference {k}")
            if k not in order:
                order.append(k)
        return compress([order.index(k) + 1 for k in keys])
    s = re.sub(r"«cite:([^»]+)»", rep, s)
    assert "«" not in s and "»" not in s
    return s, order


def md_table(header, rows, align=None):
    align = align or ["l"] + ["c"] * (len(header) - 1)
    sep = {"l": ":--", "c": ":-:", "r": "--:"}
    lines = ["| " + " | ".join(header) + " |", "|" + "|".join(sep[a] for a in align) + "|"]
    lines += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(lines) + "\n"


def run_pandoc(md: str, out: Path, resource_dir: Path):
    require_pandoc()
    tmp = out.with_suffix(".md")
    tmp.write_text(md, encoding="utf-8")
    subprocess.run(["pandoc", str(tmp), "-f", "markdown+pipe_tables+tex_math_dollars-auto_identifiers", "-o", str(out),
                    "--reference-doc", str(TEMPLATE), "--resource-path", str(resource_dir)], check=True)
    return tmp


# ------------------------------------------------------------------ Word post-processing

def _set_cell_border(cell, **kw):
    tcPr = cell._tc.get_or_add_tcPr()
    b = tcPr.find(qn("w:tcBorders"))
    if b is None:
        b = OxmlElement("w:tcBorders")
        tcPr.append(b)
    for edge, sz in kw.items():
        el = b.find(qn(f"w:{edge}"))
        if el is None:
            el = OxmlElement(f"w:{edge}")
            b.append(el)
        el.set(qn("w:val"), "single" if sz else "nil")
        if sz:
            el.set(qn("w:sz"), str(sz))
            el.set(qn("w:space"), "0")
            el.set(qn("w:color"), "000000")


def _tbl_props(tbl, width, indent, grid):
    tblPr = tbl._tbl.tblPr
    for tag in ("w:tblStyle", "w:tblW", "w:tblInd", "w:tblBorders", "w:tblLayout", "w:jc", "w:tblLook", "w:tblCellMar"):
        el = tblPr.find(qn(tag))
        if el is not None:
            tblPr.remove(el)
    w = OxmlElement("w:tblW"); w.set(qn("w:w"), str(width)); w.set(qn("w:type"), "dxa"); tblPr.append(w)
    ind = OxmlElement("w:tblInd"); ind.set(qn("w:w"), str(indent)); ind.set(qn("w:type"), "dxa"); tblPr.append(ind)
    lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); tblPr.append(lay)
    mar = OxmlElement("w:tblCellMar")
    for side, v in (("left", 57), ("right", 57)):
        e = OxmlElement(f"w:{side}"); e.set(qn("w:w"), str(v)); e.set(qn("w:type"), "dxa"); mar.append(e)
    tblPr.append(mar)
    g = tbl._tbl.tblGrid
    for c in list(g):
        g.remove(c)
    for cw in grid:
        gc = OxmlElement("w:gridCol"); gc.set(qn("w:w"), str(cw)); g.append(gc)
    for row in tbl.rows:
        for cw, cell in zip(grid, row.cells):
            tcPr = cell._tc.get_or_add_tcPr()
            tcW = tcPr.find(qn("w:tcW"))
            if tcW is None:
                tcW = OxmlElement("w:tcW"); tcPr.insert(0, tcW)
            tcW.set(qn("w:w"), str(cw)); tcW.set(qn("w:type"), "dxa")


def _text_len(cell):
    return max([len(p.text) for p in cell.paragraphs] + [1])


def format_table(tbl, font_pt=9.0, narrow=False):
    ncol = len(tbl.columns)
    width, indent = (COL_W, COL_IND) if narrow else (TEXT_W, 0)
    per_char = 112 if font_pt >= 9 else (104 if font_pt >= 8.5 else (96 if font_pt >= 8 else 88))   # dxa per character, Palatino
    pad = 140
    minw, want = [], []
    for j in range(ncol):
        cells = [r.cells[j].text for r in tbl.rows]
        longest_word = max(len(w) for c in cells for w in (c.split() or [""]))
        body = [len(c) for c in cells[1:]] or [1]
        minw.append(longest_word * per_char * 1.3 + pad)
        want.append(max(min(max(body), 46), len(cells[0]) * 0.55) * per_char + pad)
    # scale the wanted widths to the table width without going below the minimum of any column
    grid = [max(m, w) for m, w in zip(minw, want)]
    for _ in range(20):
        free = [j for j in range(ncol) if grid[j] > minw[j]]
        excess = sum(grid) - width
        if abs(excess) < 2 or not free:
            break
        tot = sum(grid[j] for j in free)
        for j in free:
            grid[j] = max(minw[j], grid[j] - excess * grid[j] / tot)
    if sum(grid) > width:                      # minimum widths do not fit: scale everything
        grid = [g * width / sum(grid) for g in grid]
    grid = [int(g) for g in grid]
    grid[-1] += width - sum(grid)
    _tbl_props(tbl, width, indent, grid)
    nrow = len(tbl.rows)
    for i, row in enumerate(tbl.rows):
        trPr = row._tr.get_or_add_trPr()
        cs = OxmlElement("w:cantSplit"); trPr.append(cs)
        if i == 0:
            h = OxmlElement("w:tblHeader"); trPr.append(h)
        for cell in row.cells:
            _set_cell_border(cell, top=8 if i == 0 else 0, bottom=4 if i == 0 else (8 if i == nrow - 1 else 0), left=0, right=0)
            for p in cell.paragraphs:
                p.style = "MDPI_4.2_table_body"
                pf = p.paragraph_format
                pf.space_before = Pt(1); pf.space_after = Pt(1)
                pf.keep_with_next = (i < nrow - 1) if nrow <= 8 else (i == 0)
                for r in p.runs:
                    r.font.size = Pt(font_pt)
                    if i == 0:
                        r.font.bold = True


def build_equation_tables(d):
    """Turn every MDPI_3.9_equation paragraph carrying an EQNUMnEQNUM marker into the template's two-cell layout."""
    n = 0
    for p in list(d.paragraphs):
        if p.style.name != "MDPI_3.9_equation":
            continue
        xml = p._p.xml
        m = re.search(r"EQNUM(\d+)EQNUM", xml)
        if not m:
            continue
        num = m.group(1)
        for t in p._p.iter(qn("w:t")):
            if "EQNUM" in (t.text or ""):
                t.text = re.sub(r"\s*EQNUM\d+EQNUM\s*", "", t.text)
        for r in list(p._p.findall(qn("w:r"))):
            if not "".join(t.text or "" for t in r.iter(qn("w:t"))).strip() and r.find(qn("w:drawing")) is None:
                p._p.remove(r)
        tbl = d.add_table(rows=1, cols=2)
        _tbl_props(tbl, COL_W, COL_IND, [7159, 700])
        c0, c1 = tbl.rows[0].cells
        for c in (c0, c1):
            tcPr = c._tc.get_or_add_tcPr()
            va = OxmlElement("w:vAlign"); va.set(qn("w:val"), "center"); tcPr.append(va)
            _set_cell_border(c, top=0, bottom=0, left=0, right=0)
        c0._tc.remove(c0.paragraphs[0]._p)
        M = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"
        src = p._p
        if not list(src.iter(M + "oMath")):
            prev = src.getprevious()
            assert prev is not None and list(prev.iter(M + "oMath")), f"equation ({num}): math paragraph not found"
            src = prev
        newp = deepcopy(src)
        if src is not p._p:
            src.getparent().remove(src)
        c0._tc.append(newp)
        q = c1.paragraphs[0]; q.style = "MDPI_3.a_equation_number"; q.add_run(f"({num})")
        p._p.addprevious(tbl._tbl)
        p._p.getparent().remove(p._p)
        # equation inside the cell: no extra indent
        for e in c0._tc.iter(qn("w:ind")):
            e.set(qn("w:left"), "0")
        n += 1
    return n


def highlight_markers(d):
    """Text between ⟦ and ⟧ is an unresolved author item: keep it visible and highlighted."""
    count = 0
    for p in d.paragraphs:
        if "⟦" not in p.text:
            continue
        for r in p.runs:
            if "⟦" in r.text or "⟧" in r.text or count % 2 == 1:
                pass
        full = p.text
        # rebuild runs: split on markers
        segs = re.split(r"(⟦[^⟧]*⟧)", full)
        style_runs = p.runs
        bold_prefix = style_runs[0].bold if style_runs else None
        for r in style_runs:
            r._r.getparent().remove(r._r)
        first = True
        for sgm in segs:
            if not sgm:
                continue
            if sgm.startswith("⟦"):
                r = p.add_run(sgm[1:-1]); r.font.highlight_color = WD_COLOR_INDEX.YELLOW; count += 1
            else:
                # restore bold label "Xxx:" at the start of back-matter paragraphs
                mm = re.match(r"^([A-Z][A-Za-z ]+:)(.*)$", sgm, re.S) if first else None
                if mm:
                    rb = p.add_run(mm.group(1)); rb.bold = True
                    p.add_run(mm.group(2))
                else:
                    p.add_run(sgm)
            first = False
    return count


def keep_captions(d):
    for p in d.paragraphs:
        s = p.style.name
        if s in ("MDPI_4.1_table_caption", "MDPI_5.2_figure", "MDPI_2.1_heading1", "MDPI_2.2_heading2", "MDPI_2.3_heading3"):
            p.paragraph_format.keep_with_next = True
        if s == "MDPI_5.1_figure_caption":
            p.paragraph_format.keep_together = True


def tables_in_order(d):
    """Non-equation tables in document order."""
    out = []
    for t in d.tables:
        if len(t.columns) == 2 and len(t.rows) == 1 and t.rows[0].cells[1].paragraphs[0].style.name == "MDPI_3.a_equation_number":
            continue
        out.append(t)
    return out


# ------------------------------------------------------------------ PDF export through Microsoft Word

APPLESCRIPT = '''
on run argv
  set inPath to item 1 of argv
  set outPath to item 2 of argv
  tell application "Microsoft Word"
    open file name inPath
    delay 4
    set d to active document
    if (full name of d) is not inPath then error "active document is not " & inPath
    save as d file name outPath file format format PDF
    close d saving no
  end tell
end run
'''


class PdfExportError(RuntimeError):
    pass


def require_pandoc():
    if shutil.which("pandoc") is None:
        raise SystemExit("ERROR: pandoc was not found on PATH. Install pandoc 3.x (https://pandoc.org) and rerun.")


def export_pdf(docx_path: Path, pdf_path: Path, engine: str):
    """engine 'word' (Microsoft Word for Mac via AppleScript; the route used for the delivered PDFs) or
    'libreoffice' (soffice --headless; alternative route, layout may differ slightly)."""
    if engine == "word":
        return word_pdf(docx_path, pdf_path)
    if engine == "libreoffice":
        return libreoffice_pdf(docx_path, pdf_path)
    raise PdfExportError(f"unknown PDF engine {engine!r}")


def pdf_engine_from_argv(argv):
    if "--pdf" in argv or "--pdf=word" in argv:
        return "word"
    if "--pdf=libreoffice" in argv:
        return "libreoffice"
    return None


def libreoffice_pdf(docx_path: Path, pdf_path: Path):
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if exe is None:
        raise PdfExportError("PDF export with --pdf=libreoffice needs LibreOffice (soffice) on PATH; it was not found. "
                             "The DOCX files were written; only the PDF step was skipped.")
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        subprocess.run([exe, "--headless", "--convert-to", "pdf", "--outdir", td, str(docx_path)], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=600)
        shutil.copy(Path(td) / (docx_path.stem + ".pdf"), pdf_path)
    return pdf_path


def word_pdf(docx_path: Path, pdf_path: Path):
    import platform
    if platform.system() != "Darwin" or shutil.which("osascript") is None:
        raise PdfExportError("PDF export with --pdf uses Microsoft Word for Mac through AppleScript and runs only on macOS. "
                             "On other systems use --pdf=libreoffice or omit the PDF option. The DOCX files were written.")
    if not (Path("/Applications/Microsoft Word.app").exists() or (Path.home() / "Applications/Microsoft Word.app").exists()):
        raise PdfExportError("Microsoft Word for Mac was not found in /Applications. Install it, or use --pdf=libreoffice. "
                             "The DOCX files were written.")
    WORD_DIR.mkdir(parents=True, exist_ok=True)
    src = WORD_DIR / docx_path.name
    out = WORD_DIR / pdf_path.name
    shutil.copy(docx_path, src)
    if out.exists():
        out.unlink()
    scr = WORD_DIR / "export.applescript"
    scr.write_text(APPLESCRIPT)
    hfs = lambda p: "Macintosh HD" + str(p).replace("/", ":")
    r = subprocess.run(["osascript", str(scr), hfs(src), hfs(out)], capture_output=True, text=True, timeout=600)
    if r.returncode != 0:
        raise PdfExportError("Microsoft Word did not export the PDF (AppleScript error: " + r.stderr.strip() + "). "
                             "Check that the terminal may control Word (System Settings > Privacy & Security > Automation).")
    for _ in range(30):
        if out.exists() and out.stat().st_size > 0:
            break
        time.sleep(1)
    shutil.copy(out, pdf_path)
    return pdf_path
