"""Build Phase_Robust_Sensors_Supplementary.docx/.pdf (Figure S1, Tables S1–S6) from the saved predictions and results."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import docx
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import docbuild as B  # noqa: E402
from msnums import V, f, cmp, RES  # noqa: E402

ROOT = B.ROOT
OUT = ROOT / "manuscript"
NAME = "Phase_Robust_Sensors_Supplementary"
FAULTS = ["Healthy", "Sensor bias", "Sensor gain", "Sensor noise", "AFE offset", "AFE bandwidth", "ADC offset", "ADC gain", "ADC clipping"]
ARMS = ["A0", "R1", "R1r", "PR", "PRr", "PRrM"]
SHOW = {"R1": "FS", "R1r": "FSr"}
PHL = ["ψ = 0", "ψ = 0.25", "ψ = 0.5", "ψ = 0.75", "ψ = 0.999"]
COND = [("known", "Known levels"), ("mon0", "Monitor, *E* = 0%"), ("mon1", "Monitor, *E* = ±1%"), ("mon2", "Monitor, *E* = ±2%"), ("mon5", "Monitor, *E* = ±5%")]


def fig_s1(path: Path):
    src = open(ROOT / "analysis" / "values.py").read().split('AMPS = {"bh"')[0]
    ns = {"__file__": str(ROOT / "analysis" / "values.py")}
    exec(src, ns)
    fig, axs = plt.subplots(1, 2, figsize=(6.69, 3.35))
    plt.rcParams.update({"font.family": "sans-serif", "font.size": 7})
    short = ["H", "S-bias", "S-gain", "S-noise", "A-off", "A-bw", "D-off", "D-gain", "D-clip"]
    for ax, dom, title in zip(axs, ("bh", "sp"), ("(a) Behavioral", "(b) ngspice")):
        cm = ns["pooled_cm"](ns["cells"](dom, ns["AMPS"][dom] if "AMPS" in ns else ((80, 90, 100, 110, 120) if dom == "bh" else (80, 100, 120)), "mon2"),
                             "two_point_mlp@PRr_e2", "fault")
        cmn = cm / cm.sum(1, keepdims=True)
        ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
        for i in range(9):
            for j in range(9):
                ax.text(j, i, f(cmn[i, j], 2), ha="center", va="center", fontsize=5.2, color="white" if cmn[i, j] > 0.55 else "#1a1a1a")
        for (i, j) in [(a, b) for a in (0, 1, 2, 8) for b in (0, 1, 2, 8)]:
            pass
        ax.add_patch(plt.Rectangle((-0.5, -0.5), 3, 3, fill=False, ec="#d62728", lw=1.0))
        ax.set_xticks(range(9), short, rotation=60, ha="right", fontsize=6)
        ax.set_yticks(range(9), short if dom == "bh" else [""] * 9, fontsize=6)
        ax.set_xlabel("Predicted fault class", fontsize=7)
        if dom == "bh":
            ax.set_ylabel("True fault class", fontsize=7)
        ax.set_title(title, fontsize=8, loc="left", fontweight="bold")
        np.save(ROOT / "analysis" / f"cm_fault_PRr_{dom}_E2.npy", cm)
    fig.tight_layout()
    fig.savefig(path, dpi=600)
    fig.savefig(path.with_suffix(".pdf"))
    plt.close(fig)


def t_s1():
    hdr = ["Domain", "Arm", "Reference condition"] + PHL + ["Spread"]
    rows = []
    for dom, dl in (("bh", "Behavioral"), ("sp", "ngspice")):
        for arm in ARMS:
            k = f"arm|{dom}|{arm}"
            if k not in V:
                continue
            pp = V[k]["per_phase"]
            rows.append([dl, SHOW.get(arm, arm), "Monitor, *E* = ±2%"] + [f(x) for x in pp] + [f(max(pp) - min(pp))])
            g = V.get(f"G|{dom}|{arm}|known")
            if g:
                rows.append([dl, SHOW.get(arm, arm), "Known levels"] + [f(x) for x in g["per_phase"]] + [f(g["spread"])])
    return B.md_table(hdr, rows, ["l", "l", "l"] + ["c"] * 6)


def t_s2():
    hdr = ["Domain", "Reference condition", "Amplitude", "Layer macro-F1", "Retention", "AFE recall", "ADC recall", "Cross-confusion κ"]
    rows = []
    for dom, dl in (("bh", "Behavioral"), ("sp", "ngspice")):
        for v, lab in COND:
            for a in ("80", "120"):
                x = V[f"AC|{dom}|{v}|{a}"]
                rows.append([dl, lab, f"×{int(a) / 100:.1f}", f(x["f1"]), f(x["ret"]), f(x["afe"]), f(x["adc"]), f(x["cross"])])
    for a in ("80", "120"):
        x = V[f"AC|bh|assumed|{a}"]
        rows.append(["Behavioral", "No monitor (nominal levels assumed)", f"×{int(a) / 100:.1f}", f(V["amp|bh|nomon"][a]),
                     f(V["amp|bh|nomon"][a] / V["N"]["bh"]), f(x["afe"]), f(x["adc"]), f(x["cross"])])
    return B.md_table(hdr, rows, ["l", "l"] + ["c"] * 6)


def t_s3():
    hdr = ["Dom.", "Arm", "H", "S-bias", "S-gain", "S-noise", "A-offset", "A-bw", "D-offset", "D-gain", "D-clip", "H layer", "S layer", "AFE layer", "ADC layer"]
    rows = []
    for dom, dl in (("bh", "Bh."), ("sp", "ng.")):
        for arm in ARMS:
            k = f"arm|{dom}|{arm}"
            if k in V:
                rows.append([dl, SHOW.get(arm, arm)] + [f(x, 2) for x in V[k]["fault_recall"]] + [f(x, 2) for x in V[k]["layer_recall"]])
    rows.append(["Bh.", "PRr, no monitor"] + ["–"] * 9 + [f(x, 2) for x in V["recall|bh|nomon"]])
    return B.md_table(hdr, rows, ["l", "l"] + ["c"] * 13)


def t_s4():
    names = [("two_point_A0", "Two-point, A0"), ("passive", "Passive, A0"), ("single", "Single probe, A0"), ("afe_only_A0", "AFE-only, A0"),
             ("adc_only_A0", "ADC-only, A0"), ("afe_only_PRr", "AFE-only, PRr descriptors"), ("adc_only_PRr", "ADC-only, PRr descriptors")]
    hdr = ["Reference condition", "Amplitude"] + [n for _, n in names]
    rows = []
    for v, lab in COND:
        for a in ("80", "120"):
            rows.append([lab, f"×{int(a) / 100:.1f}"] + [cmp(V[f"Bfull|{v}|{a}|{k}"]) for k, _ in names])
    return B.md_table(hdr, rows, ["l", "c"] + ["c"] * 7)


def t_s5():
    tp = json.loads((RES / "timing_and_parameters.json").read_text())
    meta = {s: json.loads((RES / f"seed_{s}" / "meta.json").read_text()) for s in (20261026, 20261027, 20261028)}
    tr = []
    for s in meta:
        mi = json.loads((RES / f"seed_{s}" / "model_info.json").read_text())
        tr += [v["train_seconds"] for k, v in mi.items() if "@PRr_" in k and isinstance(v, dict) and "train_seconds" in v]
    rows = [["MLP architecture", "20 inputs, hidden layers of 96 and 48 ReLU units, 4 (layer) or 9 (fault) outputs"],
            ["MLP parameters", "6,868 (layer network); 7,113 (fault network)"],
            ["Multiply–accumulate operations per inference", "6,720 (layer); 6,960 (fault)"],
            ["Memory for the layer network (32-bit floating point)", "about 27 kB (derived from the parameter count)"],
            ["MLP inference time", f"{f(1000 * np.mean([v['mlp_predict_ms_per_sample'] for v in tp.values()]), 2)} µs per record (batched, Python, mean of three seeds)"],
            ["Descriptor extraction time", f"Phase-robust {f(np.mean([v['descriptor_extraction_ms_per_sample']['phase_robust'] for v in tp.values()]), 2)} ms; "
             f"Revision-1 {f(np.mean([v['descriptor_extraction_ms_per_sample']['revision1'] for v in tp.values()]), 2)} ms per record (Python, one core)"],
            ["Training time of PRr networks", f"mean {f(np.mean(tr), 2)} s, maximum {f(max(tr), 2)} s per network ({len(tr)} networks)"],
            ["ngspice runs", f"{meta[20261026]['n_ngspice_runs']:,} per seed; {sum(m['n_ngspice_runs'] for m in meta.values()):,} in total"]]
    for s, m in meta.items():
        rows.append([f"Run time, seed {s}", f"total {m['total_seconds']:.1f} s (ngspice {m['ngspice_wall_seconds']:.1f} s with {m['workers']} workers; behavioral {m['behavioral_seconds']:.1f} s)"])
    rows.append(["Not measured", "Microcontroller timing, memory footprint, energy, power and silicon area"])
    return B.md_table(["Quantity", "Value"], rows, ["l", "l"])


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def t_s6():
    ev = ROOT / "evidence_package_2026-10-26" / "phase_robust_final"
    rows = [["Python", "3.12.12"], ["NumPy", "2.2.6"], ["pandas", "2.3.3"], ["SciPy", "1.16.3"], ["scikit-learn", "1.7.2"],
            ["matplotlib (original run)", "3.10.7"], ["ngspice", "ngspice-47"], ["Platform", "macOS 27.0.1, arm64"],
            ["Source of the versions", "Reproducibility checklist generated on 14 October 2026, the day of the validation run, on the same machine; installation dates of ngspice-47 (3 October 2026) and scikit-learn 1.7.2 precede the run"]]
    for rel in ("PROTOCOL_PHASE_ROBUST_FROZEN.md", "phase_robust_results/decision_rules.json", "phase_robust_results/seed_20261026/predictions.npz",
                "phase_robust_results/seed_20261027/predictions.npz", "phase_robust_results/seed_20261028/predictions.npz",
                "phase_robust_results/source_hashes_at_freeze.txt"):
        rows.append([f"SHA-256 of {rel.split('/')[-1]}" + (f" ({rel.split('/')[-2]})" if "seed_" in rel else ""), sha(ev / rel)])
    return B.md_table(["Item", "Value"], rows, ["l", "l"])


TEXT = r"""
::: {custom-style="MDPI_1.1_article_type"}
*Supplementary Materials*
:::

::: {custom-style="MDPI_1.2_title"}
Phase-Robust Active Self-Test for Fault Localization in Mixed-Signal Sensor Interfaces: A Simulation Study — Supplementary Materials
:::

::: {custom-style="MDPI_1.3_authornames"}
**Moahaimen Talib**
:::

::: {custom-style="MDPI_3.1_text"}
This document provides the detailed results that support the main article. All values are simulation results recomputed from the saved per-record predictions of the three validation dataset seeds (20261026, 20261027 and 20261028) with the aggregation and bootstrap procedure described in Section 6.5 of the main article: confusion matrices of the pooled cells are summed per seed and initialization, the metric is averaged over two initializations and three seeds, and intervals are paired condition-level cluster-bootstrap 95% intervals with 5000 resamples per seed. Abbreviations are as in the main article.
:::

::: {custom-style="MDPI_2.1_heading1"}
S1. Fine-Fault Confusion of the Primary Method
:::

::: {custom-style="MDPI_5.2_figure"}
![](FIGS1){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure S1.** Row-normalized fine-fault confusion matrices of PRr with the monitor at *E* = ±2%, pooled over amplitudes and the five phases and averaged over three dataset seeds × two initializations, in (**a**) the behavioral and (**b**) the ngspice domain (simulation results). H, healthy; S, sensor; A, AFE; D, ADC. The red box marks healthy, sensor bias and sensor gain; together with ADC clipping these classes form the group that the references do not separate (Section 7.7 of the main article).
:::

::: {custom-style="MDPI_2.1_heading1"}
S2. Supplementary Tables
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table S1.** Layer macro-F1 per edge phase for every arm, pooled over each domain's amplitudes (behavioral ×0.8–×1.2, ngspice ×0.8, ×1.0, ×1.2). Spread = largest minus smallest of the five phases.
:::

TS1

::: {custom-style="MDPI_4.1_table_caption"}
**Table S2.** Layer macro-F1, retention relative to $N_d$, AFE and ADC recall and AFE–ADC cross-confusion of PRr at ±20% reference amplitude for every reference condition, pooled over the five phases.
:::

TS2

::: {custom-style="MDPI_4.1_table_caption"}
**Table S3.** Recall per fault class and per layer of every arm with the monitor at *E* = ±2%, pooled over amplitudes and phases. Bh., behavioral; ng., ngspice; H, healthy; S, sensor; A, AFE; D, ADC; bw, bandwidth; clip, clipping. The last row is the known-level PRr network applied without monitoring at ×0.8 and ×1.2.
:::

TS3

::: {custom-style="MDPI_4.1_table_caption"}
**Table S4.** All 70 comparisons of gate B (behavioral domain, pooled over the five phases): PRr minus the baseline in layer macro-F1 with cluster-bootstrap 95% intervals. The baseline networks with PRr descriptors are trained for the same reference condition as PRr.
:::

TS4

::: {custom-style="MDPI_4.1_table_caption"}
**Table S5.** Computational cost and run time. Timings are desktop measurements of a Python implementation.
:::

TS5

::: {custom-style="MDPI_4.1_table_caption"}
**Table S6.** Software environment and integrity of the evidence files.
:::

TS6

::: {custom-style="MDPI_4.3_table_footer"}
The SHA-256 hashes of all simulator and analysis source files at the protocol freeze are listed in source_hashes_at_freeze.txt; the current source files match them.
:::
"""


def main():
    OUT.mkdir(exist_ok=True)
    figdir = OUT / "figures"
    figdir.mkdir(exist_ok=True)
    fpath = figdir / "FigS1_fault_confusion.png"
    fig_s1(fpath)
    s = TEXT.replace("FIGS1", str(fpath))
    for k, fn in (("TS1", t_s1), ("TS2", t_s2), ("TS3", t_s3), ("TS4", t_s4), ("TS5", t_s5), ("TS6", t_s6)):
        s = s.replace(k, fn())
    out = OUT / f"{NAME}.docx"
    tmp = B.run_pandoc(s, out, figdir)
    tmp.unlink()
    d = docx.Document(str(out))
    for t in B.tables_in_order(d):
        nc = len(t.columns)
        B.format_table(t, font_pt=7.5 if nc >= 9 else (8.0 if nc >= 7 else 9.0), narrow=False)
    B.keep_captions(d)
    d.save(str(out))
    print("supplementary built")
    engine = B.pdf_engine_from_argv(sys.argv)
    if engine:
        try:
            B.export_pdf(out, out.with_suffix(".pdf"), engine)
            print(f"pdf written ({engine})")
        except B.PdfExportError as exc:
            print("PDF NOT WRITTEN:", exc)
            sys.exit(3)


if __name__ == "__main__":
    main()
