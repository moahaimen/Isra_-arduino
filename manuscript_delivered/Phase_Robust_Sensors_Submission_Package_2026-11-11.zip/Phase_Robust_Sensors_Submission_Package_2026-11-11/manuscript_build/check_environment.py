"""Print the software versions used for this build and stop with a clear message if a required package is missing."""
import platform
import shutil
import subprocess
import sys

missing = []
vers = {"python": platform.python_version(), "platform": platform.platform()}
for mod, name in (("numpy", "numpy"), ("pandas", "pandas"), ("matplotlib", "matplotlib"), ("docx", "python-docx"), ("PIL", "Pillow")):
    try:
        m = __import__(mod)
        vers[name] = getattr(m, "__version__", "installed")
    except ImportError:
        missing.append(name)
if sys.version_info < (3, 11):
    missing.append("Python >= 3.11 (found %s)" % platform.python_version())
pd = shutil.which("pandoc")
vers["pandoc"] = subprocess.run([pd, "--version"], capture_output=True, text=True).stdout.splitlines()[0] if pd else "NOT FOUND"
for tool in ("soffice", "osascript"):
    vers[tool] = "available" if shutil.which(tool) else "not available"
print("environment: " + "; ".join(f"{k} {v}" for k, v in vers.items()))
if missing or not pd:
    raise SystemExit("ERROR: missing required software: " + ", ".join(missing + ([] if pd else ["pandoc"])) +
                     ". See README.md (Requirements).")
