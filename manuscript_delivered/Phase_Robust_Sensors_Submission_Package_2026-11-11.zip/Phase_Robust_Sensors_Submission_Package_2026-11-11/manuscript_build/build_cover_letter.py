"""Write manuscript/Cover_Letter_DRAFT.docx from cover_letter.md (author items highlighted)."""
import re
import subprocess
from pathlib import Path

import docx
from docx.enum.text import WD_COLOR_INDEX

ROOT = Path(__file__).resolve().parents[1]
src = ROOT / "manuscript_build" / "cover_letter.md"
out = ROOT / "manuscript" / "Cover_Letter_DRAFT.docx"
import shutil
if shutil.which("pandoc") is None:
    raise SystemExit("ERROR: pandoc was not found on PATH. Install pandoc 3.x and rerun.")
subprocess.run(["pandoc", str(src), "-o", str(out)], check=True)
d = docx.Document(str(out))
for p in d.paragraphs:
    if "⟦" in p.text:
        for r in p.runs:
            if "⟦" in r.text or "⟧" in r.text or p.text.startswith("⟦"):
                r.text = r.text.replace("⟦", "").replace("⟧", "")
                r.font.highlight_color = WD_COLOR_INDEX.YELLOW
d.save(str(out))
print("cover letter ->", out)
