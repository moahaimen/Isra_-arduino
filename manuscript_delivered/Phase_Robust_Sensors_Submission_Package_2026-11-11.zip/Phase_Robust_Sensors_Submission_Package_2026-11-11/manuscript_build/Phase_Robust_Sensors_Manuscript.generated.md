::: {custom-style="MDPI_1.1_article_type"}
*Article*
:::

::: {custom-style="MDPI_1.2_title"}
Phase-Robust Active Self-Test for Fault Localization in Mixed-Signal Sensor Interfaces: A Simulation Study
:::

::: {custom-style="MDPI_1.3_authornames"}
**Moahaimen Talib**
:::

::: {custom-style="MDPI_1.6_affiliation"}
⟦Affiliation, postal address and corresponding-author e-mail to be confirmed by the author(s).⟧
:::

::: {custom-style="MDPI_1.7_abstract"}
**Abstract:** A sensor-interface fault can originate in the sensor, the analog front-end (AFE) or the analog-to-digital converter (ADC), yet the output record rarely shows where. This study examines an active self-test in which a monitored two-level reference replaces the sensor at the AFE input and a second reference bypasses the AFE at the ADC input. An earlier version failed a behavioral-to-circuit transfer test because its transient descriptors read fixed samples after the reference step and thus depended on where the step fell between samples. Those descriptors were replaced by quantities from a first-order fit with a free edge time, and a compact multilayer perceptron was trained with randomized edge phase. Under an internally frozen protocol with three unseen dataset seeds, nine fault classes, component tolerances, 12-bit quantization and five edge phases, layer macro-F1 was 0.656 in the behavioral model and 0.649 in ngspice. On a matched amplitude grid the transfer loss was 0.002 (95% CI [−0.003, +0.006]), the phase spread was 0.005–0.011 instead of about 0.08, and AFE–ADC cross-confusion stayed below 0.09 under ±20% reference error. Healthy records and sensor bias, sensor gain and inactive clipping faults remain poorly separated; the results support fault localization in simulation, not hardware-validated detection.
:::

::: {custom-style="MDPI_1.8_keywords"}
**Keywords:** active self-test; mixed-signal sensor interface; fault localization; sampling phase; reference monitoring; neural-network classification
:::

::: {custom-style="MDPI_1.9_line"}
 
:::

::: {custom-style="MDPI_2.1_heading1"}
1\. Introduction
:::

::: {custom-style="MDPI_3.1_text"}
A measurement made through a sensor interface passes through at least three electronic stages: the sensing element, an analog front-end (AFE) that amplifies and filters the signal, and an analog-to-digital converter (ADC). When the reading is wrong, the useful question for maintenance or for a safety mechanism is not only whether something is wrong but where. A sensor that has drifted calls for recalibration or replacement of the transducer; an AFE offset or a slowed filter points to the board; an ADC gain or reference problem points to the converter or its reference. In a passive record these causes can look alike. A gain error in the AFE and a gain error in the ADC both scale the output, and an offset added before or after the amplifier produces the same shifted waveform once the signal has been digitized. Without an additional, known excitation the chain is, in the language of system identification, not identifiable layer by layer.
:::

::: {custom-style="MDPI_3.1_text"}
Built-in self-test (BIST) addresses part of this problem by injecting a known stimulus. For MEMS sensors, electrical stimuli now replace physical ones for sensitivity characterization, and testing accounts for a large share of product cost [1–3]. Readout circuits have been given on-chip calibration and self-test functions [4–6], and some self-tests separate the readout ASIC from the sensor element by reconfiguring the readout [7]. For ADCs, test methods and terminology are standardized [8], and a substantial body of work deals with testing converters on-chip with imprecise stimuli or imprecise references [9–11]. What these approaches share is that the stimulus is designed for one block. Localizing a fault among the sensor, the AFE and the ADC of one interface, during operation and with references that are themselves uncertain, is a different task.
:::

::: {custom-style="MDPI_3.1_text"}
The architecture studied here uses two reference injection points to make the chain identifiable. A first multiplexer replaces the sensor by a two-level reference at the AFE input, so that its response passes through the AFE and the ADC. A second multiplexer injects a two-level reference directly at the ADC input, bypassing the AFE. The ADC transfer estimated in the second window can then be removed before the AFE transfer is estimated in the first, and sensor faults remain visible only in the intervals in which the sensor is connected. A buffered monitor channel measures the reference levels that were actually applied, because a reference whose amplitude has drifted would otherwise be indistinguishable from a gain fault. A compact neural network classifies descriptors extracted from these windows into the faulty layer and the fault class.
:::

::: {custom-style="MDPI_3.1_text"}
A first version of this test exposed a weakness that is easy to overlook. Its transient descriptors read the AFE response a fixed number of samples (2, 5, 10, 20 and 30 ms) after the reference step. In the discrete-time behavioral model the step coincided with a sample instant, whereas in the circuit-level ngspice model the switching edge fell 1 µs before the next sample, and a classifier trained on behavioral data lost 0.119 layer macro-F1 on ngspice data (95% CI [0.107, 0.132]). A diagnostic on a development seed attributed most of this loss to the sampling phase of the reference edge. In hardware the phase is not a modeling convention but a free and generally unknown quantity: unless the test-control logic and the converter share a clock with a fixed relation, the edge can fall anywhere within a sample period, and it can differ between devices or drift with time.
:::

::: {custom-style="MDPI_3.1_text"}
This article examines a remedy and evaluates it under a protocol fixed before the validation data were generated. The research question is whether descriptors estimated from the whole reference transient, with the edge time treated as a nuisance parameter, reduce the sensitivity of fault localization to the sampling phase in both simulation domains while preserving the separation of AFE and ADC faults under reference-amplitude error. The contributions are as follows:
:::

::: {custom-style="MDPI_3.7_itemize"}
an observability analysis of the two-point reference test that states which faults are identifiable from the two windows under explicit assumptions, and how a common reference-monitor gain error propagates into the estimated AFE and ADC parameters;
:::

::: {custom-style="MDPI_3.7_itemize"}
a set of phase-robust transient descriptors obtained from a variable-projection fit of a first-order step response with a free edge time, together with the conditions under which their invariance to ADC gain, offset and edge phase holds exactly and the evidence for how closely it holds otherwise;
:::

::: {custom-style="MDPI_3.7_itemize"}
an attribution study that separates the effect of the new descriptors from that of phase-randomized training on the same three unseen dataset seeds, in a behavioral model and in a per-record ngspice netlist;
:::

::: {custom-style="MDPI_3.7_itemize"}
an account of what the method does not achieve: the classes that remain poorly separated, the reason they are poorly separated, and the limits of a transfer test between two first-order models.
:::

::: {custom-style="MDPI_3.1_text"}
The study is a simulation study. No hardware was built and no physical sensor was measured; the ngspice domain uses the same first-order circuit topology as the behavioral model with switch resistances, additional noise and circuit-level edge handling. Section 2 reviews related work and states the research gap. Section 3 describes the electronic architecture and its observability. Section 4 covers reference monitoring, calibration and the descriptors, and Section 5 the classifier. Section 6 describes the simulation design and the evaluation protocol, Section 7 presents the results, and Section 8 discusses them together with their limitations. Section 9 concludes.
:::

::: {custom-style="MDPI_2.1_heading1"}
2\. Related Work and Research Gap
:::

::: {custom-style="MDPI_2.2_heading2"}
2.1. Self-Test of Sensors and Sensor Interfaces
:::

::: {custom-style="MDPI_3.1_text"}
Self-test of sensors has developed furthest for MEMS devices, where electrostatic actuation can emulate the physical stimulus. Hantos et al. classify MEMS BIST methods by ease of implementation, usefulness, test duration and power [1], following earlier overviews such as that of Mir et al. [2]. Ozel et al. showed that an electrical-stimulus-only BIST can characterize the sensitivity of a capacitive accelerometer to within 0.55% of the value obtained with a physical stimulus [3]. On the readout side, Mason et al. integrated self-test and online calibration into a capacitive readout chip [4], Chen et al. added a digital self-test function to a sigma-delta accelerometer interface [5], and Basith et al. used charge-controlled stimuli to detect structural defects [6]. Two works are closer to the question of localization. Nessler et al. reconfigured a gyroscope readout into a purely electrical sigma-delta loop so that the readout ASIC could be characterized separately from the sensor element at wafer level [7], and Feng et al. monitored an internal quadrature-error signal to obtain an online self-test during operation, because electrostatic self-test cannot run while the gyroscope is in use [12]. Reviews of sensor front-ends with self-monitoring and self-calibration capabilities place these functions in a wider design context [13].
:::

::: {custom-style="MDPI_3.1_text"}
These methods are designed around a particular transducer and either test it during a dedicated mode or reconfigure the readout. They establish that a known electrical stimulus can stand in for the physical quantity and that the readout can be isolated from the sensor, but they do not address a generic chain in which the fault may also lie in the converter and in which the reference used for the test may itself be wrong.
:::

::: {custom-style="MDPI_2.2_heading2"}
2.2. Mixed-Signal Self-Test, ADC Testing and Reference Uncertainty
:::

::: {custom-style="MDPI_3.1_text"}
In mixed-signal test, the closest work is the self-test of analog parts terminated by ADCs proposed by Czaja [14]. In test mode the sensor signal is disconnected and replaced by a square pulse generated by the microcontroller's timers. The system ADC samples the response of the analog part, with conversions triggered by a timer synchronized with the pulse, and the samples are mapped by a modified discrete Fourier transform onto localization curves from a simulation-generated fault dictionary. The method detects faults and localizes single soft faults to individual components of the analog part, and it was verified experimentally on a second-order filter with an 8-bit microcontroller and a 16-bit ADC. The ADC and its reference are assumed to be fault-free; in the experiment the reference voltage was checked with a multimeter. Hu et al. proposed a combined production test in which the analog portion is reconfigured into a triangle or sinusoidal oscillator whose output serves as the histogram stimulus of the ADC; a digital checker evaluates the oscillation frequency, amplitude and code histogram and accepts or rejects the chip [15]. They also note that gain errors in the analog portion and in the ADC can compensate each other and treat that case as unlikely. SymBIST monitors signals that are invariant by design, such as the sum of fully differential node voltages, against tolerance windows derived from Monte Carlo analysis; it was demonstrated by defect simulation on a 10-bit SAR ADC and can run off-line or on-line as a functional-safety mechanism [16]. Earlier work established hierarchical, block-level diagnosis of analog integrated circuits [17] and on-chip test cores that both generate stimuli and digitize periodic responses [18].
:::

::: {custom-style="MDPI_3.1_text"}
ADC testing itself is well developed. IEEE Std 1241 defines gain, offset and the associated test methods [8], and BIST architectures generate test signals on-chip [19,20]. A recurring difficulty is the accuracy of the stimulus and of the reference: the stimulus error identification and removal (SEIR) method tests linearity with stimuli that are less linear than the converter [9,10], and Varier and Sun extended it to relax the precision and constancy required of the reference voltage [11]. Online methods for SAR-ADC gain and offset errors and built-in self-calibration of DAC mismatch address the converter alone [21,22]. The sources of reference inaccuracy in CMOS, including mismatch, 1/f noise and mechanical stress, are well documented [23]. Taken together, this literature motivates treating the test reference as a measured quantity rather than as a known constant, which is the role of the reference monitor in the present architecture.
:::

::: {custom-style="MDPI_2.2_heading2"}
2.3. Data-Driven Analog Fault Diagnosis and Domain Shift
:::

::: {custom-style="MDPI_3.1_text"}
Neural-network diagnosis of analog circuits has a long history. Aminian and Aminian classified faulty components from wavelet and principal-component features of the impulse response [24] and later reported that features measured on actual circuits lie closer together than those obtained in simulation [25]; Yuan et al. used kurtosis and entropy of the output signals [26]. Deep models followed: deep belief networks [27,28], one-dimensional convolutional networks on raw responses [29], generative adversarial networks on wavelet spectra [30], residual networks on spectrum maps [31], deep forests motivated by the data demands of deep networks [32] and, more recently, contrastive representation learning [33]. Gao et al. addressed few-shot circuits with transfer learning [34], Zhang et al. used domain adaptation because varying conditions alter circuit parameters and reduce diagnostic accuracy [35], and Liu et al. optimized the test stimulus jointly with the classifier [36]. Recent reviews summarize the state of the field and its open problems [37,38].
:::

::: {custom-style="MDPI_3.1_text"}
In most of these studies the circuit under test is a filter or amplifier observed at its output, the ADC is part of the measuring instrument rather than a fault location, and the timing of the stimulus relative to the sampling grid is fixed by the acquisition system. Sensor-level work on self-validating sensors detects, isolates and recovers sensor failures from the output signals [39–41], and fault models for the analog side of smart systems have been formalized for simulation-based fault injection [42]. The concern of the present study, a nuisance timing variable that differs between simulation domains and between devices, is related to domain shift but is not addressed by adapting the classifier; it is addressed by designing the descriptors so that the nuisance variable does not enter them.
:::

::: {custom-style="MDPI_2.2_heading2"}
2.4. Timing of Transient Measurements
:::

::: {custom-style="MDPI_3.1_text"}
The dependence of sampled transient measurements on timing is familiar in instrumentation. IEEE Std 181 defines state levels and transition durations of pulse waveforms and the algorithms for computing them [43]. In time-interleaved ADCs, small differences between sampling instants are a dominant limitation and are calibrated explicitly [44]. Equivalent-time sampling exploits controlled sub-sample offsets to reconstruct fast waveforms, including with microcontroller ADCs [18,45], and sine-fitting methods for ADC testing estimate phase together with amplitude and offset [8,46]. The common idea, estimating timing jointly with the quantities of interest instead of assuming it, is the idea adopted here for the reference step. Separable least squares, in which the linear parameters are eliminated in closed form, provides an efficient way to do so [47,48].
:::

::: {custom-style="MDPI_2.2_heading2"}
2.5. Research Gap
:::

::: {custom-style="MDPI_3.1_text"}
The closest prior methods each cover part of the problem. Czaja's self-test shares the principle of replacing the sensor by a known stimulus and diagnosing from sampled responses, and it goes further than the present study in two respects: it localizes faults to individual components, and it was verified in hardware [14]. It treats the ADC and its reference as a sound measuring device rather than as a possible fault location, and it fixes the timing between stimulus and samples by triggering both from the microcontroller's timers. Hu et al. test the analog portion and the ADC together, but as a production test with a pass/fail decision that relies on reconfiguring the analog portion into an oscillator [15]. According to its abstract (the full text was not accessible to us), the work of Nessler et al. characterizes a readout separately from its sensor element, for one gyroscope architecture and at wafer level [7]. SymBIST runs on-line and reaches high defect coverage, but it flags the violation of an invariance rather than assigning the fault to a stage of a signal chain [16]. Within the literature reviewed here, we did not find an evaluation of an active test that assigns faults to the sensor, the AFE or the ADC of one chain, that treats the reference amplitude as uncertain and monitored, and that quantifies how the diagnosis depends on the sampling phase of the reference edge when stimulus and sampling are not synchronized, across a behavioral and a circuit-level model. The present work addresses that gap at simulation level. It does not claim a new BIST principle, a new classifier or superiority over the diagnosis methods above, which address different circuits and fault sets and are not compared directly.
:::

::: {custom-style="MDPI_2.1_heading1"}
3\. Electronic Architecture and Diagnostic Observability
:::

::: {custom-style="MDPI_2.2_heading2"}
3.1. Signal Chain and Fault Model
:::

::: {custom-style="MDPI_3.1_text"}
Figure 1 shows the simulated interface. A physical sensor produces a slowly varying signal around a condition-dependent baseline. Multiplexer 1 (switches S1 and S2) either connects the sensor to the AFE or replaces it by the two-level reference R1. The AFE is modeled as a gain stage with offset and a first-order RC low-pass filter. Multiplexer 2 (S3 and S4) either passes the AFE output to the ADC or replaces it by the two-level reference R2. The ADC is a 12-bit converter over 0–3.3 V sampling at 1 kS/s, with gain, offset, clipping, noise and quantization. A reference-monitor channel (S5, a high-impedance buffer and a dedicated 12-bit channel) measures the levels of R1 and R2 during each plateau. Table 1 lists the parameters of each block, and Table 2 lists the nine fault classes, their location and their simulated severity range.
:::

::: {custom-style="MDPI_5.2_figure"}
![](Fig01_architecture.png){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 1.** Simulated electronic architecture of the reference-monitored two-point active self-test. During the AFE test window, MUX 1 (S1/S2) replaces the sensor by the two-level reference R1, so that the response passes through the AFE and the ADC. During the ADC test window, MUX 2 (S3/S4) injects the two-level reference R2 at the ADC input, so that the response depends on the ADC only. The ADC transfer estimated from R2 is removed before the AFE transfer is estimated from R1. A buffered monitor channel (S5) measures the applied reference levels with a gain error bounded by ±*E*. Stars mark the locations of the simulated faults. Schematic of the simulated system; no hardware was built.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 1.** Simulated blocks and parameters of the sensor interface. U(*a*, *b*) denotes a uniform draw per operating condition; tolerances are drawn per test record.
:::

| Block | Model and parameters | Role in the self-test |
|:--|:--|:--|
| Sensor | Baseline U(0.78, 1.18) V; sinusoidal component of amplitude U(0.045, 0.18) V and frequency U(0.45, 3.0) Hz; 25 mV component at 0.12 Hz; random-walk drift (1.5 mV per step); sensor noise U(2, 14) mV rms | Physical signal; disconnected during the R1 window |
| MUX 1 and reference R1 | 140–260 ms; 0.90 V then 1.30 V (two 60 ms plateaus) at the AFE input | Response passes through AFE and ADC |
| AFE | Gain U(1.65, 2.05); first-order low-pass with time constant U(8, 16) ms; offset | Amplification and filtering |
| MUX 2 and reference R2 | 340–460 ms; 1.15 V then 1.75 V at the ADC input, bypassing the AFE | Response depends on the ADC only |
| ADC | 12-bit, 0–3.3 V, 1 kS/s, 512 samples per record; noise 2.5 mV rms | Digitizes every path |
| Reference monitor | Buffered 12-bit channel, mean of 16 samples (0.25 mV rms after averaging); common gain error U(−*E*, *E*), *E* ∈ {0, 1, 2, 5}%; offset assumed trimmed | Supplies the applied reference levels to the calibration |
| Switches (ngspice only) | *R*~on~ = 0.5 Ω, *R*~off~ = 1 MΩ, threshold 2.5 V, hysteresis 0.1 V; 1 µs edges | Circuit-level multiplexers |
| Additional ngspice noise | 0.5 mV rms at the amplifier input and on each reference rail | Noise absent from the behavioral model |
| Component tolerances (test only) | AFE gain ±5%, AFE time constant ±10%, ADC gain ±2%, ADC offset ±10 mV, sensor baseline ±5% | Applied identically in both domains |

::: {custom-style="MDPI_4.3_table_footer"}
Parameters are the constants of the simulator source code used for the reported runs (SHA-256 hashes recorded at the protocol freeze).
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 2.** Fault taxonomy: the nine classes, their layer, their simulated severity and the window through which they are primarily observable.
:::

| No. | Fault class | Layer | Severity range | Primary observation |
|:-:|:--|:--|:--|:--|
| 0 | Healthy | Healthy | No fault | All windows |
| 1 | Sensor bias | Sensor | ±U(0.06, 0.24) V | Sensor intervals only |
| 2 | Sensor gain | Sensor | ±U(6, 28)% | Sensor intervals only |
| 3 | Sensor noise | Sensor | U(25, 95) mV rms | Sensor intervals only |
| 4 | AFE offset | AFE | ±U(0.06, 0.24) V | R1 window after ADC calibration |
| 5 | AFE bandwidth | AFE | Time constant × U(1.8, 4.5) | R1 transient |
| 6 | ADC offset | ADC | ±U(0.06, 0.24) V | R2 window |
| 7 | ADC gain | ADC | ±U(6, 28)% | R2 window |
| 8 | ADC clipping | ADC | Full scale × U(0.72, 0.93) | Only when the signal reaches the clipping level |

::: {custom-style="MDPI_2.2_heading2"}
3.2. Test Sequence and Timing
:::

::: {custom-style="MDPI_3.1_text"}
Each record lasts 512 ms (Figure 2). The sensor is connected from 0 to 140 ms, from 260 to 340 ms and from 460 to 512 ms; R1 is applied from 140 to 260 ms and R2 from 340 to 460 ms, each as two plateaus of 60 ms. The windows are long compared with the AFE time constant (8–16 ms nominally and up to 72 ms under a bandwidth fault). For nominal time constants the transient remaining after the 30% settling guard is small but not zero; it biases the plateau means in the same way in training and test. A slowed AFE leaves a large residual, so that a bandwidth fault is visible both in the transient and as a settling error.
:::

::: {custom-style="MDPI_3.1_text"}
Figure 2c illustrates the timing problem that motivates this study. Let the reference edge fall a fraction $\psi$ of the sample period $T$ after the sample at $t_{i-1}$. The first sample on the new level has then been exposed to the step for $(1-\psi)T$, and the normalized first-order response at the $j$-th sample after that ($j = 0, 1, \ldots$) is
:::

::: {custom-style="MDPI_3.9_equation"}
$$r_j(\psi) = 1 - \exp\!\left(-\frac{(j+1-\psi)\,T}{\tau}\right)$$ EQNUM1EQNUM
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
where $\tau$ is the AFE time constant. Its sensitivity to the phase,
:::

::: {custom-style="MDPI_3.9_equation"}
$$\frac{\partial r_j}{\partial \psi} = -\frac{T}{\tau}\,\exp\!\left(-\frac{(j+1-\psi)\,T}{\tau}\right)$$ EQNUM2EQNUM
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
is largest for the earliest samples. For $\tau$ = 12 ms and $T$ = 1 ms, the fraction read two samples after the step falls from 0.221 at $\psi = 0$ to 0.154 at $\psi = 0.999$, about a third of its value. A descriptor that reads fixed samples after the edge therefore carries the phase into the classifier. In a fit with the edge time as a free parameter, a shift of the edge is taken up mainly by the fitted edge time, so the remaining descriptors are much less affected.
:::

::: {custom-style="MDPI_5.2_figure"}
![](Fig02_timing.png){width=16cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 2.** Active self-test timing. (**a**) Multiplexer states: MUX 1 connects R1 to the AFE input from 140 to 260 ms and MUX 2 connects R2 to the ADC input from 340 to 460 ms. (**b**) Illustrative simulated ADC record from the development seed (not validation data), with the sensor intervals, the R1 and R2 windows, their 30% settling guards (dark) and the settled plateaus (light); samples are taken every 1 ms. (**c**) Analytical illustration of the edge phase $\psi$ for $\tau$ = 12 ms: an edge occurring $\psi T$ after a sample shifts every sampled value of the first-order response (Equation (1)), whereas a fit over the whole transient with a free edge time takes up most of the shift in the fitted edge time. Panels (b) and (c) are illustrative.
:::

::: {custom-style="MDPI_2.2_heading2"}
3.3. Observability of the Two-Point Test
:::

::: {custom-style="MDPI_3.1_text"}
The reason for two injection points can be made explicit with an affine model of the chain. Let $g_\mathrm{D}$ and $o_\mathrm{D}$ be the ADC gain and offset, $G$ and $o_\mathrm{A}$ the AFE gain and offset, and $x$ the AFE input. Away from transients and clipping, the sample recorded during the R2 window, when the ADC input is the reference level $u$, and during the settled part of the R1 window, when the AFE input is the reference level $v$, are
:::

::: {custom-style="MDPI_3.9_equation"}
$$y^{(2)} = g_\mathrm{D}\,u + o_\mathrm{D} + n, \qquad y^{(1)} = g_\mathrm{D}\left(G\,v + o_\mathrm{A}\right) + o_\mathrm{D} + n$$ EQNUM3EQNUM
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
with additive noise $n$. Two distinct levels $u_\mathrm{L} \neq u_\mathrm{H}$ determine $g_\mathrm{D}$ and $o_\mathrm{D}$; once they are known, two distinct levels $v_\mathrm{L} \neq v_\mathrm{H}$ determine $G$ and $o_\mathrm{A}$. A single reference applied at the AFE input determines only the products $g_\mathrm{D} G$ and $g_\mathrm{D} o_\mathrm{A} + o_\mathrm{D}$, so an AFE gain fault and an ADC gain fault of the same size produce the same record. This is the identifiability argument for the second injection point. It holds under the stated assumptions (linear stages, settled plateaus, levels known, no clipping) and says nothing about how well the parameters can be estimated in the presence of noise and tolerances; that is an empirical question answered in Section 7.
:::

::: {custom-style="MDPI_3.1_text"}
The same model shows which faults the references cannot reveal. Because R1 replaces the sensor, sensor faults are visible only in the sensor intervals. A sensor bias of 0.06–0.24 V is of the same order as the spread of the healthy baseline across operating conditions (0.78–1.18 V), and a sensor gain change of 6–28% is comparable to the spread of the signal amplitude. From a single record, without a reference for the physical quantity, these faults are therefore not identifiable from normal variation of the measurand. ADC clipping is observable only when the signal reaches the clipping level, which for the simulated range of 0.72–0.93 of full scale (2.38–3.07 V) is not the case in many records. These are structural limits of the observation, not of the classifier, and they reappear in the results.
:::

::: {custom-style="MDPI_2.1_heading1"}
4\. Reference Monitoring, Calibration and Transient Descriptors
:::

::: {custom-style="MDPI_3.1_text"}
Figure 3 summarizes the processing chain from simulation to evaluation. This section describes the reference monitor, the settled-plateau calibration and the transient descriptors; the classifier and the evaluation follow in Sections 5 and 6.
:::

::: {custom-style="MDPI_5.2_figure"}
![](Fig03_pipeline.png){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 3.** Processing and evaluation pipeline. Behavioral and ngspice simulations generate records with injected faults, component tolerances, noise and 12-bit quantization; the two-point reference test is applied at five edge phases; the reference monitor reports the applied levels with a bounded gain error *E*; twenty descriptors are extracted and classified by a compact multilayer perceptron; performance is evaluated with macro-F1, the frozen decision gates and a paired condition-level cluster bootstrap. Schematic.
:::

::: {custom-style="MDPI_2.2_heading2"}
4.1. Reference Monitor
:::

::: {custom-style="MDPI_3.1_text"}
A calibration that divides by the commanded reference difference converts any error in the reference amplitude into an apparent gain error. The monitor therefore measures the levels that were actually applied. It is modeled as a unity-gain buffer with high input impedance feeding a dedicated 12-bit channel; each reported level is the mean of 16 samples with 1 mV rms noise per sample, quantized to the 12-bit grid. The monitor's own gain error, arising for example from its reference or resistor tolerance, is common to the four levels of a record:
:::

::: {custom-style="MDPI_3.9_equation"}
$$m = Q\!\left(r\,(1+e) + n_\mathrm{m}\right), \qquad e \sim \mathcal{U}(-E, E), \qquad n_\mathrm{m} \sim \mathcal{N}\!\left(0, (0.25\ \mathrm{mV})^2\right)$$ EQNUM4EQNUM
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
where $r$ is the applied level, $m$ the reported level and $Q$ the quantizer; the offset of the monitor is assumed to be trimmed. The bound $E$ took the values 0, 1, 2 and 5%, and each monitored classifier was trained with the bound it was tested with. A variant with the applied levels known exactly serves as reference.
:::

::: {custom-style="MDPI_2.2_heading2"}
4.2. Settled-Plateau Calibration
:::

::: {custom-style="MDPI_3.1_text"}
Each reference window is split into its two plateaus, and the first 30% of every plateau is discarded as a settling guard. With $\bar{y}_\mathrm{L}$ and $\bar{y}_\mathrm{H}$ the means of the remaining samples and $m_\mathrm{L}$, $m_\mathrm{H}$ the monitored levels, the ADC parameters are estimated from R2,
:::

::: {custom-style="MDPI_3.9_equation"}
$$\hat{g}_\mathrm{D} = \frac{\bar{y}^{(2)}_\mathrm{H} - \bar{y}^{(2)}_\mathrm{L}}{m^{(2)}_\mathrm{H} - m^{(2)}_\mathrm{L}}, \qquad \hat{o}_\mathrm{D} = \bar{y}^{(2)}_\mathrm{L} - \hat{g}_\mathrm{D}\, m^{(2)}_\mathrm{L}$$ EQNUM5EQNUM
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
the record is corrected to $z = (y - \hat{o}_\mathrm{D})/\hat{g}_\mathrm{D}$, and the AFE parameters are estimated from R1 in the same way:
:::

::: {custom-style="MDPI_3.9_equation"}
$$\hat{G} = \frac{\bar{z}^{(1)}_\mathrm{H} - \bar{z}^{(1)}_\mathrm{L}}{m^{(1)}_\mathrm{H} - m^{(1)}_\mathrm{L}}, \qquad \hat{o}_\mathrm{A} = \bar{z}^{(1)}_\mathrm{L} - \hat{G}\, m^{(1)}_\mathrm{L}$$ EQNUM6EQNUM
:::

::: {custom-style="MDPI_3.1_text"}
Substituting Equations (3) and (4) into Equations (5) and (6) shows how a monitor gain error propagates. If the error is common to the four levels, $m = r(1+e)$, and the plateaus are settled and noise-free, then $\hat{g}_\mathrm{D} = g_\mathrm{D}/(1+e)$ and $\hat{o}_\mathrm{D} = o_\mathrm{D}$; after correction, $\hat{G} = G$ and $\hat{o}_\mathrm{A} = (1+e)\,o_\mathrm{A}$. A common gain error of ±5% thus appears as an apparent ADC gain error of about ±5% and a 5% scaling of the AFE offset, while the AFE gain and the ADC offset are unaffected. The smallest simulated gain fault is 6%, so this error is just below the fault range. Without a monitor, an actual reference amplitude of 0.8 or 1.2 times nominal acts as $1+e = 1/0.8$ or $1/1.2$, an apparent ADC gain error of −20% or +20%, which lies inside the simulated ADC gain-fault range. This analysis anticipates the behavior of the no-monitor control in Section 7.3.
:::

::: {custom-style="MDPI_2.2_heading2"}
4.3. Phase-Robust Transient Descriptors
:::

::: {custom-style="MDPI_3.1_text"}
The settled plateaus carry the static parameters; the AFE dynamics are carried by the transient at the step from the first to the second R1 plateau. The earlier descriptor set (here called FS, for fixed-sample) represented this transient by the normalized response two, five, ten, twenty and thirty samples after the step. Equation (1) shows why these fixed-sample fractions depend on $\psi$. The phase-robust set (PR) removes them and fits the raw samples of the second R1 plateau, together with the last sample before the step, by
:::

::: {custom-style="MDPI_3.9_equation"}
$$\hat{y}(t) = b + S\left(1 - e^{-(t-t_\mathrm{e})/\tau}\right)\mathbb{1}[t \geq t_\mathrm{e}]$$ EQNUM7EQNUM
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
where $b$ is the last sample before the step, $S$ the step span, $\tau$ the time constant and $t_\mathrm{e}$ the edge time. For given $(\tau, t_\mathrm{e})$, with $d_j = y_j - b$ and $g_j(\tau, t_\mathrm{e}) = (1 - e^{-(t_j-t_\mathrm{e})/\tau})\,\mathbb{1}[t_j \geq t_\mathrm{e}]$, the span has the closed-form least-squares value
:::

::: {custom-style="MDPI_3.9_equation"}
$$S^{*}(\tau, t_\mathrm{e}) = \frac{\sum_j g_j d_j}{\sum_j g_j^2}, \qquad \mathrm{RSS}(\tau, t_\mathrm{e}) = \sum_j d_j^2 - S^{*} \sum_j g_j d_j$$ EQNUM8EQNUM
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
so that only $(\tau, t_\mathrm{e})$ need to be searched, as in variable projection [47,48]. The search evaluates a grid of 56 logarithmically spaced time constants from 1 to 400 ms and seven edge times from −0.25 $T$ to 1.25 $T$, followed by one local refinement over ±10% in $\tau$ and ±0.2 $T$ in $t_\mathrm{e}$ (9 × 9 points). The edge time is not used as a descriptor, because it encodes the phase. With the plateau length $P$ (60 ms) and the normalized response $\rho_j = d_j / S^{*}$, five descriptors are formed:
:::

::: {custom-style="MDPI_3.9_equation"}
$$\tilde{\tau} = \frac{\tau^{*}}{P}, \quad \Delta_{10,50} = \frac{t_{50} - t_{10}}{P}, \quad \Delta_{50,90} = \frac{t_{90} - t_{50}}{P}, \quad A = \frac{T}{P}\sum_j \left(1 - \rho_j\right), \quad \varepsilon = \frac{\sqrt{\mathrm{RSS}^{*}/n}}{\lvert S^{*} \rvert}$$ EQNUM9EQNUM
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
where $t_\alpha$ is the time at which the running maximum of $\rho$ crosses the fraction $\alpha$ (linear interpolation, capped at the end of the window if the level is not reached), $A$ is the normalized transient area and $\varepsilon$ the normalized fit residual. The rise-time differences follow the transition-duration logic of IEEE Std 181 [43]; using differences of crossing times removes the common time shift. The plateau-settling errors of the FS set are retained. If the fitted span is degenerate ($\lvert S^{*} \rvert < 10^{-4}$), a documented fallback based on the raw window area is used; it was never triggered in 16,200 development-seed records. Table 3 lists the complete descriptor sets.
:::

::: {custom-style="MDPI_3.1_text"}
Two properties of these descriptors can be stated exactly, and both rest on assumptions. First, they are invariant to an affine transformation $y' = \alpha y + \beta$ with $\alpha \neq 0$: $d' = \alpha d$, $S^{*\prime} = \alpha S^{*}$ and $\mathrm{RSS}' = \alpha^2\,\mathrm{RSS}$, so the minimizing $(\tau, t_\mathrm{e})$ and the normalized response $\rho$ are unchanged. This holds before quantization and clipping, which break it, and makes the transient descriptors independent of the ADC gain and offset and of the monitored levels. Second, a shift of the edge by $\delta$ in noise-free data is reproduced exactly by the model with $t_\mathrm{e} + \delta$ and the same $\tau$ and $S$, provided that both edge times lie on the search grid; between grid points the fitted $\tau$ is approximate to the grid resolution. The grid search is deterministic, uses a fixed number of evaluations and always returns a value inside the grid; it does not guarantee the least-squares optimum outside the grid range or finer than its resolution. How closely these properties hold with noise, tolerances and quantization is therefore an empirical question. On the development seed, moving $\psi$ from 0 to 0.999 shifted the fixed-sample fraction two samples after the step by up to 1.39 standard deviations across records, and every phase-robust descriptor by at most 0.15; the fitted time constant shifted by 0.004 standard deviations.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 3.** Descriptor sets. Both sets contain 20 descriptors; PR replaces the five fixed-sample rise fractions of FS by five whole-transient descriptors.
:::

| Group | Descriptors | Window | FS | PR |
|:--|:--|:--|:-:|:-:|
| ADC calibration | ADC gain $\hat{g}_\mathrm{D}$, ADC offset $\hat{o}_\mathrm{D}$, residual noise | R2 settled plateaus | ✓ | ✓ |
| AFE calibration | AFE gain $\hat{G}$, AFE offset $\hat{o}_\mathrm{A}$, two plateau-settling errors, residual noise | R1 settled plateaus (ADC-corrected) | ✓ | ✓ |
| Sensor domain | Mean, standard deviation, high-frequency noise, peak-to-peak value and slope of the calibrated sensor signal; raw maximum and fraction of samples near the maximum | Sensor intervals | ✓ | ✓ |
| Fixed-sample transient | Normalized response 2, 5, 10, 20 and 30 samples after the R1 step | R1 step | ✓ | – |
| Whole-transient | $\tilde{\tau}$, $\Delta_{10,50}$, $\Delta_{50,90}$, $A$, $\varepsilon$ (Equation (9)) | Second R1 plateau with free edge time | – | ✓ |

::: {custom-style="MDPI_3.1_text"}
Figure 4 shows six descriptors for the nine classes on the development seed. The ADC gain and offset estimated from R2 respond only to ADC gain and offset faults and stay flat for sensor and AFE faults. The AFE gain and offset estimated from R1 after ADC correction shift for AFE faults; a bandwidth fault lowers the apparent gain and raises the apparent offset because the plateaus do not settle. The fitted time constant marks bandwidth faults, and the high-frequency noise of the sensor signal marks sensor-noise faults. None of the six descriptors separates sensor bias or sensor gain faults from healthy records, in line with the observability argument of Section 3.3.
:::

::: {custom-style="MDPI_5.2_figure"}
![](Fig04_fault_signatures.png){width=16cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 4.** Descriptor-level fault signatures on the development seed (60 records per class; illustrative, not validation data). Box plots (median, interquartile range, whiskers at 1.5 times the interquartile range, outliers hidden) of (**a**) the ADC gain and (**b**) the ADC offset estimated from R2, (**c**) the AFE gain and (**d**) the AFE offset estimated from R1 after ADC correction, (**e**) the normalized fitted time constant $\tau^{*}/P$ and (**f**) the high-frequency noise of the calibrated sensor signal, colored by faulty layer.
:::

::: {custom-style="MDPI_2.1_heading1"}
5\. Neural-Network Classification
:::

::: {custom-style="MDPI_3.1_text"}
The descriptors are physically interpretable and few, so the classifier can be small. A fully connected multilayer perceptron (MLP) with two hidden layers of 96 and 48 rectified linear units maps the standardized 20-dimensional descriptor vector to class probabilities. Two networks are trained separately. The layer network has four outputs (healthy, sensor, AFE, ADC), 6,868 parameters and 6,720 multiply–accumulate operations per inference. The fault network has nine outputs, 7,113 parameters and 6,960 multiply–accumulate operations. The networks were implemented with scikit-learn 1.7.2 [49] and trained with Adam [50] (initial learning rate $8 \times 10^{-4}$, mini-batches of 64, L2 penalty $10^{-4}$, at most 700 epochs). Each network uses the library's internal early stopping: a random 15% of its training rows is held out, the accuracy on this hold-out is evaluated after every epoch, training stops once the accuracy has failed to exceed its best value by at least $10^{-4}$ in more than 35 consecutive epochs, and the weights with the best hold-out accuracy are restored. Every configuration was trained with two initialization seeds (11 and 22), and the reported metrics average the two.
:::

::: {custom-style="MDPI_3.1_text"}
The early stopping needs a precise description because the written protocol and the implementation disagree. The protocol states that the 40-condition validation split is unused and that no early-stopped model is trained. The first statement is correct: records of those conditions are never generated or used. The second is not: the frozen training code, whose hash matches the freeze record, enables the internal early stopping described above in every network, the primary method included. The results reported here are those of the code. In scikit-learn 1.7.2 the internal hold-out is a random 15% of the training rows; it is not stratified by class, because the library stratifies only single-output targets and the four- and nine-class networks have one output per class. The stopping criterion and the restoration of the best weights are as described above. Because the hold-out is drawn by row, it shares operating conditions with the rows used for fitting, which may make the stopping point somewhat optimistic; it cannot leak test information, since the 88 test conditions are disjoint from all training conditions. The number of epochs actually run was not recorded. The architecture and settings were chosen in earlier development work on other seeds and were not tuned on the validation seeds; there, a temporal convolutional network performed on par with this MLP but not better.
:::

::: {custom-style="MDPI_3.1_text"}
The descriptor arms differ only in their inputs and in the phase used for training. Arms without phase randomization (FS, PR) are trained with records at $\psi = 0$; arms with randomization (FSr, PRr) draw $\psi \sim \mathcal{U}[0, 1)$ per training record. Randomizing a nuisance parameter during training is a standard way of making a learned model insensitive to it [51,52]. The primary method, PRr, combines the phase-robust descriptors with phase-randomized training. A secondary variant, PRrM, adds an ngspice version of every training record (same condition, fault, phase and monitor draw, with component tolerances and the additional noise), doubling the training set; it was evaluated against the same gates but is not the primary method.
:::

::: {custom-style="MDPI_2.1_heading1"}
6\. Simulation Design, Evaluation Protocol and Statistical Analysis
:::

::: {custom-style="MDPI_2.2_heading2"}
6.1. Simulation Domains
:::

::: {custom-style="MDPI_3.1_text"}
The behavioral domain is a discrete-time model of the chain in Figure 1. The AFE filter is discretized exactly, including a two-stage update at the edge interval that places the step at $\psi T$ after the previous sample; at $\psi = 0$ this reproduces the earlier zero-order-hold simulator bit for bit, which was verified by hashing the generated records. The ngspice domain renders one netlist per record with the multiplexers as voltage-controlled switches, the AFE as an RC network followed by a behavioral gain-and-offset source, and the ADC transfer and clipping as a behavioral source; it adds 0.5 mV rms noise at the amplifier input and on each reference rail and places every reference and switch-control edge at $t_{i-1} + \psi T + 1$ µs with a hold-then-step piecewise-linear source. The transient analysis uses a 0.1 ms step, and the output is interpolated onto the 1 kHz sample grid before the ADC noise and quantization are added. Each dataset seed required 13,878 ngspice runs (41,634 in total), which took 906–909 s per seed with three parallel workers. Simulations used ngspice-47 [53].
:::

::: {custom-style="MDPI_3.1_text"}
The two domains are not independent. Both are first-order RC models with an affine ADC, and in a noise-free check on the development seed they agreed to 0.14–0.27 mV mean RMS difference per phase (maximum 2.8 mV at $\psi = 0.999$). The ngspice domain therefore tests the effect of switch resistances, additional amplifier and rail noise, component tolerances and circuit-level edge handling, not that of unmodeled hardware effects such as charge injection, finite amplifier bandwidth and slew rate, reference settling or leakage. This limitation was stated in the protocol before the run.
:::

::: {custom-style="MDPI_2.2_heading2"}
6.2. Datasets, Splits and Test Grids
:::

::: {custom-style="MDPI_3.1_text"}
Table 4 summarizes the protocol. Each of the three validation dataset seeds (20261026, 20261027 and 20261028) generated 350 operating conditions, each with one instance of every fault class. The conditions were split by condition into 222 training, 40 validation and 88 test conditions, with zero overlap verified at run time. Training used behavioral records at nominal reference amplitude without component tolerances. Test records included the tolerances, ADC noise, quantization and all nine classes, with the tolerance, noise and monitor draws shared between the two domains so that each behavioral test record has an ngspice twin. The behavioral test grid covers reference amplitudes of 0.8, 0.9, 1.0, 1.1 and 1.2 times nominal at the five phases $\psi \in \{0, 0.25, 0.5, 0.75, 0.999\}$; the ngspice grid covers 0.8, 1.0 and 1.2 at the same phases. Because the two grids contain different amplitudes, scores pooled over each domain's full grid cannot be subtracted to estimate a transfer loss; transfer is evaluated only on the matched grid of 0.8, 1.0 and 1.2.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 4.** Simulation and evaluation protocol.
:::

| Item | Setting |
|:--|:--|
| Simulation domains | Behavioral discrete-time model; per-record ngspice netlist of the same topology |
| Validation dataset seeds | 20261026, 20261027, 20261028 (generated after the protocol freeze) |
| Conditions per seed | 350 operating conditions × 9 fault classes |
| Split by condition | 222 training / 40 validation (unused) / 88 test; overlap 0 |
| Test records per grid cell | 792 (88 conditions × 9 classes) per seed |
| Training data | Behavioral, amplitude ×1.0, no tolerances; $\psi = 0$ (FS, PR) or $\psi \sim \mathcal{U}[0,1)$ (FSr, PRr); PRrM adds ngspice twins |
| Edge phases (test) | $\psi$ = 0, 0.25, 0.5, 0.75, 0.999 |
| Reference amplitudes (test) | Behavioral ×0.8, ×0.9, ×1.0, ×1.1, ×1.2; ngspice ×0.8, ×1.0, ×1.2 |
| Reference conditions | Known levels; monitor with *E* = 0, ±1, ±2, ±5% (matched training); no monitor (behavioral control) |
| Disturbances (test) | Component tolerances (Table 1); ADC noise 2.5 mV rms; 12-bit quantization; ngspice adds 0.5 mV rms amplifier and rail noise |
| Initializations | Seeds 11 and 22 for every network, averaged |
| Primary metric | Layer macro-F1 (4 classes) |
| Further metrics | Fault macro-F1 (9 classes), balanced accuracy, per-class recall, AFE–ADC cross-confusion, retention, phase spread |
| Uncertainty | Paired condition-level cluster bootstrap, 5000 resamples per seed; pooled 95% percentile interval |
| Protocol status | Frozen internally before the validation data were generated (source-code hashes recorded); not registered externally |

::: {custom-style="MDPI_2.2_heading2"}
6.3. Compared Arms and Baselines
:::

::: {custom-style="MDPI_3.1_text"}
Besides FS, FSr, PR, PRr and PRrM, the evaluation includes the descriptor set of the stage before the reference revision (A0: raw waveform samples and 38 physics descriptors, trained at $\psi = 0$) and single-path baselines: a passive classifier using the sensor signal only, a single additive-probe active test, and AFE-only and ADC-only reference tests with the A0 descriptors and with the PRr descriptors restricted to their single window. A no-monitor control applies the PRr classifier trained with known levels to records in which the reference amplitude has changed but the nominal levels are assumed; it answers the question of what the monitor contributes. This control was evaluated in the behavioral domain only.
:::

::: {custom-style="MDPI_2.2_heading2"}
6.4. Metrics
:::

::: {custom-style="MDPI_3.1_text"}
For a confusion matrix with true positives $\mathrm{TP}_c$, false positives $\mathrm{FP}_c$ and false negatives $\mathrm{FN}_c$ for class $c$ of $C$ classes, the macro-F1 score is
:::

::: {custom-style="MDPI_3.9_equation"}
$$\mathrm{MF1} = \frac{1}{C}\sum_{c=1}^{C} \frac{2\,\mathrm{TP}_c}{2\,\mathrm{TP}_c + \mathrm{FP}_c + \mathrm{FN}_c}$$ EQNUM10EQNUM
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
which weights every class equally regardless of how often it is predicted [54]. Layer macro-F1 ($C = 4$) measures whether the faulty layer is found; it is the primary metric because localization to a layer is the decision the architecture is designed to support. Fault macro-F1 ($C = 9$) measures whether the specific fault is found and is not directly comparable with layer macro-F1: a sensor-bias record classified as sensor gain is wrong for the fault metric but right for the layer metric, while the layer network and the fault network are different models with different output sizes. The AFE–ADC cross-confusion
:::

::: {custom-style="MDPI_3.9_equation"}
$$\kappa = \frac{n_{\mathrm{AFE}\to\mathrm{ADC}} + n_{\mathrm{ADC}\to\mathrm{AFE}}}{n_{\mathrm{AFE}} + n_{\mathrm{ADC}}}$$ EQNUM11EQNUM
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
is the fraction of AFE- and ADC-fault records assigned to the other of the two layers; it isolates the confusion that the second injection point is meant to prevent and is unaffected by errors among healthy and sensor records. Retention is the ratio of layer macro-F1 at a shifted reference amplitude to the nominal value $N_d$, defined as the layer macro-F1 of PRr with known levels at amplitude ×1.0 pooled over the five phases in domain $d$. The phase spread is the difference between the largest and smallest layer macro-F1 among the five phases.
:::

::: {custom-style="MDPI_2.2_heading2"}
6.5. Aggregation, Uncertainty and Decision Rules
:::

::: {custom-style="MDPI_3.1_text"}
For every dataset seed and initialization, the confusion matrices of all pooled grid cells (amplitudes and phases, as stated for each result) are summed and the metric is computed once from the sum; the metric is then averaged over the two initializations and over the three dataset seeds. Paired differences between two arms, or between the two domains for the same classifier, are assessed with a condition-level cluster bootstrap [55,56]: for each seed, 5000 multinomial resamples of the 88 test conditions are drawn, the same weights are applied to both members of the pair and to every pooled cell, and the pooled 95% interval is formed from the percentiles of the mean of the three per-seed bootstrap differences,
:::

::: {custom-style="MDPI_3.9_equation"}
$$\Delta^{*}_b = \frac{1}{3}\sum_{s=1}^{3}\left[\mathrm{MF1}_A\!\left(\mathbf{W}^{*}_{s,b}\right) - \mathrm{MF1}_B\!\left(\mathbf{W}^{*}_{s,b}\right)\right], \qquad b = 1, \ldots, 5000$$ EQNUM12EQNUM
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
where $\mathbf{W}^{*}_{s,b}$ are the resampling weights of seed $s$. An improvement is stated only when this interval excludes zero, and a difference is called consistent when it has the same sign in all three seeds. The interval reflects the sampling of test conditions given the trained networks; variability between training runs enters only through the two initializations and the three seed-specific training sets.
:::

::: {custom-style="MDPI_3.1_text"}
The protocol fixed seven criteria before the validation run (Table 5): retention of at least 0.85 $N_d$ at ×0.8 and ×1.2 (A), superiority over the earlier method and the single-path baselines with interval lower bounds above zero (B), cross-confusion below 0.15 (C), retention of at least 0.70 $N_d$ with a ±5% monitor error (D), a behavioral-to-ngspice transfer loss of at most 0.10 at $E$ = ±2% on the matched grid (E), interval support for every claimed improvement (F) and a phase spread of at most 0.05 (G). The decision was GO only if all gates held for PRr in both domains where applicable. Development used a separate seed (20261097), which is also the source of all illustrative panels, and no descriptor, fit setting, threshold or model was changed after the validation data were generated. The protocol and the hashes of the source code were recorded internally but not deposited in an external registry, so the study is not preregistered in the usual sense. The one known discrepancy between the written protocol and the code concerns early stopping (Section 5).
:::

::: {custom-style="MDPI_2.2_heading2"}
6.6. Software, Reproducibility and Use of Generative AI
:::

::: {custom-style="MDPI_3.1_text"}
The runs used Python 3.12.12, NumPy 2.2.6, pandas 2.3.3, SciPy 1.16.3, scikit-learn 1.7.2 and ngspice-47 on macOS (arm64); these versions were recorded on the day of the run on the machine that produced it, not in the run logs (Table S6). The simulator and training source code is provided with the article, and its SHA-256 hashes match those recorded when the protocol was fixed. All statistics, tables and figures can be regenerated from the saved per-record predictions; an independent recomputation reproduced the stored results exactly. Rerunning the simulations and the training on a second machine has not been attempted.
:::

::: {custom-style="MDPI_3.1_text"}
Generative AI was used in this study. Claude Code (Anthropic) was used to implement the simulation, descriptor, training and analysis software, to draft the frozen protocols and stage reports under the author's direction, and, for this article, to search and verify the literature, regenerate figures from the saved data, recompute the statistics and draft the text. The author reviewed the design decisions, the code and the results and takes responsibility for the content.
:::

::: {custom-style="MDPI_2.1_heading1"}
7\. Results
:::

::: {custom-style="MDPI_2.2_heading2"}
7.1. Overall Performance and Decision Gates
:::

::: {custom-style="MDPI_3.1_text"}
PRr met all decision gates in both domains (Table 5). Table 6 gives the overall scores with the monitor at $E$ = ±2%, pooled over each domain's full test grid. PRr reached a layer macro-F1 of 0.656 in the behavioral domain and 0.649 in ngspice, and a fault macro-F1 of 0.668 and 0.662. The three dataset seeds gave behavioral layer scores of 0.652–0.660. Because the two domains are pooled over different amplitude grids, the difference between these two headline values is not a transfer loss; the matched comparison follows in Section 7.5.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 5.** Decision gates fixed in the protocol and results for the primary method PRr. $N_d$ is the PRr layer macro-F1 with known levels at ×1.0 pooled over phases (0.659 behavioral, 0.660 ngspice).
:::

| Gate | Criterion | Threshold | Observed (PRr) | Behavioral | ngspice |
|:-:|:--|:--|:--|:-:|:-:|
| A | Retention at ×0.8 and ×1.2 (known levels, *E* ≤ ±2%) | ≥ 0.85 $N_d$ | Lowest 0.916 $N_d$ | Pass | Pass |
| B | Difference to earlier method and single-path baselines (behavioral, 70 comparisons) | Lower 95% bound > 0 | Smallest lower bound +0.112 | Pass | – |
| C | AFE–ADC cross-confusion at ×0.8 and ×1.2 | < 0.15 | Largest 0.089 | Pass | Pass |
| D | Retention with *E* = ±5% (×0.8, ×1.2 and pooled) | ≥ 0.70 $N_d$ | Lowest 0.924 $N_d$ | Pass | Pass |
| E | Transfer loss, matched grid, *E* = ±2% | ≤ 0.10 | 0.002 [−0.003, +0.006] | Pass | – |
| F | Interval support for every claimed improvement | Interval excludes 0 | Applied throughout | Met | Met |
| G | Phase spread (known levels and *E* = ±2%) | ≤ 0.05 | 0.005–0.011 | Pass | Pass |

::: {custom-style="MDPI_4.1_table_caption"}
**Table 6.** Overall classification results with the monitor at *E* = ±2%, pooled over amplitudes and the five phases (mean of three dataset seeds × two initializations).
:::

| Method | Role | Domain (amplitude grid) | Layer macro-F1 | Layer balanced accuracy | Fault macro-F1 | Fault balanced accuracy |
|:--|:--|:--|:-:|:-:|:-:|:-:|
| PRr | Primary | Behavioral (×0.8–×1.2, 5 levels) | 0.656 | 0.660 | 0.668 | 0.670 |
| PRr | Primary | ngspice (×0.8, ×1.0, ×1.2) | 0.649 | 0.654 | 0.662 | 0.665 |
| PRrM | Secondary | Behavioral (×0.8–×1.2, 5 levels) | 0.672 | 0.674 | 0.675 | 0.676 |
| PRrM | Secondary | ngspice (×0.8, ×1.0, ×1.2) | 0.663 | 0.666 | 0.671 | 0.673 |
| FS | Fixed-sample descriptors | Behavioral (×0.8–×1.2, 5 levels) | 0.614 | 0.622 | 0.638 | 0.644 |
| FS | Fixed-sample descriptors | ngspice (×0.8, ×1.0, ×1.2) | 0.606 | 0.616 | 0.631 | 0.639 |

::: {custom-style="MDPI_4.3_table_footer"}
Behavioral and ngspice rows use different amplitude grids and must not be subtracted; the matched-grid comparison is given in Section 7.5.
:::

::: {custom-style="MDPI_3.1_text"}
These absolute values are modest. A layer macro-F1 of about 0.65 means that the classifier is far from a reliable four-way decision, and Section 7.7 shows that the shortfall is concentrated in a well-defined group of classes. The gates measure robustness to the reference amplitude, to the monitor error, to the domain and to the phase relative to the nominal performance; passing them does not make the nominal performance high.
:::

::: {custom-style="MDPI_2.2_heading2"}
7.2. Sensitivity to the Sampling Phase
:::

::: {custom-style="MDPI_3.1_text"}
Figure 5 shows the central result. With the fixed-sample descriptors (FS), layer macro-F1 declined steadily as the edge moved through the sample period, with a phase spread of 0.081 in the behavioral domain and 0.081 in ngspice, beyond the 0.05 limit of gate G. With the phase-robust descriptors and randomized training (PRr) the curves were nearly flat, with spreads of 0.006 and 0.010; over the four gate-G variants (known levels and $E$ = ±2%, both domains) the PRr spread was 0.005–0.011. Per-phase values for every arm and reference condition are listed in Table S1. Randomizing the phase during training reduced the FS spread to 0.025 and 0.026, so the classifier can partly learn to ignore the phase, but it did not remove the decline at $\psi = 0.999$. The phase-robust descriptors trained only at $\psi = 0$ (PR) were as flat as PRr (0.004 and 0.007), which indicates that the robustness comes from the descriptors themselves rather than from the training distribution. The behavior matches the mechanism in panel (c): the early fixed-sample fractions move by more than one standard deviation over the phase range, and the whole-transient descriptors hardly move.
:::

::: {custom-style="MDPI_5.2_figure"}
![](Fig05_phase_sensitivity.png){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 5.** Sensitivity to the sampling phase. Layer macro-F1 (monitor *E* = ±2%, pooled over each domain's reference amplitudes; mean of three dataset seeds × two initializations) versus the edge phase $\psi$ in (**a**) the behavioral and (**b**) the ngspice domain, for the fixed-sample descriptors (FS), FS with phase-randomized training (FSr), the phase-robust descriptors (PR), the primary method (PRr) and the secondary mixed-domain variant (PRrM); simulation results. (**c**) Mechanism on the development seed (illustrative): mean absolute descriptor shift relative to $\psi = 0$, in units of the across-record standard deviation, for two fixed-sample fractions and three phase-robust descriptors.
:::

::: {custom-style="MDPI_2.2_heading2"}
7.3. Robustness to Reference Amplitude and Monitor Error
:::

::: {custom-style="MDPI_3.1_text"}
Figure 6 and Table 7 show layer macro-F1 as a function of the actual reference amplitude. With known levels, PRr retained at least 0.916 of $N_d$ at ×0.8 and ×1.2 across the known and monitored variants with $E$ ≤ ±2% (gate A), and at $E$ = ±5% the lowest retention was 0.924 (gate D). The monitored variants differed from each other by up to 0.018 at ×1.0 (0.655–0.673). Because each variant is a separately trained network, these differences include training variability and should not be read as an effect of the monitor error; in particular, the $E$ = ±2% network scoring above the known-level network does not mean that a monitor error helps.
:::

::: {custom-style="MDPI_3.1_text"}
The no-monitor control shows what the monitor contributes. The same PRr network that reached 0.615 and 0.643 with known levels at ×0.8 and ×1.2 fell to 0.310 and 0.237 when the nominal levels were assumed, and its fault macro-F1 fell to 0.241 and 0.258. The earlier descriptor set A0 collapsed in the same way, from 0.560 at ×1.0 to 0.140 and 0.121. As predicted by the calibration analysis of Section 4.2, an unmonitored amplitude change is absorbed as an apparent ADC gain error: without monitoring, nearly all healthy and sensor records were assigned to the ADC layer (Section 7.4). The monitor is therefore not an optional refinement but a necessary part of the two-point test whenever the reference amplitude is uncertain. This conclusion rests on behavioral evidence only, since the no-monitor control was not simulated in ngspice.
:::

::: {custom-style="MDPI_5.2_figure"}
![](Fig06_reference_amplitude.png){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 6.** Robustness to the reference amplitude (simulation results). Layer macro-F1, pooled over the five phases and averaged over three dataset seeds, versus the actual reference amplitude for PRr with known levels and with the monitor (*E* = 0, ±1, ±2, ±5%), the fixed-sample descriptors (FS, known levels) and the earlier descriptors (A0), in (**a**) the behavioral and (**b**) the ngspice domain. In (a), the no-monitor control applies the known-level PRr network with the nominal levels assumed; it was evaluated in the behavioral domain only. ngspice was simulated at ×0.8, ×1.0 and ×1.2.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 7.** Layer macro-F1 of PRr versus the actual reference amplitude, pooled over the five phases (mean of three dataset seeds).
:::

| Reference condition | Bh. ×0.8 | Bh. ×0.9 | Bh. ×1.0 | Bh. ×1.1 | Bh. ×1.2 | ng. ×0.8 | ng. ×1.0 | ng. ×1.2 |
|:--|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| PRr, known levels | 0.615 | 0.646 | 0.659 | 0.667 | 0.643 | 0.616 | 0.660 | 0.642 |
| PRr, monitor, *E* = 0% | 0.610 | 0.638 | 0.655 | 0.665 | 0.642 | 0.606 | 0.655 | 0.644 |
| PRr, monitor, *E* = ±1% | 0.608 | 0.638 | 0.658 | 0.670 | 0.644 | 0.604 | 0.655 | 0.644 |
| PRr, monitor, *E* = ±2% | 0.614 | 0.647 | 0.673 | 0.681 | 0.663 | 0.611 | 0.671 | 0.664 |
| PRr, monitor, *E* = ±5% | 0.611 | 0.644 | 0.662 | 0.676 | 0.649 | 0.610 | 0.663 | 0.646 |
| FS, known levels | 0.578 | 0.604 | 0.619 | 0.618 | 0.593 | 0.578 | 0.621 | 0.589 |
| A0 (earlier descriptors) | 0.140 | 0.224 | 0.560 | 0.182 | 0.121 | – | – | – |
| PRr, no monitor (nominal levels assumed) | 0.310 | 0.423 | 0.659 | 0.389 | 0.237 | – | – | – |


::: {custom-style="MDPI_4.3_table_footer"}
Monitored variants are trained with the matching error bound. The no-monitor control was evaluated in the behavioral domain only (–: not simulated).
:::

::: {custom-style="MDPI_2.2_heading2"}
7.4. Separation of AFE and ADC Faults
:::

::: {custom-style="MDPI_3.1_text"}
The second injection point exists to keep AFE and ADC faults apart, and Figure 7 and Table 8 show that it does so when the reference levels are known or monitored. At ±20% reference amplitude, AFE recall was 0.863–0.912 and ADC recall 0.773–0.845 over all known and monitored conditions in both domains, and the AFE–ADC cross-confusion was between 0.026 and 0.089, well below the 0.15 limit of gate C. Without monitoring, the cross-confusion rose to 0.230 at ×0.8 and 0.336 at ×1.2, AFE recall fell to 0.426 and 0.375, and ADC recall stayed high (0.944 and 0.820) only because almost every record was assigned to the ADC layer. Cross-confusion was larger at ×1.2 than at ×0.8 in every condition; with known levels the increase came mostly from ADC faults assigned to the AFE layer (Figure 7b).
:::

::: {custom-style="MDPI_5.2_figure"}
![](Fig07_afe_adc_separation.png){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 7.** Separation of AFE and ADC faults by PRr in the behavioral domain (simulation results, pooled over the five phases; mean of three dataset seeds × two initializations). (**a**,**b**) Row-normalized layer confusion matrices with known levels at ×0.8 and ×1.2; (**c**,**d**) the same network without reference monitoring (nominal levels assumed). H, healthy; S, sensor. Red boxes mark the AFE–ADC cells. (**e**) AFE recall, ADC recall and AFE–ADC cross-confusion (Equation (11)) for known levels, the monitor with *E* = 0 to ±5% and the no-monitor control at ×0.8 and ×1.2; the dashed line is the gate C limit.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 8.** AFE/ADC separation of PRr at ±20% reference amplitude, pooled over the five phases. Complete results for every monitor condition are given in Table S2.
:::

| Domain | Reference condition | AFE recall ×0.8 | ADC recall ×0.8 | κ ×0.8 | AFE recall ×1.2 | ADC recall ×1.2 | κ ×1.2 |
|:--|:--|:-:|:-:|:-:|:-:|:-:|:-:|
| Behavioral | Known levels | 0.912 | 0.831 | 0.026 | 0.898 | 0.797 | 0.089 |
| Behavioral | Monitor, *E* = ±2% | 0.886 | 0.826 | 0.035 | 0.885 | 0.797 | 0.079 |
| Behavioral | Monitor, *E* = ±5% | 0.891 | 0.778 | 0.033 | 0.878 | 0.777 | 0.083 |
| ngspice | Known levels | 0.909 | 0.833 | 0.028 | 0.898 | 0.799 | 0.088 |
| ngspice | Monitor, *E* = ±2% | 0.883 | 0.832 | 0.036 | 0.885 | 0.797 | 0.078 |
| ngspice | Monitor, *E* = ±5% | 0.887 | 0.773 | 0.034 | 0.875 | 0.778 | 0.081 |
| Behavioral | No monitor (nominal levels assumed) | 0.426 | 0.944 | 0.230 | 0.375 | 0.820 | 0.336 |


::: {custom-style="MDPI_2.2_heading2"}
7.5. Behavioral-to-Circuit Transfer
:::

::: {custom-style="MDPI_3.1_text"}
Table 9 and Figure 8 compare the behaviorally trained PRr network on the matched grid (×0.8, ×1.0 and ×1.2 at the five phases) in both domains. At $E$ = ±2%, the case fixed for gate E, layer macro-F1 was 0.650 on behavioral data and 0.649 on ngspice data, a transfer loss of 0.002 with 95% interval [−0.003, +0.006]; the loss was consistent in sign across the three seeds but small in every one. Over all five reference conditions the loss ranged from −0.001 to +0.002, with every interval inside −0.005 to +0.006; the corresponding loss in fault macro-F1 at $E$ = ±2% was +0.000 [−0.003, +0.002]. Per phase, the behavioral and ngspice curves differed by at most 0.003 (Figure 8c).
:::

::: {custom-style="MDPI_3.1_text"}
The first version of the test lost 0.119 [0.107, 0.132] under the same criterion. Figure 8b and Table 9 show this value for orientation only: it was obtained on other seeds and with other descriptors, so it is not a controlled comparison. The controlled evidence for the role of the phase is the comparison of FS and PR on the same seeds and phases in Section 7.2. Because the two domains differ by only 0.14–0.27 mV in the noise-free case, a transfer loss close to zero is the expected outcome once the descriptors are insensitive to the timing convention. It shows that the circuit-level effects modeled here do not disturb the diagnosis, not that hardware would behave in the same way.
:::

::: {custom-style="MDPI_3.1_text"}
Mixed-domain training (PRrM) raised the ngspice score above that of PRr by +0.014 [+0.005, +0.024] at $E$ = ±2% and by +0.014 to +0.040 over the five reference conditions, and it also raised the behavioral score (Section 7.6). Since PRrM sees twice as many training rows, including rows with tolerances and the additional noise, the gain cannot be attributed to the ngspice data alone.
:::

::: {custom-style="MDPI_5.2_figure"}
![](Fig08_domain_transfer.png){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 8.** Behavioral-to-ngspice transfer on the matched grid (×0.8, ×1.0 and ×1.2 at five phases; simulation results). (**a**) Layer macro-F1 of the behaviorally trained PRr network on behavioral data and on ngspice data, and of the secondary variant PRrM on ngspice data, for each reference condition. (**b**) Transfer loss (behavioral minus ngspice) with paired cluster-bootstrap 95% intervals; the square marks the loss of the first version of the test (other seeds and descriptors; not a controlled comparison); the dashed line is the gate E limit. (**c**) Layer macro-F1 per edge phase at *E* = ±2% for PRr and PRrM in both domains, pooled over the matched grid and recomputed from the saved predictions.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 9.** Behavioral-to-ngspice transfer of layer macro-F1 on the matched grid (×0.8, ×1.0, ×1.2 × five phases).
:::

| Reference condition | PRr behavioral | PRr ngspice | Loss, layer macro-F1 [95% CI] | Loss, fault macro-F1 [95% CI] | PRrM ngspice | PRrM − PRr on ngspice [95% CI] |
|:--|:-:|:-:|:-:|:-:|:-:|:-:|
| Known levels | 0.639 | 0.639 | −0.001 [−0.005, +0.004] | −0.001 [−0.004, +0.002] | 0.677 | +0.038 [+0.029, +0.047] |
| Monitor, *E* = 0% | 0.636 | 0.635 | +0.001 [−0.003, +0.004] | +0.001 [−0.002, +0.004] | 0.675 | +0.040 [+0.031, +0.050] |
| Monitor, *E* = ±1% | 0.637 | 0.634 | +0.002 [−0.001, +0.006] | −0.001 [−0.004, +0.001] | 0.670 | +0.036 [+0.027, +0.045] |
| Monitor, *E* = ±2% | 0.650 | 0.649 | +0.002 [−0.003, +0.006] | +0.000 [−0.003, +0.002] | 0.663 | +0.014 [+0.005, +0.024] |
| Monitor, *E* = ±5% | 0.640 | 0.640 | +0.001 [−0.003, +0.005] | −0.002 [−0.004, +0.001] | 0.655 | +0.015 [+0.006, +0.024] |
| First version, *E* = ±2% (other seeds) | 0.658 | 0.539 | 0.119 [0.107, 0.132] | – | – | – |


::: {custom-style="MDPI_4.3_table_footer"}
Both PRr columns use the same behaviorally trained network. Intervals are paired condition-level cluster-bootstrap 95% intervals (5000 resamples per seed). The last row is the first version of the test, evaluated on other seeds with other descriptors; it is shown for orientation and is not a controlled comparison.
:::

::: {custom-style="MDPI_2.2_heading2"}
7.6. Attribution and Baselines
:::

::: {custom-style="MDPI_3.1_text"}
Figure 9 and Table 10 separate the two ingredients of PRr at $E$ = ±2%. Replacing the fixed-sample fractions by the whole-transient descriptors without changing the training (PR − FS) improved layer macro-F1 by +0.042 [+0.033, +0.051] in the behavioral domain and +0.040 [+0.032, +0.049] in ngspice. Randomizing the training phase without changing the descriptors (FSr − FS) improved it by +0.030 [+0.023, +0.038] and +0.029 [+0.022, +0.037]. Given randomization, the descriptors still added +0.012 [+0.004, +0.019] and +0.014 [+0.006, +0.022]; given the robust descriptors, randomization added nothing that could be resolved (+0.000 [−0.006, +0.006] and +0.003 [−0.004, +0.009]). Every resolved difference had the same sign in all three seeds. The practical reading is that the descriptors carry the improvement. PR and PRr are statistically indistinguishable, and PRr remains the primary method only because the protocol fixed it in advance.
:::

::: {custom-style="MDPI_5.2_figure"}
![](Fig09_ablation.png){width=16cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 9.** Attribution study (simulation results, monitor *E* = ±2%, pooled over amplitudes and phases). (**a**) Layer macro-F1 of the earlier descriptors (A0), the fixed-sample descriptors (FS), FS with phase-randomized training (FSr), the phase-robust descriptors (PR), the primary method (PRr) and the secondary variant (PRrM); solid bars behavioral, hatched bars ngspice (A0 was not simulated in ngspice). The two domains are pooled over different amplitude grids. (**b**) Phase spread; the dashed line is the gate G limit. (**c**) Paired differences with cluster-bootstrap 95% intervals.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 10.** Attribution of the PRr improvement: paired differences in layer and fault macro-F1 at *E* = ±2%, pooled over amplitudes and phases, with cluster-bootstrap 95% intervals.
:::

| Comparison | Layer, behavioral | Layer, ngspice | Fault, behavioral | Fault, ngspice |
|:--|:-:|:-:|:-:|:-:|
| PR − FS: descriptors alone | +0.042 [+0.033, +0.051] | +0.040 [+0.032, +0.049] | +0.028 [+0.022, +0.035] | +0.030 [+0.023, +0.036] |
| FSr − FS: phase randomization alone | +0.030 [+0.023, +0.038] | +0.029 [+0.022, +0.037] | +0.016 [+0.011, +0.020] | +0.016 [+0.012, +0.021] |
| PRr − FSr: descriptors, given randomization | +0.012 [+0.004, +0.019] | +0.014 [+0.006, +0.022] | +0.014 [+0.008, +0.020] | +0.015 [+0.008, +0.021] |
| PRr − PR: randomization, given robust descriptors | +0.000 [−0.006, +0.006] | +0.003 [−0.004, +0.009] | +0.001 [−0.002, +0.004] | +0.001 [−0.002, +0.005] |
| PRr − FS: both ingredients | +0.042 [+0.034, +0.050] | +0.043 [+0.035, +0.051] | +0.030 [+0.023, +0.036] | +0.031 [+0.024, +0.038] |
| PRrM − PRr: mixed-domain training | +0.016 [+0.008, +0.025] | +0.014 [+0.005, +0.024] | +0.008 [+0.002, +0.014] | +0.009 [+0.003, +0.015] |
| PRr − A0: against earlier descriptors | +0.375 [+0.363, +0.387] | – | +0.440 [+0.431, +0.450] | – |


::: {custom-style="MDPI_3.1_text"}
Mixed-domain training improved layer macro-F1 by +0.016 [+0.008, +0.025] in the behavioral domain and +0.014 [+0.005, +0.024] in ngspice. Against the earlier A0 descriptors, PRr was better by +0.375 [+0.363, +0.387] in the behavioral domain, a difference driven mainly by the collapse of A0 under reference-amplitude error (Figure 6a).
:::

::: {custom-style="MDPI_3.1_text"}
Table 11 compares PRr with the single-path baselines at ±20% amplitude with known levels, the comparisons of gate B. The passive classifier (layer macro-F1 0.259) and the single additive probe (0.349/0.396 at ×0.8/×1.2) show that neither the sensor signal alone nor a single probe localizes the faults reliably. More informative are the single-window versions of PRr itself: the AFE-only test reached 0.473/0.516 and the ADC-only test 0.455/0.452, against 0.615/0.643 for the two-point test. With the same descriptors and the same classifier, removing either reference window costs more than 0.12 layer macro-F1, which is the empirical counterpart of the identifiability argument in Section 3.3. Over all 70 comparisons of gate B (seven baselines, five reference conditions, two amplitudes; Table S4), the smallest interval lower bound was +0.112.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 11.** Baseline comparison in the behavioral domain with known reference levels, pooled over the five phases. Differences are PRr minus the baseline with cluster-bootstrap 95% intervals.
:::

| Method | Layer macro-F1 ×0.8 | Layer macro-F1 ×1.2 | PRr − method ×0.8 [95% CI] | PRr − method ×1.2 [95% CI] |
|:--|:-:|:-:|:-:|:-:|
| Passive (sensor signal only), A0 descriptors | 0.259 | 0.259 | +0.356 [+0.341, +0.371] | +0.384 [+0.368, +0.400] |
| Single additive probe, A0 descriptors | 0.349 | 0.396 | +0.266 [+0.250, +0.282] | +0.246 [+0.230, +0.261] |
| AFE-only reference, A0 descriptors | 0.320 | 0.295 | +0.295 [+0.280, +0.311] | +0.348 [+0.329, +0.366] |
| ADC-only reference, A0 descriptors | 0.120 | 0.122 | +0.495 [+0.482, +0.508] | +0.521 [+0.507, +0.534] |
| Two-point reference, A0 descriptors | 0.140 | 0.121 | +0.475 [+0.461, +0.489] | +0.521 [+0.507, +0.535] |
| AFE-only reference, PRr descriptors | 0.473 | 0.516 | +0.142 [+0.128, +0.155] | +0.126 [+0.112, +0.140] |
| ADC-only reference, PRr descriptors | 0.455 | 0.452 | +0.160 [+0.144, +0.175] | +0.190 [+0.176, +0.206] |
| Two-point, FS descriptors | 0.578 | 0.593 | – | – |
| Two-point, FSr | 0.626 | 0.634 | – | – |
| Two-point, PR | 0.612 | 0.635 | – | – |
| Two-point, PRr (primary) | 0.615 | 0.643 | – | – |
| Two-point, PRrM (secondary) | 0.660 | 0.670 | – | – |


::: {custom-style="MDPI_2.2_heading2"}
7.7. Per-Class Performance and Weak Classes
:::

::: {custom-style="MDPI_3.1_text"}
Figure 10 and Table 12 explain the modest absolute scores. Five classes were recognized well by PRr in both domains: sensor noise, AFE offset, AFE bandwidth, ADC offset and ADC gain, with recall between 0.845 and 0.997. Four classes were not: healthy, sensor bias, sensor gain and ADC clipping, with recall between 0.260 and 0.475. The fine-fault confusion matrix (Figure S1) shows that these four classes are confused mainly with each other. In the behavioral domain, healthy records were assigned to ADC clipping in 30% of cases and to sensor bias or sensor gain in 38%, and ADC-clipping records were assigned to healthy in 21% of cases. This is the pattern expected from Section 3.3. Sensor bias and gain cannot be separated from normal variation of the measurand in a single record. A clipping fault whose threshold the signal never reaches produces a record identical to a healthy one; on the development seed, the median of the largest raw sample in the sensor intervals was 1.98 V, below the lowest simulated clipping level of 2.38 V.
:::

::: {custom-style="MDPI_3.1_text"}
At the layer level, the consequence is a healthy-layer recall of only 0.142 in the behavioral domain and 0.134 in ngspice: most healthy records were flagged as faulty. As evaluated here, the classifier is therefore a localization aid for records already suspected to be faulty, not a detector that decides whether a fault is present. Mixed-domain training raised the behavioral healthy-layer recall to 0.238 without changing this picture. None of the revisions in this study was designed to address these classes, and none did.
:::

::: {custom-style="MDPI_5.2_figure"}
![](Fig10_per_class_recall.png){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 10.** Per-class recall (simulation results, monitor *E* = ±2%, pooled over amplitudes and phases; mean of three dataset seeds). (**a**,**b**) Fine-fault recall of every arm in the behavioral and ngspice domains; PRr, the primary method, in bold. (**c**) Layer recall of FS, PRr and PRrM in both domains and of the no-monitor control (behavioral, ×0.8 and ×1.2). Red outlines mark recall below 0.50, a display threshold rather than a criterion of the protocol.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 12.** Recall per fault class and per layer for PRr and PRrM at *E* = ±2%, pooled over amplitudes and phases (mean of three dataset seeds). Results for all arms are given in Table S3.
:::

| Class | PRr behavioral | PRr ngspice | PRrM behavioral | PRrM ngspice | FS behavioral |
|:--|:-:|:-:|:-:|:-:|:-:|
| Healthy | 0.294 | 0.266 | 0.356 | 0.320 | 0.230 |
| Sensor bias | 0.260 | 0.263 | 0.255 | 0.256 | 0.231 |
| Sensor gain | 0.314 | 0.310 | 0.338 | 0.347 | 0.312 |
| Sensor noise | 0.984 | 0.982 | 0.983 | 0.983 | 0.988 |
| AFE offset | 0.857 | 0.845 | 0.921 | 0.912 | 0.763 |
| AFE bandwidth | 0.955 | 0.942 | 0.942 | 0.928 | 0.938 |
| ADC offset | 0.997 | 0.995 | 0.997 | 0.995 | 0.992 |
| ADC gain | 0.922 | 0.907 | 0.927 | 0.915 | 0.948 |
| ADC clipping | 0.447 | 0.475 | 0.368 | 0.399 | 0.398 |
| Healthy layer | 0.142 | 0.134 | 0.238 | 0.220 | 0.098 |
| Sensor layer | 0.780 | 0.773 | 0.742 | 0.735 | 0.703 |
| AFE layer | 0.911 | 0.901 | 0.940 | 0.933 | 0.866 |
| ADC layer | 0.806 | 0.810 | 0.775 | 0.776 | 0.822 |


::: {custom-style="MDPI_2.2_heading2"}
7.8. Computational Cost
:::

::: {custom-style="MDPI_3.1_text"}
The phase-robust descriptors took 0.79 ms per record on one core of a desktop computer in Python, against 0.47 ms for the FS set, and one MLP inference took 0.68 µs per record in batched evaluation. The layer network's 6,868 parameters occupy about 27 kB in 32-bit floating point. These are desktop measurements of an unoptimized implementation; no microcontroller timing, memory footprint, energy or silicon area was measured, and the feasibility of an embedded implementation is an expectation rather than a result of this study. Table S5 lists the complete cost and runtime figures.
:::

::: {custom-style="MDPI_2.1_heading1"}
8\. Discussion
:::

::: {custom-style="MDPI_2.2_heading2"}
8.1. What the Results Show
:::

::: {custom-style="MDPI_3.1_text"}
The study set out to test one explanation and one remedy. The explanation was that the behavioral-to-circuit loss of the first version came largely from the sampling phase of the reference edge; the remedy was to estimate the transient with the edge time as a free parameter. Both are supported within the simulated setting. On the same seeds, the fixed-sample descriptors lost about 0.08 layer macro-F1 across the sample period in both domains, the fit-based descriptors lost at most 0.011, and the behavioral and ngspice results agreed to within 0.002. The attribution shows that the descriptors, not the randomized training, carry the effect. This is an argument for addressing a nuisance variable in the feature design when its physics is known, rather than relying on the classifier to average it out: randomization helped the fixed-sample descriptors but left a residual decline at $\psi = 0.999$, whereas the fitted descriptors reduced the dependence to a few thousandths of layer macro-F1 even when trained at a single phase.
:::

::: {custom-style="MDPI_3.1_text"}
The second finding concerns the reference. The calibration analysis of Section 4.2 predicts that an unmonitored amplitude change will appear as an ADC gain error, and the no-monitor control shows exactly this, with layer macro-F1 falling to 0.310 and 0.237 at ±20%. With a monitor whose common gain error is bounded by 5%, the apparent ADC gain error stays below the smallest simulated gain fault, and the results bear this out. A reference monitor should thus be treated as part of the test architecture and its error bound as a design parameter that must be smaller than the smallest gain fault to be detected.
:::

::: {custom-style="MDPI_2.2_heading2"}
8.2. Relation to Previous Work
:::

::: {custom-style="MDPI_3.1_text"}
The two-point principle is not new: estimating gain and offset from known input levels is standard practice in ADC testing and calibration [8,21], and isolating a readout from its sensor has been demonstrated [7]. What this study adds is the combination of a second injection point behind the AFE, so that ADC and AFE parameters are estimated in sequence, with a measured rather than assumed reference and with transient descriptors that are insensitive to the edge timing over the tested range, evaluated together on unseen seeds in two simulation domains. Czaja's self-test is the closest in its use of sampled pulse responses for localization [14]; it localizes more finely (to components) and has been verified in hardware, whereas the present architecture extends localization to the converter, which in that approach serves as the measuring instrument, at the price of a second multiplexer and a monitor channel. Where stimulus and sampling can be synchronized by design, as in that work, the phase problem studied here does not arise; the phase-robust descriptors are aimed at interfaces in which they cannot. Hu et al. accept that analog and converter gain errors can mask each other [15]; the second injection point is a way to make them separable instead. Compared with the deep-learning diagnosis literature [29,31,33], the classifier here is deliberately small and its inputs are physically defined; the results suggest that, for this problem, the limiting factor is the observability of certain faults rather than the capacity of the classifier. A direct numerical comparison with these works is not meaningful because they address different circuits, fault sets and data.
:::

::: {custom-style="MDPI_2.2_heading2"}
8.3. Practical Implications
:::

::: {custom-style="MDPI_3.1_text"}
Several design rules follow for a sensor interface that is meant to localize its own faults. References should be injected at two depths of the chain, one in front of the AFE and one directly at the ADC input, and the ADC transfer should be removed before the AFE transfer is estimated. The applied reference levels should be measured, with a monitor gain error smaller than the smallest gain fault of interest. Transient descriptors should not read fixed samples after a test edge unless the edge is synchronized with the sampling clock by design; in this implementation the fit adds about 0.3 ms per record and reduces the dependence substantially. Finally, the test cannot reveal what the references do not excite: a sensor-side reference or redundancy is needed to separate sensor bias and gain from the measurand, and clipping can be tested only by a stimulus that reaches the clipping level, for example a third reference level near full scale. These suggestions follow from the analysis and the simulations; their benefit in hardware remains to be shown.
:::

::: {custom-style="MDPI_2.2_heading2"}
8.4. Limitations
:::

::: {custom-style="MDPI_3.1_text"}
The limitations are substantial and define the scope of the conclusions.
:::

::: {custom-style="MDPI_3.8_bullet"}
Both simulation domains are first-order RC models with an affine ADC, developed within the same project, and they agree closely in the noise-free case. The transfer result therefore probes switch resistances, additional noise, tolerances and circuit-level edge handling, not unmodeled hardware effects such as charge injection, op-amp bandwidth and slew rate, reference settling, leakage or ADC nonlinearity. It is not a hardware validation.
:::

::: {custom-style="MDPI_3.8_bullet"}
The phase model assumes one common, constant edge phase for all reference and multiplexer edges within a record. Jitter between edges, drift of the phase within a record and different phases for the AFE and ADC references were not tested.
:::

::: {custom-style="MDPI_3.8_bullet"}
The monitor is simulated with a common gain error, white noise and a trimmed offset, and each monitored network was trained with the error bound it was tested with, which assumes that the bound is known.
:::

::: {custom-style="MDPI_3.8_bullet"}
Absolute performance is modest, the healthy-layer recall is about 0.14 and four classes are poorly separated. The classifier is a localization aid, not a detector, and no claim of deployable diagnostic accuracy is made.
:::

::: {custom-style="MDPI_3.8_bullet"}
The evidence comes from three dataset seeds with 88 test conditions each. The intervals resample test conditions and do not capture variability between training runs beyond two initializations; separately trained networks for different monitor bounds differed by up to 0.018 at nominal amplitude. The early stopping used a row-level rather than a condition-level hold-out.
:::

::: {custom-style="MDPI_3.8_bullet"}
Robustness was demonstrated for the nuisance variables that were varied (edge phase, reference amplitude, monitor error, tolerances and the two domains) over the tested ranges. It does not imply robustness to other variables, other fault types or multiple simultaneous faults, which were not simulated.
:::

::: {custom-style="MDPI_3.8_bullet"}
The protocol was fixed and hashed internally but not registered externally, and it misstates the use of early stopping (Section 5). The statistics and figures are reproducible from the saved predictions; the simulations and training have not been rerun independently.
:::

::: {custom-style="MDPI_2.2_heading2"}
8.5. Future Work
:::

::: {custom-style="MDPI_3.1_text"}
The next step is a validation with circuit models that include real operational-amplifier and switch behavior, followed by a small hardware prototype with a microcontroller ADC, where the edge phase is genuinely uncontrolled and the monitor error can be measured. Extending the test with a sensor-side reference and a near-full-scale level would address the weak classes directly. Jitter and drift of the edge phase, simultaneous faults and an embedded implementation of the fit and the network should be evaluated under the same kind of frozen protocol.
:::

::: {custom-style="MDPI_2.1_heading1"}
9\. Conclusions
:::

::: {custom-style="MDPI_3.1_text"}
A two-point active self-test with a monitored reference can localize AFE and ADC faults in a simulated sensor interface while keeping their mutual confusion low under ±20% reference-amplitude error, provided that the reference levels are measured. Its transient descriptors should be insensitive to where the reference edge falls between ADC samples: replacing fixed-sample readings by a first-order fit with a free edge time reduced the phase spread of layer macro-F1 from about 0.08 to 0.005–0.011 and brought the behavioral-to-ngspice transfer loss on a matched grid to 0.002 [−0.003, +0.006], meeting all decision gates fixed before the validation run. The improvement comes from the descriptors rather than from randomized training. Absolute layer macro-F1 remains about 0.65 because healthy records, sensor bias and gain faults and inactive clipping faults are structurally hard to observe with the present references. The method should therefore be read as a phase-robust localization aid validated in two closely related simulation domains, not as a hardware-validated fault detector.
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Supplementary Materials:** The following supporting information is provided in the file Phase_Robust_Sensors_Supplementary: Figure S1: Fine-fault confusion matrix of PRr; Table S1: Layer macro-F1 per edge phase for every arm and reference condition; Table S2: AFE/ADC separation for every reference condition; Table S3: Per-class recall of every arm; Table S4: All 70 comparisons of gate B; Table S5: Computational cost and runtime; Table S6: Software environment and evidence files.
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Author Contributions:** ⟦To be completed by the author(s) using the CRediT roles.⟧ 
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Funding:** ⟦To be completed by the author(s).⟧
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Institutional Review Board Statement:** Not applicable.
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Informed Consent Statement:** Not applicable.
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Data Availability Statement:** The frozen protocol, the simulator, descriptor, training and analysis source code, the per-record predictions of all three validation seeds, the summary results, the figure source data and the scripts that regenerate every figure, table and statistic in this article are included in the supporting material submitted with this article. ⟦Repository name and persistent identifier, if the material is also deposited publicly, to be added by the author(s).⟧
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Acknowledgments:** During the preparation of this study and manuscript, the author used Claude Code (Anthropic) for implementing the simulation, descriptor, training and analysis software, drafting the frozen protocols and stage reports, searching and verifying the literature, regenerating figures from saved data, recomputing the statistics and drafting the text. The author has reviewed and edited the output and takes full responsibility for the content of this publication.
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Conflicts of Interest:** ⟦To be completed by the author(s).⟧
:::

::: {custom-style="MDPI_2.1_heading1"}
Abbreviations
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
The following abbreviations are used in this manuscript:
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
A0 Descriptor set of the stage before the reference revision
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
ADC Analog-to-digital converter
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
AFE Analog front-end
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
BIST Built-in self-test
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
CI Confidence interval
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
FS Fixed-sample descriptor set (rise fractions read at fixed samples after the step)
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
FSr FS with phase-randomized training
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
MEMS Micro-electro-mechanical system
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
MLP Multilayer perceptron
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
MUX Multiplexer
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
PR Phase-robust descriptors, trained at ψ = 0
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
PRr Phase-robust descriptors with phase-randomized training (primary method)
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
PRrM PRr with mixed behavioral and ngspice training (secondary variant)
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
R1, R2 Two-level references at the AFE input and at the ADC input
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
RMS Root mean square
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
RSS Residual sum of squares
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
SAR Successive-approximation register
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
SEIR Stimulus error identification and removal
:::


::: {custom-style="MDPI_2.1_heading1"}
References
:::

::: {custom-style="MDPI_8.1_references"}
Hantos, G.; Flynn, D.; Desmulliez, M.P.Y. Built-In Self-Test (BIST) Methods for MEMS: A Review. *Micromachines* **2021**, *12*, 40. https://doi.org/10.3390/mi12010040.
:::

::: {custom-style="MDPI_8.1_references"}
Mir, S.; Rufer, L.; Dhayni, A. Built-in-self-test techniques for MEMS. *Microelectron. J.* **2006**, *37*, 1591–1597. https://doi.org/10.1016/j.mejo.2006.04.016.
:::

::: {custom-style="MDPI_8.1_references"}
Ozel, M.K.; Cheperak, M.; Dar, T.; Kiaei, S.; Bakkaloglu, B.; Ozev, S. An Electrical-Stimulus-Only BIST IC for Capacitive MEMS Accelerometer Sensitivity Characterization. *IEEE Sens. J.* **2017**, *17*, 695–708. https://doi.org/10.1109/JSEN.2016.2636861.
:::

::: {custom-style="MDPI_8.1_references"}
Mason, A.; Chavan, A.V.; Wise, K.D. A Mixed-Voltage Sensor Readout Circuit With On-Chip Calibration and Built-In Self-Test. *IEEE Sens. J.* **2007**, *7*, 1225–1232. https://doi.org/10.1109/JSEN.2007.897957.
:::

::: {custom-style="MDPI_8.1_references"}
Chen, D.; Liu, X.; Yin, L.; Wang, Y.; Shi, Z.; Zhang, G. A ΣΔ Closed-Loop Interface for a MEMS Accelerometer with Digital Built-In Self-Test Function. *Micromachines* **2018**, *9*, 444. https://doi.org/10.3390/mi9090444.
:::

::: {custom-style="MDPI_8.1_references"}
Basith, I.I.; Kandalaft, N.; Rashidzadeh, R.; Ahmadi, M. Charge-Controlled Readout and BIST Circuit for MEMS Sensors. *IEEE Trans. Comput.-Aided Des. Integr. Circuits Syst.* **2013**, *32*, 433–441. https://doi.org/10.1109/TCAD.2012.2218602.
:::

::: {custom-style="MDPI_8.1_references"}
Nessler, S.; Marx, M.; Manoli, Y. A Self-Test on Wafer Level for a MEM Gyroscope Readout Based on ΔΣ Modulation. *IEEE Trans. Circuits Syst. I Regul. Pap.* **2018**, *65*, 870–880. https://doi.org/10.1109/TCSI.2017.2767199.
:::

::: {custom-style="MDPI_8.1_references"}
*IEEE Std 1241-2010*; IEEE Standard for Terminology and Test Methods for Analog-to-Digital Converters. IEEE: New York, NY, USA, 2011. https://doi.org/10.1109/IEEESTD.2011.5692956.
:::

::: {custom-style="MDPI_8.1_references"}
Jin, L.; Parthasarathy, K.; Kuyel, T.; Chen, D.; Geiger, R.L. Accurate Testing of Analog-to-Digital Converters Using Low Linearity Signals With Stimulus Error Identification and Removal. *IEEE Trans. Instrum. Meas.* **2005**, *54*, 1188–1199. https://doi.org/10.1109/TIM.2005.847240.
:::

::: {custom-style="MDPI_8.1_references"}
Parthasarathy, K.; Kuyel, T.; Price, D.; Jin, L.; Chen, D.; Geiger, R. BIST and production testing of ADCs using imprecise stimulus. *ACM Trans. Des. Autom. Electron. Syst.* **2003**, *8*, 522–545. https://doi.org/10.1145/944027.944035.
:::

::: {custom-style="MDPI_8.1_references"}
Varier, V.; Sun, N. High-Precision ADC Testing With Relaxed Reference Voltage Stationarity. *IEEE Trans. Instrum. Meas.* **2021**, *70*, 1–9. https://doi.org/10.1109/TIM.2020.3031208.
:::

::: {custom-style="MDPI_8.1_references"}
Feng, R.; Wang, J.; Qiao, W.; Wang, F.; Zhou, M.; Shang, X.; Yu, L.; Zhou, L.; Guo, S. Real-Time Built-In Self-Test of MEMS Gyroscope Based on Quadrature Error Signal. *Micromachines* **2021**, *12*, 1115. https://doi.org/10.3390/mi12091115.
:::

::: {custom-style="MDPI_8.1_references"}
Alraho, S.; Zaman, Q.; Abd, H.; König, A. Integrated Sensor Electronic Front-Ends with Self-X Capabilities. *Chips* **2022**, *1*, 83–120. https://doi.org/10.3390/chips1020008.
:::

::: {custom-style="MDPI_8.1_references"}
Czaja, Z. Self-Testing of Analog Parts Terminated by ADCs Based on Multiple Sampling of Time Responses. *IEEE Trans. Instrum. Meas.* **2013**, *62*, 3160–3167. https://doi.org/10.1109/TIM.2013.2272867.
:::

::: {custom-style="MDPI_8.1_references"}
Hu, G.; Wang, H.; Yang, S. Combined Self-Test of Analog Portion and ADCs in Integrated Mixed-Signal Circuits. *IEICE Trans. Inf. Syst.* **2008**, *E91-D*, 2134–2140. https://doi.org/10.1093/ietisy/e91-d.8.2134.
:::

::: {custom-style="MDPI_8.1_references"}
Pavlidis, A.; Louërat, M.-M.; Faehn, E.; Kumar, A.; Stratigopoulos, H.-G. SymBIST: Symmetry-Based Analog and Mixed-Signal Built-In Self-Test for Functional Safety. *IEEE Trans. Circuits Syst. I Regul. Pap.* **2021**, *68*, 2580–2593. https://doi.org/10.1109/TCSI.2021.3067180.
:::

::: {custom-style="MDPI_8.1_references"}
Ho, C.K.; Shepherd, P.R.; Eberhardt, F.; Tenten, W. Hierarchical fault diagnosis of analog integrated circuits. *IEEE Trans. Circuits Syst. I Fundam. Theory Appl.* **2001**, *48*, 921–929. https://doi.org/10.1109/81.940182.
:::

::: {custom-style="MDPI_8.1_references"}
Hafed, M.M.; Abaskharoun, N.; Roberts, G.W. A 4-GHz effective sample rate integrated test core for analog and mixed-signal circuits. *IEEE J. Solid-State Circuits* **2002**, *37*, 499–514. https://doi.org/10.1109/4.991388.
:::

::: {custom-style="MDPI_8.1_references"}
Wibbenmeyer, J.; Chen, C.-I.H. Built-In Self-Test for Low-Voltage High-Speed Analog-to-Digital Converters. *IEEE Trans. Instrum. Meas.* **2007**, *56*, 2748–2756. https://doi.org/10.1109/TIM.2007.908343.
:::

::: {custom-style="MDPI_8.1_references"}
Santin, E.; Oliveira, L.B.; Goes, J. Built-in self test of high speed analog-to-digital converters. *IEEE Instrum. Meas. Mag.* **2019**, *22*, 4–10. https://doi.org/10.1109/MIM.2019.8917897.
:::

::: {custom-style="MDPI_8.1_references"}
Mohammedali, M.A.; Al-Gayem, Q. New and Accurate Online Self-Test Methods for Gain and Offset Errors of 10-Bit SAR-ADC. *J. Electr. Comput. Eng.* **2024**, *2024*, 8824886. https://doi.org/10.1155/jece/8824886.
:::

::: {custom-style="MDPI_8.1_references"}
Thirunakkarasu, S.; Bakkaloglu, B. Built-in Self-Calibration and Digital-Trim Technique for 14-Bit SAR ADCs Achieving ±1 LSB INL. *IEEE Trans. Very Large Scale Integr. (VLSI) Syst.* **2015**, *23*, 916–925. https://doi.org/10.1109/TVLSI.2014.2321761.
:::

::: {custom-style="MDPI_8.1_references"}
Meijer, G.C.M.; Wang, G.; Fruett, F. Temperature sensors and voltage references implemented in CMOS technology. *IEEE Sens. J.* **2001**, *1*, 225–234. https://doi.org/10.1109/JSEN.2001.954835.
:::

::: {custom-style="MDPI_8.1_references"}
Aminian, M.; Aminian, F. Neural-network based analog-circuit fault diagnosis using wavelet transform as preprocessor. *IEEE Trans. Circuits Syst. II Analog Digit. Signal Process.* **2000**, *47*, 151–156. https://doi.org/10.1109/82.823545.
:::

::: {custom-style="MDPI_8.1_references"}
Aminian, F.; Aminian, M.; Collins, H.W. Analog fault diagnosis of actual circuits using neural networks. *IEEE Trans. Instrum. Meas.* **2002**, *51*, 544–550. https://doi.org/10.1109/TIM.2002.1017726.
:::

::: {custom-style="MDPI_8.1_references"}
Yuan, L.; He, Y.; Huang, J.; Sun, Y. A New Neural-Network-Based Fault Diagnosis Approach for Analog Circuits by Using Kurtosis and Entropy as a Preprocessor. *IEEE Trans. Instrum. Meas.* **2010**, *59*, 586–595. https://doi.org/10.1109/TIM.2009.2025068.
:::

::: {custom-style="MDPI_8.1_references"}
Liu, Z.; Jia, Z.; Vong, C.-M.; Bu, S.; Han, J.; Tang, X. Capturing High-Discriminative Fault Features for Electronics-Rich Analog System via Deep Learning. *IEEE Trans. Ind. Inform.* **2017**, *13*, 1213–1226. https://doi.org/10.1109/TII.2017.2690940.
:::

::: {custom-style="MDPI_8.1_references"}
Zhao, G.; Liu, X.; Zhang, B.; Liu, Y.; Niu, G.; Hu, C. A novel approach for analog circuit fault diagnosis based on Deep Belief Network. *Measurement* **2018**, *121*, 170–178. https://doi.org/10.1016/j.measurement.2018.02.044.
:::

::: {custom-style="MDPI_8.1_references"}
Yang, H.; Meng, C.; Wang, C. Data-Driven Feature Extraction for Analog Circuit Fault Diagnosis Using 1-D Convolutional Neural Network. *IEEE Access* **2020**, *8*, 18305–18315. https://doi.org/10.1109/ACCESS.2020.2968744.
:::

::: {custom-style="MDPI_8.1_references"}
He, W.; He, Y.; Li, B. Generative Adversarial Networks With Comprehensive Wavelet Feature for Fault Diagnosis of Analog Circuits. *IEEE Trans. Instrum. Meas.* **2020**, *69*, 6640–6650. https://doi.org/10.1109/TIM.2020.2969008.
:::

::: {custom-style="MDPI_8.1_references"}
Ji, L.; Fu, C.; Sun, W. Soft Fault Diagnosis of Analog Circuits Based on a ResNet With Circuit Spectrum Map. *IEEE Trans. Circuits Syst. I Regul. Pap.* **2021**, *68*, 2841–2849. https://doi.org/10.1109/TCSI.2021.3076282.
:::

::: {custom-style="MDPI_8.1_references"}
Jia, Z.; Liu, Z.; Gan, Y.; Vong, C.-M.; Pecht, M. A Deep Forest-Based Fault Diagnosis Scheme for Electronics-Rich Analog Circuit Systems. *IEEE Trans. Ind. Electron.* **2021**, *68*, 10087–10096. https://doi.org/10.1109/TIE.2020.3020252.
:::

::: {custom-style="MDPI_8.1_references"}
Zhou, N.; Huang, J.; Zhao, Y.; Chen, S.; Zhao, J.; Long, F. Data-Driven Soft Fault Diagnosis for Analog Circuits Based on Contrastive Learning. *IEEE Trans. Instrum. Meas.* **2025**, *74*, 1–11. https://doi.org/10.1109/TIM.2025.3612648.
:::

::: {custom-style="MDPI_8.1_references"}
Gao, Z.; Yan, A.; Huang, Z.; Cui, J.; Roh, B.-H.; Liu, G.; Girard, P.; Wen, X. Graph-Based Multitask Transfer Learning for Fault Detection and Diagnosis of Few-Shot Analog Circuits. *IEEE Internet Things J.* **2025**, *12*, 21264–21279. https://doi.org/10.1109/JIOT.2025.3547957.
:::

::: {custom-style="MDPI_8.1_references"}
Zhang, C.; Du, P.; Zhou, D.; Dong, Z.; He, S.; Zhou, Z. Fault Diagnosis of Low-Noise Amplifier Circuit Based on Fusion Domain Adaptation Method. *Actuators* **2024**, *13*, 379. https://doi.org/10.3390/act13090379.
:::

::: {custom-style="MDPI_8.1_references"}
Liu, X.; Yang, H.; Gao, T.; Yang, J. A Hybrid Fault Diagnosis Framework Based on Test Stimulus Optimization and MPCNN for Analog Circuits. *IEEE Trans. Instrum. Meas.* **2025**, *74*, 1–13. https://doi.org/10.1109/TIM.2025.3588964.
:::

::: {custom-style="MDPI_8.1_references"}
Hałgas, S. Challenges in Fault Diagnosis of Nonlinear Circuits. *Electronics* **2025**, *14*, 4427. https://doi.org/10.3390/electronics14224427.
:::

::: {custom-style="MDPI_8.1_references"}
Qiu, S.; Cui, X.; Ping, Z.; Shan, N.; Li, Z.; Bao, X.; Xu, X. Deep Learning Techniques in Intelligent Fault Diagnosis and Prognosis for Industrial Systems: A Review. *Sensors* **2023**, *23*, 1305. https://doi.org/10.3390/s23031305.
:::

::: {custom-style="MDPI_8.1_references"}
Shen, Z.; Wang, Q. Failure Detection, Isolation, and Recovery of Multifunctional Self-Validating Sensor. *IEEE Trans. Instrum. Meas.* **2012**, *61*, 3351–3362. https://doi.org/10.1109/TIM.2012.2205509.
:::

::: {custom-style="MDPI_8.1_references"}
Chen, Y.; Wang, M.; Chen, Z.; Zhao, W.; Shi, Y. Self-validating sensor technology and its application in artificial olfaction: A review. *Measurement* **2025**, *242*, 116025. https://doi.org/10.1016/j.measurement.2024.116025.
:::

::: {custom-style="MDPI_8.1_references"}
Wang, M.; Chen, Y.; Chen, Y.; Chen, Z.; Marco, S. Fault Detection, Isolation, and Diagnosis Method for Self-Validating MOX Gas Sensor Arrays Under Multiple Fault Conditions. *IEEE Trans. Instrum. Meas.* **2026**, *75*, 3525214. https://doi.org/10.1109/TIM.2026.3744022.
:::

::: {custom-style="MDPI_8.1_references"}
Tosoni, F.; Dall’Ora, N.; Fraccaroli, E.; Vinco, S.; Fummi, F. Multidomain Fault Models Covering the Analog Side of a Smart or Cyber–Physical System. *IEEE Trans. Comput.* **2024**, *73*, 829–841. https://doi.org/10.1109/TC.2023.3345135.
:::

::: {custom-style="MDPI_8.1_references"}
*IEEE Std 181-2011*; IEEE Standard for Transitions, Pulses, and Related Waveforms. IEEE: New York, NY, USA, 2011. https://doi.org/10.1109/IEEESTD.2011.6016198.
:::

::: {custom-style="MDPI_8.1_references"}
Gu, M.; Tao, Y.; Zhong, Y.; Jie, L.; Sun, N. Timing-Skew Calibration Techniques in Time-Interleaved ADCs. *IEEE Open J. Solid-State Circuits Soc.* **2025**, *5*, 1–10. https://doi.org/10.1109/OJSSCS.2024.3519486.
:::

::: {custom-style="MDPI_8.1_references"}
Svatos, J.; Fischer, J.; Holub, J. High-speed equivalent-time sampling virtual instrument based on microcontroller ADC. *Measurement* **2023**, *220*, 113392. https://doi.org/10.1016/j.measurement.2023.113392.
:::

::: {custom-style="MDPI_8.1_references"}
Renczes, B.; Pálfi, V. A computationally efficient non-iterative four-parameter sine fitting method. *IET Signal Process.* **2021**, *15*, 562–571. https://doi.org/10.1049/sil2.12061.
:::

::: {custom-style="MDPI_8.1_references"}
Golub, G.H.; Pereyra, V. The Differentiation of Pseudo-Inverses and Nonlinear Least Squares Problems Whose Variables Separate. *SIAM J. Numer. Anal.* **1973**, *10*, 413–432. https://doi.org/10.1137/0710036.
:::

::: {custom-style="MDPI_8.1_references"}
Golub, G.; Pereyra, V. Separable nonlinear least squares: the variable projection method and its applications. *Inverse Probl.* **2003**, *19*, R1–R26. https://doi.org/10.1088/0266-5611/19/2/201.
:::

::: {custom-style="MDPI_8.1_references"}
Pedregosa, F.; Varoquaux, G.; Gramfort, A.; Michel, V.; Thirion, B.; Grisel, O.; Blondel, M.; Prettenhofer, P.; Weiss, R.; Dubourg, V.; Vanderplas, J.; Passos, A.; Cournapeau, D.; Brucher, M.; Perrot, M.; Duchesnay, É. Scikit-learn: Machine Learning in Python. *J. Mach. Learn. Res.* **2011**, *12*, 2825–2830. Available online: https://jmlr.org/papers/v12/pedregosa11a.html (accessed on 11 November 2026).
:::

::: {custom-style="MDPI_8.1_references"}
Kingma, D.P.; Ba, J. Adam: A Method for Stochastic Optimization. In Proceedings of the 3rd International Conference on Learning Representations (ICLR), San Diego, CA, USA, 7–9 May 2015. Available online: https://arxiv.org/abs/1412.6980 (accessed on 11 November 2026).
:::

::: {custom-style="MDPI_8.1_references"}
Tobin, J.; Fong, R.; Ray, A.; Schneider, J.; Zaremba, W.; Abbeel, P. Domain randomization for transferring deep neural networks from simulation to the real world. In Proceedings of the 2017 IEEE/RSJ International Conference on Intelligent Robots and Systems (IROS), Vancouver, BC, Canada, 24–28 September 2017; pp. 23–30. https://doi.org/10.1109/IROS.2017.8202133.
:::

::: {custom-style="MDPI_8.1_references"}
Iwana, B.K.; Uchida, S. An empirical survey of data augmentation for time series classification with neural networks. *PLoS ONE* **2021**, *16*, e0254841. https://doi.org/10.1371/journal.pone.0254841.
:::

::: {custom-style="MDPI_8.1_references"}
Ngspice Developers. *Ngspice User's Manual, Version 47*. Available online: https://ngspice.sourceforge.io/docs/ngspice-47-manual.pdf (accessed on 11 November 2026).
:::

::: {custom-style="MDPI_8.1_references"}
Sokolova, M.; Lapalme, G. A systematic analysis of performance measures for classification tasks. *Inf. Process. Manag.* **2009**, *45*, 427–437. https://doi.org/10.1016/j.ipm.2009.03.002.
:::

::: {custom-style="MDPI_8.1_references"}
Field, C.A.; Welsh, A.H. Bootstrapping Clustered Data. *J. R. Stat. Soc. Ser. B Stat. Methodol.* **2007**, *69*, 369–390. https://doi.org/10.1111/j.1467-9868.2007.00593.x.
:::

::: {custom-style="MDPI_8.1_references"}
Davison, A.C.; Hinkley, D.V. *Bootstrap Methods and Their Application*; Cambridge University Press: Cambridge, UK, 1997. https://doi.org/10.1017/CBO9780511802843.
:::

