"""Export a DOCX to PDF through Word and write page-pair PNGs for visual inspection."""
import glob, shutil, subprocess, sys
from pathlib import Path
from PIL import Image
sys.path.insert(0, str(Path(__file__).resolve().parent))
import docbuild as B
docx_p = Path(sys.argv[1]); pdf_p = docx_p.with_suffix(".pdf"); outdir = Path(sys.argv[2])
B.word_pdf(docx_p, pdf_p)
shutil.rmtree(outdir, ignore_errors=True); outdir.mkdir(parents=True)
subprocess.run(["pdftoppm", "-r", sys.argv[3] if len(sys.argv) > 3 else "75", "-png", str(pdf_p), str(outdir / "p")], check=True)
fs = sorted(glob.glob(str(outdir / "p-*.png")))
for i in range(0, len(fs), 2):
    ims = [Image.open(f) for f in fs[i:i + 2]]
    c = Image.new("RGB", (sum(im.width for im in ims) + 10, max(im.height for im in ims)), "gray"); x = 0
    for im in ims:
        c.paste(im, (x, 0)); x += im.width + 10
    c.save(outdir / f"pair_{i // 2 + 1:02d}.png")
print(len(fs), "pages")
