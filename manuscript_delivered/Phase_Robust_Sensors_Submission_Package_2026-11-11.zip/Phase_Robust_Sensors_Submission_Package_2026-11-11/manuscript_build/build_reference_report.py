"""Write manuscript/REFERENCE_VERIFICATION.md from refs.py, the citation order and the literature records."""
import json
from pathlib import Path

import refs

ROOT = Path(__file__).resolve().parents[1]
L = ROOT / "manuscript_build" / "literature"
order = json.loads((ROOT / "manuscript_build" / "citation_order.json").read_text())
recheck = dict(json.loads((L / "crossref_recheck_2026-11-11.json").read_text()))
s1 = json.loads((L / "searchlog1.json").read_text()) + json.loads((L / "searchlog2.json").read_text())
CLAIM = json.loads((L / "claims.json").read_text())

FULLTEXT = {"hu2008": "Full text (J-STAGE publisher PDF, free)", "pavlidis2021": "Full text (HAL author version hal-03171195)",
            "czaja2013": "Full text (author's postprint, MOST Wiedzy repository)", "nessler2018": "Abstract only; full text not accessible"}
REC_NOTE = {
    "hantos2021": "Crossref: published online 31 Dec 2020 in volume 12 (2021); cited with the volume year, as the journal does",
    "ieee1241": "Crossref standard record: approved 17 Jun 2010, published 2011",
    "nessler2018": "Crossref title contains LaTeX markup ($\\Delta \\Sigma$); title printed as ΔΣ",
    "ho2001": "Crossref stores the first author as one string 'Chung Kin Ho'; printed as Ho, C.K.",
    "meijer2001": "Crossref stores 'Guijie Wang' as one string; printed as Wang, G.",
    "yuan2010": "Crossref stores full names as single strings; printed as Yuan, L.; He, Y.; Huang, J.; Sun, Y.",
    "wang2026": "Crossref lists the article number as a range 3525214–3525214; printed as 3525214",
    "pavlidis2021": "Crossref spells the second author 'Louerat'; the author's own spelling Louërat (HAL full text) is printed",
}

out = ["# Reference verification record\n",
       "Manuscript: *Phase-Robust Active Self-Test for Fault Localization in Mixed-Signal Sensor Interfaces: A Simulation Study*.  ",
       "Checked 11 November 2026. **56 references**, all cited in the text and numbered by first appearance.\n",
       "## 1. Method\n",
       "Each reference was checked twice, and the two checks are reported separately.\n",
       "1. **Bibliographic record.** Authors, title, year, venue, volume, issue, pages or article number and DOI were compared field by field with the Crossref record of the DOI. This was done when the list was built and again in an automated recheck (`manuscript_build/literature/crossref_recheck_2026-11-11.json`). For the three items without a DOI, the publisher page was used: JMLR for scikit-learn, arXiv for Adam, and the ngspice documentation for the ngspice-47 manual.",
       "2. **Support for the citing sentence.** The full text was read for the closest prior works where a legal copy exists. For all other references the abstract was read (Crossref or OpenAlex) and compared with the sentence that cites it. Standards were checked against their scope statements. References whose record has no abstract are cited only for what their title and record state.\n",
       "## 2. Full texts of the closest prior works\n",
       "| No. | Reference | What was read | Finding used in the manuscript |", "|---:|---|---|---|"]
for k in ("nessler2018", "czaja2013", "hu2008", "pavlidis2021"):
    out.append(f"| {order.index(k) + 1} | {refs.REFS[k]['authors'].split(';')[0]} et al., {refs.REFS[k]['year']} | {FULLTEXT[k]} | {refs.REFS[k]['support'].split('Checked:')[0].strip()} |")
out += ["",
        "**Not fully read:** Nessler et al. (2018), IEEE TCSI. It is paywalled, and Unpaywall, OpenAlex and Semantic Scholar list no open copy. The manuscript describes it only as far as its abstract states and says so in the text (Section 2.5).",
        "",
        "**Effect of reading Czaja (2013) in full.** The earlier comparison was correct that the ADC serves as the measuring device rather than as a fault location. It was incomplete in three respects, which Sections 2.2, 2.5 and 8.2 now state:",
        "- the method also replaces the sensor signal by a known stimulus during the test;",
        "- it localizes single soft faults to individual components, which is finer than the layer-level localization here, and it was verified in hardware;",
        "- it synchronizes stimulus and sampling with the microcontroller's timers, so the sampling-phase problem studied here does not arise in it. The manuscript therefore presents phase robustness as relevant to interfaces in which such synchronization is not available, not as a shortcoming of that work.",
        "",
        "## 3. Search scope\n",
        "This was a focused search, not a systematic review. It used the OpenAlex works search on 11 November 2026, limited to articles and reviews published from 1 January 2020, sorted by relevance; the first 12 results of each query were screened by title, venue and abstract. Foundational pre-2020 work was added from the earlier package's candidate list after each record was re-checked.\n",
        "| Query | Hits | Screened |", "|---|---:|---:|"]
out += [f"| {q['query']} | {q['total_hits']:,} | {q['retrieved']} |" for q in s1]
out += ["\nNot covered: a PRISMA-style systematic review, patents, theses and non-English literature.\n",
        "## 4. Per-reference record (citation order)\n",
        "| No. | Key | First author, year, venue | DOI / URL | Record check | Cited for | Support check |", "|---:|---|---|---|---|---|---|"]
for i, k in enumerate(order, 1):
    r = refs.REFS[k]
    first = (r.get("authors") or r.get("author_org") or r.get("designation", "")).split(";")[0].strip()
    venue = r.get("journal") or r.get("booktitle") or r.get("publisher") or r.get("designation", "")
    link = f"https://doi.org/{r['doi']}" if r.get("doi") else r.get("url", "")
    rc = recheck.get(k, "")
    rec = "Crossref: all fields agree" if rc == "OK" else REC_NOTE.get(k, rc if r.get("doi") else "Publisher page checked")
    if k in REC_NOTE and rc == "OK":
        rec = "Crossref: all fields agree; " + REC_NOTE[k]
    sup = r["support"]
    lvl = ("full text" if "Full text read" in sup else "abstract only (full text inaccessible)" if "abstract only" in sup
           else "title/record only" if ("title-level" in sup or "no abstract" in sup or "Crossref record and title" in sup)
           else "standard scope" if r["type"] == "standard" else "publisher/software page" if not r.get("doi") else "abstract")
    out.append(f"| {i} | `{k}` | {first}, {r['year']}, *{venue}* | {link} | {rec} | {CLAIM[k]} | {lvl}: {sup.split('Checked:')[0].strip()} |")
out += ["\n## 5. Cross-check with the independent reference set on the project branch\n",
        "`manuscript_submission/cloud_draft/refs.py` (53 references) shares 17 DOIs with this list. For all 17, year, volume and pages agree. The only differing field was the spelling of Louërat in Pavlidis et al.: Crossref has \"Louerat\", while the author's own version (HAL) has \"Louërat\". The author's spelling is now printed. The cross-check also corrected two dispositions of the earlier candidate list (Section 6).\n",
        "## 6. Earlier candidate entries\n",
        "| Earlier key | Finding | Action |", "|---|---|---|"]
for a, b, c in [
    ("aminian2000wavelet", "Confirmed; DOI 10.1109/82.823545 added", "Kept"),
    ("sun2004wavelet", "Exists; the old author order was wrong (Crossref: He, Y.; Tan, Y.; Sun, Y.) and the volume (151) was missing", "Not cited; more direct sources cited instead"),
    ("zhao2018dbn", "Confirmed", "Kept"),
    ("mir2006bist", "Confirmed; DOI added; Crossref title 'Built-in-self-test techniques for MEMS'", "Kept"),
    ("deb2002bist", "Exists (ITC 2002, pp. 1075–1084)", "Not cited; superseded by the 2021 review"),
    ("henry1993svs", "Exists: Henry, M.P.; Clarke, D.W., Control Eng. Pract. 1993, 1, 585–610, DOI 10.1016/0967-0661(93)91382-7 (Crossref record found in the cross-check; an earlier, wrong DOI had been tried)", "Not cited; self-validating sensors are covered by [39–41]. The earlier note that the record could not be confirmed is withdrawn"),
    ("ieee1241", "Edition resolved: IEEE Std 1241-2010, published 2011", "Kept"),
    ("jin2005seir", "Confirmed; DOI added", "Kept"),
    ("ieee181", "Edition resolved: IEEE Std 181-2011", "Kept"),
    ("golub1973varpro", "Confirmed; DOI added", "Kept"),
    ("field2007clustered", "Confirmed", "Kept"),
    ("efron1993bootstrap", "Exists: Chapman & Hall 1993 (Springer DOI 10.1007/978-1-4899-4541-9; a CRC re-issue has DOI 10.1201/9780429246593)", "Not cited; Davison & Hinkley (1997) covers the percentile intervals used"),
    ("ngspice47", "Version-47 manual listed on the ngspice documentation page; ngspice-47 was installed on the run machine before the run", "Kept"),
]:
    out.append(f"| `{a}` | {b} | {c} |")
out += ["\n## 7. Statements removed or limited because a source could not support them\n",
        "- No \"first\", \"state-of-the-art\" or superiority claim is made. The gap statement (Section 2.5) is limited to the literature reviewed and to simulation.",
        "- For [1], the cost statement reads \"a large share of product cost\".",
        "- [45] is cited only for the existence of equivalent-time sampling with microcontroller ADCs (title/record check).",
        "- [7] is characterized only as far as its abstract states; the text says so.",
        "- The comparison with [14] was revised after reading its full text (Section 2 above).\n",
        "## 8. Limits\n",
        "Support was checked against the full texts of [14], [15] and [16] and against abstracts or records for all other references. Page ranges and article numbers follow Crossref. IEEE TIM and OJSSCS items carry Crossref page ranges such as 1–9, which are reproduced as listed."]
(ROOT / "manuscript" / "REFERENCE_VERIFICATION.md").write_text("\n".join(out) + "\n", encoding="utf-8")
print("REFERENCE_VERIFICATION.md written")
