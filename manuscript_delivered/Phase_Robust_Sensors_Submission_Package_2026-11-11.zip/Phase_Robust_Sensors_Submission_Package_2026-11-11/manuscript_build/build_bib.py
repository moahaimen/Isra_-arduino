"""Write manuscript/references.bib (citation order) from refs.py."""
import json
from pathlib import Path

import refs

ROOT = Path(__file__).resolve().parents[1]
order = json.loads((ROOT / "manuscript_build" / "citation_order.json").read_text())


def bibtex(k):
    r = refs.REFS[k]
    t = r["type"]
    typ = {"article": "article", "inproceedings": "inproceedings", "book": "book", "standard": "techreport", "manual": "manual"}[t]
    f = []
    if "authors" in r:
        f.append(("author", " and ".join(a.strip() for a in r["authors"].replace("; et al.", "").split(";"))))
    f.append(("title", "{" + r["title"] + "}"))
    for a, b in (("journal", "journal"), ("booktitle", "booktitle"), ("publisher", "publisher"), ("volume", "volume"),
                 ("number", "issue"), ("pages", "pages"), ("year", "year"), ("doi", "doi"), ("url", "url")):
        if r.get(b):
            f.append((a, str(r[b])))
    if t == "standard":
        f += [("institution", "IEEE"), ("number", r["designation"])]
    if t == "manual":
        f.append(("organization", r["author_org"]))
    if r.get("accessed"):
        f.append(("urldate", r["accessed"]))
    f.append(("note", "Checked 11 November 2026: " + r["support"].replace("{", "(").replace("}", ")")))
    return f"@{typ}{{{k},\n" + ",\n".join(f"  {a:<12} = {{{v}}}" for a, v in f) + "\n}\n"


out = ("% references.bib: Phase-Robust Active Self-Test (MDPI Sensors manuscript)\n"
       "% Order follows first citation. Every entry was checked on 11 November 2026; see REFERENCE_VERIFICATION.md.\n\n")
out += "\n".join(f"% [{i + 1}]\n" + bibtex(k) for i, k in enumerate(order))
(ROOT / "manuscript" / "references.bib").write_text(out, encoding="utf-8")
print(len(order), "entries -> manuscript/references.bib")
