"""Formatted manuscript numbers, all derived from analysis/values.json (unrounded values recomputed from the
saved per-record predictions) or from the saved run metadata.  Differences are computed from unrounded values
and rounded only here."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
V = json.loads((ROOT / "analysis" / "values.json").read_text())
RES = ROOT / "evidence_package_2026-10-26" / "phase_robust_final" / "phase_robust_results"
PP = ROOT / "evidence_package_2026-10-26" / "paper_package"
MINUS = "−"


import sys as _sys  # noqa: E402
_sys.path.insert(0, str(ROOT / "analysis"))
from rounding import round_str  # noqa: E402


def f(x, d=3, sign=False):
    """Exact decimal rounding (analysis/rounding.py), Unicode minus."""
    return round_str(x, d, sign).replace("-", MINUS)


def ci(lo, hi, d=3):
    return f"[{f(lo, d, True)}, {f(hi, d, True)}]"


def cmp(c, d=3):
    return f"{f(c['diff'], d, True)} {ci(c['lo'], c['hi'], d)}"


N = {}
A = lambda dom, arm: V[f"arm|{dom}|{arm}"]
for dom in ("bh", "sp"):
    for arm in ("A0", "R1", "R1r", "PR", "PRr", "PRrM"):
        if dom == "sp" and arm == "A0":
            continue
        a = A(dom, arm)
        N[f"{arm}_{dom}_L"] = f(a["layer_f1"])
        N[f"{arm}_{dom}_Lba"] = f(a["layer_bacc"])
        N[f"{arm}_{dom}_F"] = f(a["fault_f1"])
        N[f"{arm}_{dom}_Fba"] = f(a["fault_bacc"])
        N[f"{arm}_{dom}_spread"] = f(a["spread"])
        ps = a["layer_f1_per_seed"]
        N[f"{arm}_{dom}_seedrange"] = f"{f(min(ps))}–{f(max(ps))}"
N["N_bh"], N["N_sp"] = f(V["N"]["bh"]), f(V["N"]["sp"])

# gate G spreads
G = {k: V[k]["spread"] for k in V if k.startswith("G|")}
prr = [G[f"G|{d}|PRr|{v}"] for d in ("bh", "sp") for v in ("known", "mon2")]
N["G_min"], N["G_max"] = f(min(prr)), f(max(prr))
N["R1_G_bh_known"], N["R1_G_sp_known"] = f(G["G|bh|R1|known"]), f(G["G|sp|R1|known"])
N["PRrM_G_max"] = f(max(G[f"G|{d}|PRrM|{v}"] for d in ("bh", "sp") for v in ("known", "mon2")))

# transfer
E2 = V["E|mon2"]
N["E2_BB"], N["E2_BS"], N["E2_MS"] = f(E2["BB"]), f(E2["BS"]), f(E2["MS"])
N["E2_drop"], N["E2_drop_ci"] = f(E2["drop"]["diff"]), ci(E2["drop"]["lo"], E2["drop"]["hi"])
N["E2_dropF"] = cmp(E2["drop_fault"])
N["E2_MSBS"] = cmp(E2["MS_BS"])
drops = [V[f"E|{v}"]["drop"] for v in ("known", "mon0", "mon1", "mon2", "mon5")]
N["E_drop_min"], N["E_drop_max"] = f(min(d["diff"] for d in drops), sign=True), f(max(d["diff"] for d in drops), sign=True)
N["E_ci_lo_min"], N["E_ci_hi_max"] = f(min(d["lo"] for d in drops), sign=True), f(max(d["hi"] for d in drops), sign=True)
N["E_MSBS_min"] = f(min(V[f"E|{v}"]["MS_BS"]["diff"] for v in ("known", "mon0", "mon1", "mon2", "mon5")), sign=True)
N["E_MSBS_max"] = f(max(V[f"E|{v}"]["MS_BS"]["diff"] for v in ("known", "mon0", "mon1", "mon2", "mon5")), sign=True)
# matched-grid behavioural PRr per phase vs ngspice per phase (E = 2 %)
ep = V["Ephase|mon2"]
gap = [b - s for b, s in zip(ep["bh"]["PRr"], ep["sp"]["PRr"])]
N["Ephase_gap_max"] = f(max(abs(g) for g in gap))
# previous stage (historical, from the paper package provenance)
N["PREV_drop"], N["PREV_ci"], N["PREV_bh"], N["PREV_sp"] = "0.119", "[0.107, 0.132]", "0.658", "0.539"

# gates A, C, D
ac = {k: V[k] for k in V if k.startswith("AC|")}
retA = {k: v["ret"] for k, v in ac.items() if "assumed" not in k and k.split("|")[2] in ("known", "mon0", "mon1", "mon2")}
kA = min(retA, key=retA.get)
N["A_worst"] = f(retA[kA]); N["A_worst_where"] = kA
crosses = {k: v["cross"] for k, v in ac.items() if "assumed" not in k}
kC = max(crosses, key=crosses.get)
N["C_max"] = f(crosses[kC]); N["C_max_where"] = kC
N["C_min"] = f(min(crosses.values()))
retD = [ac[f"AC|{d}|mon5|{a}"]["ret"] for d in ("bh", "sp") for a in ("80", "120")] + [V["D|bh|pooled"]["ret"], V["D|sp|pooled"]["ret"]]
N["D_worst"] = f(min(retD))
N["NM_cross80"], N["NM_cross120"] = f(ac["AC|bh|assumed|80"]["cross"]), f(ac["AC|bh|assumed|120"]["cross"])
N["NM_afe80"], N["NM_afe120"] = f(ac["AC|bh|assumed|80"]["afe"]), f(ac["AC|bh|assumed|120"]["afe"])
N["NM_adc80"], N["NM_adc120"] = f(ac["AC|bh|assumed|80"]["adc"]), f(ac["AC|bh|assumed|120"]["adc"])
afe_rec = [v["afe"] for k, v in ac.items() if "assumed" not in k]
adc_rec = [v["adc"] for k, v in ac.items() if "assumed" not in k]
N["AFE_rec_range"] = f"{f(min(afe_rec))}–{f(max(afe_rec))}"
N["ADC_rec_range"] = f"{f(min(adc_rec))}–{f(max(adc_rec))}"

# amplitude curves / no monitor
am = lambda k, a: V[k][str(a)]
N["K80"], N["K120"] = f(am("amp|bh|PRr|known", 80)), f(am("amp|bh|PRr|known", 120))
N["NM80"], N["NM90"], N["NM110"], N["NM120"] = (f(am("amp|bh|nomon", a)) for a in (80, 90, 110, 120))
N["NMF80"], N["NMF120"] = f(am("ampfault|bh|nomon", 80)), f(am("ampfault|bh|nomon", 120))
N["A0_80"], N["A0_100"], N["A0_120"] = (f(am("amp|bh|A0|known", a)) for a in (80, 100, 120))
mons = [am(f"amp|bh|PRr|{v}", a) for v in ("known", "mon0", "mon1", "mon2", "mon5") for a in (80, 90, 100, 110, 120)]
x10 = [am(f"amp|bh|PRr|{v}", 100) for v in ("known", "mon0", "mon1", "mon2", "mon5")]
N["X10_min"], N["X10_max"] = f(min(x10)), f(max(x10))
N["X10_spreadvar"] = f(max(x10) - min(x10))

# attribution
for dom in ("bh", "sp"):
    for c in ("PR-R1", "R1r-R1", "PRr-R1r", "PRr-PR", "PRr-R1", "PRrM-PRr", "PRr-A0"):
        k = f"att|{dom}|{c}"
        if k in V:
            N[f"att_{dom}_{c}"] = cmp(V[k])
            N[f"attF_{dom}_{c}"] = cmp(V[f"attfault|{dom}|{c}"])

# baselines
B = lambda name, a: V[f"base|{name}"][str(a)]
N["Bmin_lo"] = f(min(V[k]["lo"] for k in V if k.startswith("Bfull|")), sign=True)
N["B_afePRr"] = f"{f(B('afe_only_PRr', 80))}/{f(B('afe_only_PRr', 120))}"
N["B_adcPRr"] = f"{f(B('adc_only_PRr', 80))}/{f(B('adc_only_PRr', 120))}"
N["B_single"] = f"{f(B('single', 80))}/{f(B('single', 120))}"
N["B_passive"] = f(B("passive", 80))

# per-class recall
fr = lambda dom, arm: A(dom, arm)["fault_recall"]
lr = lambda dom, arm: A(dom, arm)["layer_recall"]
N["rec_H_bh"], N["rec_H_sp"] = f(lr("bh", "PRr")[0]), f(lr("sp", "PRr")[0])
N["recF_bh"] = {i: f(x) for i, x in enumerate(fr("bh", "PRr"))}
N["recM_H_bh"] = f(lr("bh", "PRrM")[0])
obs = [fr(d, "PRr")[i] for d in ("bh", "sp") for i in (3, 4, 5, 6, 7)]
N["obs_min"], N["obs_max"] = f(min(obs)), f(max(obs))
weak = [fr(d, "PRr")[i] for d in ("bh", "sp") for i in (0, 1, 2, 8)]
N["weak_min"], N["weak_max"] = f(min(weak)), f(max(weak))

# development-seed and run metadata
dv = json.loads((PP / "figure_data" / "dev_seed_verification.json").read_text())
nf = dv["noise_free_agreement_per_phase"]
N["NF_mean_min"] = f(min(v["mean_rmse_mV"] for v in nf.values()), 2)
N["NF_mean_max"] = f(max(v["mean_rmse_mV"] for v in nf.values()), 2)
N["NF_max"] = f(max(v["max_rmse_mV"] for v in nf.values()), 1)
N["DEV_rise2"] = f(max(dv["descriptor_phase_invariance"]["revision1"]["rise_2"]), 2)
N["DEV_PRmax"] = f(max(max(v) for v in dv["descriptor_phase_invariance"]["phase_robust"].values()), 2)
N["DEV_tau"] = f(max(dv["descriptor_phase_invariance"]["phase_robust"]["tau_norm"]), 3)
tp = json.loads((RES / "timing_and_parameters.json").read_text())
import numpy as np  # noqa: E402
N["t_pr"] = f(np.mean([v["descriptor_extraction_ms_per_sample"]["phase_robust"] for v in tp.values()]), 2)
N["t_r1"] = f(np.mean([v["descriptor_extraction_ms_per_sample"]["revision1"] for v in tp.values()]), 2)
N["t_mlp_us"] = f(1000 * np.mean([v["mlp_predict_ms_per_sample"] for v in tp.values()]), 2)
meta = [json.loads((RES / f"seed_{s}" / "meta.json").read_text()) for s in (20261026, 20261027, 20261028)]
N["sp_wall_min"], N["sp_wall_max"] = f(min(m['ngspice_wall_seconds'] for m in meta), 0), f(max(m['ngspice_wall_seconds'] for m in meta), 0)
N["n_sp_runs"] = f"{meta[0]['n_ngspice_runs']:,}"
N["n_sp_total"] = f"{sum(m['n_ngspice_runs'] for m in meta):,}"

# fine-fault confusion of PRr (behavioral, E = 2 %, pooled), saved by the analysis step
_cm = np.load(ROOT / "analysis" / "cm_fault_PRr_bh_E2.npy")
_cmn = _cm / _cm.sum(1, keepdims=True)
N["CM_H_clip"] = f(100 * _cmn[0, 8], 0)
N["CM_H_sens"] = f(100 * (_cmn[0, 1] + _cmn[0, 2]), 0)
N["CM_clip_H"] = f(100 * _cmn[8, 0], 0)
N["CM_H_H"] = f(100 * _cmn[0, 0], 0)
import pandas as _pd  # noqa: E402
_dd = _pd.read_csv(PP / "figure_data" / "fig05_fault_signature_descriptors_dev_seed.csv")
N["DEV_ymax_med"] = f(float(_dd["ymax_s"].median()), 2)
