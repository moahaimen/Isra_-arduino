"""Export the manuscript and supplement DOCX files to PDF.

    python3 manuscript_build/export_pdfs.py --pdf               # Microsoft Word for Mac (route used for the delivered PDFs)
    python3 manuscript_build/export_pdfs.py --pdf=libreoffice   # LibreOffice, any platform (layout may differ slightly)

Exits with code 3 and a plain message if the chosen tool is not available; the DOCX files are not affected.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import docbuild as B  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
engine = B.pdf_engine_from_argv(sys.argv)
if engine is None:
    raise SystemExit("usage: export_pdfs.py --pdf | --pdf=libreoffice")
for name in ("Phase_Robust_Sensors_Manuscript", "Phase_Robust_Sensors_Supplementary"):
    d = ROOT / "manuscript" / f"{name}.docx"
    if not d.exists():
        raise SystemExit(f"ERROR: {d} does not exist; run the DOCX build first.")
    try:
        B.export_pdf(d, d.with_suffix(".pdf"), engine)
        print(f"{d.with_suffix('.pdf').name} written ({engine})")
    except B.PdfExportError as exc:
        print("PDF NOT WRITTEN:", exc)
        sys.exit(3)
