::: {custom-style="Normal"}
⟦Date⟧
:::

Editor-in-Chief  
*Sensors* (MDPI)

Dear Editor,

We submit the manuscript **"Phase-Robust Active Self-Test for Fault Localization in Mixed-Signal Sensor Interfaces: A Simulation Study"** for consideration as an Article in *Sensors*.

A wrong reading from a sensor interface can originate in the sensing element, the analog front-end or the analog-to-digital converter. The output record alone rarely shows which. The manuscript studies an active self-test that injects one monitored two-level reference in front of the front-end and a second one directly at the converter input, so that the converter and front-end transfers can be estimated in sequence. It addresses a timing problem that matters in practice: transient descriptors read at fixed samples after a test edge depend on where the edge falls between converter samples. Replacing them with a first-order fit that has a free edge time reduced the phase sensitivity of layer macro-F1 from about 0.08 to 0.005–0.011. In a behavioral model and a per-record ngspice netlist, with nine fault classes, component tolerances and ±20% reference-amplitude error, it also brought the behavioral-to-circuit transfer loss on a matched grid to 0.002 (95% CI −0.003 to +0.006).

The work fits the journal's scope in sensor interface electronics, self-diagnosis and signal processing for sensors. We report its limits as plainly as its results. The study is simulation-only. Absolute layer macro-F1 is about 0.65, because healthy records, sensor bias and gain faults and inactive clipping faults are hard to observe with the present references. The written protocol and the training code disagree on early stopping, and the manuscript states this.

The frozen protocol, the per-record predictions, the simulator and training source code and the scripts that regenerate every table and figure are provided as supporting material. Generative AI (Claude Code, Anthropic) was used as described in the Methods and Acknowledgments.

⟦The two statements required by Sensors must be confirmed by the authors before they are included: (1) that neither the manuscript nor any part of its content is currently under consideration for publication with, or published in, another journal; (2) that all authors have approved the manuscript and agree with its submission to Sensors. State any previous submission of this work to an MDPI journal and its manuscript ID, if applicable.⟧

Sincerely,

⟦Corresponding author: full name, affiliation, postal address, e-mail⟧
