::: {custom-style="MDPI_1.1_article_type"}
*Article*
:::

::: {custom-style="MDPI_1.2_title"}
Phase-Robust Active Self-Test for Fault Localization in Mixed-Signal Sensor Interfaces: A Simulation Study
:::

::: {custom-style="MDPI_1.3_authornames"}
**Moahaimen Talib**
:::

::: {custom-style="MDPI_1.7_abstract"}
**Abstract:** A sensor-interface fault can originate in the sensor, the analog front-end (AFE) or the analog-to-digital converter (ADC), yet the output record rarely shows where. This study examines an active self-test in which a monitored two-level reference replaces the sensor at the AFE input and a second reference bypasses the AFE at the ADC input. An earlier version failed a behavioral-to-circuit transfer test because its transient descriptors read fixed samples after the reference step and thus depended on where the step fell between samples. Those descriptors were replaced by quantities from a first-order fit with a free edge time, and a compact multilayer perceptron was trained with randomized edge phase. Under an internally frozen protocol with three unseen dataset seeds, nine fault classes, component tolerances, 12-bit quantization and five edge phases, layer macro-F1 was {{PRr_bh_L}} in the behavioral model and {{PRr_sp_L}} in ngspice. On a matched amplitude grid the transfer loss was {{E2_drop}} (95% CI {{E2_drop_ci}}), the phase spread was {{G_min}}–{{G_max}} instead of about 0.08, and AFE–ADC cross-confusion stayed below 0.09 under ±20% reference error. Healthy records and sensor bias, sensor gain and inactive clipping faults remain poorly separated; the results support fault localization in simulation, not hardware-validated detection.
:::

::: {custom-style="MDPI_1.8_keywords"}
**Keywords:** active self-test; mixed-signal sensor interface; fault localization; sampling phase; reference monitoring; neural-network classification
:::

::: {custom-style="MDPI_1.9_line"}
 
:::

::: {custom-style="MDPI_2.1_heading1"}
1\. Introduction
:::

::: {custom-style="MDPI_3.1_text"}
A measurement made through a sensor interface passes through at least three electronic stages: the sensing element, an analog front-end (AFE) that amplifies and filters the signal, and an analog-to-digital converter (ADC). When the reading is wrong, the useful question for maintenance or for a safety mechanism is not only whether something is wrong but where. A sensor that has drifted calls for recalibration or replacement of the transducer; an AFE offset or a slowed filter points to the board; an ADC gain or reference problem points to the converter or its reference. In a passive record these causes can look alike. A gain error in the AFE and a gain error in the ADC both scale the output, and an offset added before or after the amplifier produces the same shifted waveform once the signal has been digitized. Without an additional, known excitation the chain is, in the language of system identification, not identifiable layer by layer.
:::

::: {custom-style="MDPI_3.1_text"}
Built-in self-test (BIST) addresses part of this problem by injecting a known stimulus. For MEMS sensors, electrical stimuli now replace physical ones for sensitivity characterization, and testing accounts for a large share of product cost «cite:hantos2021,mir2006,ozel2017». Readout circuits have been given on-chip calibration and self-test functions «cite:mason2007,chen2018,basith2013», and some self-tests separate the readout ASIC from the sensor element by reconfiguring the readout «cite:nessler2018». For ADCs, test methods and terminology are standardized «cite:ieee1241», and a substantial body of work deals with testing converters on-chip with imprecise stimuli or imprecise references «cite:jin2005,parthasarathy2003,varier2021». What these approaches share is that the stimulus is designed for one block. Localizing a fault among the sensor, the AFE and the ADC of one interface, during operation and with references that are themselves uncertain, is a different task.
:::

::: {custom-style="MDPI_3.1_text"}
The architecture studied here uses two reference injection points to make the chain identifiable. A first multiplexer replaces the sensor by a two-level reference at the AFE input, so that its response passes through the AFE and the ADC. A second multiplexer injects a two-level reference directly at the ADC input, bypassing the AFE. The ADC transfer estimated in the second window can then be removed before the AFE transfer is estimated in the first, and sensor faults remain visible only in the intervals in which the sensor is connected. A buffered monitor channel measures the reference levels that were actually applied, because a reference whose amplitude has drifted would otherwise be indistinguishable from a gain fault. A compact neural network classifies descriptors extracted from these windows into the faulty layer and the fault class.
:::

::: {custom-style="MDPI_3.1_text"}
An earlier validation stage of this architecture failed for a reason that is easy to overlook. Its transient descriptors read the AFE response a fixed number of samples (2, 5, 10, 20 and 30 ms) after the reference step. In the discrete-time behavioral model the step coincided with a sample instant, whereas in the circuit-level ngspice model the switching edge fell 1 µs before the next sample. Trained on behavioral data and tested on ngspice, the classifier lost {{PREV_drop}} layer macro-F1 (behavioral {{PREV_bh}}, ngspice {{PREV_sp}}, 95% CI of the loss {{PREV_ci}}), which exceeded the frozen limit of 0.10. A post hoc diagnostic on a development seed attributed most of the loss to the sampling phase of the reference edge relative to the ADC sample grid. In hardware this phase is not a modeling convention but a free and generally unknown quantity: unless the test-control logic and the converter share a clock with a fixed relation, the edge can fall anywhere inside a sample period, and it can differ between devices or drift with time.
:::

::: {custom-style="MDPI_3.1_text"}
This article reports the revision that addresses this weakness and its evaluation under a protocol frozen before the validation data were generated. The research question is whether descriptors estimated from the whole reference transient, with the edge time treated as a nuisance parameter, make the fault-localization performance independent of the sampling phase in both simulation domains while preserving the separation of AFE and ADC faults under reference-amplitude error. The specific contributions are as follows:
:::

::: {custom-style="MDPI_3.7_itemize"}
an observability analysis of the two-point reference test that states which faults are identifiable from the two windows under explicit assumptions, and how a common reference-monitor gain error propagates into the estimated AFE and ADC parameters;
:::

::: {custom-style="MDPI_3.7_itemize"}
a set of phase-robust transient descriptors obtained from a variable-projection fit of a first-order step response with a free edge time, together with the conditions under which their invariance to ADC gain, offset and edge phase holds exactly and the evidence for how closely it holds otherwise;
:::

::: {custom-style="MDPI_3.7_itemize"}
an attribution study that separates the effect of the new descriptors from that of phase-randomized training on the same three unseen dataset seeds, in a behavioral model and in a per-record ngspice netlist;
:::

::: {custom-style="MDPI_3.7_itemize"}
an account of what the method does not achieve: the classes that remain poorly separated, the reason they are poorly separated, and the limits of a transfer test between two first-order models.
:::

::: {custom-style="MDPI_3.1_text"}
The study is a simulation study. No hardware was built and no physical sensor was measured; the ngspice domain uses the same first-order circuit topology as the behavioral model with switch resistances, additional noise and circuit-level edge handling. Section 2 reviews related work and states the research gap. Section 3 describes the electronic architecture and its observability. Section 4 covers reference monitoring, calibration and the descriptors, and Section 5 the classifier. Section 6 describes the simulation design and the evaluation protocol, Section 7 presents the results, and Section 8 discusses them together with their limitations. Section 9 concludes.
:::

::: {custom-style="MDPI_2.1_heading1"}
2\. Related Work and Research Gap
:::

::: {custom-style="MDPI_2.2_heading2"}
2.1. Self-Test of Sensors and Sensor Interfaces
:::

::: {custom-style="MDPI_3.1_text"}
Self-test of sensors has developed furthest for MEMS devices, where electrostatic actuation can emulate the physical stimulus. Hantos et al. classify MEMS BIST methods by ease of implementation, usefulness, test duration and power «cite:hantos2021», following earlier overviews such as that of Mir et al. «cite:mir2006». Ozel et al. showed that an electrical-stimulus-only BIST can characterize the sensitivity of a capacitive accelerometer to within 0.55% of the value obtained with a physical stimulus «cite:ozel2017». On the readout side, Mason et al. integrated self-test and online calibration into a capacitive readout chip «cite:mason2007», Chen et al. added a digital self-test function to a sigma-delta accelerometer interface «cite:chen2018», and Basith et al. used charge-controlled stimuli to detect structural defects «cite:basith2013». Two works are closer to the question of localization. Nessler et al. reconfigured a gyroscope readout into a purely electrical sigma-delta loop so that the readout ASIC could be characterized separately from the sensor element at wafer level «cite:nessler2018», and Feng et al. monitored an internal quadrature-error signal to obtain an online self-test during operation, because electrostatic self-test cannot run while the gyroscope is in use «cite:feng2021». Reviews of sensor front-ends with self-monitoring and self-calibration capabilities place these functions in a wider design context «cite:alraho2022».
:::

::: {custom-style="MDPI_3.1_text"}
These methods are designed around a particular transducer and either test it during a dedicated mode or reconfigure the readout. They establish that a known electrical stimulus can stand in for the physical quantity and that the readout can be isolated from the sensor, but they do not address a generic chain in which the fault may also lie in the converter and in which the reference used for the test may itself be wrong.
:::

::: {custom-style="MDPI_2.2_heading2"}
2.2. Mixed-Signal Self-Test, ADC Testing and Reference Uncertainty
:::

::: {custom-style="MDPI_3.1_text"}
In mixed-signal test, the closest work is the self-test of analog parts terminated by ADCs proposed by Czaja, in which a microcontroller samples the response of the analog part to a square impulse with its own ADC and localizes single soft faults in the analog part from the trajectory of these samples «cite:czaja2013». Hu et al. combined a self-test of the analog portion and of the ADC by reconfiguring the analog portion into an oscillator whose output stimulates the converter for a histogram test «cite:hu2008». SymBIST checks signals that are invariant by design against a tolerance window and can run on-line as a functional-safety mechanism «cite:pavlidis2021». Earlier work established hierarchical, block-level diagnosis of analog integrated circuits «cite:ho2001» and on-chip test cores that both generate stimuli and digitize periodic responses «cite:hafed2002».
:::

::: {custom-style="MDPI_3.1_text"}
ADC testing itself is well developed. IEEE Std 1241 defines gain, offset and the associated test methods «cite:ieee1241», and BIST architectures generate test signals on-chip «cite:wibbenmeyer2007,santin2019». A recurring difficulty is the accuracy of the stimulus and of the reference: the stimulus error identification and removal (SEIR) method tests linearity with stimuli that are less linear than the converter «cite:jin2005,parthasarathy2003», and Varier and Sun extended it to relax the precision and constancy required of the reference voltage «cite:varier2021». Online methods for SAR-ADC gain and offset errors and built-in self-calibration of DAC mismatch address the converter alone «cite:mohammedali2024,thirunakkarasu2015». The sources of reference inaccuracy in CMOS, including mismatch, 1/f noise and mechanical stress, are well documented «cite:meijer2001». Taken together, this literature motivates treating the test reference as a measured quantity rather than as a known constant, which is the role of the reference monitor in the present architecture.
:::

::: {custom-style="MDPI_2.2_heading2"}
2.3. Data-Driven Analog Fault Diagnosis and Domain Shift
:::

::: {custom-style="MDPI_3.1_text"}
Neural-network diagnosis of analog circuits has a long history. Aminian and Aminian classified faulty components from wavelet and principal-component features of the impulse response «cite:aminian2000» and later reported that features measured on actual circuits lie closer together than those obtained in simulation «cite:aminian2002»; Yuan et al. used kurtosis and entropy of the output signals «cite:yuan2010». Deep models followed: deep belief networks «cite:liu2017,zhao2018», one-dimensional convolutional networks on raw responses «cite:yang2020», generative adversarial networks on wavelet spectra «cite:he2020», residual networks on spectrum maps «cite:ji2021», deep forests motivated by the data demands of deep networks «cite:jia2021» and, more recently, contrastive representation learning «cite:zhou2025». Gao et al. addressed few-shot circuits with transfer learning «cite:gao2025», Zhang et al. used domain adaptation because varying conditions alter circuit parameters and reduce diagnostic accuracy «cite:zhang2024», and Liu et al. optimized the test stimulus jointly with the classifier «cite:liu2025». Recent reviews summarize the state of the field and its open problems «cite:halgas2025,qiu2023».
:::

::: {custom-style="MDPI_3.1_text"}
In most of these studies the circuit under test is a filter or amplifier observed at its output, the ADC is part of the measuring instrument rather than a fault location, and the timing of the stimulus relative to the sampling grid is fixed by the acquisition system. Sensor-level work on self-validating sensors detects, isolates and recovers sensor failures from the output signals «cite:shen2012,chen2025,wang2026», and fault models for the analog side of smart systems have been formalized for simulation-based fault injection «cite:tosoni2024». The concern of the present study, a nuisance timing variable that differs between simulation domains and between devices, is related to domain shift but is not addressed by adapting the classifier; it is addressed by designing the descriptors so that the nuisance variable does not enter them.
:::

::: {custom-style="MDPI_2.2_heading2"}
2.4. Timing of Transient Measurements
:::

::: {custom-style="MDPI_3.1_text"}
The dependence of sampled transient measurements on timing is familiar in instrumentation. IEEE Std 181 defines state levels and transition durations of pulse waveforms and the algorithms for computing them «cite:ieee181». In time-interleaved ADCs, small differences between sampling instants are a dominant limitation and are calibrated explicitly «cite:gu2025». Equivalent-time sampling exploits controlled sub-sample offsets to reconstruct fast waveforms, including with microcontroller ADCs «cite:hafed2002,svatos2023», and sine-fitting methods for ADC testing estimate phase together with amplitude and offset «cite:ieee1241,renczes2021». The common idea, estimating timing jointly with the quantities of interest instead of assuming it, is the idea adopted here for the reference step. Separable least squares, in which the linear parameters are eliminated in closed form, provides an efficient way to do so «cite:golub1973,golub2003».
:::

::: {custom-style="MDPI_2.2_heading2"}
2.5. Research Gap
:::

::: {custom-style="MDPI_3.1_text"}
The closest prior methods each cover part of the problem. Czaja's self-test uses ADC samples of a step-like response to localize faults, but in the analog part, with the ADC acting as the measurement device «cite:czaja2013». Hu et al. test the analog portion and the ADC together, but through an oscillation-based reconfiguration and a histogram test rather than during operation of the sensor chain «cite:hu2008». Nessler et al. separate the readout from the sensor element, but for one gyroscope architecture and at wafer level «cite:nessler2018». SymBIST runs on-line but detects violations of invariances rather than localizing a fault to a stage «cite:pavlidis2021». Within the literature reviewed here, we did not find an evaluation of an active test that localizes faults among the sensor, the AFE and the ADC of one chain, that treats the reference amplitude as uncertain and monitored, and that quantifies the dependence of the diagnosis on the sampling phase of the reference edge across a behavioral and a circuit-level model. The present work fills that specific gap at simulation level. It does not claim a new BIST principle, a new classifier or superiority over the diagnosis methods above, which address different circuits and fault sets and are not compared directly.
:::

::: {custom-style="MDPI_2.1_heading1"}
3\. Electronic Architecture and Diagnostic Observability
:::

::: {custom-style="MDPI_2.2_heading2"}
3.1. Signal Chain and Fault Model
:::

::: {custom-style="MDPI_3.1_text"}
Figure 1 shows the simulated interface. A physical sensor produces a slowly varying signal around a condition-dependent baseline. Multiplexer 1 (switches S1 and S2) either connects the sensor to the AFE or replaces it by the two-level reference R1. The AFE is modeled as a gain stage with offset and a first-order RC low-pass filter. Multiplexer 2 (S3 and S4) either passes the AFE output to the ADC or replaces it by the two-level reference R2. The ADC is a 12-bit converter over 0–3.3 V sampling at 1 kS/s, with gain, offset, clipping, noise and quantization. A reference-monitor channel (S5, a high-impedance buffer and a dedicated 12-bit channel) measures the levels of R1 and R2 during each plateau. Table 1 lists the parameters of each block, and Table 2 lists the nine fault classes, their location and their simulated severity range.
:::

::: {custom-style="MDPI_5.2_figure"}
![](FIG:Fig01_architecture){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 1.** Simulated electronic architecture of the reference-monitored two-point active self-test. During the AFE test window, MUX 1 (S1/S2) replaces the sensor by the two-level reference R1, so that the response passes through the AFE and the ADC. During the ADC test window, MUX 2 (S3/S4) injects the two-level reference R2 at the ADC input, so that the response depends on the ADC only. The ADC transfer estimated from R2 is removed before the AFE transfer is estimated from R1. A buffered monitor channel (S5) measures the applied reference levels with a gain error bounded by ±*E*. Stars mark the locations of the simulated faults. Schematic of the simulated system; no hardware was built.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 1.** Simulated blocks and parameters of the sensor interface. U(*a*, *b*) denotes a uniform draw per operating condition; tolerances are drawn per test record.
:::

| Block | Model and parameters | Role in the self-test |
|:--|:--|:--|
| Sensor | Baseline U(0.78, 1.18) V; sinusoidal component of amplitude U(0.045, 0.18) V and frequency U(0.45, 3.0) Hz; 25 mV component at 0.12 Hz; random-walk drift (1.5 mV per step); sensor noise U(2, 14) mV rms | Physical signal; disconnected during the R1 window |
| MUX 1 and reference R1 | 140–260 ms; 0.90 V then 1.30 V (two 60 ms plateaus) at the AFE input | Response passes through AFE and ADC |
| AFE | Gain U(1.65, 2.05); first-order low-pass with time constant U(8, 16) ms; offset | Amplification and filtering |
| MUX 2 and reference R2 | 340–460 ms; 1.15 V then 1.75 V at the ADC input, bypassing the AFE | Response depends on the ADC only |
| ADC | 12-bit, 0–3.3 V, 1 kS/s, 512 samples per record; noise 2.5 mV rms | Digitizes every path |
| Reference monitor | Buffered 12-bit channel, mean of 16 samples (0.25 mV rms after averaging); common gain error U(−*E*, *E*), *E* ∈ {0, 1, 2, 5}%; offset assumed trimmed | Supplies the applied reference levels to the calibration |
| Switches (ngspice only) | *R*~on~ = 0.5 Ω, *R*~off~ = 1 MΩ, threshold 2.5 V, hysteresis 0.1 V; 1 µs edges | Circuit-level multiplexers |
| Additional ngspice noise | 0.5 mV rms at the amplifier input and on each reference rail | Noise absent from the behavioral model |
| Component tolerances (test only) | AFE gain ±5%, AFE time constant ±10%, ADC gain ±2%, ADC offset ±10 mV, sensor baseline ±5% | Applied identically in both domains |

::: {custom-style="MDPI_4.3_table_footer"}
Parameters are the constants of the simulator source code used for the reported runs (SHA-256 hashes recorded at the protocol freeze).
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 2.** Fault taxonomy: the nine classes, their layer, their simulated severity and the window through which they are primarily observable.
:::

| No. | Fault class | Layer | Severity range | Primary observation |
|:-:|:--|:--|:--|:--|
| 0 | Healthy | Healthy | No fault | All windows |
| 1 | Sensor bias | Sensor | ±U(0.06, 0.24) V | Sensor intervals only |
| 2 | Sensor gain | Sensor | ±U(6, 28)% | Sensor intervals only |
| 3 | Sensor noise | Sensor | U(25, 95) mV rms | Sensor intervals only |
| 4 | AFE offset | AFE | ±U(0.06, 0.24) V | R1 window after ADC calibration |
| 5 | AFE bandwidth | AFE | Time constant × U(1.8, 4.5) | R1 transient |
| 6 | ADC offset | ADC | ±U(0.06, 0.24) V | R2 window |
| 7 | ADC gain | ADC | ±U(6, 28)% | R2 window |
| 8 | ADC clipping | ADC | Full scale × U(0.72, 0.93) | Only when the signal reaches the clipping level |

::: {custom-style="MDPI_2.2_heading2"}
3.2. Test Sequence and Timing
:::

::: {custom-style="MDPI_3.1_text"}
Each record lasts 512 ms (Figure 2). The sensor is connected from 0 to 140 ms, from 260 to 340 ms and from 460 to 512 ms; R1 is applied from 140 to 260 ms and R2 from 340 to 460 ms, each as two plateaus of 60 ms. The windows are long compared with the AFE time constant (8–16 ms nominally and up to 72 ms under a bandwidth fault). For nominal time constants the transient remaining after the 30% settling guard is small but not zero; it biases the plateau means in the same way in training and test. A slowed AFE leaves a large residual, so that a bandwidth fault is visible both in the transient and as a settling error.
:::

::: {custom-style="MDPI_3.1_text"}
Figure 2c illustrates the timing problem that motivates this study. Let the reference edge fall a fraction $\psi$ of the sample period $T$ after the sample at $t_{i-1}$. The first sample on the new level has then been exposed to the step for $(1-\psi)T$, and the normalized first-order response at the $j$-th sample after that ($j = 0, 1, \ldots$) is
:::

::: {custom-style="MDPI_3.9_equation"}
$$r_j(\psi) = 1 - \exp\!\left(-\frac{(j+1-\psi)\,T}{\tau}\right)$$ #EQ:phase#
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
where $\tau$ is the AFE time constant. Its sensitivity to the phase,
:::

::: {custom-style="MDPI_3.9_equation"}
$$\frac{\partial r_j}{\partial \psi} = -\frac{T}{\tau}\,\exp\!\left(-\frac{(j+1-\psi)\,T}{\tau}\right)$$ #EQ:phasesens#
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
is largest for the earliest samples. For $\tau$ = 12 ms and $T$ = 1 ms, the fraction read two samples after the step falls from 0.221 at $\psi = 0$ to 0.154 at $\psi = 0.999$, about a third of its value. A descriptor that reads fixed samples after the edge therefore carries the phase into the classifier. A fit with the edge time as a free parameter does not, because shifting the edge changes only the fitted edge time.
:::

::: {custom-style="MDPI_5.2_figure"}
![](FIG:Fig02_timing){width=16cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 2.** Active self-test timing. (**a**) Multiplexer states: MUX 1 connects R1 to the AFE input from 140 to 260 ms and MUX 2 connects R2 to the ADC input from 340 to 460 ms. (**b**) Illustrative simulated ADC record from the development seed (not validation data), with the sensor intervals, the R1 and R2 windows, their 30% settling guards (dark) and the settled plateaus (light); samples are taken every 1 ms. (**c**) Analytical illustration of the edge phase $\psi$ for $\tau$ = 12 ms: an edge occurring $\psi T$ after a sample shifts every sampled value of the first-order response (Equation (EQREF:phase)), whereas a fit over the whole transient with a free edge time absorbs the shift. Panels (b) and (c) are illustrative.
:::

::: {custom-style="MDPI_2.2_heading2"}
3.3. Observability of the Two-Point Test
:::

::: {custom-style="MDPI_3.1_text"}
The reason for two injection points can be made explicit with an affine model of the chain. Let $g_\mathrm{D}$ and $o_\mathrm{D}$ be the ADC gain and offset, $G$ and $o_\mathrm{A}$ the AFE gain and offset, and $x$ the AFE input. Away from transients and clipping, the sample recorded during the R2 window, when the ADC input is the reference level $u$, and during the settled part of the R1 window, when the AFE input is the reference level $v$, are
:::

::: {custom-style="MDPI_3.9_equation"}
$$y^{(2)} = g_\mathrm{D}\,u + o_\mathrm{D} + n, \qquad y^{(1)} = g_\mathrm{D}\left(G\,v + o_\mathrm{A}\right) + o_\mathrm{D} + n$$ #EQ:affine#
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
with additive noise $n$. Two distinct levels $u_\mathrm{L} \neq u_\mathrm{H}$ determine $g_\mathrm{D}$ and $o_\mathrm{D}$; once they are known, two distinct levels $v_\mathrm{L} \neq v_\mathrm{H}$ determine $G$ and $o_\mathrm{A}$. A single reference applied at the AFE input determines only the products $g_\mathrm{D} G$ and $g_\mathrm{D} o_\mathrm{A} + o_\mathrm{D}$, so an AFE gain fault and an ADC gain fault of the same size produce the same record. This is the identifiability argument for the second injection point. It holds under the stated assumptions (linear stages, settled plateaus, levels known, no clipping) and says nothing about how well the parameters can be estimated in the presence of noise and tolerances; that is an empirical question answered in Section 7.
:::

::: {custom-style="MDPI_3.1_text"}
The same model shows which faults the references cannot reveal. Because R1 replaces the sensor, sensor faults are visible only in the sensor intervals. A sensor bias of 0.06–0.24 V is of the same order as the spread of the healthy baseline across operating conditions (0.78–1.18 V), and a sensor gain change of 6–28% is comparable to the spread of the signal amplitude. From a single record, without a reference for the physical quantity, these faults are therefore not identifiable from normal variation of the measurand. ADC clipping is observable only when the signal reaches the clipping level, which for the simulated range of 0.72–0.93 of full scale (2.38–3.07 V) is not the case in many records. These are structural limits of the observation, not of the classifier, and they reappear in the results.
:::

::: {custom-style="MDPI_2.1_heading1"}
4\. Reference Monitoring, Calibration and Transient Descriptors
:::

::: {custom-style="MDPI_3.1_text"}
Figure 3 summarizes the processing chain from simulation to evaluation. This section describes the reference monitor, the settled-plateau calibration and the transient descriptors; the classifier and the evaluation follow in Sections 5 and 6.
:::

::: {custom-style="MDPI_5.2_figure"}
![](FIG:Fig03_pipeline){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 3.** Processing and evaluation pipeline. Behavioral and ngspice simulations generate records with injected faults, component tolerances, noise and 12-bit quantization; the two-point reference test is applied at five edge phases; the reference monitor reports the applied levels with a bounded gain error *E*; twenty descriptors are extracted and classified by a compact multilayer perceptron; performance is evaluated with macro-F1, the frozen decision gates and a paired condition-level cluster bootstrap. Schematic.
:::

::: {custom-style="MDPI_2.2_heading2"}
4.1. Reference Monitor
:::

::: {custom-style="MDPI_3.1_text"}
A calibration that divides by the commanded reference difference converts any error in the reference amplitude into an apparent gain error. The monitor therefore measures the levels that were actually applied. It is modeled as a unity-gain buffer with high input impedance feeding a dedicated 12-bit channel; each reported level is the mean of 16 samples with 1 mV rms noise per sample, quantized to the 12-bit grid. The monitor's own gain error, arising for example from its reference or resistor tolerance, is common to the four levels of a record:
:::

::: {custom-style="MDPI_3.9_equation"}
$$m = Q\!\left(r\,(1+e) + n_\mathrm{m}\right), \qquad e \sim \mathcal{U}(-E, E), \qquad n_\mathrm{m} \sim \mathcal{N}\!\left(0, (0.25\ \mathrm{mV})^2\right)$$ #EQ:monitor#
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
where $r$ is the applied level, $m$ the reported level and $Q$ the quantizer; the offset of the monitor is assumed to be trimmed. The bound $E$ took the values 0, 1, 2 and 5%, and each monitored classifier was trained with the bound it was tested with. A variant with the applied levels known exactly serves as reference.
:::

::: {custom-style="MDPI_2.2_heading2"}
4.2. Settled-Plateau Calibration
:::

::: {custom-style="MDPI_3.1_text"}
Each reference window is split into its two plateaus, and the first 30% of every plateau is discarded as a settling guard. With $\bar{y}_\mathrm{L}$ and $\bar{y}_\mathrm{H}$ the means of the remaining samples and $m_\mathrm{L}$, $m_\mathrm{H}$ the monitored levels, the ADC parameters are estimated from R2,
:::

::: {custom-style="MDPI_3.9_equation"}
$$\hat{g}_\mathrm{D} = \frac{\bar{y}^{(2)}_\mathrm{H} - \bar{y}^{(2)}_\mathrm{L}}{m^{(2)}_\mathrm{H} - m^{(2)}_\mathrm{L}}, \qquad \hat{o}_\mathrm{D} = \bar{y}^{(2)}_\mathrm{L} - \hat{g}_\mathrm{D}\, m^{(2)}_\mathrm{L}$$ #EQ:adccal#
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
the record is corrected to $z = (y - \hat{o}_\mathrm{D})/\hat{g}_\mathrm{D}$, and the AFE parameters are estimated from R1 in the same way:
:::

::: {custom-style="MDPI_3.9_equation"}
$$\hat{G} = \frac{\bar{z}^{(1)}_\mathrm{H} - \bar{z}^{(1)}_\mathrm{L}}{m^{(1)}_\mathrm{H} - m^{(1)}_\mathrm{L}}, \qquad \hat{o}_\mathrm{A} = \bar{z}^{(1)}_\mathrm{L} - \hat{G}\, m^{(1)}_\mathrm{L}$$ #EQ:afecal#
:::

::: {custom-style="MDPI_3.1_text"}
Substituting Equations (EQREF:affine) and (EQREF:monitor) into Equations (EQREF:adccal) and (EQREF:afecal) shows how a monitor gain error propagates. If the error is common to the four levels, $m = r(1+e)$, and the plateaus are settled and noise-free, then $\hat{g}_\mathrm{D} = g_\mathrm{D}/(1+e)$ and $\hat{o}_\mathrm{D} = o_\mathrm{D}$; after correction, $\hat{G} = G$ and $\hat{o}_\mathrm{A} = (1+e)\,o_\mathrm{A}$. A common gain error of ±5% thus appears as an apparent ADC gain error of about ±5% and a 5% scaling of the AFE offset, while the AFE gain and the ADC offset are unaffected. The smallest simulated gain fault is 6%, so this error is just below the fault range. Without a monitor, an actual reference amplitude of 0.8 or 1.2 times nominal acts as $1+e = 1/0.8$ or $1/1.2$, an apparent ADC gain error of −20% or +20%, which lies inside the simulated ADC gain-fault range. This analysis anticipates the behavior of the no-monitor control in Section 7.3.
:::

::: {custom-style="MDPI_2.2_heading2"}
4.3. Phase-Robust Transient Descriptors
:::

::: {custom-style="MDPI_3.1_text"}
The settled plateaus carry the static parameters; the AFE dynamics are carried by the transient at the step from the first to the second R1 plateau. The earlier descriptor set (here called FS, for fixed-sample) represented this transient by the normalized response two, five, ten, twenty and thirty samples after the step. Equation (EQREF:phase) shows why these fixed-sample fractions depend on $\psi$. The phase-robust set (PR) removes them and fits the raw samples of the second R1 plateau, together with the last sample before the step, by
:::

::: {custom-style="MDPI_3.9_equation"}
$$\hat{y}(t) = b + S\left(1 - e^{-(t-t_\mathrm{e})/\tau}\right)\mathbb{1}[t \geq t_\mathrm{e}]$$ #EQ:fit#
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
where $b$ is the last sample before the step, $S$ the step span, $\tau$ the time constant and $t_\mathrm{e}$ the edge time. For given $(\tau, t_\mathrm{e})$, with $d_j = y_j - b$ and $g_j(\tau, t_\mathrm{e}) = (1 - e^{-(t_j-t_\mathrm{e})/\tau})\,\mathbb{1}[t_j \geq t_\mathrm{e}]$, the span has the closed-form least-squares value
:::

::: {custom-style="MDPI_3.9_equation"}
$$S^{*}(\tau, t_\mathrm{e}) = \frac{\sum_j g_j d_j}{\sum_j g_j^2}, \qquad \mathrm{RSS}(\tau, t_\mathrm{e}) = \sum_j d_j^2 - S^{*} \sum_j g_j d_j$$ #EQ:varpro#
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
so that only $(\tau, t_\mathrm{e})$ need to be searched, as in variable projection «cite:golub1973,golub2003». The search evaluates a grid of 56 logarithmically spaced time constants from 1 to 400 ms and seven edge times from −0.25 $T$ to 1.25 $T$, followed by one local refinement over ±10% in $\tau$ and ±0.2 $T$ in $t_\mathrm{e}$ (9 × 9 points). The edge time is not used as a descriptor, because it encodes the phase. With the plateau length $P$ (60 ms) and the normalized response $\rho_j = d_j / S^{*}$, five descriptors are formed:
:::

::: {custom-style="MDPI_3.9_equation"}
$$\tilde{\tau} = \frac{\tau^{*}}{P}, \quad \Delta_{10,50} = \frac{t_{50} - t_{10}}{P}, \quad \Delta_{50,90} = \frac{t_{90} - t_{50}}{P}, \quad A = \frac{T}{P}\sum_j \left(1 - \rho_j\right), \quad \varepsilon = \frac{\sqrt{\mathrm{RSS}^{*}/n}}{\lvert S^{*} \rvert}$$ #EQ:desc#
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
where $t_\alpha$ is the time at which the running maximum of $\rho$ crosses the fraction $\alpha$ (linear interpolation, capped at the end of the window if the level is not reached), $A$ is the normalized transient area and $\varepsilon$ the normalized fit residual. The rise-time differences follow the transition-duration logic of IEEE Std 181 «cite:ieee181»; using differences of crossing times removes the common time shift. The plateau-settling errors of the FS set are retained. If the fitted span is degenerate ($\lvert S^{*} \rvert < 10^{-4}$), a documented fallback based on the raw window area is used; it was never triggered in 16,200 development-seed records. Table 3 lists the complete descriptor sets.
:::

::: {custom-style="MDPI_3.1_text"}
Two properties of these descriptors can be stated exactly, and both rest on assumptions. First, they are invariant to an affine transformation $y' = \alpha y + \beta$ with $\alpha \neq 0$: $d' = \alpha d$, $S^{*\prime} = \alpha S^{*}$ and $\mathrm{RSS}' = \alpha^2\,\mathrm{RSS}$, so the minimizing $(\tau, t_\mathrm{e})$ and the normalized response $\rho$ are unchanged. This holds before quantization and clipping, which break it, and makes the transient descriptors independent of the ADC gain and offset and of the monitored levels. Second, a shift of the edge by $\delta$ in noise-free data is reproduced exactly by the model with $t_\mathrm{e} + \delta$ and the same $\tau$ and $S$, provided that both edge times lie on the search grid; between grid points the fitted $\tau$ is approximate to the grid resolution. The grid search is deterministic, uses a fixed number of evaluations and always returns a value inside the grid; it does not guarantee the least-squares optimum outside the grid range or finer than its resolution. How closely the invariance holds with noise, tolerances and quantization is therefore an empirical question. On the development seed (disclosed before the validation run), moving $\psi$ from 0 to 0.999 shifted the fixed-sample fraction two samples after the step by up to {{DEV_rise2}} standard deviations across records, and every phase-robust descriptor by at most {{DEV_PRmax}}; the fitted time constant shifted by {{DEV_tau}} standard deviations.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 3.** Descriptor sets. Both sets contain 20 descriptors; PR replaces the five fixed-sample rise fractions of FS by five whole-transient descriptors.
:::

| Group | Descriptors | Window | FS | PR |
|:--|:--|:--|:-:|:-:|
| ADC calibration | ADC gain $\hat{g}_\mathrm{D}$, ADC offset $\hat{o}_\mathrm{D}$, residual noise | R2 settled plateaus | ✓ | ✓ |
| AFE calibration | AFE gain $\hat{G}$, AFE offset $\hat{o}_\mathrm{A}$, two plateau-settling errors, residual noise | R1 settled plateaus (ADC-corrected) | ✓ | ✓ |
| Sensor domain | Mean, standard deviation, high-frequency noise, peak-to-peak value and slope of the calibrated sensor signal; raw maximum and fraction of samples near the maximum | Sensor intervals | ✓ | ✓ |
| Fixed-sample transient | Normalized response 2, 5, 10, 20 and 30 samples after the R1 step | R1 step | ✓ | – |
| Whole-transient | $\tilde{\tau}$, $\Delta_{10,50}$, $\Delta_{50,90}$, $A$, $\varepsilon$ (Equation (EQREF:desc)) | Second R1 plateau with free edge time | – | ✓ |

::: {custom-style="MDPI_3.1_text"}
Figure 4 shows six descriptors for the nine classes on the development seed. The ADC gain and offset estimated from R2 respond only to ADC gain and offset faults and stay flat for sensor and AFE faults. The AFE gain and offset estimated from R1 after ADC correction shift for AFE faults; a bandwidth fault lowers the apparent gain and raises the apparent offset because the plateaus do not settle. The fitted time constant marks bandwidth faults, and the high-frequency noise of the sensor signal marks sensor-noise faults. None of the six descriptors separates sensor bias or sensor gain faults from healthy records, in line with the observability argument of Section 3.3.
:::

::: {custom-style="MDPI_5.2_figure"}
![](FIG:Fig04_fault_signatures){width=16cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 4.** Descriptor-level fault signatures on the development seed (60 records per class; illustrative, not validation data). Box plots (median, interquartile range, whiskers at 1.5 times the interquartile range, outliers hidden) of (**a**) the ADC gain and (**b**) the ADC offset estimated from R2, (**c**) the AFE gain and (**d**) the AFE offset estimated from R1 after ADC correction, (**e**) the normalized fitted time constant $\tau^{*}/P$ and (**f**) the high-frequency noise of the calibrated sensor signal, colored by faulty layer.
:::

::: {custom-style="MDPI_2.1_heading1"}
5\. Neural-Network Classification
:::

::: {custom-style="MDPI_3.1_text"}
The descriptors are physically interpretable and few, so the classifier can be small. A fully connected multilayer perceptron (MLP) with two hidden layers of 96 and 48 rectified linear units maps the standardized 20-dimensional descriptor vector to class probabilities. Two networks are trained separately. The layer network has four outputs (healthy, sensor, AFE, ADC), 6,868 parameters and 6,720 multiply–accumulate operations per inference. The fault network has nine outputs, 7,113 parameters and 6,960 multiply–accumulate operations. The networks were implemented with scikit-learn 1.7.2 «cite:pedregosa2011» and trained with Adam «cite:kingma2015» (initial learning rate $8 \times 10^{-4}$, mini-batches of 64, L2 penalty $10^{-4}$, at most 700 epochs). Each network uses the library's internal early stopping: 15% of its training rows, drawn at random, are held out and training stops when the validation accuracy has not improved by more than $10^{-4}$ for 35 consecutive epochs. Every configuration was trained with two initialization seeds (11 and 22), and the reported metrics average the two.
:::

::: {custom-style="MDPI_3.1_text"}
Two details of the training need to be stated because earlier project documents described them inconsistently. The frozen protocol states that the condition-level validation split was not used and that there is no early-stopped model; the source code shows that this refers to the 40-condition validation split, which indeed plays no role, while each network applies the internal early stopping described above to its own training rows. The internal hold-out is drawn by row rather than by operating condition, so it contains rows from conditions that are also in the training part. This can make the stopping criterion slightly optimistic but cannot leak test information, because the 88 test conditions are disjoint from all training conditions. The architecture and settings were fixed in earlier development stages and were not tuned on the validation seeds; in an earlier stage on a different seed, a temporal convolutional network reached statistical parity with this MLP but no advantage.
:::

::: {custom-style="MDPI_3.1_text"}
The descriptor arms differ only in their inputs and in the phase used for training. Arms without phase randomization (FS, PR) are trained with records at $\psi = 0$; arms with randomization (FSr, PRr) draw $\psi \sim \mathcal{U}[0, 1)$ per training record. Randomizing a nuisance parameter during training is a standard way of making a learned model insensitive to it «cite:tobin2017,iwana2021». The primary method fixed in the protocol, PRr, combines the phase-robust descriptors with phase-randomized training. A secondary variant, PRrM, adds an ngspice version of every training record (same condition, fault, phase and monitor draw, with component tolerances and the additional noise), doubling the training set; it was evaluated against the same gates but is not the primary method.
:::

::: {custom-style="MDPI_2.1_heading1"}
6\. Simulation Design, Evaluation Protocol and Statistical Analysis
:::

::: {custom-style="MDPI_2.2_heading2"}
6.1. Simulation Domains
:::

::: {custom-style="MDPI_3.1_text"}
The behavioral domain is a discrete-time model of the chain in Figure 1. The AFE filter is discretized exactly, including a two-stage update at the edge interval that places the step at $\psi T$ after the previous sample; at $\psi = 0$ this reproduces the earlier zero-order-hold simulator bit for bit, which was verified by hashing the generated records. The ngspice domain renders one netlist per record with the multiplexers as voltage-controlled switches, the AFE as an RC network followed by a behavioral gain-and-offset source, and the ADC transfer and clipping as a behavioral source; it adds 0.5 mV rms noise at the amplifier input and on each reference rail and places every reference and switch-control edge at $t_{i-1} + \psi T + 1$ µs with a hold-then-step piecewise-linear source. The transient analysis uses a 0.1 ms step, and the output is interpolated onto the 1 kHz sample grid before the ADC noise and quantization are added. Each dataset seed required {{n_sp_runs}} ngspice runs ({{n_sp_total}} in total), which took {{sp_wall_min}}–{{sp_wall_max}} s per seed with three parallel workers. Simulations used ngspice-47 «cite:ngspice47».
:::

::: {custom-style="MDPI_3.1_text"}
The two domains are not independent. Both are first-order RC models with an affine ADC, and in a noise-free check on the development seed they agreed to {{NF_mean_min}}–{{NF_mean_max}} mV mean RMS difference per phase (maximum {{NF_max}} mV at $\psi = 0.999$). The ngspice domain therefore tests the effect of switch resistances, additional amplifier and rail noise, component tolerances and circuit-level edge handling, not that of unmodeled hardware effects such as charge injection, finite amplifier bandwidth and slew rate, reference settling or leakage. This limitation was stated in the protocol before the run.
:::

::: {custom-style="MDPI_2.2_heading2"}
6.2. Datasets, Splits and Test Grids
:::

::: {custom-style="MDPI_3.1_text"}
Table 4 summarizes the protocol. Each of the three validation dataset seeds (20261026, 20261027 and 20261028) generated 350 operating conditions, each with one instance of every fault class. The conditions were split by condition into 222 training, 40 validation and 88 test conditions, with zero overlap verified at run time. Training used behavioral records at nominal reference amplitude without component tolerances. Test records included the tolerances, ADC noise, quantization and all nine classes, with the tolerance, noise and monitor draws shared between the two domains so that each behavioral test record has an ngspice twin. The behavioral test grid covers reference amplitudes of 0.8, 0.9, 1.0, 1.1 and 1.2 times nominal at the five phases $\psi \in \{0, 0.25, 0.5, 0.75, 0.999\}$; the ngspice grid covers 0.8, 1.0 and 1.2 at the same phases. Because the two grids contain different amplitudes, scores pooled over each domain's full grid cannot be subtracted to estimate a transfer loss; transfer is evaluated only on the matched grid of 0.8, 1.0 and 1.2.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 4.** Simulation and evaluation protocol.
:::

| Item | Setting |
|:--|:--|
| Simulation domains | Behavioral discrete-time model; per-record ngspice netlist of the same topology |
| Validation dataset seeds | 20261026, 20261027, 20261028 (generated after the protocol freeze) |
| Conditions per seed | 350 operating conditions × 9 fault classes |
| Split by condition | 222 training / 40 validation (unused) / 88 test; overlap 0 |
| Test records per grid cell | 792 (88 conditions × 9 classes) per seed |
| Training data | Behavioral, amplitude ×1.0, no tolerances; $\psi = 0$ (FS, PR) or $\psi \sim \mathcal{U}[0,1)$ (FSr, PRr); PRrM adds ngspice twins |
| Edge phases (test) | $\psi$ = 0, 0.25, 0.5, 0.75, 0.999 |
| Reference amplitudes (test) | Behavioral ×0.8, ×0.9, ×1.0, ×1.1, ×1.2; ngspice ×0.8, ×1.0, ×1.2 |
| Reference conditions | Known levels; monitor with *E* = 0, ±1, ±2, ±5% (matched training); no monitor (behavioral control) |
| Disturbances (test) | Component tolerances (Table 1); ADC noise 2.5 mV rms; 12-bit quantization; ngspice adds 0.5 mV rms amplifier and rail noise |
| Initializations | Seeds 11 and 22 for every network, averaged |
| Primary metric | Layer macro-F1 (4 classes) |
| Further metrics | Fault macro-F1 (9 classes), balanced accuracy, per-class recall, AFE–ADC cross-confusion, retention, phase spread |
| Uncertainty | Paired condition-level cluster bootstrap, 5000 resamples per seed; pooled 95% percentile interval |
| Protocol status | Frozen internally before the validation data were generated (source-code hashes recorded); not registered externally |

::: {custom-style="MDPI_2.2_heading2"}
6.3. Compared Arms and Baselines
:::

::: {custom-style="MDPI_3.1_text"}
Besides FS, FSr, PR, PRr and PRrM, the evaluation includes the descriptor set of the stage before the reference revision (A0: raw waveform samples and 38 physics descriptors, trained at $\psi = 0$) and single-path baselines: a passive classifier using the sensor signal only, a single additive-probe active test, and AFE-only and ADC-only reference tests with the A0 descriptors and with the PRr descriptors restricted to their single window. A no-monitor control applies the PRr classifier trained with known levels to records in which the reference amplitude has changed but the nominal levels are assumed; it answers the question of what the monitor contributes. This control was evaluated in the behavioral domain only.
:::

::: {custom-style="MDPI_2.2_heading2"}
6.4. Metrics
:::

::: {custom-style="MDPI_3.1_text"}
For a confusion matrix with true positives $\mathrm{TP}_c$, false positives $\mathrm{FP}_c$ and false negatives $\mathrm{FN}_c$ for class $c$ of $C$ classes, the macro-F1 score is
:::

::: {custom-style="MDPI_3.9_equation"}
$$\mathrm{MF1} = \frac{1}{C}\sum_{c=1}^{C} \frac{2\,\mathrm{TP}_c}{2\,\mathrm{TP}_c + \mathrm{FP}_c + \mathrm{FN}_c}$$ #EQ:mf1#
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
which weights every class equally regardless of how often it is predicted «cite:sokolova2009». Layer macro-F1 ($C = 4$) measures whether the faulty layer is found; it is the primary metric because localization to a layer is the decision the architecture is designed to support. Fault macro-F1 ($C = 9$) measures whether the specific fault is found and is not directly comparable with layer macro-F1: a sensor-bias record classified as sensor gain is wrong for the fault metric but right for the layer metric, while the layer network and the fault network are different models with different output sizes. The AFE–ADC cross-confusion
:::

::: {custom-style="MDPI_3.9_equation"}
$$\kappa = \frac{n_{\mathrm{AFE}\to\mathrm{ADC}} + n_{\mathrm{ADC}\to\mathrm{AFE}}}{n_{\mathrm{AFE}} + n_{\mathrm{ADC}}}$$ #EQ:cross#
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
is the fraction of AFE- and ADC-fault records assigned to the other of the two layers; it isolates the confusion that the second injection point is meant to prevent and is unaffected by errors among healthy and sensor records. Retention is the ratio of layer macro-F1 at a shifted reference amplitude to the nominal value $N_d$, defined as the layer macro-F1 of PRr with known levels at amplitude ×1.0 pooled over the five phases in domain $d$. The phase spread is the difference between the largest and smallest layer macro-F1 among the five phases.
:::

::: {custom-style="MDPI_2.2_heading2"}
6.5. Aggregation, Uncertainty and Decision Rules
:::

::: {custom-style="MDPI_3.1_text"}
For every dataset seed and initialization, the confusion matrices of all pooled grid cells (amplitudes and phases, as stated for each result) are summed and the metric is computed once from the sum; the metric is then averaged over the two initializations and over the three dataset seeds. Paired differences between two arms, or between the two domains for the same classifier, are assessed with a condition-level cluster bootstrap «cite:field2007,davison1997»: for each seed, 5000 multinomial resamples of the 88 test conditions are drawn, the same weights are applied to both members of the pair and to every pooled cell, and the pooled 95% interval is formed from the percentiles of the mean of the three per-seed bootstrap differences,
:::

::: {custom-style="MDPI_3.9_equation"}
$$\Delta^{*}_b = \frac{1}{3}\sum_{s=1}^{3}\left[\mathrm{MF1}_A\!\left(\mathbf{W}^{*}_{s,b}\right) - \mathrm{MF1}_B\!\left(\mathbf{W}^{*}_{s,b}\right)\right], \qquad b = 1, \ldots, 5000$$ #EQ:boot#
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
where $\mathbf{W}^{*}_{s,b}$ are the resampling weights of seed $s$. An improvement is stated only when this interval excludes zero, and a difference is called consistent when it has the same sign in all three seeds. The interval reflects the sampling of test conditions given the trained networks; variability between training runs enters only through the two initializations and the three seed-specific training sets.
:::

::: {custom-style="MDPI_3.1_text"}
The protocol fixed seven criteria before the validation run (Table 5): retention of at least 0.85 $N_d$ at ×0.8 and ×1.2 (A), superiority over the earlier method and the single-path baselines with interval lower bounds above zero (B), cross-confusion below 0.15 (C), retention of at least 0.70 $N_d$ with a ±5% monitor error (D), a behavioral-to-ngspice transfer loss of at most 0.10 at $E$ = ±2% on the matched grid (E), interval support for every claimed improvement (F) and a phase spread of at most 0.05 (G). The decision was GO only if all gates held for PRr in both domains where applicable. Development and debugging used a separate seed (20261097), which is the source of all illustrative panels; no descriptor, fit setting, threshold or model was changed after the validation seeds were generated. The protocol and the source-code hashes were recorded internally. They were not deposited in an external registry, so the study is described as following an internally frozen protocol rather than as preregistered.
:::

::: {custom-style="MDPI_2.2_heading2"}
6.6. Software, Reproducibility and Use of Generative AI
:::

::: {custom-style="MDPI_3.1_text"}
The runs used Python 3.12.12, NumPy 2.2.6, pandas 2.3.3, SciPy 1.16.3, scikit-learn 1.7.2 and ngspice-47 on macOS (arm64). These versions were recorded on the day of the validation run on the machine that produced it, and the installation dates of ngspice and scikit-learn precede the run; the run logs themselves do not record versions (Table S6). The SHA-256 hashes of all simulator and analysis source files match those recorded at the protocol freeze. Every number in this article was recomputed from the saved per-record predictions with an independent script, which reproduced the stored decision values, bootstrap intervals and summary tables (488 checks, no mismatch). This establishes reproducibility of the statistics and figures from the saved predictions; a rerun of the simulations and of the training on a second machine has not been performed.
:::

::: {custom-style="MDPI_3.1_text"}
Generative AI was used in this study. Claude Code (Anthropic) was used to implement the simulation, descriptor, training and analysis software, to draft the frozen protocols and stage reports under the author's direction, and, for this article, to search and verify the literature, regenerate figures from the saved data, recompute the statistics and draft the text. The author reviewed the design decisions, the code and the results and takes responsibility for the content.
:::

::: {custom-style="MDPI_2.1_heading1"}
7\. Results
:::

::: {custom-style="MDPI_2.2_heading2"}
7.1. Overall Performance and Decision Gates
:::

::: {custom-style="MDPI_3.1_text"}
All gates fixed in the protocol were met for PRr in both domains (Table 5), and the protocol decision was GO. Table 6 gives the overall scores with the monitor at $E$ = ±2%, pooled over each domain's full test grid. PRr reached a layer macro-F1 of {{PRr_bh_L}} in the behavioral domain and {{PRr_sp_L}} in ngspice, and a fault macro-F1 of {{PRr_bh_F}} and {{PRr_sp_F}}. The three dataset seeds gave behavioral layer scores of {{PRr_bh_seedrange}}. Because the two domains are pooled over different amplitude grids, the difference between these two headline values is not a transfer loss; the matched comparison follows in Section 7.5.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 5.** Decision gates fixed in the protocol and results for the primary method PRr. $N_d$ is the PRr layer macro-F1 with known levels at ×1.0 pooled over phases ({{N_bh}} behavioral, {{N_sp}} ngspice).
:::

| Gate | Criterion | Threshold | Observed (PRr) | Behavioral | ngspice |
|:-:|:--|:--|:--|:-:|:-:|
| A | Retention at ×0.8 and ×1.2 (known levels, *E* ≤ ±2%) | ≥ 0.85 $N_d$ | Lowest {{A_worst}} $N_d$ | Pass | Pass |
| B | Difference to earlier method and single-path baselines (behavioral, 70 comparisons) | Lower 95% bound > 0 | Smallest lower bound {{Bmin_lo}} | Pass | – |
| C | AFE–ADC cross-confusion at ×0.8 and ×1.2 | < 0.15 | Largest {{C_max}} | Pass | Pass |
| D | Retention with *E* = ±5% (×0.8, ×1.2 and pooled) | ≥ 0.70 $N_d$ | Lowest {{D_worst}} $N_d$ | Pass | Pass |
| E | Transfer loss, matched grid, *E* = ±2% | ≤ 0.10 | {{E2_drop}} {{E2_drop_ci}} | Pass | – |
| F | Interval support for every claimed improvement | Interval excludes 0 | Applied throughout | Met | Met |
| G | Phase spread (known levels and *E* = ±2%) | ≤ 0.05 | {{G_min}}–{{G_max}} | Pass | Pass |

::: {custom-style="MDPI_4.1_table_caption"}
**Table 6.** Overall classification results with the monitor at *E* = ±2%, pooled over amplitudes and the five phases (mean of three dataset seeds × two initializations).
:::

| Method | Role | Domain (amplitude grid) | Layer macro-F1 | Layer balanced accuracy | Fault macro-F1 | Fault balanced accuracy |
|:--|:--|:--|:-:|:-:|:-:|:-:|
| PRr | Primary | Behavioral (×0.8–×1.2, 5 levels) | {{PRr_bh_L}} | {{PRr_bh_Lba}} | {{PRr_bh_F}} | {{PRr_bh_Fba}} |
| PRr | Primary | ngspice (×0.8, ×1.0, ×1.2) | {{PRr_sp_L}} | {{PRr_sp_Lba}} | {{PRr_sp_F}} | {{PRr_sp_Fba}} |
| PRrM | Secondary | Behavioral (×0.8–×1.2, 5 levels) | {{PRrM_bh_L}} | {{PRrM_bh_Lba}} | {{PRrM_bh_F}} | {{PRrM_bh_Fba}} |
| PRrM | Secondary | ngspice (×0.8, ×1.0, ×1.2) | {{PRrM_sp_L}} | {{PRrM_sp_Lba}} | {{PRrM_sp_F}} | {{PRrM_sp_Fba}} |
| FS | Fixed-sample descriptors | Behavioral (×0.8–×1.2, 5 levels) | {{R1_bh_L}} | {{R1_bh_Lba}} | {{R1_bh_F}} | {{R1_bh_Fba}} |
| FS | Fixed-sample descriptors | ngspice (×0.8, ×1.0, ×1.2) | {{R1_sp_L}} | {{R1_sp_Lba}} | {{R1_sp_F}} | {{R1_sp_Fba}} |

::: {custom-style="MDPI_4.3_table_footer"}
Behavioral and ngspice rows use different amplitude grids and must not be subtracted; the matched-grid comparison is given in Section 7.5.
:::

::: {custom-style="MDPI_3.1_text"}
These absolute values are modest. A layer macro-F1 of about 0.65 means that the classifier is far from a reliable four-way decision, and Section 7.7 shows that the shortfall is concentrated in a well-defined group of classes. The gates measure robustness to the reference amplitude, to the monitor error, to the domain and to the phase relative to the nominal performance; passing them does not make the nominal performance high.
:::

::: {custom-style="MDPI_2.2_heading2"}
7.2. Sensitivity to the Sampling Phase
:::

::: {custom-style="MDPI_3.1_text"}
Figure 5 shows the central result. With the fixed-sample descriptors (FS), layer macro-F1 declined steadily as the edge moved through the sample period, with a phase spread of {{R1_bh_spread}} in the behavioral domain and {{R1_sp_spread}} in ngspice, beyond the 0.05 limit of gate G. With the phase-robust descriptors and randomized training (PRr) the curves were nearly flat, with spreads of {{PRr_bh_spread}} and {{PRr_sp_spread}}; over the four gate-G variants (known levels and $E$ = ±2%, both domains) the PRr spread was {{G_min}}–{{G_max}}. Per-phase values for every arm and reference condition are listed in Table S1. Randomizing the phase during training reduced the FS spread to {{R1r_bh_spread}} and {{R1r_sp_spread}}, so the classifier can partly learn to ignore the phase, but it did not remove the decline at $\psi = 0.999$. The phase-robust descriptors trained only at $\psi = 0$ (PR) were as flat as PRr ({{PR_bh_spread}} and {{PR_sp_spread}}), which indicates that the robustness comes from the descriptors themselves rather than from the training distribution. The behavior matches the mechanism in panel (c): the early fixed-sample fractions move by more than one standard deviation over the phase range, and the whole-transient descriptors hardly move.
:::

::: {custom-style="MDPI_5.2_figure"}
![](FIG:Fig05_phase_sensitivity){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 5.** Sensitivity to the sampling phase. Layer macro-F1 (monitor *E* = ±2%, pooled over each domain's reference amplitudes; mean of three dataset seeds × two initializations) versus the edge phase $\psi$ in (**a**) the behavioral and (**b**) the ngspice domain, for the fixed-sample descriptors (FS), FS with phase-randomized training (FSr), the phase-robust descriptors (PR), the primary method (PRr) and the secondary mixed-domain variant (PRrM); simulation results. (**c**) Mechanism on the development seed (illustrative): mean absolute descriptor shift relative to $\psi = 0$, in units of the across-record standard deviation, for two fixed-sample fractions and three phase-robust descriptors.
:::

::: {custom-style="MDPI_2.2_heading2"}
7.3. Robustness to Reference Amplitude and Monitor Error
:::

::: {custom-style="MDPI_3.1_text"}
Figure 6 and Table 7 show layer macro-F1 as a function of the actual reference amplitude. With known levels, PRr retained at least {{A_worst}} of $N_d$ at ×0.8 and ×1.2 across the known and monitored variants with $E$ ≤ ±2% (gate A), and at $E$ = ±5% the lowest retention was {{D_worst}} (gate D). The monitored variants differed from each other by up to {{X10_spreadvar}} at ×1.0 ({{X10_min}}–{{X10_max}}). Because each variant is a separately trained network, these differences include training variability and should not be read as an effect of the monitor error; in particular, the $E$ = ±2% network scoring above the known-level network does not mean that a monitor error helps.
:::

::: {custom-style="MDPI_3.1_text"}
The no-monitor control shows what the monitor contributes. The same PRr network that reached {{K80}} and {{K120}} with known levels at ×0.8 and ×1.2 fell to {{NM80}} and {{NM120}} when the nominal levels were assumed, and its fault macro-F1 fell to {{NMF80}} and {{NMF120}}. The earlier descriptor set A0 collapsed in the same way, from {{A0_100}} at ×1.0 to {{A0_80}} and {{A0_120}}. As predicted by the calibration analysis of Section 4.2, an unmonitored amplitude change is absorbed as an apparent ADC gain error: without monitoring, nearly all healthy and sensor records were assigned to the ADC layer (Section 7.4). The monitor is therefore not an optional refinement but a necessary part of the two-point test whenever the reference amplitude is uncertain. This conclusion rests on behavioral evidence only, since the no-monitor control was not simulated in ngspice.
:::

::: {custom-style="MDPI_5.2_figure"}
![](FIG:Fig06_reference_amplitude){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 6.** Robustness to the reference amplitude (simulation results). Layer macro-F1, pooled over the five phases and averaged over three dataset seeds, versus the actual reference amplitude for PRr with known levels and with the monitor (*E* = 0, ±1, ±2, ±5%), the fixed-sample descriptors (FS, known levels) and the earlier descriptors (A0), in (**a**) the behavioral and (**b**) the ngspice domain. In (a), the no-monitor control applies the known-level PRr network with the nominal levels assumed; it was evaluated in the behavioral domain only. ngspice was simulated at ×0.8, ×1.0 and ×1.2.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 7.** Layer macro-F1 of PRr versus the actual reference amplitude, pooled over the five phases (mean of three dataset seeds).
:::

TABLE:amp

::: {custom-style="MDPI_4.3_table_footer"}
Monitored variants are trained with the matching error bound. The no-monitor control was evaluated in the behavioral domain only (–: not simulated).
:::

::: {custom-style="MDPI_2.2_heading2"}
7.4. Separation of AFE and ADC Faults
:::

::: {custom-style="MDPI_3.1_text"}
The second injection point exists to keep AFE and ADC faults apart, and Figure 7 and Table 8 show that it does so when the reference levels are known or monitored. At ±20% reference amplitude, AFE recall was {{AFE_rec_range}} and ADC recall {{ADC_rec_range}} over all known and monitored conditions in both domains, and the AFE–ADC cross-confusion was between {{C_min}} and {{C_max}}, well below the 0.15 limit of gate C. Without monitoring, the cross-confusion rose to {{NM_cross80}} at ×0.8 and {{NM_cross120}} at ×1.2, AFE recall fell to {{NM_afe80}} and {{NM_afe120}}, and ADC recall stayed high ({{NM_adc80}} and {{NM_adc120}}) only because almost every record was assigned to the ADC layer. Cross-confusion was larger at ×1.2 than at ×0.8 in every condition; with known levels the increase came mostly from ADC faults assigned to the AFE layer (Figure 7b).
:::

::: {custom-style="MDPI_5.2_figure"}
![](FIG:Fig07_afe_adc_separation){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 7.** Separation of AFE and ADC faults by PRr in the behavioral domain (simulation results, pooled over the five phases; mean of three dataset seeds × two initializations). (**a**,**b**) Row-normalized layer confusion matrices with known levels at ×0.8 and ×1.2; (**c**,**d**) the same network without reference monitoring (nominal levels assumed). H, healthy; S, sensor. Red boxes mark the AFE–ADC cells. (**e**) AFE recall, ADC recall and AFE–ADC cross-confusion (Equation (EQREF:cross)) for known levels, the monitor with *E* = 0 to ±5% and the no-monitor control at ×0.8 and ×1.2; the dashed line is the gate C limit.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 8.** AFE/ADC separation of PRr at ±20% reference amplitude, pooled over the five phases. Complete results for every monitor condition are given in Table S2.
:::

TABLE:sep

::: {custom-style="MDPI_2.2_heading2"}
7.5. Behavioral-to-Circuit Transfer
:::

::: {custom-style="MDPI_3.1_text"}
Table 9 and Figure 8 compare the behaviorally trained PRr network on the matched grid (×0.8, ×1.0 and ×1.2 at the five phases) in both domains. At $E$ = ±2%, the case fixed for gate E, layer macro-F1 was {{E2_BB}} on behavioral data and {{E2_BS}} on ngspice data, a transfer loss of {{E2_drop}} with 95% interval {{E2_drop_ci}}; the loss was consistent in sign across the three seeds but small in every one. Over all five reference conditions the loss ranged from {{E_drop_min}} to {{E_drop_max}}, with every interval inside {{E_ci_lo_min}} to {{E_ci_hi_max}}; the corresponding loss in fault macro-F1 at $E$ = ±2% was {{E2_dropF}}. Per phase, the behavioral and ngspice curves differed by at most {{Ephase_gap_max}} (Figure 8c).
:::

::: {custom-style="MDPI_3.1_text"}
The previous validation stage lost {{PREV_drop}} {{PREV_ci}} under the same gate. That value is shown in Figure 8b and Table 9 as history, not as a controlled comparison: it was obtained on different dataset seeds with different descriptors, with the behavioral model fixed at $\psi = 0$ and the ngspice edges at $\psi = 0.999$, and its decision file is not part of the evidence of this study. The controlled evidence for the phase explanation is the comparison of FS and PR on the same seeds and the same phases in Section 7.2. Given that the two domains differ in the noise-free case by only {{NF_mean_min}}–{{NF_mean_max}} mV, a transfer loss close to zero is the expected outcome once the timing convention no longer enters the descriptors; it shows that the remaining circuit-level effects modeled here do not disturb the diagnosis, not that hardware would behave in the same way.
:::

::: {custom-style="MDPI_3.1_text"}
Mixed-domain training (PRrM) raised the ngspice score above that of PRr by {{E2_MSBS}} at $E$ = ±2% and by {{E_MSBS_min}} to {{E_MSBS_max}} over the five reference conditions, and it also raised the behavioral score (Section 7.6). Since PRrM sees twice as many training rows, including rows with tolerances and the additional noise, the gain cannot be attributed to the ngspice data alone.
:::

::: {custom-style="MDPI_5.2_figure"}
![](FIG:Fig08_domain_transfer){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 8.** Behavioral-to-ngspice transfer on the matched grid (×0.8, ×1.0 and ×1.2 at five phases; simulation results). (**a**) Layer macro-F1 of the behaviorally trained PRr network on behavioral data and on ngspice data, and of the secondary variant PRrM on ngspice data, for each reference condition. (**b**) Transfer loss (behavioral minus ngspice) with paired cluster-bootstrap 95% intervals; the square marks the loss of the previous validation stage (historical value from different seeds and descriptors, not a controlled comparison); the dashed line is the gate E limit. (**c**) Layer macro-F1 per edge phase at *E* = ±2% for PRr and PRrM in both domains, pooled over the matched grid and recomputed from the saved predictions.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 9.** Behavioral-to-ngspice transfer of layer macro-F1 on the matched grid (×0.8, ×1.0, ×1.2 × five phases).
:::

TABLE:transfer

::: {custom-style="MDPI_4.3_table_footer"}
Both PRr columns use the same behaviorally trained network. Intervals are paired condition-level cluster-bootstrap 95% intervals (5000 resamples per seed). The previous-stage row is historical context from a different validation stage and is not a controlled comparison.
:::

::: {custom-style="MDPI_2.2_heading2"}
7.6. Attribution and Baselines
:::

::: {custom-style="MDPI_3.1_text"}
Figure 9 and Table 10 separate the two ingredients of PRr at $E$ = ±2%. Replacing the fixed-sample fractions by the whole-transient descriptors without changing the training (PR − FS) improved layer macro-F1 by {{att_bh_PR-R1}} in the behavioral domain and {{att_sp_PR-R1}} in ngspice. Randomizing the training phase without changing the descriptors (FSr − FS) improved it by {{att_bh_R1r-R1}} and {{att_sp_R1r-R1}}. Given randomization, the descriptors still added {{att_bh_PRr-R1r}} and {{att_sp_PRr-R1r}}; given the robust descriptors, randomization added nothing that could be resolved ({{att_bh_PRr-PR}} and {{att_sp_PRr-PR}}). Every resolved difference had the same sign in all three seeds. The practical reading is that the descriptors carry the improvement. PR and PRr are statistically indistinguishable, and PRr remains the primary method only because the protocol fixed it in advance.
:::

::: {custom-style="MDPI_5.2_figure"}
![](FIG:Fig09_ablation){width=16cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 9.** Attribution study (simulation results, monitor *E* = ±2%, pooled over amplitudes and phases). (**a**) Layer macro-F1 of the earlier descriptors (A0), the fixed-sample descriptors (FS), FS with phase-randomized training (FSr), the phase-robust descriptors (PR), the primary method (PRr) and the secondary variant (PRrM); solid bars behavioral, hatched bars ngspice (A0 was not simulated in ngspice). The two domains are pooled over different amplitude grids. (**b**) Phase spread; the dashed line is the gate G limit. (**c**) Paired differences with cluster-bootstrap 95% intervals.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 10.** Attribution of the PRr improvement: paired differences in layer and fault macro-F1 at *E* = ±2%, pooled over amplitudes and phases, with cluster-bootstrap 95% intervals.
:::

TABLE:att

::: {custom-style="MDPI_3.1_text"}
Mixed-domain training improved layer macro-F1 by {{att_bh_PRrM-PRr}} in the behavioral domain and {{att_sp_PRrM-PRr}} in ngspice. Against the earlier A0 descriptors, PRr was better by {{att_bh_PRr-A0}} in the behavioral domain, a difference driven mainly by the collapse of A0 under reference-amplitude error (Figure 6a).
:::

::: {custom-style="MDPI_3.1_text"}
Table 11 compares PRr with the single-path baselines at ±20% amplitude with known levels, the comparisons of gate B. The passive classifier (layer macro-F1 {{B_passive}}) and the single additive probe ({{B_single}} at ×0.8/×1.2) show that neither the sensor signal alone nor a single probe localizes the faults reliably. More informative are the single-window versions of PRr itself: the AFE-only test reached {{B_afePRr}} and the ADC-only test {{B_adcPRr}}, against {{K80}}/{{K120}} for the two-point test. With the same descriptors and the same classifier, removing either reference window costs more than 0.12 layer macro-F1, which is the empirical counterpart of the identifiability argument in Section 3.3. Over all 70 comparisons of gate B (seven baselines, five reference conditions, two amplitudes; Table S4), the smallest interval lower bound was {{Bmin_lo}}.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 11.** Baseline comparison in the behavioral domain with known reference levels, pooled over the five phases. Differences are PRr minus the baseline with cluster-bootstrap 95% intervals.
:::

TABLE:base

::: {custom-style="MDPI_2.2_heading2"}
7.7. Per-Class Performance and Weak Classes
:::

::: {custom-style="MDPI_3.1_text"}
Figure 10 and Table 12 explain the modest absolute scores. Five classes were recognized well by PRr in both domains: sensor noise, AFE offset, AFE bandwidth, ADC offset and ADC gain, with recall between {{obs_min}} and {{obs_max}}. Four classes were not: healthy, sensor bias, sensor gain and ADC clipping, with recall between {{weak_min}} and {{weak_max}}. The fine-fault confusion matrix (Figure S1) shows that these four classes are confused mainly with each other. In the behavioral domain, healthy records were assigned to ADC clipping in {{CM_H_clip}}% of cases and to sensor bias or sensor gain in {{CM_H_sens}}%, and ADC-clipping records were assigned to healthy in {{CM_clip_H}}% of cases. This is the pattern expected from Section 3.3. Sensor bias and gain cannot be separated from normal variation of the measurand in a single record. A clipping fault whose threshold the signal never reaches produces a record identical to a healthy one; on the development seed, the median of the largest raw sample in the sensor intervals was {{DEV_ymax_med}} V, below the lowest simulated clipping level of 2.38 V.
:::

::: {custom-style="MDPI_3.1_text"}
At the layer level, the consequence is a healthy-layer recall of only {{rec_H_bh}} in the behavioral domain and {{rec_H_sp}} in ngspice: most healthy records were flagged as faulty. As evaluated here, the classifier is therefore a localization aid for records already suspected to be faulty, not a detector that decides whether a fault is present. Mixed-domain training raised the behavioral healthy-layer recall to {{recM_H_bh}} without changing this picture. None of the revisions in this study was designed to address these classes, and none did.
:::

::: {custom-style="MDPI_5.2_figure"}
![](FIG:Fig10_per_class_recall){width=17cm}
:::

::: {custom-style="MDPI_5.1_figure_caption"}
**Figure 10.** Per-class recall (simulation results, monitor *E* = ±2%, pooled over amplitudes and phases; mean of three dataset seeds). (**a**,**b**) Fine-fault recall of every arm in the behavioral and ngspice domains; PRr, the primary method, in bold. (**c**) Layer recall of FS, PRr and PRrM in both domains and of the no-monitor control (behavioral, ×0.8 and ×1.2). Red outlines mark recall below 0.50, a display threshold rather than a criterion of the protocol.
:::

::: {custom-style="MDPI_4.1_table_caption"}
**Table 12.** Recall per fault class and per layer for PRr and PRrM at *E* = ±2%, pooled over amplitudes and phases (mean of three dataset seeds). Results for all arms are given in Table S3.
:::

TABLE:recall

::: {custom-style="MDPI_2.2_heading2"}
7.8. Computational Cost
:::

::: {custom-style="MDPI_3.1_text"}
The phase-robust descriptors took {{t_pr}} ms per record on one core of a desktop computer in Python, against {{t_r1}} ms for the FS set, and one MLP inference took {{t_mlp_us}} µs per record in batched evaluation. The layer network's 6,868 parameters occupy about 27 kB in 32-bit floating point. These are desktop measurements of an unoptimized implementation; no microcontroller timing, memory footprint, energy or silicon area was measured, and the feasibility of an embedded implementation is an expectation rather than a result of this study. Table S5 lists the complete cost and runtime figures.
:::

::: {custom-style="MDPI_2.1_heading1"}
8\. Discussion
:::

::: {custom-style="MDPI_2.2_heading2"}
8.1. What the Results Show
:::

::: {custom-style="MDPI_3.1_text"}
The study set out to test one explanation and one remedy. The explanation was that the earlier transfer failure came largely from the sampling phase of the reference edge; the remedy was to estimate the transient with the edge time as a free parameter. Both are supported within the simulated setting. On the same seeds, the fixed-sample descriptors lost about 0.08 layer macro-F1 across the sample period in both domains, the fit-based descriptors lost at most 0.011, and with the phase no longer in the descriptors the behavioral and ngspice results agreed to within {{E2_drop}}. The attribution shows that the descriptors, not the randomized training, carry the effect. This is an argument for addressing a nuisance variable in the feature design when its physics is known, rather than relying on the classifier to average it out: randomization helped the fixed-sample descriptors but left a residual decline at $\psi = 0.999$, whereas the fitted descriptors removed the dependence even when trained at a single phase.
:::

::: {custom-style="MDPI_3.1_text"}
The second finding concerns the reference. The calibration analysis of Section 4.2 predicts that an unmonitored amplitude change will appear as an ADC gain error, and the no-monitor control shows exactly this, with layer macro-F1 falling to {{NM80}} and {{NM120}} at ±20%. With a monitor whose common gain error is bounded by 5%, the apparent ADC gain error stays below the smallest simulated gain fault, and the results bear this out. A reference monitor should thus be treated as part of the test architecture and its error bound as a design parameter that must be smaller than the smallest gain fault to be detected.
:::

::: {custom-style="MDPI_2.2_heading2"}
8.2. Relation to Previous Work
:::

::: {custom-style="MDPI_3.1_text"}
The two-point principle is not new: estimating gain and offset from known input levels is standard practice in ADC testing and calibration «cite:ieee1241,mohammedali2024», and isolating a readout from its sensor has been demonstrated «cite:nessler2018». What this study adds is the combination of a second injection point behind the AFE, so that ADC and AFE parameters are estimated in sequence, with a measured rather than assumed reference and with transient descriptors that do not depend on the edge timing, evaluated as a whole on unseen seeds in two simulation domains. Czaja's self-test is the closest in its use of sampled step-like responses for localization «cite:czaja2013». The present architecture extends the localization to the converter itself, which in that approach serves as the measuring instrument, at the price of a second multiplexer and a monitor channel. Compared with the deep-learning diagnosis literature «cite:yang2020,ji2021,zhou2025», the classifier here is deliberately small and its inputs are physically defined; the results suggest that, for this problem, the limiting factor is the observability of certain faults rather than the capacity of the classifier. A direct numerical comparison with these works is not meaningful because they address different circuits, fault sets and data.
:::

::: {custom-style="MDPI_2.2_heading2"}
8.3. Practical Implications
:::

::: {custom-style="MDPI_3.1_text"}
Several design rules follow for a sensor interface that is meant to localize its own faults. References should be injected at two depths of the chain, one in front of the AFE and one directly at the ADC input, and the ADC transfer should be removed before the AFE transfer is estimated. The applied reference levels should be measured, with a monitor gain error smaller than the smallest gain fault of interest. Transient descriptors should not read fixed samples after a test edge unless the edge is synchronized with the sampling clock by design; a fit with a free edge time costs a few hundred microseconds per record in an unoptimized implementation and removes the dependence. Finally, the test cannot reveal what the references do not excite: a sensor-side reference or redundancy is needed to separate sensor bias and gain from the measurand, and clipping can be tested only by a stimulus that reaches the clipping level, for example a third reference level near full scale. These suggestions follow from the analysis and the simulations; their benefit in hardware remains to be shown.
:::

::: {custom-style="MDPI_2.2_heading2"}
8.4. Limitations
:::

::: {custom-style="MDPI_3.1_text"}
The limitations are substantial and define the scope of the conclusions.
:::

::: {custom-style="MDPI_3.8_bullet"}
Both simulation domains are first-order RC models with an affine ADC, developed within the same project, and they agree closely in the noise-free case. The transfer result therefore probes switch resistances, additional noise, tolerances and circuit-level edge handling, not unmodeled hardware effects such as charge injection, op-amp bandwidth and slew rate, reference settling, leakage or ADC nonlinearity. It is not a hardware validation.
:::

::: {custom-style="MDPI_3.8_bullet"}
The phase model assumes one common, constant edge phase for all reference and multiplexer edges within a record. Jitter between edges, drift of the phase within a record and different phases for the AFE and ADC references were not tested.
:::

::: {custom-style="MDPI_3.8_bullet"}
The monitor is simulated with a common gain error, white noise and a trimmed offset, and each monitored network was trained with the error bound it was tested with, which assumes that the bound is known.
:::

::: {custom-style="MDPI_3.8_bullet"}
Absolute performance is modest, the healthy-layer recall is about 0.14 and four classes are poorly separated. The classifier is a localization aid, not a detector, and no claim of deployable diagnostic accuracy is made.
:::

::: {custom-style="MDPI_3.8_bullet"}
The evidence comes from three dataset seeds with 88 test conditions each. The intervals resample test conditions and do not capture variability between training runs beyond two initializations; separately trained networks for different monitor bounds differed by up to {{X10_spreadvar}} at nominal amplitude. The early stopping used a row-level rather than a condition-level hold-out.
:::

::: {custom-style="MDPI_3.8_bullet"}
Robustness was demonstrated for the nuisance variables that were varied (edge phase, reference amplitude, monitor error, tolerances and the two domains) over the tested ranges. It does not imply robustness to other variables, other fault types or multiple simultaneous faults, which were not simulated.
:::

::: {custom-style="MDPI_3.8_bullet"}
The protocol was frozen and hashed internally but not registered externally. The statistics and figures are reproducible from the saved predictions; an independent rerun of the simulations and training has not yet been performed.
:::

::: {custom-style="MDPI_2.2_heading2"}
8.5. Future Work
:::

::: {custom-style="MDPI_3.1_text"}
The next step is a validation with circuit models that include real operational-amplifier and switch behavior, followed by a small hardware prototype with a microcontroller ADC, where the edge phase is genuinely uncontrolled and the monitor error can be measured. Extending the test with a sensor-side reference and a near-full-scale level would address the weak classes directly. Jitter and drift of the edge phase, simultaneous faults and an embedded implementation of the fit and the network should be evaluated under the same kind of frozen protocol.
:::

::: {custom-style="MDPI_2.1_heading1"}
9\. Conclusions
:::

::: {custom-style="MDPI_3.1_text"}
A two-point active self-test with a monitored reference can localize AFE and ADC faults in a simulated sensor interface while keeping their mutual confusion low under ±20% reference-amplitude error, provided that the reference levels are measured. Its transient descriptors must not depend on where the reference edge falls between ADC samples. Replacing fixed-sample readings by a first-order fit with a free edge time reduced the phase spread of layer macro-F1 from about 0.08 to {{G_min}}–{{G_max}} and brought the behavioral-to-ngspice transfer loss on a matched grid to {{E2_drop}} {{E2_drop_ci}}, with all gates of an internally frozen protocol met. The improvement comes from the descriptors rather than from randomized training. Absolute layer macro-F1 remains about 0.65 because healthy records, sensor bias and gain faults and inactive clipping faults are structurally hard to observe with the present references. The method should therefore be read as a phase-robust localization aid validated in two closely related simulation domains, not as a hardware-validated fault detector.
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Supplementary Materials:** The following supporting information is provided in the file Phase_Robust_Sensors_Supplementary: Figure S1: Fine-fault confusion matrix of PRr; Table S1: Layer macro-F1 per edge phase for every arm and reference condition; Table S2: AFE/ADC separation for every reference condition; Table S3: Per-class recall of every arm; Table S4: All 70 comparisons of gate B; Table S5: Computational cost and runtime; Table S6: Software environment and evidence files.
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Author Contributions:** AUTHORCONFIRM. 
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Funding:** AUTHORCONFIRM.
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Institutional Review Board Statement:** Not applicable.
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Informed Consent Statement:** Not applicable.
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Data Availability Statement:** The frozen protocol, the per-record predictions of all three validation seeds, the summary results, the figure source data and the scripts that regenerate every figure, table and statistic in this article are included in the supporting material submitted with this article. AUTHORCONFIRM-DAS
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Acknowledgments:** During the preparation of this study and manuscript, the author used Claude Code (Anthropic) for implementing the simulation, descriptor, training and analysis software, drafting the frozen protocols and stage reports, searching and verifying the literature, regenerating figures from saved data, recomputing the statistics and drafting the text. The author has reviewed and edited the output and takes full responsibility for the content of this publication.
:::

::: {custom-style="MDPI_6.2_back_matter"}
**Conflicts of Interest:** AUTHORCONFIRM.
:::

::: {custom-style="MDPI_2.1_heading1"}
Abbreviations
:::

::: {custom-style="MDPI_3.2_text_no_indent"}
The following abbreviations are used in this manuscript:
:::

ABBREVIATIONS

::: {custom-style="MDPI_2.1_heading1"}
References
:::

REFERENCES
