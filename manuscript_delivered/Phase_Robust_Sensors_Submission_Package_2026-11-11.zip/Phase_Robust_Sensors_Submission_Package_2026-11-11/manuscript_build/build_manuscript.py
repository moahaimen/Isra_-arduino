"""Build Phase_Robust_Sensors_Manuscript.docx/.pdf from text_main.md, the recomputed values and the verified references."""
from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path

import docx

sys.path.insert(0, str(Path(__file__).resolve().parent))
import docbuild as B  # noqa: E402
import msnums  # noqa: E402
import refs  # noqa: E402
from msnums import V, f, ci, cmp  # noqa: E402

ROOT = B.ROOT
OUT = ROOT / "manuscript"
FIG_SRC = ROOT / "mdpi_sensors_preparation" / "figures"
FIG_OUT = OUT / "figures"
NAME = "Phase_Robust_Sensors_Manuscript"

COND = [("known", "Known levels"), ("mon0", "Monitor, *E* = 0%"), ("mon1", "Monitor, *E* = ±1%"), ("mon2", "Monitor, *E* = ±2%"),
        ("mon5", "Monitor, *E* = ±5%")]


def t_amp():
    hdr = ["Reference condition", "Bh. ×0.8", "Bh. ×0.9", "Bh. ×1.0", "Bh. ×1.1", "Bh. ×1.2", "ng. ×0.8", "ng. ×1.0", "ng. ×1.2"]
    rows = []
    for v, lab in COND:
        b, s = V[f"amp|bh|PRr|{v}"], V[f"amp|sp|PRr|{v}"]
        rows.append([f"PRr, {lab[0].lower() + lab[1:]}"] + [f(b[str(a)]) for a in (80, 90, 100, 110, 120)] + [f(s[str(a)]) for a in (80, 100, 120)])
    b, s = V["amp|bh|R1|known"], V["amp|sp|R1|known"]
    rows.append(["FS, known levels"] + [f(b[str(a)]) for a in (80, 90, 100, 110, 120)] + [f(s[str(a)]) for a in (80, 100, 120)])
    b = V["amp|bh|A0|known"]
    rows.append(["A0 (earlier descriptors)"] + [f(b[str(a)]) for a in (80, 90, 100, 110, 120)] + ["–"] * 3)
    b = V["amp|bh|nomon"]
    rows.append(["PRr, no monitor (nominal levels assumed)"] + [f(b[str(a)]) for a in (80, 90, 100, 110, 120)] + ["–"] * 3)
    return B.md_table(hdr, rows)


def t_sep():
    hdr = ["Domain", "Reference condition", "AFE recall ×0.8", "ADC recall ×0.8", "κ ×0.8", "AFE recall ×1.2", "ADC recall ×1.2", "κ ×1.2"]
    rows = []
    for dom, dl in (("bh", "Behavioral"), ("sp", "ngspice")):
        for v, lab in (COND[0], COND[3], COND[4]):
            a8, a12 = V[f"AC|{dom}|{v}|80"], V[f"AC|{dom}|{v}|120"]
            rows.append([dl, lab, f(a8["afe"]), f(a8["adc"]), f(a8["cross"]), f(a12["afe"]), f(a12["adc"]), f(a12["cross"])])
    a8, a12 = V["AC|bh|assumed|80"], V["AC|bh|assumed|120"]
    rows.append(["Behavioral", "No monitor (nominal levels assumed)", f(a8["afe"]), f(a8["adc"]), f(a8["cross"]), f(a12["afe"]), f(a12["adc"]), f(a12["cross"])])
    return B.md_table(hdr, rows, ["l", "l"] + ["c"] * 6)


def t_transfer():
    hdr = ["Reference condition", "PRr behavioral", "PRr ngspice", "Loss, layer macro-F1 [95% CI]", "Loss, fault macro-F1 [95% CI]",
           "PRrM ngspice", "PRrM − PRr on ngspice [95% CI]"]
    rows = []
    for v, lab in COND:
        e = V[f"E|{v}"]
        rows.append([lab, f(e["BB"]), f(e["BS"]), cmp(e["drop"]), cmp(e["drop_fault"]), f(e["MS"]), cmp(e["MS_BS"])])
    rows.append(["First version, *E* = ±2% (other seeds)", msnums.N["PREV_bh"], msnums.N["PREV_sp"],
                 f"{msnums.N['PREV_drop']} {msnums.N['PREV_ci']}", "–", "–", "–"])
    return B.md_table(hdr, rows, ["l"] + ["c"] * 6)


ATT = [("PR-R1", "PR − FS: descriptors alone"), ("R1r-R1", "FSr − FS: phase randomization alone"),
       ("PRr-R1r", "PRr − FSr: descriptors, given randomization"), ("PRr-PR", "PRr − PR: randomization, given robust descriptors"),
       ("PRr-R1", "PRr − FS: both ingredients"), ("PRrM-PRr", "PRrM − PRr: mixed-domain training"), ("PRr-A0", "PRr − A0: against earlier descriptors")]


def t_att():
    hdr = ["Comparison", "Layer, behavioral", "Layer, ngspice", "Fault, behavioral", "Fault, ngspice"]
    rows = []
    for k, lab in ATT:
        rows.append([lab, cmp(V[f"att|bh|{k}"]), cmp(V[f"att|sp|{k}"]) if f"att|sp|{k}" in V else "–",
                     cmp(V[f"attfault|bh|{k}"]), cmp(V[f"attfault|sp|{k}"]) if f"attfault|sp|{k}" in V else "–"])
    return B.md_table(hdr, rows)


BASE = [("passive", "Passive (sensor signal only), A0 descriptors"), ("single", "Single additive probe, A0 descriptors"),
        ("afe_only_A0", "AFE-only reference, A0 descriptors"), ("adc_only_A0", "ADC-only reference, A0 descriptors"),
        ("two_point_A0", "Two-point reference, A0 descriptors"), ("afe_only_PRr", "AFE-only reference, PRr descriptors"),
        ("adc_only_PRr", "ADC-only reference, PRr descriptors")]


def t_base():
    hdr = ["Method", "Layer macro-F1 ×0.8", "Layer macro-F1 ×1.2", "PRr − method ×0.8 [95% CI]", "PRr − method ×1.2 [95% CI]"]
    rows = []
    for k, lab in BASE:
        b = V[f"base|{k}"]
        rows.append([lab, f(b["80"]), f(b["120"]), cmp(V[f"B|known|80|{k}"]), cmp(V[f"B|known|120|{k}"])])
    for k, lab in (("R1", "Two-point, FS descriptors"), ("R1r", "Two-point, FSr"), ("PR", "Two-point, PR"),
                   ("PRr", "Two-point, PRr (primary)"), ("PRrM", "Two-point, PRrM (secondary)")):
        b = V[f"base|{k}"]
        rows.append([lab, f(b["80"]), f(b["120"]), "–", "–"])
    return B.md_table(hdr, rows)


def t_recall():
    names = ["Healthy", "Sensor bias", "Sensor gain", "Sensor noise", "AFE offset", "AFE bandwidth", "ADC offset", "ADC gain", "ADC clipping"]
    layers = ["Healthy layer", "Sensor layer", "AFE layer", "ADC layer"]
    cols = [("bh", "PRr"), ("sp", "PRr"), ("bh", "PRrM"), ("sp", "PRrM"), ("bh", "R1")]
    hdr = ["Class", "PRr behavioral", "PRr ngspice", "PRrM behavioral", "PRrM ngspice", "FS behavioral"]
    rows = []
    for i, n in enumerate(names):
        rows.append([n] + [f(V[f"arm|{d}|{a}"]["fault_recall"][i]) for d, a in cols])
    for i, n in enumerate(layers):
        rows.append([n] + [f(V[f"arm|{d}|{a}"]["layer_recall"][i]) for d, a in cols])
    return B.md_table(hdr, rows)


ABBR = [("A0", "Descriptor set of the stage before the reference revision"), ("ADC", "Analog-to-digital converter"),
        ("AFE", "Analog front-end"), ("BIST", "Built-in self-test"), ("CI", "Confidence interval"),
        ("FS", "Fixed-sample descriptor set (rise fractions read at fixed samples after the step)"), ("FSr", "FS with phase-randomized training"),
        ("MEMS", "Micro-electro-mechanical system"), ("MLP", "Multilayer perceptron"), ("MUX", "Multiplexer"),
        ("PR", "Phase-robust descriptors, trained at ψ = 0"), ("PRr", "Phase-robust descriptors with phase-randomized training (primary method)"),
        ("PRrM", "PRr with mixed behavioral and ngspice training (secondary variant)"), ("R1, R2", "Two-level references at the AFE input and at the ADC input"), ("RMS", "Root mean square"), ("RSS", "Residual sum of squares"),
        ("SAR", "Successive-approximation register"), ("SEIR", "Stimulus error identification and removal")]

CONFIRM = {
    "**Author Contributions:** AUTHORCONFIRM.": "**Author Contributions:** ⟦To be completed by the author(s) using the CRediT roles.⟧",
    "**Funding:** AUTHORCONFIRM.": "**Funding:** ⟦To be completed by the author(s).⟧",
    "**Conflicts of Interest:** AUTHORCONFIRM.": "**Conflicts of Interest:** ⟦To be completed by the author(s).⟧",
    "AUTHORCONFIRM-DAS": "⟦Repository name and persistent identifier, if the material is also deposited publicly, to be added by the author(s).⟧",
}
AFFIL = ("::: {custom-style=\"MDPI_1.6_affiliation\"}\n⟦Affiliation, postal address and corresponding-author e-mail to be confirmed by the author(s).⟧\n:::\n")


def build_md():
    s = (ROOT / "manuscript_build" / "text_main.md").read_text(encoding="utf-8")
    s = B.fill_tokens(s)
    for k, fn in (("amp", t_amp), ("sep", t_sep), ("transfer", t_transfer), ("att", t_att), ("base", t_base), ("recall", t_recall)):
        s = s.replace(f"TABLE:{k}", fn())
    for a, b in CONFIRM.items():
        assert a in s, a
        s = s.replace(a, b)
    assert "AUTHORCONFIRM" not in s
    s = s.replace(":::\n\n::: {custom-style=\"MDPI_1.7_abstract\"}", ":::\n\n" + AFFIL + "\n::: {custom-style=\"MDPI_1.7_abstract\"}", 1)
    s = re.sub(r"FIG:(Fig\d\d_[a-z_]+)", lambda m: f"{m.group(1)}.png", s)  # file names only; pandoc resolves them via --resource-path
    s, eqn = B.number_equations(s)
    s, order = B.number_citations(s)
    abbr = "\n".join(f"::: {{custom-style=\"MDPI_3.2_text_no_indent\"}}\n{a} {b}\n:::\n" for a, b in ABBR)
    s = s.replace("ABBREVIATIONS", abbr)
    reflist = "\n".join(f"::: {{custom-style=\"MDPI_8.1_references\"}}\n{refs.mdpi(k)}\n:::\n" for k in order)
    s = s.replace("REFERENCES", reflist)
    return s, order, eqn


def abstract_words(md):
    m = re.search(r"\*\*Abstract:\*\* (.*?)\n:::", md, re.S)
    return len(m.group(1).split())


def postprocess(path: Path):
    d = docx.Document(str(path))
    n_eq = B.build_equation_tables(d)
    tabs = B.tables_in_order(d)
    narrow = {1, 4}  # Tables 2 and 5 (0-based 1, 4) fit the text column? decided below by column count
    for i, t in enumerate(tabs):
        ncol = len(t.columns)
        B.format_table(t, font_pt=8.5 if ncol >= 6 else 9.0, narrow=ncol <= 2)
    n_hl = B.highlight_markers(d)
    B.keep_captions(d)
    d.save(str(path))
    return n_eq, len(tabs), n_hl


def main():
    OUT.mkdir(exist_ok=True)
    FIG_OUT.mkdir(exist_ok=True)
    for p in sorted(FIG_SRC.glob("Fig*")):
        shutil.copy(p, FIG_OUT / p.name)
    md, order, eqn = build_md()
    print("abstract words:", abstract_words(md), "| references:", len(order), "| equations:", len(eqn))
    docx_path = OUT / f"{NAME}.docx"
    tmp_md = B.run_pandoc(md, docx_path, FIG_OUT)
    shutil.move(tmp_md, ROOT / "manuscript_build" / f"{NAME}.generated.md")
    n_eq, n_tab, n_hl = postprocess(docx_path)
    print("equation tables:", n_eq, "| tables:", n_tab, "| highlighted author items:", n_hl)
    (ROOT / "manuscript_build" / "citation_order.json").write_text(json.dumps(order, indent=1))
    import rounding
    ties = sorted(set(rounding.TIES))
    (ROOT / "analysis" / "ties_formatted_manuscript.txt").write_text(
        "Exact decimal ties met while formatting manuscript numbers (rounded half to even):\n" +
        "\n".join(f"{v} -> {rounding.round_str(float(v), d)} ({d} decimals)" for v, d in ties) + "\n")
    print("exact ties formatted:", ties)
    engine = B.pdf_engine_from_argv(sys.argv)
    if engine:
        try:
            B.export_pdf(docx_path, OUT / f"{NAME}.pdf", engine)
            print(f"pdf written ({engine})")
        except B.PdfExportError as exc:
            print("PDF NOT WRITTEN:", exc)
            sys.exit(3)


if __name__ == "__main__":
    main()
